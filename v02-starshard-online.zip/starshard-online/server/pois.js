// 월드의 주요 지점(별조각, 귀환석, 야영지, 상자, 몬스터 출현 지점 등)을 seed 로부터 생성한다.
import { W, BIOME, BIOME_INFO, VILLAGE, VOLCANO } from '../shared/world.js';
import { rand2 } from '../shared/noise.js';
import { GOLEM_NAMES, NPC_DEFS } from '../shared/defs.js';

export function generatePOIs(world) {
  const seed = world.seed;
  const N = W.VERTS;
  const H = world.heights;
  const patches = [];

  const vx = (i) => -W.HALF + i * W.CELL;

  function rough(i, j, k) {
    const h0 = H[j * N + i];
    let m = 0;
    for (let dj = -k; dj <= k; dj++) {
      for (let di = -k; di <= k; di++) {
        const ii = i + di;
        const jj = j + dj;
        if (ii < 0 || jj < 0 || ii > W.GRID || jj > W.GRID) return 99;
        const d = Math.abs(H[jj * N + ii] - h0);
        if (d > m) m = d;
      }
    }
    return m;
  }

  // 기준점 주변에서 조건에 맞는 격자점을 찾는다. mode: 'high' | 'flat'
  function findSpot(ax, az, radius, mode, minH = 2) {
    const i0 = Math.max(3, Math.floor((ax - radius + W.HALF) / W.CELL));
    const i1 = Math.min(W.GRID - 3, Math.ceil((ax + radius + W.HALF) / W.CELL));
    const j0 = Math.max(3, Math.floor((az - radius + W.HALF) / W.CELL));
    const j1 = Math.min(W.GRID - 3, Math.ceil((az + radius + W.HALF) / W.CELL));
    let best = null;
    let bestScore = -1e9;
    for (let j = j0; j <= j1; j++) {
      for (let i = i0; i <= i1; i++) {
        const x = vx(i);
        const z = vx(j);
        const dx = x - ax;
        const dz = z - az;
        const d = Math.sqrt(dx * dx + dz * dz);
        if (d > radius) continue;
        const h = H[j * N + i];
        if (h < minH) continue;
        let score;
        if (mode === 'high') score = h - d * 0.01;
        else score = -rough(i, j, 2) * 2 - d * 0.02;
        if (score > bestScore) {
          bestScore = score;
          best = { x, z, h, rough: rough(i, j, 2) };
        }
      }
    }
    return best;
  }

  // 특정 바이옴 안쪽(경계에서 떨어진 곳)에서 가장 높은 지점
  function highestInBiome(b) {
    let best = null;
    for (let j = 4; j < W.GRID - 4; j++) {
      for (let i = 4; i < W.GRID - 4; i++) {
        const idx = j * N + i;
        if (world.biome[idx] !== b) continue;
        if (world.biome[idx - 3] !== b || world.biome[idx + 3] !== b || world.biome[idx - 3 * N] !== b || world.biome[idx + 3 * N] !== b) continue;
        const h = H[idx];
        if (!best || h > best.h) best = { x: vx(i), z: vx(j), h, rough: rough(i, j, 2) };
      }
    }
    return best;
  }

  function flatten(x, z, r, f, h) {
    patches.push({ x, z, r, f, h: Math.round(h * 100) / 100 });
  }

  // ---- 마을 & 보스 경기장 ----
  flatten(VILLAGE.x, VILLAGE.z, VILLAGE.r, 24, VILLAGE.h);
  flatten(VOLCANO.x, VOLCANO.z, VOLCANO.arenaR, 4, VOLCANO.floor);

  // ---- 별조각 12개 ----
  const shardDefs = [
    { name: '바람 언덕', ax: -120, az: -110, r: 70, mode: 'high', guard: 'none' },
    { name: '호숫가 도깨비 소굴', ax: 165, az: 150, r: 60, mode: 'flat', guard: 'camp', comp: ['goblin', 'goblin', 'goblin', 'thrower'], elite: 'goblin' },
    { name: '깊은 숲의 제단', ax: 600, az: 90, r: 70, mode: 'flat', guard: 'golem' },
    { name: '늑대 언덕', ax: -560, az: -100, r: 70, mode: 'flat', guard: 'camp', comp: ['wolf', 'wolf', 'wolf'], elite: 'wolf' },
    { name: '붉은 탁상지', ax: 120, az: 540, r: 150, mode: 'high', biomeHigh: BIOME.DESERT, guard: 'none' },
    { name: '모래에 묻힌 유적', ax: -70, az: 560, r: 70, mode: 'flat', guard: 'golem' },
    { name: '늪의 심장', ax: -470, az: 330, r: 80, mode: 'flat', guard: 'golem' },
    { name: '말랑이 둥지', ax: -330, az: 470, r: 70, mode: 'flat', guard: 'camp', comp: ['slime', 'slime', 'slime', 'slime'], elite: 'slime' },
    { name: '서리봉 정상', ax: -140, az: -480, r: 260, mode: 'high', guard: 'none' },
    { name: '설인의 야영지', ax: -330, az: -420, r: 80, mode: 'flat', guard: 'camp', comp: ['yeti', 'wolf', 'wolf'], elite: 'yeti' },
    { name: '분화구 가장자리', ax: VOLCANO.x, az: VOLCANO.z, r: 66, mode: 'high', guard: 'camp', comp: ['imp', 'imp', 'imp'], elite: 'imp' },
    { name: '잿더미 제단', ax: 290, az: -250, r: 60, mode: 'flat', guard: 'golem' },
  ];

  const shards = [];
  const spawns = [];
  const camps = [];
  const chests = [];

  function addSpawn(type, level, x, z, extra = {}) {
    const s = { id: spawns.length, type, level, x: Math.round(x * 10) / 10, z: Math.round(z * 10) / 10, biome: world.biomeAt(x, z), shard: -1, camp: -1, elite: 0, ...extra };
    spawns.push(s);
    return s;
  }

  // 중심 주변 원형으로 배치 (sin/cos 없이 고정 방향 테이블 사용)
  const RING = [
    [1, 0], [0.7071, 0.7071], [0, 1], [-0.7071, 0.7071], [-1, 0], [-0.7071, -0.7071], [0, -1], [0.7071, -0.7071],
    [0.9239, 0.3827], [0.3827, 0.9239], [-0.3827, 0.9239], [-0.9239, 0.3827], [-0.9239, -0.3827], [-0.3827, -0.9239], [0.3827, -0.9239], [0.9239, -0.3827],
  ];

  shardDefs.forEach((d, id) => {
    const spot = (d.biomeHigh !== undefined ? highestInBiome(d.biomeHigh) : null) || findSpot(d.ax, d.az, d.r, d.mode, d.mode === 'flat' ? 2.2 : 2) || { x: d.ax, z: d.az, h: 5 };
    const b = world.biomeAt(spot.x, spot.z);
    const lvl = BIOME_INFO[b].level + 1;
    flatten(spot.x, spot.z, d.mode === 'high' ? 6 : 12, d.mode === 'high' ? 8 : 9, spot.h);
    shards.push({ id, name: d.name, x: spot.x, z: spot.z, guard: d.guard, biome: b });
    if (d.guard === 'golem') {
      addSpawn('golem', lvl, spot.x + 6, spot.z + 3, { shard: id, name: GOLEM_NAMES[b] });
    } else if (d.guard === 'camp') {
      d.comp.forEach((type, k) => {
        const dir = RING[(k * 3 + id) % 8];
        addSpawn(type, lvl, spot.x + dir[0] * 7.5, spot.z + dir[1] * 7.5, { shard: id });
      });
      const dir = RING[(id + 5) % 8];
      addSpawn(d.elite, lvl, spot.x + dir[0] * 5, spot.z + dir[1] * 5, { shard: id, elite: 1 });
    }
    chests.push({ id: chests.length, x: spot.x - 3.5, z: spot.z + 3.2, tier: Math.min(4, 1 + Math.floor(lvl / 3)), kind: 'shrine' });
  });

  // ---- 귀환석 (빠른 이동) ----
  const stoneDefs = [
    { name: '새벽 마을', ax: 9, az: -15, fixed: true },
    { name: '속삭임 숲', ax: 370, az: 110 },
    { name: '황금 사막', ax: 30, az: 330 },
    { name: '안개 늪', ax: -320, az: 240 },
    { name: '서리봉 기슭', ax: -130, az: -290 },
    { name: '화산 협곡 입구', ax: VOLCANO.x + VOLCANO.notchX * 142, az: VOLCANO.z + VOLCANO.notchZ * 142 },
    { name: '단풍 고원', ax: -420, az: -90 },
  ];
  const stones = [];
  stoneDefs.forEach((d, id) => {
    let spot;
    if (d.fixed) spot = { x: d.ax, z: d.az, h: VILLAGE.h };
    else {
      spot = findSpot(d.ax, d.az, 36, 'flat', 2.5) || { x: d.ax, z: d.az, h: 6 };
      flatten(spot.x, spot.z, 5, 7, spot.h);
    }
    stones.push({ id, name: d.name, x: spot.x, z: spot.z });
  });

  const far = (x, z, list, dist) => {
    for (const o of list) {
      const dx = x - o.x;
      const dz = z - o.z;
      if (dx * dx + dz * dz < dist * dist) return false;
    }
    return true;
  };
  const distVillage = (x, z) => Math.sqrt((x - VILLAGE.x) * (x - VILLAGE.x) + (z - VILLAGE.z) * (z - VILLAGE.z));
  const distVolcano = (x, z) => Math.sqrt((x - VOLCANO.x) * (x - VOLCANO.x) + (z - VOLCANO.z) * (z - VOLCANO.z));

  // ---- 일반 야영지 ----
  const CAMP_COMP = [
    ['goblin', 'goblin', 'goblin', 'thrower'],
    ['goblin', 'goblin', 'goblin', 'thrower', 'thrower'],
    ['yeti', 'wolf', 'wolf', 'wolf'],
    ['goblin', 'goblin', 'scorpion', 'scorpion', 'thrower'],
    ['goblin', 'goblin', 'thrower', 'thrower', 'slime', 'slime'],
    ['imp', 'imp', 'imp', 'imp'],
    ['goblin', 'goblin', 'wolf', 'wolf', 'thrower'],
  ];
  const CSTEP = 150;
  for (let gz = 0; gz < 11; gz++) {
    for (let gx = 0; gx < 11; gx++) {
      if (rand2(gx, gz, seed + 301) > 0.6) continue;
      const ax = -W.HALF + (gx + 0.2 + 0.6 * rand2(gx, gz, seed + 302)) * CSTEP - 25;
      const az = -W.HALF + (gz + 0.2 + 0.6 * rand2(gx, gz, seed + 303)) * CSTEP - 25;
      const spot = findSpot(ax, az, 34, 'flat', 2.5);
      if (!spot || spot.rough > 3.2) continue;
      if (distVillage(spot.x, spot.z) < 170) continue;
      if (distVolcano(spot.x, spot.z) < 75) continue;
      if (!far(spot.x, spot.z, shards, 90) || !far(spot.x, spot.z, stones, 60) || !far(spot.x, spot.z, camps, 150)) continue;
      const b = world.biomeAt(spot.x, spot.z);
      const lvl = BIOME_INFO[b].level;
      const id = camps.length;
      flatten(spot.x, spot.z, 8, 8, spot.h);
      camps.push({ id, x: spot.x, z: spot.z, biome: b });
      CAMP_COMP[b].forEach((type, k) => {
        const dir = RING[(k * 2 + id * 3) % 16];
        addSpawn(type, lvl, spot.x + dir[0] * 6.5, spot.z + dir[1] * 6.5, { camp: id });
      });
      chests.push({ id: chests.length, x: spot.x + 2.8, z: spot.z - 2.4, tier: Math.min(4, 1 + Math.floor(lvl / 3)), kind: 'camp' });
    }
  }

  // ---- 들판의 보물상자 ----
  const XSTEP = 100;
  for (let gz = 0; gz < 16; gz++) {
    for (let gx = 0; gx < 16; gx++) {
      if (rand2(gx, gz, seed + 311) > 0.36) continue;
      const x = -W.HALF + (gx + 0.1 + 0.8 * rand2(gx, gz, seed + 312)) * XSTEP;
      const z = -W.HALF + (gz + 0.1 + 0.8 * rand2(gx, gz, seed + 313)) * XSTEP;
      const h = world.heightAt(x, z);
      if (h < 1.3 || world.slopeAt(x, z) > 0.45) continue;
      if (distVillage(x, z) < 110 || distVolcano(x, z) < 60) continue;
      if (!far(x, z, shards, 25) || !far(x, z, stones, 15) || !far(x, z, camps, 25)) continue;
      const lvl = BIOME_INFO[world.biomeAt(x, z)].level;
      chests.push({ id: chests.length, x: Math.round(x * 10) / 10, z: Math.round(z * 10) / 10, tier: Math.min(4, 1 + Math.floor(lvl / 3)), kind: 'wild' });
    }
  }

  // ---- 회복 열매 덤불 ----
  const bushes = [];
  const BSTEP = 52;
  const BG = Math.floor(W.SIZE / BSTEP);
  for (let gz = 0; gz < BG; gz++) {
    for (let gx = 0; gx < BG; gx++) {
      if (rand2(gx, gz, seed + 321) > 0.34) continue;
      const x = -W.HALF + (gx + 0.1 + 0.8 * rand2(gx, gz, seed + 322)) * BSTEP;
      const z = -W.HALF + (gz + 0.1 + 0.8 * rand2(gx, gz, seed + 323)) * BSTEP;
      const h = world.heightAt(x, z);
      if (h < 1.2 || world.slopeAt(x, z) > 0.5) continue;
      const b = world.biomeAt(x, z);
      if (b === BIOME.VOLCANO || b === BIOME.SNOW) {
        if (rand2(gx, gz, seed + 324) > 0.3) continue;
      }
      if (distVillage(x, z) < 50) continue;
      if (!far(x, z, shards, 10) || !far(x, z, stones, 6) || !far(x, z, camps, 10)) continue;
      bushes.push({ id: bushes.length, x: Math.round(x * 10) / 10, z: Math.round(z * 10) / 10 });
    }
  }

  // ---- 들판의 몬스터 ----
  const TABLE = {
    [BIOME.MEADOW]: [['slime', 0.62, 1, 3], ['goblin', 0.28, 1, 2], ['thrower', 0.1, 1, 1]],
    [BIOME.FOREST]: [['wolf', 0.38, 2, 3], ['goblin', 0.3, 1, 2], ['thrower', 0.14, 1, 1], ['slime', 0.18, 2, 3]],
    [BIOME.AUTUMN]: [['wolf', 0.36, 2, 3], ['goblin', 0.36, 1, 3], ['thrower', 0.14, 1, 2], ['slime', 0.14, 2, 3]],
    [BIOME.DESERT]: [['scorpion', 0.52, 1, 2], ['goblin', 0.26, 1, 2], ['thrower', 0.22, 1, 2]],
    [BIOME.SWAMP]: [['slime', 0.5, 2, 4], ['thrower', 0.2, 1, 2], ['goblin', 0.3, 1, 2]],
    [BIOME.SNOW]: [['wolf', 0.45, 2, 3], ['yeti', 0.25, 1, 1], ['slime', 0.3, 2, 3]],
    [BIOME.VOLCANO]: [['imp', 0.5, 1, 2], ['slime', 0.3, 2, 3], ['goblin', 0.2, 1, 2]],
  };
  const SSTEP = 56;
  const SG = Math.floor(W.SIZE / SSTEP);
  for (let gz = 0; gz < SG; gz++) {
    for (let gx = 0; gx < SG; gx++) {
      if (rand2(gx, gz, seed + 331) > 0.5) continue;
      const x = -W.HALF + (gx + 0.15 + 0.7 * rand2(gx, gz, seed + 332)) * SSTEP;
      const z = -W.HALF + (gz + 0.15 + 0.7 * rand2(gx, gz, seed + 333)) * SSTEP;
      const h = world.heightAt(x, z);
      const b = world.biomeAt(x, z);
      if (h < (b === BIOME.SWAMP ? 0.5 : 1.2) || world.slopeAt(x, z) > 0.6) continue;
      const dv = distVillage(x, z);
      if (dv < 100 || distVolcano(x, z) < 62) continue;
      if (!far(x, z, shards, 34) || !far(x, z, stones, 30) || !far(x, z, camps, 36)) continue;
      const table = TABLE[b];
      let pick = rand2(gx, gz, seed + 334);
      let entry = table[0];
      for (const e of table) {
        if (pick < e[1]) { entry = e; break; }
        pick -= e[1];
      }
      let type = entry[0];
      let lvl = BIOME_INFO[b].level + (rand2(gx, gz, seed + 335) < 0.35 ? 1 : 0);
      if (b === BIOME.MEADOW && dv < 230) { type = 'slime'; lvl = 1; }
      const cnt = entry[2] + Math.floor(rand2(gx, gz, seed + 336) * (entry[3] - entry[2] + 1));
      for (let k = 0; k < cnt; k++) {
        const dir = RING[(k * 5 + gx + gz * 3) % 16];
        const rr = k === 0 ? 0 : 3.2;
        const sx = x + dir[0] * rr;
        const sz = z + dir[1] * rr;
        if (world.heightAt(sx, sz) < 0.5) continue;
        addSpawn(type, lvl, sx, sz);
      }
    }
  }

  // ---- NPC ----
  const npcs = [];
  for (const kind of Object.keys(NPC_DEFS)) {
    const d = NPC_DEFS[kind];
    npcs.push({ id: npcs.length, kind, name: d.name, x: VILLAGE.x + d.x, z: VILLAGE.z + d.z, yaw: d.yaw });
  }
  // 각 귀환석 옆의 길잡이
  const GUIDE_NAMES = ['', '나무꾼 솔', '상인 모래', '약초꾼 이끼', '산지기 눈솔', '탐험가 불씨', '사냥꾼 단풍'];
  for (let i = 1; i < stones.length; i++) {
    npcs.push({ id: npcs.length, kind: 'guide', name: GUIDE_NAMES[i], x: stones[i].x + 3.2, z: stones[i].z + 1.5, yaw: 4.2, stone: i });
  }

  // 보스와 소환수 (평소에는 잠들어 있다)
  const boss = addSpawn('lord', 14, VOLCANO.x, VOLCANO.z - 8, { boss: 1 });
  const minions = [];
  for (let k = 0; k < 6; k++) {
    const dir = RING[(k * 3) % 16];
    minions.push(addSpawn(k % 2 ? 'imp' : 'slime', 12, VOLCANO.x + dir[0] * 14, VOLCANO.z + dir[1] * 14, { minion: 1 }).id);
  }

  return {
    village: { x: VILLAGE.x, z: VILLAGE.z },
    arena: { x: VOLCANO.x, z: VOLCANO.z, r: VOLCANO.arenaR },
    patches,
    shards,
    stones,
    camps,
    chests,
    bushes,
    spawns,
    npcs,
    bossId: boss.id,
    minionIds: minions,
  };
}

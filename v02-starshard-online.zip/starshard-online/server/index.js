// 별조각 원정대 서버: 정적 파일 제공 + WebSocket 멀티플레이
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';
import { WebSocketServer } from 'ws';
import { Game } from './game.js';
import { TICK_MS, DEFAULT_SEED, MAX_PLAYERS } from '../shared/defs.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PORT = Number(process.env.PORT) || 3000;
const SEED = Number(process.env.WORLD_SEED) || DEFAULT_SEED;
const SAVE_PATH = process.env.SAVE_PATH || path.join(ROOT, 'data', 'world.json');

const game = new Game({ seed: SEED, savePath: SAVE_PATH });

// ---------- 정적 파일 ----------
const MOUNTS = [
  { prefix: '/vendor/three/', dir: path.join(ROOT, 'node_modules', 'three', 'build'), allow: new Set(['three.module.js', 'three.core.js']), cache: 'public, max-age=604800' },
  { prefix: '/shared/', dir: path.join(ROOT, 'shared'), cache: 'no-cache' },
  { prefix: '/', dir: path.join(ROOT, 'public'), cache: 'no-cache' },
];
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};
const COMPRESSIBLE = new Set(['.html', '.js', '.css', '.json', '.svg', '.webmanifest', '.txt']);
const fileCache = new Map();

function loadFile(file) {
  let st;
  try {
    st = fs.statSync(file);
  } catch {
    return null;
  }
  if (!st.isFile()) return null;
  const tag = `"${st.size.toString(36)}-${Math.floor(st.mtimeMs).toString(36)}"`;
  let e = fileCache.get(file);
  if (e && e.tag === tag) return e;
  const ext = path.extname(file).toLowerCase();
  e = { tag, ext, type: TYPES[ext] || 'application/octet-stream', raw: fs.readFileSync(file), br: null, gz: null };
  fileCache.set(file, e);
  return e;
}

// 링크 미리보기(카카오톡 등)는 절대 주소가 필요해서, HTML 안의 __ORIGIN__ 을 접속한 주소로 바꿔 준다.
const originCache = new Map();
function withOrigin(e, req) {
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || 'localhost').replace(/[^a-zA-Z0-9.:\-\[\]]/g, '').slice(0, 100);
  const proto = String(req.headers['x-forwarded-proto'] || 'http').split(',')[0].trim() === 'https' ? 'https' : 'http';
  const key = `${e.tag}|${proto}://${host}`;
  let v = originCache.get(key);
  if (!v) {
    if (originCache.size > 20) originCache.clear();
    const raw = Buffer.from(e.raw.toString('utf8').replaceAll('__ORIGIN__', `${proto}://${host}`), 'utf8');
    v = { tag: `"${e.tag.slice(1, -1)}-${host.length.toString(36)}${proto.length}"`, ext: e.ext, type: e.type, raw, br: null, gz: null };
    originCache.set(key, v);
  }
  return v;
}

function serveStatic(req, res) {
  let pathname;
  try {
    pathname = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  } catch {
    res.writeHead(400).end();
    return;
  }
  if (pathname === '/') pathname = '/index.html';
  for (const m of MOUNTS) {
    if (!pathname.startsWith(m.prefix)) continue;
    const rel = pathname.slice(m.prefix.length);
    if (m.allow && !m.allow.has(rel)) continue;
    const file = path.normalize(path.join(m.dir, rel));
    if (!file.startsWith(m.dir + path.sep)) break;
    let e = loadFile(file);
    if (!e) continue;
    if (e.ext === '.html') e = withOrigin(e, req);
    const headers = { 'Content-Type': e.type, 'Cache-Control': m.cache, ETag: e.tag, 'X-Content-Type-Options': 'nosniff' };
    if (req.headers['if-none-match'] === e.tag) {
      res.writeHead(304, headers).end();
      return;
    }
    let body = e.raw;
    if (COMPRESSIBLE.has(e.ext) && e.raw.length > 1024) {
      const ae = String(req.headers['accept-encoding'] || '');
      headers.Vary = 'Accept-Encoding';
      if (/\bbr\b/.test(ae)) {
        if (!e.br) e.br = zlib.brotliCompressSync(e.raw, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 5 } });
        body = e.br;
        headers['Content-Encoding'] = 'br';
      } else if (/\bgzip\b/.test(ae)) {
        if (!e.gz) e.gz = zlib.gzipSync(e.raw, { level: 6 });
        body = e.gz;
        headers['Content-Encoding'] = 'gzip';
      }
    }
    headers['Content-Length'] = body.length;
    res.writeHead(200, headers);
    res.end(req.method === 'HEAD' ? undefined : body);
    return;
  }
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('404 - 찾을 수 없습니다');
}

// 정적 월드 데이터 (지형 패치, 별조각·몬스터 위치 등). 서버가 켜져 있는 동안 변하지 않는다.
const worldRaw = Buffer.from(game.staticJson, 'utf8');
const worldTag = `"w${game.seed}-${worldRaw.length.toString(36)}"`;
let worldBr = null;
let worldGz = null;
function sendWorld(req, res) {
  const headers = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-cache', ETag: worldTag, Vary: 'Accept-Encoding' };
  if (req.headers['if-none-match'] === worldTag) {
    res.writeHead(304, headers).end();
    return;
  }
  const ae = String(req.headers['accept-encoding'] || '');
  let body = worldRaw;
  if (/\bbr\b/.test(ae)) {
    if (!worldBr) worldBr = zlib.brotliCompressSync(worldRaw, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 5 } });
    body = worldBr;
    headers['Content-Encoding'] = 'br';
  } else if (/\bgzip\b/.test(ae)) {
    if (!worldGz) worldGz = zlib.gzipSync(worldRaw);
    body = worldGz;
    headers['Content-Encoding'] = 'gzip';
  }
  headers['Content-Length'] = body.length;
  res.writeHead(200, headers);
  res.end(req.method === 'HEAD' ? undefined : body);
}

const server = http.createServer((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405).end();
    return;
  }
  if (req.url === '/healthz') {
    res.writeHead(200, { 'Content-Type': 'text/plain' }).end('ok');
    return;
  }
  if (req.url === '/world') {
    sendWorld(req, res);
    return;
  }
  if (req.url === '/status') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }).end(JSON.stringify({ ...game.status(), tickAvgMs: +perf.avgMs.toFixed(3), tickMaxMs: +perf.maxMs.toFixed(2), uptimeSec: Math.round(process.uptime()), memMB: Math.round(process.memoryUsage().rss / 1048576) }));
    return;
  }
  serveStatic(req, res);
});

// ---------- WebSocket ----------
const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 8 * 1024, perMessageDeflate: false });

wss.on('connection', (ws) => {
  const p = game.addPlayer(ws);
  if (!p) {
    ws.send(JSON.stringify({ t: 'full', max: MAX_PLAYERS }));
    ws.close(1013, 'full');
    return;
  }
  ws.isAlive = true;
  ws.on('pong', () => {
    ws.isAlive = true;
  });
  ws.on('message', (data, isBinary) => {
    const now = Date.now();
    p.lastMsg = now;
    // 간단한 도배 방지: 초당 80개 초과 시 연결 종료
    if (now - p.msgWindow > 1000) {
      p.msgWindow = now;
      p.msgCount = 0;
    }
    if (++p.msgCount > 80) {
      ws.terminate();
      return;
    }
    try {
      if (isBinary) game.onBinary(p, data);
      else {
        const msg = JSON.parse(data.toString('utf8'));
        if (msg && typeof msg === 'object' && typeof msg.t === 'string') game.onMessage(p, msg);
      }
    } catch (err) {
      console.error('[ws] 메시지 처리 오류:', err.message);
    }
  });
  ws.on('close', () => game.removePlayer(p));
  ws.on('error', () => game.removePlayer(p));
});

// 죽은 연결 정리
setInterval(() => {
  const now = Date.now();
  for (const ws of wss.clients) {
    if (ws.isAlive === false) {
      ws.terminate();
      continue;
    }
    ws.isAlive = false;
    try {
      ws.ping();
    } catch {
      /* 무시 */
    }
  }
  for (const p of game.players.values()) {
    if (now - p.lastMsg > 45000) p.ws.terminate();
  }
}, 20000);

// 게임 루프
let last = Date.now();
const perf = { avgMs: 0, maxMs: 0 };
setInterval(() => {
  const t0 = performance.now();
  try {
    game.tick();
  } catch (err) {
    console.error('[tick] 오류:', err);
  }
  const spent = performance.now() - t0;
  perf.avgMs += (spent - perf.avgMs) * 0.02;
  if (spent > perf.maxMs) perf.maxMs = spent;
  const now = Date.now();
  if (spent > 80 && now - last > 5000) {
    last = now;
    console.warn(`[tick] 느린 틱: ${spent.toFixed(0)}ms`);
  }
}, TICK_MS);

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[server] 별조각 원정대 서버 시작: http://localhost:${PORT}`);
});

function shutdown() {
  console.log('[server] 종료 중…');
  game.persist();
  for (const ws of wss.clients) {
    try {
      ws.send(JSON.stringify({ t: 'bye' }));
      ws.close(1001, 'restart');
    } catch {
      /* 무시 */
    }
  }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 1500).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// 렌더러, 조명, 하늘, 물, 구름, 재질 등 화면의 기본 요소
import * as THREE from '/vendor/three/three.module.js';
import { Geo, M } from './geo.js';
import { env, flags, patchMaterial, installToneMapping, makeNoiseTexture, ATMO_PARS } from './shade.js';
import { Post, probeGraphics } from './post.js';

export const QUALITY = {
  low: { label: '낮음', pr: 1.0, maxPixels: 2.1e6, lite: true, aniso: 1, post: false, msaa: 0, bloomLevels: 0, shadows: 0, shadowR: 0, fogFar: 420, propRange: 210, grass: 0, grassR: 0, lights: 0, ambient: 0.4 },
  medium: { label: '보통', pr: 1.5, maxPixels: 2.4e6, lite: false, aniso: 2, post: true, msaa: 2, bloomLevels: 4, shadows: 1024, shadowR: 38, fogFar: 600, propRange: 320, grass: 3200, grassR: 27, lights: 2, ambient: 0.7 },
  high: { label: '높음', pr: 2.0, maxPixels: 4.6e6, lite: false, aniso: 4, post: true, msaa: 4, bloomLevels: 5, shadows: 2048, shadowR: 66, fogFar: 780, propRange: 480, grass: 13000, grassR: 46, lights: 3, ambient: 1 },
};

const C = (hex) => new THREE.Color(hex);
const SKY = {
  dayTop: C(0x2674df), dayHor: C(0xc4e2fb),
  duskTop: C(0x3d3f86), duskHor: C(0xf7a878),
  nightTop: C(0x03061a), nightHor: C(0x131d38),
  sunDay: C(0xfff1d6), sunDusk: C(0xff8f48), moon: C(0x8fa8ff),
  fogSunDay: C(0xfff3dc), fogSunDusk: C(0xff9648), fogSunNight: C(0x2c3a66),
  hemiSkyDay: C(0xd4ecff), hemiGroundDay: C(0x93a070),
  hemiSkyNight: C(0x4a62ad), hemiGroundNight: C(0x232d4a),
};

// 지역별 분위기: 안개 농도, 안개 색조, 화면 색 보정 (초원, 숲, 설산, 사막, 늪, 화산, 단풍)
const MOOD = [
  { fog: 1.0, tint: [1, 1, 1], grade: [1, 1, 1] },
  { fog: 1.25, tint: [0.86, 1.0, 0.9], grade: [0.97, 1.02, 0.97] },
  { fog: 1.35, tint: [1.08, 1.08, 1.08], grade: [0.96, 1.0, 1.05] },
  { fog: 1.1, tint: [1.15, 1.02, 0.8], grade: [1.04, 1.0, 0.93] },
  { fog: 2.0, tint: [0.72, 0.9, 0.68], grade: [0.95, 1.02, 0.92] },
  { fog: 1.6, tint: [0.78, 0.55, 0.5], grade: [1.06, 0.97, 0.92] },
  { fog: 1.05, tint: [1.1, 1.0, 0.86], grade: [1.04, 1.0, 0.95] },
];

function smooth(e0, e1, x) {
  let t = (x - e0) / (e1 - e0);
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return t * t * (3 - 2 * t);
}

// ---------- 지형 셰이더 조각 ----------
const TERRAIN_VERT_PARS = /* glsl */ `
attribute vec3 rock;
attribute vec4 tmat;
varying vec3 vRock;
varying vec4 vMat;
varying vec3 vWNormal;
`;
const TERRAIN_VERT = /* glsl */ `
vRock = rock;
vMat = tmat;
vWNormal = normal;
`;
const TERRAIN_FRAG_PARS = /* glsl */ `
uniform sampler2D uShade;
uniform sampler2D uData;
uniform float uShadeK;
varying vec3 vRock;
varying vec4 vMat;
varying vec3 vWNormal;
`;
// 지면 색: 얼룩, 마른 풀, 모래 물결, 절벽 암석과 지층, 젖은 물가, 나무 그늘
const TERRAIN_FRAG_COLOR = /* glsl */ `
vec3 tWp = vWorldPos;
vec3 tN = normalize(vWNormal);
vec4 nA = texture2D(uNoise, tWp.xz * 0.0117);
vec4 nB = texture2D(uNoise, tWp.xz * 0.071 + 0.37);
#ifdef GFX_LITE
  vec4 nC = nB.gbar;
#else
  vec4 nC = texture2D(uNoise, tWp.xz * 0.43 + 0.11);
#endif
float tMott = nA.r * 0.45 + nB.g * 0.35 + nC.b * 0.2;
vec3 tGround = diffuseColor.rgb * (0.80 + 0.40 * tMott);
tGround = mix(tGround, tGround * vec3(1.16, 1.07, 0.74), vMat.x * smoothstep(0.52, 0.78, nA.g) * 0.8);
tGround = mix(tGround, tGround * vec3(0.78, 0.94, 0.84), vMat.x * smoothstep(0.55, 0.8, nA.b) * 0.7);
float tRip = sin((tWp.x * 0.83 + tWp.z * 0.47) * 2.4 + nB.r * 8.0);
tGround *= 1.0 + vMat.y * tRip * 0.05;
float tSlope = 1.0 - tN.y;
float tRocky = smoothstep(0.235, 0.30, tSlope + (nB.r - 0.5) * 0.10 + (nC.g - 0.5) * 0.07) * smoothstep(0.5, 2.6, tWp.y + (nC.b - 0.5) * 1.2);
// 비탈은 옆에서 본 좌표로 무늬를 입혀 세로로 늘어지지 않게 한다
#ifdef GFX_LITE
  vec4 nS = nB.barg;
#else
  vec4 nS = texture2D(uNoise, vec2(tWp.x + tWp.z, tWp.y * 1.7) * 0.11);
#endif
float tStrata = sin(tWp.y * 1.15 + nA.r * 7.0 + nB.g * 2.5) * 0.5 + 0.5;
vec3 tRock = vRock * (0.66 + 0.55 * nS.r) * (0.80 + 0.32 * tStrata);
float tEarth = (1.0 - smoothstep(6.0, 16.0, tWp.y + nA.g * 4.0)) * (1.0 - vMat.z) * (1.0 - vMat.y) * (1.0 - step(0.05, vMat.w));
tRock = mix(tRock, vec3(0.27, 0.19, 0.115) * (0.66 + 0.7 * nS.g), tEarth * 0.9);
tGround = mix(tGround, tRock, tRocky);
#ifndef GFX_LITE
  float tSwamp = texture2D(uData, (tWp.xz + 802.0) / 1604.0).g;
  float tMud = smoothstep(0.40, 0.60, nB.b * 0.6 + nA.a * 0.4) * tSwamp * (1.0 - tRocky) * step(0.2, tWp.y);
  tGround = mix(tGround, vec3(0.115, 0.09, 0.052) * (0.7 + 0.6 * nC.g), tMud * 0.82);
#endif
float tWet = (1.0 - smoothstep(0.0, 0.6, tWp.y)) * step(-0.4, tWp.y);
tGround *= 1.0 - 0.26 * tWet;
float tShade = texture2D(uShade, tWp.xz / 1600.0 + 0.5).r;
tGround *= 1.0 - tShade * uShadeK;
diffuseColor.rgb = tGround;
`;
// 잔 굴곡: 노이즈로 법선을 살짝 흔든다
const TERRAIN_FRAG_NORMAL = /* glsl */ `
float faceDirection = gl_FrontFacing ? 1.0 : -1.0;
#ifdef GFX_LITE
  vec3 tNp = tN;
#else
  vec3 tNp = normalize(tN + vec3(nC.g - 0.5, 0.0, nC.a - 0.5) * 0.20 + vec3(nS.b - 0.5, 0.0, nS.a - 0.5) * 0.6 * tRocky + vec3(nB.b - 0.5, 0.0, nB.a - 0.5) * 0.16);
#endif
vec3 normal = normalize((viewMatrix * vec4(tNp, 0.0)).xyz);
vec3 nonPerturbedNormal = normal;
`;
// 물속 빛 무늬, 눈 반짝임, 용암 균열
const TERRAIN_FRAG_LIGHT = /* glsl */ `
#ifndef GFX_LITE
if (tWp.y < 0.3) {
  float ca = texture2D(uNoise, tWp.xz * 0.09 + uTime * vec2(0.021, 0.013)).r * texture2D(uNoise, tWp.xz * 0.11 - uTime * vec2(0.017, 0.024)).g;
  ca = smoothstep(0.2, 0.42, ca);
  outgoingLight += diffuseColor.rgb * ca * 1.1 * uDay * smoothstep(0.3, -0.5, tWp.y) * smoothstep(-9.0, -2.0, tWp.y);
}
outgoingLight += vec3(1.5) * pow(nC.a, 26.0) * vMat.z * uDay * (1.0 - tRocky);
#endif
if (vMat.w > 0.01) {
  float v1 = 1.0 - abs(nB.r - 0.5) * 2.0;
  float v2 = 1.0 - abs(nC.r - 0.5) * 2.0;
  float vein = smoothstep(0.90, 0.985, v1) + 0.4 * smoothstep(0.86, 0.97, v2) * smoothstep(0.7, 0.95, v1);
  outgoingLight += vec3(3.4, 0.9, 0.12) * vein * vMat.w * (0.72 + 0.28 * sin(uTime * 1.7 + nA.r * 20.0));
}
`;

// ---------- 풀 셰이더 조각 (위치·높이·색을 모두 GPU 에서 계산) ----------
const GRASS_VERT_PARS = /* glsl */ `
attribute vec2 aOff;
attribute vec4 aRnd;
attribute float sway;
attribute float gcol;
uniform sampler2D uData;
uniform sampler2D uGround;
uniform sampler2D uNoise;
uniform sampler2D uShade;
uniform vec3 uPlayer;
uniform float uGrassR;
uniform float uShadeK;
varying vec3 vGCol;
varying float vTip;
float gH(ivec2 c) { return texelFetch(uData, clamp(c, ivec2(0), ivec2(400)), 0).r; }
`;
const GRASS_VERT_BEGIN = /* glsl */ `
vec2 gp = mod(aOff - uPlayer.xz + uGrassR, 2.0 * uGrassR) - uGrassR + uPlayer.xz;
vec2 gg = (gp + 800.0) / 4.0;
ivec2 gc = ivec2(floor(gg));
vec2 gf = fract(gg);
float ha = gH(gc);
float hb = gH(gc + ivec2(1, 0));
float hc = gH(gc + ivec2(0, 1));
float hd = gH(gc + ivec2(1, 1));
float gh;
vec2 ggrad;
if (gf.x + gf.y <= 1.0) { gh = ha + (hb - ha) * gf.x + (hc - ha) * gf.y; ggrad = vec2(hb - ha, hc - ha); }
else { gh = hd + (hc - hd) * (1.0 - gf.x) + (hb - hd) * (1.0 - gf.y); ggrad = vec2(hd - hc, hd - hb); }
float gslope = length(ggrad) * 0.25;
vec2 guv = (gp + 802.0) / 1604.0;
vec4 gdat = textureLod(uData, guv, 0.0);
float gdist = distance(gp, uPlayer.xz);
float keep = step(aRnd.w, gdat.b) * step(0.72, gh) * step(gslope, 0.85) * (1.0 - smoothstep(uGrassR * 0.66, uGrassR * 0.98, gdist));
float gs = (0.7 + aRnd.y * 0.8) * keep;
float ga = aRnd.x * 6.2832;
float gcs = cos(ga);
float gsn = sin(ga);
vec3 lp = position * gs;
vec3 transformed = vec3(lp.x * gcs + lp.z * gsn + gp.x, lp.y + gh - 0.03, -lp.x * gsn + lp.z * gcs + gp.y);
float gust = sin(dot(gp, vec2(0.11, 0.07)) - uTime * 1.7 + aRnd.z * 0.8) * 0.5 + 0.5;
float gust2 = sin(dot(gp, vec2(-0.05, 0.13)) - uTime * 1.1) * 0.5 + 0.5;
float flut = sin(uTime * 5.0 + aRnd.z * 40.0);
vec2 wind = vec2(0.85, 0.5) * (0.05 + 0.30 * gust * gust2) + vec2(flut, -flut) * 0.016;
vec2 away = gp - uPlayer.xz;
float ad = length(away);
vec2 push = (away / max(ad, 0.01)) * (1.0 - smoothstep(0.2, 1.5, ad)) * 0.45 * step(abs(uPlayer.y - gh), 1.6);
float sw = sway * gs;
transformed.xz += (wind + push) * sw;
transformed.y -= dot(wind + push, wind + push) * sw * 0.6;
vec3 gcl = textureLod(uGround, guv, 0.0).rgb;
vec4 gnA = textureLod(uNoise, gp * 0.0117, 0.0);
vec4 gnB = textureLod(uNoise, gp * 0.071 + 0.37, 0.0);
float gm = gnA.r * 0.45 + gnB.g * 0.35 + 0.1;
gcl *= 0.80 + 0.40 * gm;
gcl = mix(gcl, gcl * vec3(1.16, 1.07, 0.74), smoothstep(0.52, 0.78, gnA.g) * 0.8);
gcl = mix(gcl, gcl * vec3(0.78, 0.94, 0.84), smoothstep(0.55, 0.8, gnA.b) * 0.7);
float gsh = textureLod(uShade, gp / 1600.0 + 0.5, 0.0).r;
gcl *= 1.0 - gsh * uShadeK;
gcl *= mix(vec3(1.0), vec3(1.16, 1.03, 0.70), smoothstep(0.8, 1.0, aRnd.z) * 0.8);
vGCol = gcl * mix(vec3(0.60, 0.68, 0.62), vec3(1.20, 1.15, 0.84), gcol) * (0.92 + 0.16 * aRnd.z);
vTip = gcol;
`;
const GRASS_VERT_PROJECT = /* glsl */ `
vWorldPos = transformed;
vec4 mvPosition = viewMatrix * vec4(transformed, 1.0);
gl_Position = projectionMatrix * mvPosition;
`;
const GRASS_VERT_WORLDPOS = /* glsl */ `
#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
  vec4 worldPosition = vec4(transformed, 1.0);
#endif
`;
const UP_NORMAL = /* glsl */ `
float faceDirection = gl_FrontFacing ? 1.0 : -1.0;
vec3 normal = normalize((viewMatrix * vec4(0.0, 1.0, 0.0, 0.0)).xyz);
vec3 nonPerturbedNormal = normal;
`;

export function createGfx(canvas, qualityName, support = probeGraphics()) {
  const canPost = support.post;
  // 후처리를 쓰면 안티에일리어싱은 장면 버퍼에서 하므로 캔버스 쪽은 끈다
  const usePost = canPost && (QUALITY[qualityName] || QUALITY.medium).post;
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: !usePost, powerPreference: 'high-performance' });
  renderer.shadowMap.type = THREE.PCFShadowMap;
  installToneMapping();
  renderer.toneMapping = THREE.CustomToneMapping;
  renderer.toneMappingExposure = 1.0;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(62, 1, 0.3, 3000);
  scene.background = new THREE.Color(0xbfe6ff);

  const hemi = new THREE.HemisphereLight(0xd4ecff, 0x93a070, 1.6);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff3d2, 2.6);
  sun.shadow.camera.near = 1;
  sun.shadow.camera.far = 420;
  sun.shadow.bias = -0.0006;
  sun.shadow.normalBias = 0.06;
  scene.add(sun);
  scene.add(sun.target);

  // 모닥불·가로등용 점광원 (가까운 불빛에 돌려 쓴다)
  const pointLights = [];
  for (let i = 0; i < 3; i++) {
    const pl = new THREE.PointLight(0xffa24a, 0, 26, 1.8);
    pl.visible = false;
    scene.add(pl);
    pointLights.push(pl);
  }

  env.uNoise.value = makeNoiseTexture();
  const uTime = env.uTime;
  const uPlayer = env.uPlayer;
  const uGrassR = { value: 30 };

  // ---- 공용 재질 ----
  const matTerrain = patchMaterial(new THREE.MeshLambertMaterial({ vertexColors: true }), 'terrain', {
    vertexPars: TERRAIN_VERT_PARS,
    vertexAfterBegin: TERRAIN_VERT,
    fragPars: TERRAIN_FRAG_PARS,
    fragColor: TERRAIN_FRAG_COLOR,
    fragNormal: TERRAIN_FRAG_NORMAL,
    fragLight: TERRAIN_FRAG_LIGHT,
  });

  const RIM = /* glsl */ `
  #ifndef GFX_LITE
  {
    vec3 vd = normalize(vViewPosition);
    float rim = pow(1.0 - saturate(dot(normal, vd)), 3.0);
    outgoingLight += rim * mix(uFogColor, uSunCol, 0.45) * 0.20 * (0.35 + 0.65 * uDay);
  }
  #endif`;
  const matChar = patchMaterial(new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }), 'char', { fragLight: RIM });

  // 젤리 같은 말랑이 재질
  const matJelly = patchMaterial(new THREE.MeshPhongMaterial({ vertexColors: true, transparent: true, opacity: 0.9, shininess: 120, specular: 0xaaaaaa }), 'jelly', {
    fragLight: /* glsl */ `
    {
      vec3 vd = normalize(vViewPosition);
      float rim = pow(1.0 - saturate(dot(normal, vd)), 2.2);
      outgoingLight += diffuseColor.rgb * rim * 0.75 * (0.3 + 0.7 * uDay);
    }`,
  });

  // 발광 재질: 밝기를 1 이상으로 올려 빛 번짐이 생기게 한다
  const matGlow = patchMaterial(new THREE.MeshBasicMaterial({ vertexColors: true }), 'glow', { cloud: false });
  matGlow.color.setScalar(2.3);
  // 집 창문: 밤에만 불이 켜진다
  const matWindow = patchMaterial(new THREE.MeshBasicMaterial({ color: 0x5a7fa0 }), 'window', { cloud: false });

  // 바람에 흔들리는 장식물(나무·덤불·바위) 재질
  const matProp = patchMaterial(new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }), 'prop', {
    vertexPars: 'attribute float sway;\nvarying float vFol;',
    vertexAfterBegin: /* glsl */ `
      float pg = sin(dot(position.xz, vec2(0.11, 0.07)) - uTime * 1.7) * 0.5 + 0.5;
      transformed.x += (sin(uTime * 1.5 + position.x * 0.31 + position.z * 0.23) * 0.07 + 0.11 * pg) * sway;
      transformed.z += (cos(uTime * 1.2 + position.x * 0.19 - position.z * 0.27) * 0.05 + 0.065 * pg) * sway;
      vFol = sway;`,
    fragPars: 'varying float vFol;',
    fragColor: '#ifndef GFX_LITE\n diffuseColor.rgb *= 0.88 + 0.26 * texture2D(uNoise, vWorldPos.xz * 0.045).g;\n#endif',
    fragLight: /* glsl */ `
    #ifndef GFX_LITE
    {
      float fol = step(0.001, vFol);
      float bl = pow(max(dot(normalize(vWorldPos - cameraPosition), uSunDir), 0.0), 3.0);
      outgoingLight += diffuseColor.rgb * uSunCol * bl * 0.30 * fol * uDay;
      vec3 vd = normalize(vViewPosition);
      float rim = pow(1.0 - saturate(dot(normal, vd)), 3.0);
      outgoingLight += rim * uFogColor * 0.10 * uDay;
    }
    #endif`,
  });

  // 풀
  const matGrass = patchMaterial(new THREE.MeshLambertMaterial({ side: THREE.DoubleSide }), 'grass', {
    uniforms: { uGrassR },
    vertexPars: GRASS_VERT_PARS,
    vertexBegin: GRASS_VERT_BEGIN,
    vertexProject: GRASS_VERT_PROJECT,
    vertexWorldpos: GRASS_VERT_WORLDPOS,
    fragPars: 'varying vec3 vGCol;\nvarying float vTip;',
    fragColor: 'diffuseColor.rgb *= vGCol;',
    fragNormal: UP_NORMAL,
    fragLight: /* glsl */ `
    {
      float bl = pow(max(dot(normalize(vWorldPos - cameraPosition), uSunDir), 0.0), 3.0);
      outgoingLight += diffuseColor.rgb * uSunCol * bl * 0.24 * vTip * uDay;
    }`,
  });

  // ---- 하늘 ----
  const skyUniforms = {
    uZenith: { value: new THREE.Color() },
    uFogColor: env.uFogColor,
    uFogSun: env.uFogSun,
    uSunDir: env.uSunDir,
    uSunPos: { value: new THREE.Vector3(0, 1, 0) },
    uMoonPos: { value: new THREE.Vector3(0, -1, 0) },
    uSunDisc: { value: new THREE.Color() },
    uNight: { value: 0 },
    uDay: env.uDay,
    uTime: env.uTime,
    uNoise: env.uNoise,
  };
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(1000, 32, 16),
    new THREE.ShaderMaterial({
      uniforms: skyUniforms,
      side: THREE.BackSide,
      depthWrite: false,
      depthTest: false,
      fog: false,
      vertexShader: /* glsl */ `
        varying vec3 vDir;
        void main() {
          vDir = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }`,
      fragmentShader: /* glsl */ `
        uniform vec3 uZenith; uniform vec3 uFogColor; uniform vec3 uFogSun; uniform vec3 uSunDir;
        uniform vec3 uSunPos; uniform vec3 uMoonPos; uniform vec3 uSunDisc;
        uniform float uNight; uniform float uDay; uniform float uTime;
        uniform sampler2D uNoise;
        varying vec3 vDir;
        void main() {
          vec3 d = normalize(vDir);
          float h = d.y;
          float s = pow(max(dot(d, uSunDir), 0.0), 5.0);
          vec3 hor = mix(uFogColor, uFogSun, s * 0.75);
          float t = pow(clamp(h, 0.0, 1.0), 0.45);
          vec3 col = mix(hor, uZenith, t);
          float sd = max(dot(d, uSunPos), 0.0);
          col += uSunDisc * (pow(sd, 900.0) * 0.45 + pow(sd, 90.0) * 0.03 + pow(sd, 14.0) * 0.011);
          col += uSunDisc * smoothstep(0.99962, 0.99976, sd) * 2.0;
          float md = max(dot(d, uMoonPos), 0.0);
          col += vec3(1.6, 1.75, 2.1) * smoothstep(0.99945, 0.9996, md) * uNight;
          col += vec3(0.25, 0.32, 0.5) * pow(md, 50.0) * 0.3 * uNight;
          // 높은 하늘의 새털구름
          #ifndef GFX_LITE
          if (h > 0.015) {
            vec2 cuv = d.xz / (h + 0.22);
            float n = texture2D(uNoise, cuv * 0.11 + uTime * vec2(0.0016, 0.0007)).r * 0.62 + texture2D(uNoise, cuv * 0.31 - uTime * vec2(0.001, 0.0021)).g * 0.38;
            float c = smoothstep(0.5, 0.8, n) * smoothstep(0.015, 0.28, h);
            vec3 ccol = vec3(0.07 + 1.0 * uDay) + uFogSun * s * 0.7 + hor * 0.12;
            col = mix(col, ccol, c * 0.5);
          }
          #endif
          col = mix(col, hor * 0.94, smoothstep(0.0, -0.3, h));
          gl_FragColor = vec4(col, 1.0);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`,
    })
  );
  sky.renderOrder = -20;
  sky.frustumCulled = false;
  scene.add(sky);

  // 별
  const starGeo = new THREE.BufferGeometry();
  {
    const n = 900;
    const p = new Float32Array(n * 3);
    let s = 12345;
    const rnd = () => ((s = (Math.imul(s, 1664525) + 1013904223) | 0) >>> 0) / 4294967296;
    for (let i = 0; i < n; i++) {
      const u = rnd() * 2 - 1;
      const a = rnd() * Math.PI * 2;
      const r = Math.sqrt(1 - u * u);
      p[i * 3] = r * Math.cos(a) * 900;
      p[i * 3 + 1] = Math.abs(u) * 900;
      p[i * 3 + 2] = r * Math.sin(a) * 900;
    }
    starGeo.setAttribute('position', new THREE.BufferAttribute(p, 3));
  }
  const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 2.2, sizeAttenuation: false, transparent: true, opacity: 0, depthWrite: false, fog: false }));
  stars.material.color.setScalar(2.4);
  stars.renderOrder = -19;
  stars.frustumCulled = false;
  scene.add(stars);

  // ---- 구름 ----
  const cloudMat = new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true, fog: false });
  const clouds = new THREE.Group();
  {
    const g = new Geo();
    let s = 777;
    const rnd = () => ((s = (Math.imul(s, 1664525) + 1013904223) | 0) >>> 0) / 4294967296;
    const SPAN = 3200;
    for (let i = 0; i < 38; i++) {
      const cx = (rnd() - 0.5) * SPAN;
      const cz = (rnd() - 0.5) * SPAN;
      const cy = 200 + rnd() * 130;
      const size = 24 + rnd() * 34;
      const n = 4 + Math.floor(rnd() * 4);
      for (let k = 0; k < n; k++) {
        const r = size * (0.5 + rnd() * 0.6);
        g.ico(r, 1, M(cx + (k - n / 2) * size * 0.7 + rnd() * 8, cy + rnd() * 7, cz + (rnd() - 0.5) * size * 0.9, 0, rnd() * 6, 0, 1, 0.44, 0.82), 0xc4d4ea, 0xffffff, 0.22, i * 7 + k);
      }
    }
    const geo = g.build(false);
    for (let k = 0; k < 2; k++) {
      const m = new THREE.Mesh(geo, cloudMat);
      m.frustumCulled = false;
      clouds.add(m);
    }
    clouds.userData.span = SPAN;
  }
  scene.add(clouds);

  // ---- 물: 수심에 따라 색이 달라지고 물가에 거품이 인다 ----
  const waterUniforms = {
    uData: env.uData, uNoise: env.uNoise, uTime: env.uTime,
    uFogColor: env.uFogColor, uFogSun: env.uFogSun, uSunDir: env.uSunDir, uFogDensity: env.uFogDensity, uSunCol: env.uSunCol,
    uZenith: skyUniforms.uZenith,
    uShallow: { value: C(0x45d6cb) }, uDeep: { value: C(0x0b4a8c) }, uSwamp: { value: C(0x4f6236) },
    uLight: { value: 1 },
  };
  const waterMat = new THREE.ShaderMaterial({
    uniforms: waterUniforms,
    transparent: true,
    depthWrite: false,
    vertexShader: /* glsl */ `
      varying vec3 vWorldPos;
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPos = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }`,
    fragmentShader: /* glsl */ `
      uniform sampler2D uData; uniform sampler2D uNoise; uniform float uTime;
      uniform vec3 uSunCol; uniform vec3 uZenith; uniform vec3 uShallow; uniform vec3 uDeep; uniform vec3 uSwamp; uniform float uLight;
      varying vec3 vWorldPos;
      ${ATMO_PARS}
      void main() {
        vec2 p = vWorldPos.xz;
        vec2 uv = (p + 802.0) / 1604.0;
        vec4 dat = texture2D(uData, uv);
        float inMap = step(abs(p.x), 798.0) * step(abs(p.y), 798.0);
        float depth = mix(26.0, -dat.r, inMap);
        if (depth < -0.3) discard;
        vec3 n1 = texture2D(uNoise, p * 0.021 + uTime * vec2(0.011, 0.006)).rgb;
        vec3 n2 = texture2D(uNoise, p * 0.057 - uTime * vec2(0.008, 0.013)).gbr;
        #ifdef GFX_LITE
          vec3 n3 = n2.brg;
        #else
          vec3 n3 = texture2D(uNoise, p * 0.19 + uTime * vec2(0.021, -0.017)).brg;
        #endif
        vec2 bump = (n1.xy - 0.5) * 0.9 + (n2.xy - 0.5) * 0.6 + (n3.xy - 0.5) * 0.35;
        vec3 N = normalize(vec3(bump.x * 0.5, 1.0, bump.y * 0.5));
        vec3 V = normalize(cameraPosition - vWorldPos);
        float fres = pow(1.0 - max(dot(N, V), 0.0), 4.0);
        float dk = smoothstep(0.0, 7.5, depth);
        vec3 base = mix(uShallow, uDeep, dk);
        base = mix(base, uSwamp, clamp(dat.g * 1.2, 0.0, 1.0) * inMap * 0.9);
        vec3 col = base * uLight;
        vec3 R = reflect(-V, N);
        vec3 skyRef = mix(uFogColor, uZenith, clamp(R.y * 1.5, 0.0, 1.0));
        col = mix(col, skyRef, fres * 0.8);
        vec3 H = normalize(uSunDir + V);
        float nh = max(dot(N, H), 0.0);
        col += uSunCol * (pow(nh, 260.0) * 3.0 + pow(nh, 40.0) * 0.12);
        // 물가 거품
        float shore = 1.0 - smoothstep(0.0, 0.9, depth);
        float lap = sin(depth * 7.0 - uTime * 1.6 + n2.r * 4.0) * 0.5 + 0.5;
        float foam = smoothstep(0.55, 0.9, shore * (0.5 + 0.65 * lap) + (n3.r - 0.5) * 0.4);
        foam = max(foam, smoothstep(0.9, 1.0, shore));
        foam *= inMap;
        col = mix(col, vec3(0.5 + 0.6 * uLight), foam * 0.85);
        float alpha = mix(0.34, 0.94, smoothstep(0.0, 3.6, depth));
        alpha = max(alpha, fres * 0.9);
        alpha = max(alpha, foam * 0.9);
        alpha *= smoothstep(-0.3, 0.04, depth);
        col = applyAtmo(col, vWorldPos);
        gl_FragColor = vec4(col, alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  });
  const waterGeo = new THREE.PlaneGeometry(6400, 6400, 1, 1);
  waterGeo.rotateX(-Math.PI / 2);
  const water = new THREE.Mesh(waterGeo, waterMat);
  water.renderOrder = 5;
  water.frustumCulled = false;
  scene.add(water);

  const post = canPost ? new Post(renderer) : null;
  const _size = new THREE.Vector2();

  const gfx = {
    renderer, scene, camera, hemi, sun, sky, water, clouds, pointLights, post,
    uTime, uPlayer, uGrassR, env,
    matTerrain, matChar, matProp, matGrass, matGlow, matJelly, matWindow,
    quality: QUALITY[qualityName] || QUALITY.medium,
    qualityName,
    night: 0,
    sunElev: 1,
    fogColor: new THREE.Color(),
    canPost,
    resScale: 1, // 느린 기기에서는 해상도를 단계적으로 낮춘다
    mood: { fog: 1, tint: new THREE.Color(1, 1, 1), grade: new THREE.Color(1, 1, 1) },

    // 플레이어가 서 있는 곳의 바이옴 가중치(bw[o..o+6])에 맞춰 분위기를 서서히 바꾼다
    setMood(bw, o, dt) {
      let sum = 0;
      let fog = 0, tr = 0, tg = 0, tb = 0, gr = 0, gg = 0, gb = 0;
      for (let k = 0; k < MOOD.length; k++) {
        const w = bw[o + k];
        if (!w) continue;
        const m = MOOD[k];
        sum += w;
        fog += m.fog * w;
        tr += m.tint[0] * w; tg += m.tint[1] * w; tb += m.tint[2] * w;
        gr += m.grade[0] * w; gg += m.grade[1] * w; gb += m.grade[2] * w;
      }
      if (!sum) return;
      const k = Math.min(1, dt * 0.9);
      const md = this.mood;
      md.fog += (fog / sum - md.fog) * k;
      md.tint.r += (tr / sum - md.tint.r) * k; md.tint.g += (tg / sum - md.tint.g) * k; md.tint.b += (tb / sum - md.tint.b) * k;
      md.grade.r += (gr / sum - md.grade.r) * k; md.grade.g += (gg / sum - md.grade.g) * k; md.grade.b += (gb / sum - md.grade.b) * k;
    },

    setQuality(name) {
      this.qualityName = name;
      const q = (this.quality = QUALITY[name] || QUALITY.medium);
      this.resScale = 1;
      flags.lite = !!q.lite;
      for (const m of [sky.material, waterMat]) {
        m.defines = q.lite ? { GFX_LITE: '' } : {};
        m.needsUpdate = true;
      }
      const noise = env.uNoise.value;
      const aniso = Math.min(q.aniso, renderer.capabilities.getMaxAnisotropy());
      if (noise.anisotropy !== aniso) {
        noise.anisotropy = aniso;
        noise.needsUpdate = true;
      }
      renderer.shadowMap.enabled = q.shadows > 0;
      sun.castShadow = q.shadows > 0;
      if (q.shadows > 0) {
        if (sun.shadow.map) {
          sun.shadow.map.dispose();
          sun.shadow.map = null;
        }
        sun.shadow.mapSize.set(q.shadows, q.shadows);
        const c = sun.shadow.camera;
        c.left = -q.shadowR;
        c.right = q.shadowR;
        c.top = q.shadowR;
        c.bottom = -q.shadowR;
        c.updateProjectionMatrix();
      }
      env.uFogDensity.value = (2.34 / q.fogFar) * this.mood.fog;
      env.uShadeK.value = q.shadows > 0 ? 0.36 : 0.5;
      pointLights.forEach((pl, i) => (pl.visible = i < q.lights));
      for (const m of [matTerrain, matChar, matProp, matGrass, matJelly, matGlow, matWindow, cloudMat]) m.needsUpdate = true;
      this.resize();
    },

    setResScale(scale) {
      this.resScale = scale;
      this.resize();
    },

    resize() {
      const w = window.innerWidth;
      const h = window.innerHeight;
      // 화면이 아주 큰 기기에서 그리는 화소 수가 지나치게 늘지 않도록 상한을 둔다
      let pr = Math.min(window.devicePixelRatio || 1, this.quality.pr);
      if (w * h * pr * pr > this.quality.maxPixels) pr = Math.sqrt(this.quality.maxPixels / (w * h));
      renderer.setPixelRatio(pr * this.resScale);
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      // 세로 화면에서는 시야를 조금 넓힌다
      camera.fov = w < h ? 78 : 62;
      camera.updateProjectionMatrix();
      if (post && this.quality.post) {
        renderer.getDrawingBufferSize(_size);
        post.setSize(Math.max(8, _size.x), Math.max(8, _size.y), support.msaa ? this.quality.msaa : 0, this.quality.bloomLevels);
      }
    },

    // tod: 0..1 (0 = 해뜰 무렵), focus: 그림자가 따라갈 위치
    update(tod, time, dt, focus) {
      uTime.value = time;
      // 낮이 64%, 밤이 36%
      const ang = tod < 0.64 ? (Math.PI * tod) / 0.64 : Math.PI + (Math.PI * (tod - 0.64)) / 0.36;
      const e = Math.sin(ang);
      const sx = Math.cos(ang);
      this.sunElev = e;
      const sunPos = skyUniforms.uSunPos.value.set(sx, e, 0.35).normalize();
      const moonPos = skyUniforms.uMoonPos.value.set(-sx, -e, -0.25).normalize();
      const dayF = smooth(-0.08, 0.28, e);
      const duskF = Math.max(0, 1 - Math.abs(e) / 0.34);
      const night = 1 - dayF;
      this.night = night;

      skyUniforms.uZenith.value.copy(SKY.nightTop).lerp(SKY.dayTop, dayF).lerp(SKY.duskTop, duskF * 0.6);
      env.uFogColor.value.copy(SKY.nightHor).lerp(SKY.dayHor, dayF).lerp(SKY.duskHor, duskF * 0.62);
      env.uFogSun.value.copy(SKY.fogSunNight).lerp(SKY.fogSunDay, dayF).lerp(SKY.fogSunDusk, duskF * 0.9);
      env.uFogColor.value.multiply(this.mood.tint);
      env.uFogDensity.value = (2.34 / this.quality.fogFar) * this.mood.fog;
      const discUp = smooth(-0.1, 0.03, e);
      const hi = smooth(0.04, 0.4, e);
      skyUniforms.uSunDisc.value.setRGB(10.5 * discUp, (4.6 + 5.4 * hi) * discUp, (1.5 + 6.5 * hi) * discUp);
      skyUniforms.uNight.value = night;
      stars.material.opacity = smooth(0.03, -0.16, e) * 0.95;
      this.fogColor.copy(env.uFogColor.value);
      scene.background.copy(this.fogColor);
      env.uDay.value = dayF;
      env.uCloud.value = 0.85 * dayF;

      hemi.color.copy(SKY.hemiSkyNight).lerp(SKY.hemiSkyDay, dayF);
      hemi.groundColor.copy(SKY.hemiGroundNight).lerp(SKY.hemiGroundDay, dayF);
      hemi.intensity = 1.25 + 0.55 * dayF;

      if (e >= 0) {
        sun.color.copy(SKY.sunDay).lerp(SKY.sunDusk, duskF);
        sun.intensity = 2.5 * smooth(0.0, 0.22, e);
        env.uSunDir.value.copy(sunPos);
        env.uSunCol.value.copy(sun.color).multiplyScalar(smooth(0.0, 0.2, e));
      } else {
        sun.color.copy(SKY.moon);
        sun.intensity = 1.5 * smooth(0.0, 0.22, -e);
        env.uSunDir.value.copy(moonPos);
        env.uSunCol.value.copy(SKY.moon).multiplyScalar(0.3 * smooth(0.0, 0.2, -e));
      }
      sun.position.copy(focus).addScaledVector(env.uSunDir.value, 190);
      sun.target.position.copy(focus);
      sun.target.updateMatrixWorld();

      cloudMat.color.setScalar(0.35 + 0.65 * dayF).lerp(SKY.duskHor, duskF * 0.35);
      cloudMat.emissive.copy(SKY.duskHor).multiplyScalar(duskF * 0.42 * smooth(-0.12, 0.05, e));
      waterUniforms.uLight.value = 0.16 + 0.84 * dayF;
      // 밤에는 창문에 불이 켜진다
      const lit = smooth(0.25, 0.75, night);
      const glass = 0.2 + 0.8 * dayF;
      matWindow.color.setRGB(0.22 * glass + 2.6 * lit, 0.42 * glass + 1.75 * lit, 0.6 * glass + 0.62 * lit);
      if (post) {
        post.matFinal.uniforms.uExposure.value = 1.0 + 0.4 * night;
        post.matFinal.uniforms.uBloom.value = 0.3 + 0.12 * night;
        post.matFinal.uniforms.uTint.value.copy(this.mood.grade);
      }
      renderer.toneMappingExposure = 1.0 + 0.4 * night;

      sky.position.copy(camera.position);
      stars.position.copy(camera.position);
      stars.rotation.y = time * 0.004;

      // 구름 이동 (두 장을 이어 붙여 순환)
      const span = clouds.userData.span;
      const off = (time * 2.2) % span;
      clouds.children[0].position.x = off;
      clouds.children[1].position.x = off - span;

      water.position.set(camera.position.x, 0, camera.position.z);
    },

    render() {
      if (post && this.quality.post) post.render(scene, camera);
      else {
        renderer.setRenderTarget(null);
        renderer.render(scene, camera);
      }
    },
  };

  gfx.setQuality(qualityName);
  return gfx;
}

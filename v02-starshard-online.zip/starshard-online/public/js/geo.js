// 로우폴리 지오메트리 빌더: 기본 도형을 색상과 함께 하나의 메시로 합친다.
import * as THREE from '/vendor/three/three.module.js';

const _col = new THREE.Color();
const colorCache = new Map();

// sRGB 16진수 색 -> 선형 [r,g,b]
export function lin(hex) {
  let c = colorCache.get(hex);
  if (!c) {
    _col.setHex(hex);
    c = [_col.r, _col.g, _col.b];
    colorCache.set(hex, c);
  }
  return c;
}

const _pos = new THREE.Vector3();
const _quat = new THREE.Quaternion();
const _scl = new THREE.Vector3();
const _eul = new THREE.Euler();

// 위치/회전/크기로 변환 행렬 생성
export function M(x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = sx, sz = sx) {
  _pos.set(x, y, z);
  _eul.set(rx, ry, rz, 'YXZ');
  _quat.setFromEuler(_eul);
  _scl.set(sx, sy, sz);
  return new THREE.Matrix4().compose(_pos, _quat, _scl);
}

function hash3(a, b) {
  let h = Math.imul(a | 0, 374761393) ^ Math.imul(b | 0, 668265263);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

// ---- 20면체 데이터 ----
const ICO = [];
{
  const t = (1 + Math.sqrt(5)) / 2;
  const v = [-1, t, 0, 1, t, 0, -1, -t, 0, 1, -t, 0, 0, -1, t, 0, 1, t, 0, -1, -t, 0, 1, -t, t, 0, -1, t, 0, 1, -t, 0, -1, -t, 0, 1];
  const f = [0, 11, 5, 0, 5, 1, 0, 1, 7, 0, 7, 10, 0, 10, 11, 1, 5, 9, 5, 11, 4, 11, 10, 2, 10, 7, 6, 7, 1, 8, 3, 9, 4, 3, 4, 2, 3, 2, 6, 3, 6, 8, 3, 8, 9, 4, 9, 5, 2, 4, 11, 6, 2, 10, 8, 6, 7, 9, 8, 1];
  const norm = (arr) => {
    for (let i = 0; i < arr.length; i += 3) {
      const l = Math.hypot(arr[i], arr[i + 1], arr[i + 2]);
      arr[i] /= l;
      arr[i + 1] /= l;
      arr[i + 2] /= l;
    }
    return arr;
  };
  ICO[0] = { v: norm(v.slice()), f: f.slice() };
  // 한 단계 세분화
  const sub = (src) => {
    const vv = src.v.slice();
    const ff = [];
    const mid = new Map();
    const midpoint = (a, b) => {
      const key = a < b ? a * 100000 + b : b * 100000 + a;
      let m = mid.get(key);
      if (m === undefined) {
        m = vv.length / 3;
        vv.push((vv[a * 3] + vv[b * 3]) / 2, (vv[a * 3 + 1] + vv[b * 3 + 1]) / 2, (vv[a * 3 + 2] + vv[b * 3 + 2]) / 2);
        mid.set(key, m);
      }
      return m;
    };
    for (let i = 0; i < src.f.length; i += 3) {
      const a = src.f[i];
      const b = src.f[i + 1];
      const c = src.f[i + 2];
      const ab = midpoint(a, b);
      const bc = midpoint(b, c);
      const ca = midpoint(c, a);
      ff.push(a, ab, ca, b, bc, ab, c, ca, bc, ab, bc, ca);
    }
    return { v: norm(vv), f: ff };
  };
  ICO[1] = sub(ICO[0]);
  ICO[2] = sub(ICO[1]);
}

export class Geo {
  constructor() {
    this.p = [];
    this.c = [];
    this.s = [];
    this.i = [];
    this.swayOn = false;
  }

  get vertCount() {
    return this.p.length / 3;
  }

  // 로컬 정점들을 행렬 m 으로 변환해 추가. color2 가 있으면 로컬 y 기준으로 아래(color)->위(color2) 그라데이션.
  _emit(verts, tris, m, color, color2, sway) {
    const base = this.p.length / 3;
    const e = m ? m.elements : null;
    const c1 = typeof color === 'number' ? lin(color) : color;
    const c2 = color2 === undefined || color2 === null ? null : typeof color2 === 'number' ? lin(color2) : color2;
    let minY = Infinity;
    let maxY = -Infinity;
    if (c2 || sway) {
      for (let i = 1; i < verts.length; i += 3) {
        if (verts[i] < minY) minY = verts[i];
        if (verts[i] > maxY) maxY = verts[i];
      }
    }
    const span = maxY - minY || 1;
    for (let i = 0; i < verts.length; i += 3) {
      const x = verts[i];
      const y = verts[i + 1];
      const z = verts[i + 2];
      if (e) this.p.push(e[0] * x + e[4] * y + e[8] * z + e[12], e[1] * x + e[5] * y + e[9] * z + e[13], e[2] * x + e[6] * y + e[10] * z + e[14]);
      else this.p.push(x, y, z);
      const t = c2 || sway ? (y - minY) / span : 0;
      if (c2) this.c.push(c1[0] + (c2[0] - c1[0]) * t, c1[1] + (c2[1] - c1[1]) * t, c1[2] + (c2[2] - c1[2]) * t);
      else this.c.push(c1[0], c1[1], c1[2]);
      this.s.push(sway ? sway * (0.35 + 0.65 * t) : 0);
    }
    if (sway) this.swayOn = true;
    for (let i = 0; i < tris.length; i++) this.i.push(base + tris[i]);
    return this;
  }

  box(w, h, d, m, color, color2, sway) {
    const x = w / 2;
    const y = h / 2;
    const z = d / 2;
    return this._emit(
      [-x, -y, -z, x, -y, -z, x, y, -z, -x, y, -z, -x, -y, z, x, -y, z, x, y, z, -x, y, z],
      [0, 2, 1, 0, 3, 2, 4, 5, 6, 4, 6, 7, 0, 4, 7, 0, 7, 3, 1, 2, 6, 1, 6, 5, 3, 7, 6, 3, 6, 2, 0, 1, 5, 0, 5, 4],
      m, color, color2, sway
    );
  }

  // 위쪽이 좁아지는 상자 (taper: 윗면 크기 비율)
  taperBox(w, h, d, taper, m, color, color2, sway) {
    const x = w / 2;
    const y = h / 2;
    const z = d / 2;
    const tx = x * taper;
    const tz = z * taper;
    return this._emit(
      [-x, -y, -z, x, -y, -z, tx, y, -tz, -tx, y, -tz, -x, -y, z, x, -y, z, tx, y, tz, -tx, y, tz],
      [0, 2, 1, 0, 3, 2, 4, 5, 6, 4, 6, 7, 0, 4, 7, 0, 7, 3, 1, 2, 6, 1, 6, 5, 3, 7, 6, 3, 6, 2, 0, 1, 5, 0, 5, 4],
      m, color, color2, sway
    );
  }

  // 원기둥/원뿔 (rt: 윗 반지름, rb: 아랫 반지름). y 중심 기준.
  cyl(rt, rb, h, n, m, color, color2, sway, caps = true) {
    const v = [];
    const f = [];
    const y0 = -h / 2;
    const y1 = h / 2;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      v.push(Math.cos(a) * rb, y0, Math.sin(a) * rb);
    }
    const apex = rt <= 1e-4;
    if (apex) v.push(0, y1, 0);
    else {
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2;
        v.push(Math.cos(a) * rt, y1, Math.sin(a) * rt);
      }
    }
    for (let i = 0; i < n; i++) {
      const b0 = i;
      const b1 = (i + 1) % n;
      if (apex) f.push(b0, n, b1);
      else {
        const t0 = n + i;
        const t1 = n + ((i + 1) % n);
        f.push(b0, t0, b1, b1, t0, t1);
      }
    }
    if (caps) {
      const cb = v.length / 3;
      v.push(0, y0, 0);
      for (let i = 0; i < n; i++) f.push(cb, i, (i + 1) % n);
      if (!apex) {
        const ct = v.length / 3;
        v.push(0, y1, 0);
        for (let i = 0; i < n; i++) f.push(ct, n + ((i + 1) % n), n + i);
      }
    }
    return this._emit(v, f, m, color, color2, sway);
  }

  cone(r, h, n, m, color, color2, sway) {
    return this.cyl(0, r, h, n, m, color, color2, sway, true);
  }

  // 20면체 기반 덩어리. jitter 로 울퉁불퉁하게.
  ico(r, detail, m, color, color2, jitter = 0, seed = 1, sway = 0) {
    const src = ICO[detail];
    let v = src.v;
    if (r !== 1 || jitter) {
      v = new Array(src.v.length);
      for (let i = 0; i < src.v.length; i += 3) {
        const k = r * (jitter ? 1 + (hash3(i, seed) - 0.5) * jitter : 1);
        v[i] = src.v[i] * k;
        v[i + 1] = src.v[i + 1] * k;
        v[i + 2] = src.v[i + 2] * k;
      }
    }
    return this._emit(v, src.f, m, color, color2, sway);
  }

  // 삼각 지붕 (박공): 폭 w(x), 높이 h, 길이 d(z)
  roof(w, h, d, m, color, color2) {
    const x = w / 2;
    const z = d / 2;
    return this._emit(
      [-x, 0, -z, x, 0, -z, 0, h, -z, -x, 0, z, x, 0, z, 0, h, z],
      [0, 2, 1, 3, 4, 5, 0, 3, 5, 0, 5, 2, 1, 2, 5, 1, 5, 4, 0, 1, 4, 0, 4, 3],
      m, color, color2
    );
  }

  // 임의의 사각형 (정점 4개, 반시계 방향) - 양면이 필요하면 두 번 호출
  quad(a, b, c, d, color, color2, sway) {
    return this._emit([...a, ...b, ...c, ...d], [0, 1, 2, 0, 2, 3], null, color, color2, sway);
  }

  tri(a, b, c, color, sway) {
    return this._emit([...a, ...b, ...c], [0, 1, 2], null, color, null, sway);
  }

  // 다른 Geo 를 변환해서 합치기
  merge(other, m) {
    const base = this.p.length / 3;
    const e = m ? m.elements : null;
    for (let i = 0; i < other.p.length; i += 3) {
      const x = other.p[i];
      const y = other.p[i + 1];
      const z = other.p[i + 2];
      if (e) this.p.push(e[0] * x + e[4] * y + e[8] * z + e[12], e[1] * x + e[5] * y + e[9] * z + e[13], e[2] * x + e[6] * y + e[10] * z + e[14]);
      else this.p.push(x, y, z);
    }
    for (let i = 0; i < other.c.length; i++) this.c.push(other.c[i]);
    for (let i = 0; i < other.s.length; i++) this.s.push(other.s[i]);
    for (let i = 0; i < other.i.length; i++) this.i.push(base + other.i[i]);
    if (other.swayOn) this.swayOn = true;
    return this;
  }

  // 타입 배열 묶음 (대량 인스턴스 합치기용)
  template() {
    return {
      p: new Float32Array(this.p),
      c: new Float32Array(this.c),
      s: new Float32Array(this.s),
      i: new Uint16Array(this.i),
      nv: this.p.length / 3,
      ni: this.i.length,
    };
  }

  build(withSway = this.swayOn) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(this.p), 3));
    g.setAttribute('color', new THREE.BufferAttribute(new Float32Array(this.c), 3));
    if (withSway) g.setAttribute('sway', new THREE.BufferAttribute(new Float32Array(this.s), 1));
    const nv = this.p.length / 3;
    g.setIndex(new THREE.BufferAttribute(nv > 65535 ? new Uint32Array(this.i) : new Uint16Array(this.i), 1));
    g.computeBoundingSphere();
    g.computeBoundingBox();
    return g;
  }
}

// 여러 템플릿 인스턴스를 미리 할당한 버퍼에 빠르게 합친다.
export class MergeBuffer {
  constructor(nv, ni) {
    this.p = new Float32Array(nv * 3);
    this.c = new Float32Array(nv * 3);
    this.s = new Float32Array(nv);
    this.i = nv > 65535 ? new Uint32Array(ni) : new Uint16Array(ni);
    this.nv = 0;
    this.ni = 0;
  }

  add(t, x, y, z, scale, rotY, tr = 1, tg = 1, tb = 1) {
    const cs = Math.cos(rotY) * scale;
    const sn = Math.sin(rotY) * scale;
    const base = this.nv;
    let o = base * 3;
    const tp = t.p;
    const tc = t.c;
    for (let k = 0; k < tp.length; k += 3) {
      const px = tp[k];
      const pz = tp[k + 2];
      this.p[o] = px * cs + pz * sn + x;
      this.p[o + 1] = tp[k + 1] * scale + y;
      this.p[o + 2] = -px * sn + pz * cs + z;
      this.c[o] = tc[k] * tr;
      this.c[o + 1] = tc[k + 1] * tg;
      this.c[o + 2] = tc[k + 2] * tb;
      o += 3;
    }
    const ts = t.s;
    for (let k = 0; k < ts.length; k++) this.s[base + k] = ts[k] * scale;
    const ti = t.i;
    let io = this.ni;
    for (let k = 0; k < ti.length; k++) this.i[io++] = ti[k] + base;
    this.nv += t.nv;
    this.ni += t.ni;
  }

  build(withSway = true) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.p.subarray(0, this.nv * 3), 3));
    g.setAttribute('color', new THREE.BufferAttribute(this.c.subarray(0, this.nv * 3), 3));
    if (withSway) g.setAttribute('sway', new THREE.BufferAttribute(this.s.subarray(0, this.nv), 1));
    g.setIndex(new THREE.BufferAttribute(this.i.subarray(0, this.ni), 1));
    g.computeBoundingSphere();
    g.computeBoundingBox();
    return g;
  }
}

// 내 캐릭터: 이동(달리기·점프·활공·수영·등반), 전투, 카메라
import * as THREE from '/vendor/three/three.module.js';
import { ANIM, ARMORS, BERRY_HEAL, MAX_LEVEL, SEND_MS, maxHpFor, maxStaminaFor, xpNeed, playerAtk, playerBowAtk } from '/shared/defs.js';
import { W } from '/shared/world.js';
import { encodeState } from '/shared/proto.js';
import { makeHumanoid, animateHumanoid, playerLook, setWeapon } from './models.js';

const GRAV = 28;
const JUMP_V = 9.8;
const RUN = 6.6;
const SPRINT = 10.4;
const SWIM_Y = -0.95;
const STEEP = 1.0;
const TAU = Math.PI * 2;

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
function angDiff(a, b) {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}
const _grad = { x: 0, z: 0 };
const _v = new THREE.Vector3();

export class Player {
  constructor(game) {
    this.game = game;
    this.pos = new THREE.Vector3();
    this.vel = new THREE.Vector3();
    this.yaw = Math.PI;
    this.camYaw = Math.PI;
    this.camPitch = 0.3;
    this.camDist = 7.5;
    this.camCur = 7.5;
    this.camTarget = new THREE.Vector3();
    this.shake = 0;
    this.state = 'ground';
    this.anim = ANIM.IDLE;
    this.action = null;
    this.comboK = -1;
    this.comboT = 0;
    this.queued = false;
    this.atkCd = 0;
    this.bowCd = 0;
    this.healCd = 0;
    this.invuln = 0;
    this.hurtT = 0;
    this.deadT = 0;
    this.airT = 0;
    this.groundH = 0;
    this.stamina = 100;
    this.maxStamina = 100;
    this.staminaDelay = 0;
    this.exhausted = false;
    this.sprinting = false;
    this.hp = 6;
    this.maxHp = 6;
    this.lastSafe = new THREE.Vector3();
    this.safeT = 0;
    this.sendT = 0;
    this.restT = 0;
    this.resting = false;
    this.speedNow = 0;
    this.stepT = 0;
    this.lock = null; // 주목하고 있는 몬스터
    this.rig = null;
    this.buildRig();
    this.refreshStats();
    this.hp = clamp(game.save.hp || this.maxHp, 1, this.maxHp);
    this.stamina = this.maxStamina;
  }

  buildRig() {
    const scene = this.game.gfx.scene;
    if (this.rig) scene.remove(this.rig.root);
    this.rig = makeHumanoid(playerLook(this.game.save));
    scene.add(this.rig.root);
    if (!this.blob && this.game.fx) {
      this.blob = this.game.fx.makeBlob(0.55);
      scene.add(this.blob);
    }
  }

  refreshStats() {
    const s = this.game.save;
    this.maxHp = maxHpFor(s.level);
    this.maxStamina = maxStaminaFor(s.level);
    this.atk = playerAtk(s.level, s.sword);
    this.bowAtk = playerBowAtk(s.level, s.bow);
    this.def = ARMORS[s.armor].def;
    if (this.hp > this.maxHp) this.hp = this.maxHp;
  }

  profile() {
    const s = this.game.save;
    return { name: s.name, tunic: s.tunic, hair: s.hair, lvl: s.level, sword: s.sword, armor: s.armor, bow: s.bow };
  }

  teleport(x, z, yaw) {
    const h = this.game.world.heightAt(x, z);
    this.pos.set(x, Math.max(h, SWIM_Y), z);
    this.vel.set(0, 0, 0);
    this.state = 'ground';
    this.action = null;
    if (yaw !== undefined) {
      this.yaw = yaw;
      this.camYaw = yaw;
    }
    this.lock = null;
    this.game.input.autoRun = false;
    this.lastSafe.copy(this.pos);
    this.camTarget.set(x, this.pos.y + 1.45, z);
  }

  useStamina(n) {
    this.stamina -= n;
    this.staminaDelay = 0.8;
    if (this.stamina <= 0) {
      this.stamina = 0;
      this.exhausted = true;
    }
  }

  addXp(n) {
    const s = this.game.save;
    if (s.level >= MAX_LEVEL) return;
    s.xp += n;
    let leveled = false;
    while (s.level < MAX_LEVEL && s.xp >= xpNeed(s.level)) {
      s.xp -= xpNeed(s.level);
      s.level++;
      leveled = true;
    }
    if (leveled) {
      this.refreshStats();
      this.hp = this.maxHp;
      this.stamina = this.maxStamina;
      this.game.onLevelUp();
    }
  }

  heal(n) {
    this.hp = Math.min(this.maxHp, this.hp + n);
  }

  // 피해를 받는다. 실제로 맞았으면 true
  damage(amount, fromX, fromZ, opts = {}) {
    if (this.state === 'dead' || (this.invuln > 0 && !opts.force)) return false;
    const dmg = opts.raw ? amount : Math.max(1, amount - this.def);
    this.hp = Math.max(0, this.hp - dmg);
    this.invuln = 0.9;
    this.hurtT = 0.32;
    this.shake = Math.max(this.shake, 0.35);
    if (!opts.noKnock) {
      let dx = this.pos.x - fromX;
      let dz = this.pos.z - fromZ;
      const d = Math.hypot(dx, dz) || 1;
      dx /= d;
      dz /= d;
      const kb = opts.knock || 7;
      this.vel.x = dx * kb;
      this.vel.z = dz * kb;
      if (this.state === 'ground' || this.state === 'climb' || this.state === 'glide') {
        this.state = 'air';
        this.vel.y = 4.5;
        this.airT = 0.2;
      }
    }
    if (this.action && this.action.type !== 'atk') this.action = null;
    this.game.onPlayerHurt(dmg);
    if (this.hp <= 0) this.die();
    return true;
  }

  die() {
    this.state = 'dead';
    this.deadT = 4.2;
    this.action = null;
    this.lock = null;
    this.game.input.autoRun = false;
    this.vel.set(0, 0, 0);
    this.game.onPlayerDead();
  }

  respawn() {
    const g = this.game;
    const stone = g.pois.stones[g.save.lastStone] || g.pois.stones[0];
    this.hp = this.maxHp;
    this.stamina = this.maxStamina;
    this.exhausted = false;
    this.invuln = 2.5;
    this.teleport(stone.x + 1.8, stone.z + 2.2);
    g.onPlayerRespawn();
  }

  drown() {
    const g = this.game;
    this.stamina = this.maxStamina * 0.5;
    this.exhausted = false;
    this.hp = Math.max(0, this.hp - 2);
    g.onPlayerHurt(2);
    if (this.hp <= 0) {
      this.pos.copy(this.lastSafe);
      this.die();
      return;
    }
    this.teleport(this.lastSafe.x, this.lastSafe.z);
    this.invuln = 1.5;
    g.ui.toast('힘이 빠져 물가로 떠밀려 왔습니다…');
  }

  // ---------- 주목 (대상 고정) ----------
  toggleLock() {
    const g = this.game;
    if (this.lock) {
      this.lock = null;
      g.audio.click();
      return;
    }
    const e = g.ents.pickLockTarget(this.pos.x, this.pos.z, this.camYaw, 30);
    if (e) {
      this.lock = e;
      g.audio.click();
    } else g.ui.toast('주목할 몬스터가 근처에 없습니다.');
  }

  // ---------- 전투 ----------
  startAttack(dirX, dirZ, hasInput) {
    const g = this.game;
    const k = this.comboT > 0 ? (this.comboK + 1) % 3 : 0;
    this.comboK = k;
    this.action = { type: 'atk', k, t: 0, dur: k === 2 ? 0.5 : 0.36, hitAt: k === 2 ? 0.24 : 0.15, done: false };
    this.queued = false;
    const base = hasInput ? Math.atan2(dirX, dirZ) : this.yaw;
    // 주목한 대상이 닿을 거리에 있으면 그쪽을, 아니면 가까운 몬스터를 향한다
    let tgt = null;
    const lk = this.lock;
    if (lk) {
      const d = Math.hypot(lk.x - this.pos.x, lk.z - this.pos.z) - lk.info.radius;
      if (d < 7) tgt = { x: lk.x, z: lk.z, dist: Math.max(0, d), e: lk };
    }
    if (!tgt) tgt = g.ents.nearestMonster(this.pos.x, this.pos.z, 6.0, base, hasInput ? 1.9 : 2.6);
    if (tgt) this.yaw = Math.atan2(tgt.x - this.pos.x, tgt.z - this.pos.z);
    else this.yaw = base;
    if (this.state === 'ground') {
      this.vel.x = Math.sin(this.yaw) * (tgt && tgt.dist < 2.2 ? 1.5 : 5.5);
      this.vel.z = Math.cos(this.yaw) * (tgt && tgt.dist < 2.2 ? 1.5 : 5.5);
    }
    g.audio.swing(k);
  }

  doHit(k) {
    const g = this.game;
    const reach = k === 2 ? 3.6 : 3.1;
    const ids = g.ents.monstersInArc(this.pos.x, this.pos.y, this.pos.z, this.yaw, reach, k === 2 ? 1.7 : 1.5);
    g.fx.slash(this.pos.x, this.pos.y + 1.0, this.pos.z, this.yaw, k, g.save.sword);
    if (ids.length) {
      g.net.send({ t: 'a', ids, k });
      this.shake = Math.max(this.shake, k === 2 ? 0.28 : 0.14);
      g.audio.hit();
      for (const id of ids) g.ents.flashMonster(id);
    }
  }

  startBow() {
    const g = this.game;
    if (g.save.arrows <= 0) {
      g.ui.toast('화살이 없습니다. 상인에게서 살 수 있어요.');
      this.bowCd = 0.6;
      return;
    }
    // 조준: 주목한 대상 > 카메라 방향 + 가까운 적 보정 (마우스로 조준할 때만 보정을 좁게)
    const cy = this.camYaw;
    const lk = this.lock;
    const tgt = lk
      ? { x: lk.x, y: lk.y + lk.info.def.height * (lk.info.elite ? 1.45 : 1) * 0.55, z: lk.z }
      : g.ents.aimTarget(this.pos, cy, g.input.isTouch ? 0.6 : g.input.locked ? 0.24 : 0.5, 70);
    const dir = new THREE.Vector3();
    const ox = this.pos.x;
    const oy = this.pos.y + 1.3;
    const oz = this.pos.z;
    if (tgt) {
      const d = Math.hypot(tgt.x - ox, tgt.z - oz);
      const tf = d / 55;
      dir.set(tgt.x - ox, tgt.y + 0.5 * 9 * tf * tf - oy, tgt.z - oz).normalize();
    } else {
      const p = clamp(0.14 - this.camPitch * 0.55, -0.6, 0.5);
      dir.set(Math.sin(cy) * Math.cos(p), Math.sin(p), Math.cos(cy) * Math.cos(p));
    }
    this.yaw = Math.atan2(dir.x, dir.z);
    this.action = { type: 'bow', t: 0, dur: 0.5, hitAt: 0.2, done: false, dir };
  }

  shoot(dir) {
    const g = this.game;
    g.save.arrows--;
    const ox = this.pos.x + dir.x * 0.6;
    const oy = this.pos.y + 1.3;
    const oz = this.pos.z + dir.z * 0.6;
    g.ents.spawnArrow(ox, oy, oz, dir.x, dir.y, dir.z, true);
    g.net.send({ t: 'shot', x: ox, y: oy, z: oz, dx: dir.x, dy: dir.y, dz: dir.z });
    g.audio.bow();
    g.ui.dirty = true;
  }

  useBerry() {
    const g = this.game;
    if (this.healCd > 0 || this.state === 'dead') return;
    if (g.save.berries <= 0) {
      g.ui.toast('회복 열매가 없습니다.');
      this.healCd = 0.5;
      return;
    }
    if (this.hp >= this.maxHp) {
      g.ui.toast('체력이 이미 가득합니다.');
      this.healCd = 0.5;
      return;
    }
    g.save.berries--;
    this.heal(BERRY_HEAL);
    this.healCd = 0.8;
    g.fx.burst(this.pos.x, this.pos.y + 1.2, this.pos.z, 0x7dff8a, 14, 2.5);
    g.audio.heal();
    g.ui.dirty = true;
  }

  // ---------- 충돌 ----------
  pushOut(cx, cz, r) {
    const dx = this.pos.x - cx;
    const dz = this.pos.z - cz;
    const d2 = dx * dx + dz * dz;
    if (d2 >= r * r) return;
    const d = Math.sqrt(d2);
    if (d < 1e-4) {
      this.pos.x = cx + r;
      return;
    }
    this.pos.x = cx + (dx / d) * r;
    this.pos.z = cz + (dz / d) * r;
  }

  collide() {
    const p = this.pos;
    const world = this.game.world;
    const R = 0.42;
    if (p.y - this.groundH < 5) {
      const lx = p.x + W.HALF;
      const lz = p.z + W.HALF;
      const cx = Math.floor(lx / W.CHUNK);
      const cz = Math.floor(lz / W.CHUNK);
      const fx = lx - cx * W.CHUNK;
      const fz = lz - cz * W.CHUNK;
      const x0 = fx < 4 ? -1 : 0;
      const x1 = fx > W.CHUNK - 4 ? 1 : 0;
      const z0 = fz < 4 ? -1 : 0;
      const z1 = fz > W.CHUNK - 4 ? 1 : 0;
      for (let oz = z0; oz <= z1; oz++) {
        for (let ox = x0; ox <= x1; ox++) {
          const list = world.chunkProps(cx + ox, cz + oz);
          for (let i = 0; i < list.length; i++) {
            const q = list[i];
            if (q.cr > 0) this.pushOut(q.x, q.z, q.cr + R);
          }
        }
      }
      for (const c of this.game.ents.colliders) {
        if (c.hw !== undefined) {
          // 축 정렬 상자
          const dx = p.x - c.x;
          const dz = p.z - c.z;
          const ax = Math.abs(dx) - c.hw - R;
          const az = Math.abs(dz) - c.hd - R;
          if (ax < 0 && az < 0) {
            if (ax > az) p.x = c.x + Math.sign(dx || 1) * (c.hw + R);
            else p.z = c.z + Math.sign(dz || 1) * (c.hd + R);
          }
        } else this.pushOut(c.x, c.z, c.r + R);
      }
    }
    const lim = W.HALF - 6;
    p.x = clamp(p.x, -lim, lim);
    p.z = clamp(p.z, -lim, lim);
  }

  // ---------- 메인 업데이트 ----------
  update(dt) {
    const g = this.game;
    const input = g.input;
    const world = g.world;
    const save = g.save;

    this.lookIdle = input.lookDX || input.lookDY ? 0 : (this.lookIdle || 0) + dt;
    this.camYaw -= input.lookDX;
    this.camPitch = clamp(this.camPitch + input.lookDY, -0.4, 1.38);
    input.lookDX = 0;
    input.lookDY = 0;
    if (input.consume('camreset')) {
      this.camYaw = this.yaw;
      this.camPitch = 0.3;
    }
    // 주목: 켜 두면 시점이 대상을 따라간다
    if (input.consume('lock') && this.state !== 'dead') this.toggleLock();
    const lock = this.lock;
    if (lock) {
      const dl = Math.hypot(lock.x - this.pos.x, lock.z - this.pos.z);
      if (lock.dying || !lock.shown || g.ents.monsters.get(lock.id) !== lock || dl > 38 || this.state === 'dead') this.lock = null;
      else {
        if (dl > 0.6) this.camYaw += angDiff(this.camYaw, Math.atan2(lock.x - this.pos.x, lock.z - this.pos.z)) * Math.min(1, 6 * dt);
        g.ents.target = lock;
        g.ents.targetT = 0.5;
      }
    }
    if (input.zoom) {
      this.camDist = clamp(this.camDist + input.zoom * 0.9, 3.5, 16);
      input.zoom = 0;
    }
    this.invuln -= dt;
    this.hurtT -= dt;
    this.atkCd -= dt;
    this.bowCd -= dt;
    this.healCd -= dt;
    this.comboT -= dt;
    this.shake = Math.max(0, this.shake - dt * 1.6);

    if (this.state === 'dead') {
      this.deadT -= dt;
      this.anim = ANIM.DEAD;
      this.resting = false;
      const gh = world.heightAt(this.pos.x, this.pos.z);
      this.pos.y = Math.max(this.pos.y - 6 * dt, Math.max(gh, SWIM_Y));
      if (this.deadT <= 0) this.respawn();
      this.finish(dt, 0);
      return;
    }

    // 입력 방향 (카메라 기준)
    const mx = input.moveX;
    const my = input.moveY;
    const mag = Math.min(1, Math.hypot(mx, my));
    let dirX = 0;
    let dirZ = 0;
    const hasInput = mag > 0.05;
    if (hasInput) {
      const sy = Math.sin(this.camYaw);
      const cy = Math.cos(this.camYaw);
      dirX = sy * my - cy * mx;
      dirZ = cy * my + sy * mx;
      const l = Math.hypot(dirX, dirZ) || 1;
      dirX /= l;
      dirZ /= l;
    }

    // 행동 (공격·활) 진행
    let moveScale = 1;
    const act = this.action;
    if (act) {
      act.t += dt;
      if (act.type === 'atk') {
        moveScale = 0.22;
        if (!act.done && act.t >= act.hitAt) {
          act.done = true;
          this.doHit(act.k);
        }
        if (input.consume('attack')) this.queued = true;
        if (act.t >= act.dur) {
          this.action = null;
          this.comboT = 0.55;
          if (this.queued && this.state === 'ground') this.startAttack(dirX, dirZ, hasInput);
        }
      } else if (act.type === 'bow') {
        moveScale = 0.35;
        if (!act.done && act.t >= act.hitAt) {
          act.done = true;
          this.shoot(act.dir);
        }
        if (act.t >= act.dur) {
          this.action = null;
          this.bowCd = 0.15;
        }
      } else if (act.type === 'emote') {
        if (hasInput || (act.dur > 0 && act.t >= act.dur)) this.action = null;
      }
    }
    const canAct = this.state === 'ground' || this.state === 'air';
    if (!this.action || this.action.type === 'emote') {
      if (input.consume('attack') && canAct && this.atkCd <= 0) this.startAttack(dirX, dirZ, hasInput);
      else if (input.consume('bow') && canAct && this.bowCd <= 0) this.startBow();
      else if (input.consume('emote1')) this.action = { type: 'emote', anim: ANIM.WAVE, t: 0, dur: 2.2 };
      else if (input.consume('emote2')) this.action = { type: 'emote', anim: ANIM.CHEER, t: 0, dur: 2.2 };
      else if (input.consume('emote3') && this.state === 'ground') this.action = { type: 'emote', anim: ANIM.SIT, t: 0, dur: 0 };
    }
    if (input.consume('heal')) this.useBerry();

    const jumpPressed = input.consume('jump');
    this.sprinting = false;
    let moving = hasInput;
    const prevX = this.pos.x;
    const prevZ = this.pos.z;

    if (this.state === 'swim') {
      let sp = 3.7;
      let drain = hasInput ? 4.2 : 1.2;
      if (input.sprint && hasInput && !this.exhausted) {
        sp = 5.5;
        drain = 9.5;
      }
      this.useStamina(drain * dt);
      const k = Math.min(1, 5 * dt);
      this.vel.x += (dirX * sp * mag - this.vel.x) * k;
      this.vel.z += (dirZ * sp * mag - this.vel.z) * k;
      const nx = this.pos.x + this.vel.x * dt;
      const nz = this.pos.z + this.vel.z * dt;
      const ng = world.heightAt(nx, nz);
      this.groundH = ng;
      if (ng >= -1.1) {
        this.state = 'ground';
        this.pos.set(nx, ng, nz);
      } else {
        this.pos.set(nx, SWIM_Y + Math.sin(g.time * 2.6) * 0.05, nz);
        if (this.stamina <= 0) this.drown();
      }
      this.vel.y = 0;
    } else if (this.state === 'ground' || this.state === 'climb') {
      world.gradAt(this.pos.x, this.pos.z, _grad);
      const slope = Math.hypot(_grad.x, _grad.z);
      const here = world.heightAt(this.pos.x, this.pos.z);
      this.groundH = here;
      let climbing = false;
      if (slope > STEEP && here > -0.5) {
        if (this.exhausted || this.stamina <= 0) {
          // 미끄러져 내려간다
          const inv = 1 / slope;
          const k = Math.min(1, 5 * dt);
          this.vel.x += (-_grad.x * inv * 9 - this.vel.x) * k;
          this.vel.z += (-_grad.z * inv * 9 - this.vel.z) * k;
          moving = false;
        } else {
          climbing = true;
          const up = hasInput ? (dirX * _grad.x + dirZ * _grad.z) / slope : 0;
          const upc = Math.max(0, up);
          const sp = 2.5 / Math.sqrt(1 + slope * slope * upc * upc);
          const k = Math.min(1, 12 * dt);
          this.vel.x += (dirX * sp * mag * moveScale - this.vel.x) * k;
          this.vel.z += (dirZ * sp * mag * moveScale - this.vel.z) * k;
          if (hasInput) this.useStamina((up > 0.15 ? 6.5 : 2) * dt);
          if (jumpPressed && this.stamina > 12) {
            // 힘껏 뛰어오르기
            this.useStamina(16);
            const inv = 1 / slope;
            const hop = 2.0 / Math.sqrt(1 + slope * slope);
            this.pos.x += _grad.x * inv * hop;
            this.pos.z += _grad.z * inv * hop;
            g.audio.jump();
          }
        }
      } else {
        let speed = RUN * mag;
        if (input.sprint && mag > 0.5 && !this.exhausted && this.stamina > 0 && moveScale === 1) {
          speed = SPRINT;
          this.useStamina(11 * dt);
          this.sprinting = true;
        }
        const rise = dirX * _grad.x + dirZ * _grad.z;
        if (rise > 0.35) speed *= 1 - 0.45 * clamp((rise - 0.35) / 0.65, 0, 1);
        if (here < -0.3) speed *= 0.62;
        speed *= moveScale;
        const k = Math.min(1, 14 * dt);
        this.vel.x += (dirX * speed - this.vel.x) * k;
        this.vel.z += (dirZ * speed - this.vel.z) * k;
        if (jumpPressed && (!this.action || this.action.type === 'emote')) {
          this.state = 'air';
          this.vel.y = JUMP_V;
          this.airT = 0;
          this.action = null;
          g.audio.jump();
        }
      }
      if (this.state !== 'air') {
        this.state = climbing ? 'climb' : 'ground';
        const nx = this.pos.x + this.vel.x * dt;
        const nz = this.pos.z + this.vel.z * dt;
        const ng = world.heightAt(nx, nz);
        const hs = Math.hypot(this.vel.x, this.vel.z);
        if (ng < -1.25) {
          this.state = 'swim';
          this.pos.set(nx, Math.max(ng, SWIM_Y), nz);
          g.fx.splash(nx, nz);
          g.audio.splash();
        } else if (!climbing && ng < this.pos.y - (0.5 + hs * dt * 1.4)) {
          this.state = 'air';
          this.vel.y = 0;
          this.airT = 0;
          this.pos.x = nx;
          this.pos.z = nz;
        } else {
          this.pos.set(nx, ng, nz);
        }
        this.groundH = ng;
      }
    } else {
      // 공중 / 활공
      this.airT += dt;
      if (jumpPressed && this.airT > 0.12) {
        if (this.state === 'glide') this.state = 'air';
        else if (!save.glider) g.ui.toast('활공 천이 없습니다. 촌장과 이야기해 보세요.');
        else if (this.exhausted || this.stamina <= 0) g.ui.toast('기력이 부족합니다.');
        else if (this.pos.y - world.heightAt(this.pos.x, this.pos.z) > 1.2) {
          this.state = 'glide';
          this.action = null;
          g.audio.glide();
        }
      }
      if (this.state === 'glide') {
        this.useStamina(4.0 * dt);
        if (this.stamina <= 0) this.state = 'air';
        if (this.vel.y < -2.3) this.vel.y = Math.min(-2.3, this.vel.y + 55 * dt);
        else this.vel.y = Math.max(-2.3, this.vel.y - GRAV * 0.35 * dt);
        const fx = hasInput ? dirX : Math.sin(this.yaw);
        const fz = hasInput ? dirZ : Math.cos(this.yaw);
        const k = Math.min(1, 2.6 * dt);
        this.vel.x += (fx * 9.5 - this.vel.x) * k;
        this.vel.z += (fz * 9.5 - this.vel.z) * k;
        moving = true;
      } else {
        this.vel.y = Math.max(-48, this.vel.y - GRAV * dt);
        if (hasInput) {
          const k = Math.min(1, 2.4 * dt);
          this.vel.x += (dirX * RUN * mag - this.vel.x) * k;
          this.vel.z += (dirZ * RUN * mag - this.vel.z) * k;
        }
      }
      let nx = this.pos.x + this.vel.x * dt;
      let nz = this.pos.z + this.vel.z * dt;
      const ny = this.pos.y + this.vel.y * dt;
      let ng = world.heightAt(nx, nz);
      if (ng > ny + 0.8 && ng > this.pos.y + 0.8) {
        // 벽에 부딪힘
        nx = this.pos.x;
        nz = this.pos.z;
        this.vel.x *= 0.2;
        this.vel.z *= 0.2;
        ng = world.heightAt(nx, nz);
      }
      this.groundH = ng;
      if (ng < -1.25 && ny <= SWIM_Y) {
        this.pos.set(nx, SWIM_Y, nz);
        this.state = 'swim';
        if (this.vel.y < -6) {
          g.fx.splash(nx, nz);
          g.audio.splash();
        }
        this.vel.y = 0;
      } else if (ny <= ng) {
        const vy = this.vel.y;
        this.pos.set(nx, ng, nz);
        this.state = 'ground';
        this.vel.y = 0;
        if (vy < -24) {
          const dmg = 2 + Math.floor((-vy - 24) / 4);
          this.damage(dmg, nx, nz, { raw: true, noKnock: true, force: true });
          if (this.state !== 'dead') g.ui.toast('높은 곳에서 떨어졌습니다!');
        }
        if (vy < -6) {
          g.fx.dust(nx, ng, nz);
          g.audio.land();
        }
      } else {
        this.pos.set(nx, ny, nz);
      }
    }

    if (this.state !== 'dead') this.collide();
    // 충돌로 밀려난 뒤 지면 높이 보정
    if (this.state === 'ground' || this.state === 'climb') {
      this.pos.y = world.heightAt(this.pos.x, this.pos.z);
      this.groundH = this.pos.y;
    }

    // 기력 회복
    const usingNow = this.staminaDelay > 0;
    this.staminaDelay -= dt;
    if (!usingNow && this.state === 'ground') this.stamina = Math.min(this.maxStamina, this.stamina + 32 * dt);
    if (this.exhausted && this.stamina >= this.maxStamina * 0.3) this.exhausted = false;

    // 안전한 위치 기억
    this.safeT -= dt;
    if (this.safeT <= 0 && this.state === 'ground' && this.groundH > 0.6) {
      this.safeT = 0.5;
      this.lastSafe.copy(this.pos);
    }

    // 모닥불 곁 / 마을에서는 서서히 회복
    this.resting = this.state === 'ground' && g.ents.nearRest(this.pos.x, this.pos.z);
    if (this.resting && this.hp < this.maxHp) {
      this.restT += dt;
      if (this.restT > 1.4) {
        this.restT = 0;
        this.heal(1);
      }
    } else this.restT = 0;

    // 바라보는 방향
    const dxm = this.pos.x - prevX;
    const dzm = this.pos.z - prevZ;
    this.speedNow = Math.hypot(dxm, dzm) / Math.max(dt, 1e-4);
    // 설정에서 켰다면: 시점을 직접 돌리지 않는 동안, 움직이는 방향으로 시점이 천천히 따라간다
    if (save.settings.follow && hasInput && !this.lock && this.lookIdle > 0.7 && this.speedNow > 1.5) {
      const off = angDiff(this.camYaw, Math.atan2(dirX, dirZ));
      // 카메라 쪽으로 달려올 때는 돌리지 않는다 (시점이 뒤집히지 않게)
      if (Math.abs(off) < 2.2) this.camYaw += off * Math.min(1, 1.1 * dt);
    }
    const locked = this.action && (this.action.type === 'atk' || this.action.type === 'bow');
    if (hasInput && !locked) {
      const want = Math.atan2(dirX, dirZ);
      this.yaw += angDiff(this.yaw, want) * Math.min(1, 13 * dt);
    }

    // 애니메이션 선택
    let anim = ANIM.IDLE;
    const a = this.action;
    if (this.hurtT > 0) anim = ANIM.HURT;
    else if (a && a.type === 'atk') anim = ANIM.ATK1 + a.k;
    else if (a && a.type === 'bow') anim = ANIM.BOW;
    else if (this.state === 'swim') anim = hasInput ? ANIM.SWIM : ANIM.SWIMIDLE;
    else if (this.state === 'climb') anim = hasInput ? ANIM.CLIMB : ANIM.CLIMBIDLE;
    else if (this.state === 'glide') anim = ANIM.GLIDE;
    else if (this.state === 'air') anim = this.vel.y > 1 ? ANIM.JUMP : ANIM.FALL;
    else if (a && a.type === 'emote') anim = a.anim;
    else if (moving && this.speedNow > 0.6) anim = this.sprinting ? ANIM.SPRINT : ANIM.RUN;
    this.anim = anim;

    // 발소리 / 먼지
    if (this.state === 'ground' && this.speedNow > 2) {
      this.stepT -= dt * this.speedNow;
      if (this.stepT <= 0) {
        this.stepT = 2.6;
        g.audio.step(this.groundH < -0.2);
        if (this.sprinting) g.fx.dust(this.pos.x, this.pos.y, this.pos.z, 3);
      }
    }
    this.finish(dt, this.speedNow);
  }

  finish(dt, speed) {
    const g = this.game;
    const rig = this.rig;
    const a = this.action;
    const atkP = a && a.type === 'atk' ? Math.min(1, a.t / (a.dur * 0.75)) : 0;
    animateHumanoid(rig, this.anim, dt, speed, atkP);
    rig.root.position.copy(this.pos);
    rig.root.rotation.y = this.yaw;
    if (this.blob) {
      const show = !g.gfx.quality.shadows && this.state !== 'swim' && rig.root.visible;
      this.blob.visible = show;
      if (show) {
        const gh = Math.max(g.world.heightAt(this.pos.x, this.pos.z), 0);
        const k = Math.max(0.35, 1 - (this.pos.y - gh) * 0.07);
        this.blob.position.set(this.pos.x, gh + 0.06, this.pos.z);
        this.blob.scale.setScalar(0.55 * k);
      }
    }
    // 피격 무적 중 깜빡임
    rig.root.visible = !(this.invuln > 0 && this.state !== 'dead' && Math.floor(g.time * 16) % 2 === 0 && this.invuln < 0.9);

    // 서버로 상태 전송
    this.sendT -= dt * 1000;
    if (this.sendT <= 0) {
      this.sendT = SEND_MS;
      g.net.sendBin(encodeState(this.pos.x, this.pos.y, this.pos.z, this.yaw, this.anim, this.hp, 0));
    }
    this.updateCamera(dt);
  }

  updateCamera(dt) {
    const g = this.game;
    const world = g.world;
    const cam = g.gfx.camera;
    const tx = this.pos.x;
    const ty = this.pos.y + (this.state === 'swim' ? 1.0 : 1.5);
    const tz = this.pos.z;
    const k = Math.min(1, 14 * dt);
    this.camTarget.x += (tx - this.camTarget.x) * k;
    this.camTarget.y += (ty - this.camTarget.y) * Math.min(1, 9 * dt);
    this.camTarget.z += (tz - this.camTarget.z) * k;
    const cp = Math.cos(this.camPitch);
    const dx = -Math.sin(this.camYaw) * cp;
    const dy = Math.sin(this.camPitch);
    const dz = -Math.cos(this.camYaw) * cp;
    // 지형에 가려지지 않도록 거리 조절
    let want = this.camDist;
    const STEPS = 10;
    for (let s = 1; s <= STEPS; s++) {
      const d = (this.camDist * s) / STEPS;
      const x = this.camTarget.x + dx * d;
      const y = this.camTarget.y + dy * d;
      const z = this.camTarget.z + dz * d;
      if (y < world.heightAt(x, z) + 0.45) {
        want = Math.max(1.2, (this.camDist * (s - 1)) / STEPS);
        break;
      }
    }
    this.camCur += (want - this.camCur) * Math.min(1, (want < this.camCur ? 20 : 4) * dt);
    const d = this.camCur;
    _v.set(this.camTarget.x + dx * d, this.camTarget.y + dy * d, this.camTarget.z + dz * d);
    const floor = Math.max(world.heightAt(_v.x, _v.z), 0) + 0.4;
    if (_v.y < floor) _v.y = floor;
    if (this.shake > 0) {
      _v.x += (Math.random() - 0.5) * this.shake * 0.5;
      _v.y += (Math.random() - 0.5) * this.shake * 0.5;
      _v.z += (Math.random() - 0.5) * this.shake * 0.5;
    }
    cam.position.copy(_v);
    cam.lookAt(this.camTarget);
  }
}

export { setWeapon };

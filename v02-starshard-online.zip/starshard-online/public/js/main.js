// 별조각 원정대 - 게임 시작점. 각 모듈을 연결하고 메인 루프를 돌린다.
import { createWorld, exclusionsFor, VILLAGE, VOLCANO, BIOME_INFO, NB } from '/shared/world.js';
import { DAY_MS, SHARD_COUNT, VILLAGE_LAYOUT, MON } from '/shared/defs.js';
import { createGfx, QUALITY } from './gfx.js';
import { probeGraphics } from './post.js';
import { Terrain } from './terrain.js';
import { initModels } from './models.js';
import { Input } from './input.js';
import { Net } from './net.js';
import { Player } from './player.js';
import { Entities } from './entities.js';
import { WorldObjects, chestLoot } from './objects.js';
import { Fx } from './fx.js';
import { UI } from './ui.js';
import { GameAudio } from './audio.js';
import { loadSave, storeSave, storeSaveNow, defaultSave } from './save.js';

const params = new URLSearchParams(location.search);
const canvas = document.getElementById('game');

const game = {
  save: loadSave(),
  params,
  time: 0,
  playing: false,
  ready: false,
  world: null,
  pois: null,
  gfx: null,
  terrain: null,
  objects: null,
  ents: null,
  fx: null,
  player: null,
  input: null,
  net: new Net(),
  audio: new GameAudio(),
  ui: null,
  shards: new Set(),
  sealed: new Set(),
  bossState: 'sleep',
  cycle: 0,
  worldId: '',
  myId: 0,
  currentInteract: null,
  fpsT: 0,
  fpsN: 0,
  slowWindows: 0,

  saveSoon() {
    storeSave(this.save);
  },

  // ---------------- 시작 ----------------
  async boot() {
    this.input = new Input(canvas);
    document.body.classList.toggle('touch', this.input.isTouch);
    this.ui = new UI(this);
    // 키보드를 누르면 키보드 조작 화면으로, 화면을 터치하면 터치 조작 화면으로 바뀐다
    this.input.onMode = (touch) => {
      document.body.classList.toggle('touch', touch);
      this.ui.onInputMode(touch);
    };
    this.input.onUiKey = (e, typing) => this.ui.handleKey(e, typing);
    this.input.blocked = () => this.ui.anyOpen();
    this.input.sens = this.save.settings.sens || 1;
    this.audio.soundOn = this.save.settings.sound;
    this.audio.musicOn = this.save.settings.music;

    this.ui.titleStatus('서버에서 세계 정보를 받는 중…', false);
    let data;
    for (let attempt = 0; ; attempt++) {
      try {
        const res = await fetch('/world', { cache: 'no-cache' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        data = await res.json();
        break;
      } catch (err) {
        this.ui.titleStatus(`서버를 깨우는 중입니다… 잠시만 기다려 주세요 (${attempt + 1})`, false);
        await new Promise((r) => setTimeout(r, 2500));
      }
    }
    this.pois = data;
    this.ui.titleStatus('섬을 만드는 중…', false);
    await nextFrame();

    // 월드 생성 (서버와 같은 seed -> 같은 지형)
    this.world = createWorld(data.seed, { weights: true });
    this.world.applyPatches(data.patches);
    this.world.setExclusions(exclusionsFor(data));

    const support = probeGraphics();
    let q = params.get('q') || this.save.settings.quality;
    if (!QUALITY[q]) {
      const lowMem = navigator.deviceMemory && navigator.deviceMemory <= 3;
      q = support.software ? 'low' : this.input.isTouch ? (lowMem ? 'low' : 'medium') : 'high';
    }
    // 시험용: ?debug&qo=grass:0,msaa:0 처럼 품질 항목을 덮어쓴다
    if (params.has('debug') && params.get('qo')) {
      for (const kv of params.get('qo').split(',')) {
        const [k, v] = kv.split(':');
        if (k in QUALITY[q]) QUALITY[q][k] = v === 'true' ? true : v === 'false' ? false : +v;
      }
    }
    this.gfx = createGfx(canvas, q, support);
    initModels(this.gfx);
    this.terrain = new Terrain(this.gfx, this.world, data);
    this.ui.buildMapCanvas(this.terrain.mapPixels);
    this.terrain.buildTerrain();
    this.ui.titleStatus('나무를 심는 중…', false);
    await nextFrame();
    this.terrain.buildProps();
    this.terrain.setupGrass();
    this.fx = new Fx(this.gfx, this.world);
    this.objects = new WorldObjects(this);
    this.ents = new Entities(this);
    this.ents.objects = this.objects;
    this.ents.colliders = this.objects.colliders;
    this.ents.setSpawns(data.spawns, 0);
    this.objects.setStones(this.save.stones);
    this.objects.setShards(this.shards, this.sealed);
    this.player = new Player(this);
    this.spawnAtStone(this.save.lastStone);
    this.player.rig.root.visible = false;

    this.net.onJson = (m) => this.onMessage(m);
    this.net.onBinary = (dv) => this.ents.onSnapshot(dv);
    this.net.onStatus = (s) => this.onNetStatus(s);

    // 휴대폰에서 탭이 오래 뒤에 있으면 그래픽 컨텍스트를 잃을 수 있다 -> 돌아오면 새로 고침
    canvas.addEventListener('webglcontextlost', (e) => {
      e.preventDefault();
      this.persist();
      this.ui.netStatus('화면을 다시 불러오는 중…');
    });
    canvas.addEventListener('webglcontextrestored', () => location.reload());
    window.addEventListener('resize', () => this.onResize());
    window.addEventListener('orientationchange', () => setTimeout(() => this.onResize(), 250));
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) this.persist();
    });
    window.addEventListener('pagehide', () => this.persist());
    setInterval(() => this.persist(), 8000);

    this.ready = true;
    this.ui.titleStatus('준비 완료! 이름을 정하고 모험을 시작하세요.', true);
    document.getElementById('title').classList.add('reveal');
    if (params.has('debug')) {
      window.__game = this;
      window.__models = await import('./models.js');
    }
    requestAnimationFrame((t) => this.loop(t));
    if (params.has('auto')) {
      this.save.name = params.get('name') || this.save.name || '모험가';
      this.startPlay();
    }
  },

  spawnAtStone(id) {
    const st = this.pois.stones[id];
    if (!st || id === 0) {
      this.player.teleport(VILLAGE.x + VILLAGE_LAYOUT.spawn.x, VILLAGE.z + VILLAGE_LAYOUT.spawn.z, Math.PI);
    } else this.player.teleport(st.x + 1.8, st.z + 2.2);
    if (params.has('pos')) {
      const [x, z] = params.get('pos').split(',').map(Number);
      this.player.teleport(x, z);
    }
  },

  startPlay() {
    if (!this.ready || this.playing) return;
    this.audio.start();
    this.audio.click();
    this.playing = true;
    this.player.buildRig();
    this.player.refreshStats();
    this.ui.titleStatus('접속 중…');
    this.net.start(() => ({ prof: this.player.profile(), save: this.save.world }));
    storeSaveNow(this.save);
  },

  persist() {
    if (!this.player) return;
    this.save.hp = this.player.hp;
    storeSaveNow(this.save);
  },

  onNetStatus(s) {
    if (s === 'online') this.ui.netStatus('');
    else if (s === 'lost' || s === 'reconnecting' || s === 'failed') {
      if (this.input.enabled) this.ui.netStatus('연결이 끊겼습니다. 다시 접속하는 중…');
      else this.ui.titleStatus('서버에 연결하는 중… (무료 서버는 깨어나는 데 1분쯤 걸릴 수 있어요)');
    }
  },

  // ---------------- 서버 메시지 ----------------
  onMessage(m) {
    const { ui, ents, fx, audio, player, save } = this;
    switch (m.t) {
      case 'welcome': {
        if (m.seed !== this.pois.seed) {
          location.reload();
          return;
        }
        this.myId = m.id;
        ents.myId = m.id;
        ents.clearPlayers();
        ents.clearMonsters();
        for (const p of m.players) ents.addPlayer(p);
        this.applyWorld(m.state, 'init');
        if (!this.input.enabled) {
          this.input.enabled = true;
          player.rig.root.visible = true;
          ui.showGame();
          ui.chatAdd('', `${save.name} 님, 별조각 원정대에 오신 것을 환영합니다!`, 'sys');
          if (m.players.length) ui.chatAdd('', `지금 ${m.players.map((p) => p.name).join(', ')} 님이 함께 있어요.`, 'sys');
          if (!save.seenHelp) {
            save.seenHelp = true;
            ui.open('panel-help', false);
          } else if (!this.input.isTouch) ui.toast('방향키나 마우스로 시점을 돌릴 수 있어요 · H: 조작법');
        } else ui.toast('다시 연결되었습니다.', true);
        break;
      }
      case 'full':
        ui.titleStatus(`서버가 가득 찼습니다 (최대 ${m.max}명). 잠시 후 다시 시도해 주세요.`);
        ui.netStatus('서버가 가득 찼습니다.');
        break;
      case 'pj':
        ents.addPlayer(m.p);
        ui.chatAdd('', `${m.p.name} 님이 들어왔습니다.`, 'sys');
        audio.chat();
        break;
      case 'pl': {
        const e = ents.players.get(m.id);
        if (e) ui.chatAdd('', `${e.prof.name} 님이 나갔습니다.`, 'sys');
        ents.removePlayer(m.id);
        break;
      }
      case 'pp':
        ents.updatePlayerProfile(m.p);
        break;
      case 'world':
        this.applyWorld(m.state, m.ev);
        break;
      case 'seal':
        if (m.v) this.sealed.add(m.id);
        else {
          this.sealed.delete(m.id);
          const sh = this.objects.shards[m.id];
          if (sh && !sh.collected && Math.hypot(sh.x - player.pos.x, sh.z - player.pos.z) < 80) {
            ui.toast('수호자가 쓰러졌습니다! 별조각의 봉인이 풀렸어요.', true);
            fx.ring(sh.x, sh.y + 2.5, sh.z, 0xfff2a8, 5, 0.7);
          }
        }
        this.objects.setShards(this.shards, this.sealed);
        break;
      case 'sg': {
        const sh = this.objects.shards[m.id];
        const who = m.by === this.myId ? save.name : ents.players.get(m.by)?.prof.name || '누군가';
        ui.banner(`별조각 획득! ${m.n}/${SHARD_COUNT}`, `${who} 님이 「${sh.def.name}」의 별조각을 찾았습니다`);
        ui.chatAdd('', `${who} 님이 「${sh.def.name}」의 별조각을 찾았습니다! (${m.n}/${SHARD_COUNT})`, 'sys');
        audio.shard();
        fx.burst(sh.x, sh.y + 2.5, sh.z, 0xfff2a8, 50, 8, { size: 0.5, life: 1.2, grav: 2 });
        fx.ring(sh.x, sh.y + 0.6, sh.z, 0xfff2a8, 9, 0.9);
        // 모두에게 보상
        player.heal(99);
        player.addXp(40 + m.n * 12);
        save.gold += 30 + m.n * 5;
        fx.burst(player.pos.x, player.pos.y + 1, player.pos.z, 0xfff2a8, 20, 4, { size: 0.35, life: 0.9, grav: -1 });
        this.saveSoon();
        break;
      }
      case 'h':
        ents.onHit(m);
        break;
      case 'md': {
        const e = ents.onMonsterDead(m);
        if (m.to.includes(this.myId)) {
          const info = ents.spawnInfo[m.id];
          const x = e ? e.x : player.pos.x;
          const y = (e ? e.y : player.pos.y) + 1.6;
          const z = e ? e.z : player.pos.z;
          player.addXp(m.xp);
          save.gold += m.g;
          save.kills++;
          fx.text(x, y, z, `+${m.xp} 경험치`, 'xp');
          if (m.g > 0) fx.text(x, y - 0.5, z, `+${m.g} 골드`, 'gold');
          // 가끔 열매나 화살을 떨어뜨린다
          const r = Math.random();
          if (r < 0.16 || (info && info.type === 'golem')) {
            save.berries++;
            ui.toast('회복 열매를 주웠습니다.');
          } else if (r < 0.4) {
            save.arrows += 3;
            ui.toast('화살 3개를 주웠습니다.');
          }
          audio.coin();
          this.saveSoon();
        }
        break;
      }
      case 'ma':
        ents.onMonsterAttack(m);
        break;
      case 'pr':
        ents.onProjectile(m);
        break;
      case 'shot':
        ents.spawnArrow(m.x, m.y, m.z, m.dx, m.dy, m.dz, false);
        break;
      case 'chat':
        ui.chatAdd(m.name, m.text, m.id === this.myId ? 'me' : '');
        if (m.id !== this.myId) audio.chat();
        break;
      case 'sys':
        ui.chatAdd('', m.text, 'sys');
        if (m.text.startsWith('수호자')) ui.toast(m.text);
        break;
      default:
    }
  },

  applyWorld(st, ev) {
    const { ui, save, audio } = this;
    this.worldId = st.worldId;
    this.cycle = st.cycle;
    this.shards = new Set(st.shards);
    this.sealed = new Set(st.sealed);
    this.bossState = st.boss;
    this.ents.cycle = st.cycle;
    this.objects.setShards(this.shards, this.sealed);
    // 세계가 바뀌면(새 순환) 보물상자가 다시 채워진다
    const key = `${st.worldId}:${st.cycle}`;
    if (save.chestKey !== key) {
      save.chestKey = key;
      save.chests = [];
      this.objects.resetChests();
    }
    save.world = { worldId: st.worldId, cycle: st.cycle, shards: st.shards };
    this.saveSoon();
    if (ev === 'boss-awake') {
      ui.banner('그림자 군주가 깨어났다!', '화산 협곡을 지나 분화구로 향하세요');
      ui.chatAdd('', '열두 별조각이 모두 모였습니다. 잿불 화산 분화구에서 그림자 군주가 깨어났습니다!', 'sys');
      audio.roar();
    } else if (ev === 'victory') {
      ui.banner('승리!', '그림자 군주를 쓰러뜨렸습니다 — 섬에 빛이 돌아옵니다');
      ui.chatAdd('', '그림자 군주가 쓰러졌습니다! 잠시 후 더 강한 새 순환이 시작됩니다.', 'sys');
      audio.victory();
      this.fireworks = 12;
    } else if (ev === 'cycle') {
      ui.banner(`${st.cycle + 1}번째 순환`, '별조각이 다시 흩어졌습니다. 몬스터가 더 강해졌어요!');
      audio.stone();
    } else if (ev === 'restore') {
      ui.toast('이전 모험의 진행 상황을 불러왔습니다.', true);
    }
  },

  // ---------------- 게임 이벤트 ----------------
  onPlayerHurt(dmg) {
    this.ui.hurtFlash();
    this.audio.hurt();
    const p = this.player.pos;
    this.fx.text(p.x, p.y + 2.1, p.z, `-${dmg % 2 ? (dmg / 2).toFixed(1) : dmg / 2}♥`, 'hurt');
    this.fx.burst(p.x, p.y + 1.1, p.z, 0xff5a5f, 8, 3.5, { size: 0.3, life: 0.4 });
  },

  onPlayerDead() {
    this.audio.death();
    this.ui.closeAll();
  },

  onPlayerRespawn() {
    this.ui.toast('귀환석에서 다시 일어났습니다.');
    const p = this.player.pos;
    this.fx.ring(p.x, p.y + 0.3, p.z, 0x5fe0ff, 4, 0.7);
  },

  onLevelUp() {
    const s = this.save;
    this.ui.banner('레벨 업!', `Lv.${s.level} — 하트와 기력이 늘어났습니다`);
    this.audio.levelUp();
    const p = this.player.pos;
    this.fx.ring(p.x, p.y + 0.3, p.z, 0xffd35a, 5, 0.8);
    this.fx.burst(p.x, p.y + 1, p.z, 0xffd35a, 30, 5, { size: 0.4, life: 1, grav: -2 });
    this.net.send({ t: 'prof', prof: this.player.profile() });
    this.saveSoon();
  },

  onEquipChanged() {
    this.player.refreshStats();
    this.player.buildRig();
    this.net.send({ t: 'prof', prof: this.player.profile() });
  },

  onElderIntro() {
    const s = this.save;
    s.talkedElder = true;
    s.glider = true;
    this.ui.banner('활공 천을 얻었다!', '공중에서 점프를 한 번 더 누르면 날 수 있습니다');
    this.audio.chest();
    this.ui.toast('지도에 별조각 위치가 표시되었습니다.', true);
    this.saveSoon();
  },

  onBushPicked(b) {
    this.objects.pickBush(b);
    this.save.berries++;
    this.audio.pickup();
    this.fx.text(b.x, b.y + 1.4, b.z, '+1 회복 열매', 'heal');
    this.fx.burst(b.x, b.y + 0.8, b.z, 0xe0304a, 8, 2.5, { size: 0.25, life: 0.4 });
    this.saveSoon();
  },

  // 상황에 맞는 한 번짜리 도움말과 지역 진입 알림
  tips(dt) {
    const { player, save, ui } = this;
    const seen = save.tips || (save.tips = {});
    const tip = (key, text) => {
      if (seen[key]) return;
      seen[key] = 1;
      ui.toast(text);
      this.saveSoon();
    };
    if (player.state === 'swim') tip('swim', '헤엄치는 동안에는 기력이 줄어듭니다. 바닥나기 전에 뭍으로 올라가세요.');
    else if (player.state === 'climb') tip('climb', '가파른 곳은 기력을 써서 오릅니다. 완만한 곳에서 쉬면 기력이 회복돼요.');
    else if (player.state === 'glide') tip('glide', '활공 중에도 기력이 줄어듭니다. 점프를 다시 누르면 천을 접습니다.');
    if (player.exhausted) tip('tired', '기력이 바닥났습니다! 막대가 다시 찰 때까지 달리기·등반·활공을 할 수 없어요.');
    if (player.hp > 0 && player.hp <= 2 && save.berries > 0) tip('lowhp', this.input.isTouch ? '체력이 위험합니다! 열매 버튼으로 회복하세요.' : '체력이 위험합니다! Q 키로 회복 열매를 드세요.');
    // 새 지역에 들어서면 알려 준다
    const b = this.world.biomeAt(player.pos.x, player.pos.z);
    if (b !== this.curBiome) {
      this.biomeT = (this.biomeT || 0) + dt;
      if (this.biomeT > 2.5) {
        const first = this.curBiome === undefined;
        this.curBiome = b;
        this.biomeT = 0;
        const info = BIOME_INFO[b];
        if (!first && Math.hypot(player.pos.x - VILLAGE.x, player.pos.z - VILLAGE.z) > 60) {
          const hard = info.level > save.level + 3;
          ui.region(info.name, hard ? `몬스터 Lv.${info.level} · 지금은 위험한 곳입니다` : `몬스터 Lv.${info.level}`, hard);
        }
      }
    } else this.biomeT = 0;
  },

  questGoal() {
    const s = this.save;
    if (!s.talkedElder) return this.objects.npcs[0];
    if (this.bossState === 'awake') return { x: VOLCANO.x, z: VOLCANO.z };
    if (this.bossState === 'dead') return null;
    let best = null;
    let bd = Infinity;
    const p = this.player.pos;
    for (const sh of this.objects.shards) {
      if (sh.collected) continue;
      const d = Math.hypot(sh.x - p.x, sh.z - p.z);
      if (d < bd) {
        bd = d;
        best = sh;
      }
    }
    return best;
  },

  interact() {
    const it = this.currentInteract;
    const { ui, save, audio, fx, player } = this;
    if (!it || player.state === 'dead' || ui.anyOpen()) return;
    const o = it.ref;
    if (it.kind === 'npc') {
      ui.talk(o);
      audio.click();
    } else if (it.kind === 'chest') {
      o.open = true;
      save.chests.push(o.def.id);
      const loot = chestLoot(o.def);
      save.gold += loot.gold;
      save.berries += loot.berries;
      save.arrows += loot.arrows;
      audio.chest();
      fx.burst(o.x, o.y + 0.8, o.z, 0xffd35a, 22, 4, { size: 0.35, life: 0.8, grav: 3 });
      ui.toast(`보물상자: 골드 +${loot.gold}${loot.berries ? `, 열매 +${loot.berries}` : ''}, 화살 +${loot.arrows}`, true);
      this.saveSoon();
    } else if (it.kind === 'shard') {
      if (o.sealed) {
        ui.toast('수호자를 모두 쓰러뜨려야 봉인이 풀립니다!');
        audio.deny();
      } else this.net.send({ t: 'shard', id: o.def.id });
    } else if (it.kind === 'stone') {
      if (!o.active) {
        save.stones.push(o.def.id);
        save.lastStone = o.def.id;
        this.objects.setStones(save.stones);
        audio.stone();
        fx.ring(o.x, o.y + 0.5, o.z, 0x5fe0ff, 6, 0.8);
        fx.burst(o.x, o.y + 3, o.z, 0x5fe0ff, 26, 4, { size: 0.35, life: 0.9, grav: -1 });
        ui.banner('귀환석을 깨웠다', `${o.def.name} — 지도에서 언제든 이곳으로 이동할 수 있습니다`);
        this.saveSoon();
      } else {
        save.lastStone = o.def.id;
        ui.open('panel-map');
      }
    }
  },

  fastTravel(stone) {
    const p = this.player;
    if (p.state === 'dead') return;
    this.fx.ring(p.pos.x, p.pos.y + 0.3, p.pos.z, 0x5fe0ff, 4, 0.5);
    p.teleport(stone.x + 1.8, stone.z + 2.2);
    this.save.lastStone = stone.def.id;
    this.audio.stone();
    this.fx.ring(p.pos.x, p.pos.y + 0.3, p.pos.z, 0x5fe0ff, 5, 0.8);
    this.ui.toast(`${stone.def.name}(으)로 이동했습니다.`);
  },

  setQuality(name) {
    this.gfx.setQuality(name);
    this.terrain.setupGrass();
    this.save.settings.quality = name;
    this.fx.resize();
    this.saveSoon();
  },

  resetCharacter() {
    const keep = this.save;
    const fresh = defaultSave();
    fresh.name = keep.name;
    fresh.tunic = keep.tunic;
    fresh.hair = keep.hair;
    fresh.settings = keep.settings;
    fresh.world = keep.world;
    storeSaveNow(fresh);
    this.save = fresh;
    location.reload();
  },

  onResize() {
    if (!this.gfx) return;
    this.gfx.resize();
    this.fx.resize();
    this.ui.checkRotate();
  },

  // ---------------- 메인 루프 ----------------
  loop(now) {
    requestAnimationFrame((t) => this.loop(t));
    const t = now / 1000;
    let dt = t - (this.lastT || t);
    this.lastT = t;
    const realDt = Math.min(Math.max(dt, 0), 1); // 프레임 속도 측정용 (실제 흐른 시간)
    if (dt > 0.1) dt = 0.1;
    if (dt <= 0) dt = 0.001;
    this.time += dt;
    const { gfx, input, player, ui } = this;

    if (this.input.enabled) {
      input.update(dt);
      // 메뉴가 열려 있는 동안의 키는 ui.handleKey 가 처리한다. 여기서는 게임 중 단축키만.
      if (ui.anyOpen()) input.pressed.clear();
      else {
        if (input.consume('menu')) ui.openMenu();
        else if (input.consume('map')) ui.open('panel-map');
        else if (input.consume('bag')) ui.open('panel-bag');
        else if (input.consume('help')) ui.open('panel-help');
        else if (input.consume('chat')) ui.openChat();
        if (input.consume('autorun') && player.state !== 'dead') {
          input.autoRun = !input.autoRun;
          this.audio.click();
        }
        if (input.consume('interact')) this.interact();
      }

      player.update(dt);
      this.currentInteract = player.state === 'dead' ? null : this.objects.nearest(player.pos.x, player.pos.z);
      this.ents.update(dt, this.time);
      this.objects.update(dt, this.time, player.pos.x, player.pos.z);
      this.terrain.update(player.pos.x, player.pos.z);
      this.fx.ambient(dt, this.time, player.pos.x, player.pos.y, player.pos.z, gfx.night, gfx.quality.ambient);
      gfx.setMood(this.world.bw, this.world.vertIndex(player.pos.x, player.pos.z) * NB, dt);
      gfx.uPlayer.value.copy(player.pos);
      ui.update(dt);
      this.tips(dt);
      if (this.fireworks > 0 && Math.random() < dt * 4) {
        this.fireworks -= 0.25;
        const cols = [0xffd35a, 0xff5ad0, 0x5fe0ff, 0x7dff8a, 0xffffff];
        const a = Math.random() * 6.28;
        this.fx.burst(player.pos.x + Math.cos(a) * 12, player.pos.y + 10 + Math.random() * 8, player.pos.z + Math.sin(a) * 12, cols[Math.floor(Math.random() * cols.length)], 40, 9, { size: 0.5, life: 1.3, grav: 4, up: 0.5 });
      }
    } else {
      // 시작 화면: 마을 주변을 천천히 도는 카메라
      const a = this.time * 0.06 + 0.6;
      const cx = VILLAGE.x + Math.sin(a) * 78;
      const cz = VILLAGE.z + Math.cos(a) * 78;
      gfx.camera.position.set(cx, Math.max(this.world.heightAt(cx, cz), 0) + 34, cz);
      gfx.camera.lookAt(VILLAGE.x, VILLAGE.h + 6, VILLAGE.z);
      this.objects.update(dt, this.time, VILLAGE.x, VILLAGE.z);
      this.terrain.update(VILLAGE.x, VILLAGE.z);
      this.fx.ambient(dt, this.time, VILLAGE.x, VILLAGE.h, VILLAGE.z, gfx.night, gfx.quality.ambient);
      gfx.uPlayer.value.set(VILLAGE.x, VILLAGE.h, VILLAGE.z);
    }

    this.fx.update(dt, this.time);
    const todParam = params.get('tod');
    const tod = todParam !== null ? +todParam : ((this.net.serverNow() % DAY_MS) / DAY_MS + 0.12) % 1;
    const focus = this.input.enabled ? player.pos : gfx.camera.position;
    gfx.update(tod, this.time, dt, focus);
    this.audio.night = gfx.night;
    gfx.render();

    // 너무 느리면 그래픽 품질을 자동으로 낮춘다
    this.fpsT += realDt;
    this.fpsN++;
    if (this.fpsT >= 4) {
      const fps = this.fpsN / this.fpsT;
      this.fps = fps;
      this.fpsT = 0;
      this.fpsN = 0;
      if (this.input.enabled && !document.hidden && !params.has('q')) {
        this.slowWindows = fps < 24 ? this.slowWindows + 1 : 0;
        this.fastWindows = fps > 52 ? (this.fastWindows || 0) + 1 : 0;
        if (this.slowWindows >= 2) {
          this.slowWindows = 0;
          if (gfx.resScale > 0.7 && (fps >= 14 || gfx.qualityName === 'low')) {
            // 조금 느린 정도면 먼저 해상도를 낮춰 본다
            gfx.setResScale(gfx.resScale > 0.9 ? 0.82 : 0.68);
            this.fx.resize();
          } else if (gfx.qualityName !== 'low') {
            this.setQuality(gfx.qualityName === 'high' ? 'medium' : 'low');
            ui.toast('부드러운 화면을 위해 그래픽 품질을 낮췄습니다.');
          }
        } else if (this.fastWindows >= 5 && gfx.resScale < 1 && (this.resRaises || 0) < 2) {
          // 여유가 생기면 해상도를 되돌린다 (오르내림을 막기 위해 두 번까지만)
          this.fastWindows = 0;
          this.resRaises = (this.resRaises || 0) + 1;
          gfx.setResScale(gfx.resScale < 0.75 ? 0.82 : 1);
          this.fx.resize();
        }
      }
    }
  },
};

function nextFrame() {
  return new Promise((r) => requestAnimationFrame(() => r()));
}

game.boot().catch((err) => {
  console.error(err);
  const el = document.getElementById('title-status');
  if (el) el.textContent = '게임을 시작하지 못했습니다: ' + err.message;
});

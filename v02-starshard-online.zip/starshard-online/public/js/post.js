// 후처리: HDR 장면 -> 빛 번짐(블룸) -> 톤매핑·색 보정 -> 화면
import * as THREE from '/vendor/three/three.module.js';
import { TONE_FN } from './shade.js';

const VERT = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = position.xy * 0.5 + 0.5;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}`;

// 밝은 부분만 뽑아 내며 절반 크기로 줄인다
const FRAG_PREFILTER = /* glsl */ `
uniform sampler2D tSrc;
uniform vec2 uTexel;
uniform float uThreshold;
uniform float uKnee;
varying vec2 vUv;
void main() {
  vec3 c = texture2D(tSrc, vUv + uTexel * vec2(-1.0, -1.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2(1.0, -1.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2(-1.0, 1.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2(1.0, 1.0)).rgb;
  c *= 0.25;
  c = min(c, vec3(14.0));
  float br = max(c.r, max(c.g, c.b));
  float soft = clamp(br - uThreshold + uKnee, 0.0, 2.0 * uKnee);
  soft = soft * soft / (4.0 * uKnee + 0.0001);
  float contrib = max(soft, br - uThreshold) / max(br, 0.0001);
  gl_FragColor = vec4(c * contrib, 1.0);
}`;

const FRAG_DOWN = /* glsl */ `
uniform sampler2D tSrc;
uniform vec2 uTexel;
varying vec2 vUv;
void main() {
  vec3 c = texture2D(tSrc, vUv).rgb * 4.0;
  c += texture2D(tSrc, vUv + uTexel * vec2(-1.0, -1.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2(1.0, -1.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2(-1.0, 1.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2(1.0, 1.0)).rgb;
  gl_FragColor = vec4(c / 8.0, 1.0);
}`;

const FRAG_UP = /* glsl */ `
uniform sampler2D tSrc;
uniform vec2 uTexel;
varying vec2 vUv;
void main() {
  vec3 c = texture2D(tSrc, vUv + uTexel * vec2(-2.0, 0.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2(2.0, 0.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2(0.0, -2.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2(0.0, 2.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2(-1.0, -1.0)).rgb * 2.0;
  c += texture2D(tSrc, vUv + uTexel * vec2(1.0, -1.0)).rgb * 2.0;
  c += texture2D(tSrc, vUv + uTexel * vec2(-1.0, 1.0)).rgb * 2.0;
  c += texture2D(tSrc, vUv + uTexel * vec2(1.0, 1.0)).rgb * 2.0;
  gl_FragColor = vec4(c / 12.0, 1.0);
}`;

const FRAG_FINAL = /* glsl */ `
uniform sampler2D tScene;
uniform sampler2D tBloom;
uniform vec2 uTexel;
uniform float uBloom;
uniform float uExposure;
uniform float uSaturation;
uniform float uContrast;
uniform float uVignette;
uniform vec3 uTint;
varying vec2 vUv;
${TONE_FN}
float hash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}
void main() {
  vec3 c = texture2D(tScene, vUv).rgb;
  vec3 b = texture2D(tBloom, vUv + uTexel * vec2(-0.5, -0.5)).rgb;
  b += texture2D(tBloom, vUv + uTexel * vec2(0.5, -0.5)).rgb;
  b += texture2D(tBloom, vUv + uTexel * vec2(-0.5, 0.5)).rgb;
  b += texture2D(tBloom, vUv + uTexel * vec2(0.5, 0.5)).rgb;
  c += b * 0.25 * uBloom;
  c *= uExposure * uTint;
  c = gameTone(max(c, vec3(0.0)));
  float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
  c = mix(vec3(l), c, uSaturation);
  c = (c - 0.5) * uContrast + 0.5;
  float v = length((vUv - 0.5) * vec2(1.0, 0.82));
  c *= 1.0 - uVignette * smoothstep(0.42, 0.95, v);
  c = clamp(c, 0.0, 1.0);
  // 선형 -> sRGB
  c = mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));
  c += (hash12(gl_FragCoord.xy) - 0.5) / 255.0;
  gl_FragColor = vec4(c, 1.0);
}`;

// 기기의 그래픽 기능을 미리 확인한다.
//  post: HDR 렌더 타깃을 실제로 만들 수 있는지 (안 되면 후처리 없이 그린다)
//  msaa: 그 멀티샘플 버전도 되는지 (안 되면 안티에일리어싱 없이 그린다)
//  software: 그래픽 가속 없이 CPU 로 그리는 환경인지 (낮은 품질로 시작한다)
export function probeGraphics() {
  const res = { post: false, msaa: false, software: false };
  try {
    const gl = document.createElement('canvas').getContext('webgl2');
    if (!gl) return res;
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    const name = String((dbg && gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)) || gl.getParameter(gl.RENDERER) || '');
    res.software = /swiftshader|llvmpipe|softpipe|software|basic render/i.test(name);
    if (gl.getExtension('EXT_color_buffer_float') || gl.getExtension('EXT_color_buffer_half_float')) {
      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, 4, 4, 0, gl.RGBA, gl.HALF_FLOAT, null);
      const fb = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
      res.post = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
      if (res.post) {
        const rb = gl.createRenderbuffer();
        gl.bindRenderbuffer(gl.RENDERBUFFER, rb);
        gl.renderbufferStorageMultisample(gl.RENDERBUFFER, 2, gl.RGBA16F, 4, 4);
        const fb2 = gl.createFramebuffer();
        gl.bindFramebuffer(gl.FRAMEBUFFER, fb2);
        gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.RENDERBUFFER, rb);
        res.msaa = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE && gl.getError() === gl.NO_ERROR;
      }
    }
    const lose = gl.getExtension('WEBGL_lose_context');
    if (lose) lose.loseContext();
  } catch {
    // 확인에 실패하면 후처리 없이 진행
  }
  return res;
}

export class Post {
  constructor(renderer) {
    this.renderer = renderer;
    this.scene = new THREE.Scene();
    this.cam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-1, -1, 0, 3, -1, 0, -1, 3, 0]), 3));
    this.quad = new THREE.Mesh(geo, null);
    this.quad.frustumCulled = false;
    this.scene.add(this.quad);

    const mk = (frag, uniforms, extra = {}) => new THREE.ShaderMaterial({ vertexShader: VERT, fragmentShader: frag, uniforms, depthTest: false, depthWrite: false, toneMapped: false, ...extra });
    this.matPre = mk(FRAG_PREFILTER, { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() }, uThreshold: { value: 1.0 }, uKnee: { value: 0.5 } });
    this.matDown = mk(FRAG_DOWN, { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() } });
    this.matUp = mk(FRAG_UP, { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() } }, { blending: THREE.AdditiveBlending, transparent: true });
    this.matFinal = mk(FRAG_FINAL, {
      tScene: { value: null }, tBloom: { value: null }, uTexel: { value: new THREE.Vector2() },
      uBloom: { value: 0.55 }, uExposure: { value: 1.0 }, uSaturation: { value: 1.03 }, uContrast: { value: 1.04 }, uVignette: { value: 0.22 },
      uTint: { value: new THREE.Color(1, 1, 1) },
    });
    this.rtScene = null;
    this.levels = [];
    this.w = 0;
    this.h = 0;
    this.samples = 0;
    this.nLevels = 4;
  }

  setSize(w, h, samples, nLevels) {
    samples = Math.min(samples, this.renderer.capabilities.maxSamples || 0);
    if (w === this.w && h === this.h && samples === this.samples && nLevels === this.nLevels && this.rtScene) return;
    this.dispose();
    this.w = w;
    this.h = h;
    this.samples = samples;
    this.nLevels = nLevels;
    this.rtScene = new THREE.WebGLRenderTarget(w, h, {
      type: THREE.HalfFloatType, format: THREE.RGBAFormat, samples, depthBuffer: true, stencilBuffer: false,
      minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, generateMipmaps: false,
    });
    let lw = w;
    let lh = h;
    for (let i = 0; i < nLevels; i++) {
      lw = Math.max(4, Math.floor(lw / 2));
      lh = Math.max(4, Math.floor(lh / 2));
      this.levels.push(new THREE.WebGLRenderTarget(lw, lh, {
        type: THREE.HalfFloatType, format: THREE.RGBAFormat, depthBuffer: false, stencilBuffer: false,
        minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, generateMipmaps: false,
      }));
    }
  }

  dispose() {
    if (this.rtScene) this.rtScene.dispose();
    for (const l of this.levels) l.dispose();
    this.rtScene = null;
    this.levels = [];
  }

  _pass(mat, target) {
    this.quad.material = mat;
    this.renderer.setRenderTarget(target);
    this.renderer.render(this.scene, this.cam);
  }

  render(scene, camera) {
    const r = this.renderer;
    const L = this.levels;
    r.setRenderTarget(this.rtScene);
    r.render(scene, camera);

    // 밝은 부분 추출 + 단계적으로 줄이기
    this.matPre.uniforms.tSrc.value = this.rtScene.texture;
    this.matPre.uniforms.uTexel.value.set(1 / this.w, 1 / this.h);
    this._pass(this.matPre, L[0]);
    for (let i = 1; i < L.length; i++) {
      this.matDown.uniforms.tSrc.value = L[i - 1].texture;
      this.matDown.uniforms.uTexel.value.set(1 / L[i - 1].width, 1 / L[i - 1].height);
      this._pass(this.matDown, L[i]);
    }
    // 다시 키우면서 더하기
    const auto = r.autoClear;
    r.autoClear = false;
    for (let i = L.length - 1; i >= 1; i--) {
      this.matUp.uniforms.tSrc.value = L[i].texture;
      this.matUp.uniforms.uTexel.value.set(0.5 / L[i].width, 0.5 / L[i].height);
      this._pass(this.matUp, L[i - 1]);
    }
    r.autoClear = auto;

    // 합성해서 화면에
    const f = this.matFinal.uniforms;
    f.tScene.value = this.rtScene.texture;
    f.tBloom.value = L[0].texture;
    f.uTexel.value.set(1 / L[0].width, 1 / L[0].height);
    this._pass(this.matFinal, null);
  }
}

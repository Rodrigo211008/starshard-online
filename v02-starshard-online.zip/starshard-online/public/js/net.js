// 서버 연결 (WebSocket): 재접속, 시간 동기화, 메시지 전달
export class Net {
  constructor() {
    this.ws = null;
    this.connected = false;
    this.offset = 0; // 서버 시각 - 내 시각 (ms)
    this.rtt = 0;
    this.bestRtt = Infinity;
    this.onJson = () => {};
    this.onBinary = () => {};
    this.onStatus = () => {};
    this.joinPayload = null;
    this.retry = 0;
    this.closedByUser = false;
    this.pingTimer = null;
    this.pings = 0;
  }

  url() {
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    return `${proto}://${location.host}/ws`;
  }

  // join 메시지 내용을 만드는 함수를 받아 접속한다 (재접속 때도 다시 호출)
  start(makeJoin) {
    this.joinPayload = makeJoin;
    this.closedByUser = false;
    this._open();
  }

  _open() {
    this.onStatus(this.retry ? 'reconnecting' : 'connecting');
    let ws;
    try {
      ws = new WebSocket(this.url());
    } catch {
      this._scheduleRetry();
      return;
    }
    ws.binaryType = 'arraybuffer';
    this.ws = ws;
    ws.onopen = () => {
      this.connected = true;
      this.retry = 0;
      this.bestRtt = Infinity;
      this.pings = 0;
      ws.send(JSON.stringify({ t: 'join', ...this.joinPayload() }));
      this._ping();
      clearInterval(this.pingTimer);
      this.pingTimer = setInterval(() => this._ping(), 2500);
    };
    ws.onmessage = (ev) => {
      if (typeof ev.data === 'string') {
        let msg;
        try {
          msg = JSON.parse(ev.data);
        } catch {
          return;
        }
        if (msg.t === 'pong') {
          const now = Date.now();
          const rtt = now - msg.c;
          this.rtt = rtt;
          this.pings++;
          // 지연이 가장 작았던 측정값을 기준으로 시간 차이를 잡는다
          if (rtt <= this.bestRtt + 15 || this.pings % 20 === 0) {
            this.bestRtt = Math.min(this.bestRtt, rtt);
            const off = msg.s + rtt / 2 - now;
            this.offset = this.pings <= 2 ? off : this.offset + (off - this.offset) * 0.3;
          }
          return;
        }
        if (msg.t === 'welcome') {
          this.offset = msg.now - Date.now();
          this.onStatus('online');
        }
        this.onJson(msg);
      } else {
        this.onBinary(new DataView(ev.data));
      }
    };
    ws.onclose = () => {
      const was = this.connected;
      this.connected = false;
      clearInterval(this.pingTimer);
      if (this.closedByUser) return;
      this.onStatus(was ? 'lost' : 'failed');
      this._scheduleRetry();
    };
    ws.onerror = () => {};
  }

  _scheduleRetry() {
    this.retry = Math.min(this.retry + 1, 6);
    const delay = Math.min(8000, 700 * 2 ** (this.retry - 1));
    setTimeout(() => {
      if (!this.closedByUser) this._open();
    }, delay);
  }

  _ping() {
    this.send({ t: 'ping', c: Date.now() });
  }

  serverNow() {
    return Date.now() + this.offset;
  }

  // 스냅샷의 32비트 시각을 전체 시각으로 복원
  expandTime(t32) {
    const cur = this.serverNow();
    const lo = cur % 4294967296;
    let diff = t32 - lo;
    if (diff > 2147483648) diff -= 4294967296;
    else if (diff < -2147483648) diff += 4294967296;
    return cur + diff;
  }

  send(obj) {
    if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(obj));
  }

  sendBin(buf) {
    if (this.ws && this.ws.readyState === 1) this.ws.send(buf);
  }
}

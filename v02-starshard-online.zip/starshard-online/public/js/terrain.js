// 지형 메시, 지형 데이터 텍스처, 장식물(나무·바위), 풀
import * as THREE from '/vendor/three/three.module.js';
import { W, NB, BIOME, PROP, VOLCANO, VILLAGE } from '/shared/world.js';
import { VILLAGE_LAYOUT } from '/shared/defs.js';
import { rand2 } from '/shared/noise.js';
import { Geo, M, MergeBuffer, lin } from './geo.js';
import { env } from './shade.js';

const BASE = [0x76b04e, 0x4c9146, 0xf4f8ff, 0xe9cf8c, 0x6f8a4e, 0x5a4e4c, 0xcfa64a].map(lin);
const ROCK = [0x8a8f98, 0x7d8580, 0x8f98ab, 0xc98f5f, 0x57574d, 0x40393a, 0x8f8478].map(lin);
const SAND = lin(0xead9a0);
const DEEP = lin(0x2c5f6e);
const MESA = lin(0xd98e5a);
const DIRT = lin(0xc2a878);
const BASALT = lin(0x332a2b);
const SNOWCAP = lin(0xf4f8ff);
const STONE = lin(0x9a9d94);
// 풀이 자라는 정도 (바이옴별)
const GRASS_DENS = [0.95, 0.8, 0, 0.1, 0.55, 0, 0.9];

function smooth(e0, e1, x) {
  let t = (x - e0) / (e1 - e0);
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return t * t * (3 - 2 * t);
}
const toSRGB = (c) => (c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055);

// 정점별 지형 정보를 계산한다:
//  col  지면 색(선형)        rock 절벽 암석 색        tmat 재질 가중치(풀, 모래, 눈, 용암)
//  dens 풀 밀도              swamp 늪 가중치          map  지도용 색(sRGB 바이트)
export function computeTerrainColors(world, pois) {
  const N = W.VERTS;
  const H = world.heights;
  const col = new Float32Array(N * N * 3);
  const rock = new Float32Array(N * N * 3);
  const tmat = new Float32Array(N * N * 4);
  const dens = new Float32Array(N * N);
  const swamp = new Float32Array(N * N);
  const map = new Uint8ClampedArray(N * N * 4);
  const spots = [];
  for (const c of pois.camps) spots.push([c.x, c.z, 8, 0]);
  for (const s of pois.stones) spots.push([s.x, s.z, 4.5, 0]);
  for (const s of pois.shards) spots.push([s.x, s.z, 6, 1]);
  const dirt = new Float32Array(N * N);
  const stone = new Float32Array(N * N);
  for (const [dx0, dz0, r, isStone] of spots) {
    const mask = isStone ? stone : dirt;
    const i0 = Math.max(0, Math.floor((dx0 - r - 6 + W.HALF) / W.CELL));
    const i1 = Math.min(W.GRID, Math.ceil((dx0 + r + 6 + W.HALF) / W.CELL));
    const j0 = Math.max(0, Math.floor((dz0 - r - 6 + W.HALF) / W.CELL));
    const j1 = Math.min(W.GRID, Math.ceil((dz0 + r + 6 + W.HALF) / W.CELL));
    for (let j = j0; j <= j1; j++) {
      for (let i = i0; i <= i1; i++) {
        const x = -W.HALF + i * W.CELL;
        const z = -W.HALF + j * W.CELL;
        const d = Math.hypot(x - dx0, z - dz0);
        const t = 1 - smooth(r * 0.6, r + 5, d);
        if (t > mask[j * N + i]) mask[j * N + i] = t;
      }
    }
  }

  for (let j = 0; j < N; j++) {
    for (let i = 0; i < N; i++) {
      const idx = j * N + i;
      const h = H[idx];
      const x = -W.HALF + i * W.CELL;
      const z = -W.HALF + j * W.CELL;
      const hl = H[idx - (i > 0 ? 1 : 0)];
      const hr = H[idx + (i < W.GRID ? 1 : 0)];
      const hu = H[idx - (j > 0 ? N : 0)];
      const hd = H[idx + (j < W.GRID ? N : 0)];
      const gx = (hr - hl) / (2 * W.CELL);
      const gz = (hd - hu) / (2 * W.CELL);
      const slope = Math.sqrt(gx * gx + gz * gz);

      let r = 0, g = 0, b = 0, rr = 0, rg = 0, rb = 0, sum = 0, gd = 0;
      const o = idx * NB;
      for (let k = 0; k < NB; k++) {
        const w = world.bw[o + k];
        if (!w) continue;
        sum += w;
        r += BASE[k][0] * w; g += BASE[k][1] * w; b += BASE[k][2] * w;
        rr += ROCK[k][0] * w; rg += ROCK[k][1] * w; rb += ROCK[k][2] * w;
        gd += GRASS_DENS[k] * w;
      }
      r /= sum; g /= sum; b /= sum; rr /= sum; rg /= sum; rb /= sum; gd /= sum;
      const wDesert = world.bw[o + BIOME.DESERT] / sum;
      const wSwamp = world.bw[o + BIOME.SWAMP] / sum;
      const wVolc = world.bw[o + BIOME.VOLCANO] / sum;
      const wSnow = world.bw[o + BIOME.SNOW] / sum;
      const wGrass = 1 - wDesert - wVolc - wSnow;

      // 사막 탁상지
      const mesa = wDesert * smooth(13, 21, h);
      r += (MESA[0] - r) * mesa; g += (MESA[1] - g) * mesa; b += (MESA[2] - b) * mesa;
      // 높은 곳의 눈 (화산 제외)
      const cap = smooth(84, 100, h) * (1 - wVolc) * (1 - wSnow);
      r += (SNOWCAP[0] - r) * cap; g += (SNOWCAP[1] - g) * cap; b += (SNOWCAP[2] - b) * cap;
      // 분화구 바닥
      const dv = Math.hypot(x - VOLCANO.x, z - VOLCANO.z);
      let lava = wVolc * 0.16;
      if (dv < 80) {
        const t = 1 - smooth(40, 68, dv);
        r += (BASALT[0] - r) * t; g += (BASALT[1] - g) * t; b += (BASALT[2] - b) * t;
        lava = Math.max(lava, 1 - smooth(30, 78, dv));
      }
      // 마을 광장과 야영지의 흙바닥
      const dvil = Math.hypot(x - VILLAGE.x, z - VILLAGE.z);
      const dt = Math.max(dirt[idx], 1 - smooth(13, 24, dvil)) * 0.9;
      r += (DIRT[0] - r) * dt; g += (DIRT[1] - g) * dt; b += (DIRT[2] - b) * dt;
      // 별조각 제단 주변의 돌바닥
      const stt = stone[idx] * 0.85;
      r += (STONE[0] - r) * stt; g += (STONE[1] - g) * stt; b += (STONE[2] - b) * stt;
      // 해변 모래
      const sd = smooth(2.3, 0.7, h) * (1 - wSwamp * 0.85) * (1 - wVolc * 0.7);
      r += (SAND[0] - r) * sd; g += (SAND[1] - g) * sd; b += (SAND[2] - b) * sd;
      // 지도 색 (절벽 암석 + 음영 + 물) - 물속 색을 섞기 전에 계산
      {
        const rk = smooth(0.7, 1.12, slope) * (1 - mesa * 0.6);
        let mr = r + (rr - r) * rk;
        let mg = g + (rg - g) * rk;
        let mb = b + (rb - b) * rk;
        const shade = Math.max(0.55, Math.min(1.35, 1 - (gx + gz) * 0.55));
        mr *= shade; mg *= shade; mb *= shade;
        if (h < 0) {
          const t = Math.min(1, 0.55 + -h / 14);
          mr += (0.03 - mr) * t; mg += (0.2 - mg) * t; mb += (0.45 - mb) * t;
        }
        map[idx * 4] = toSRGB(Math.min(1, mr)) * 255;
        map[idx * 4 + 1] = toSRGB(Math.min(1, mg)) * 255;
        map[idx * 4 + 2] = toSRGB(Math.min(1, mb)) * 255;
        map[idx * 4 + 3] = 255;
      }
      // 물속
      if (h < 0) {
        const t = smooth(0, -8, h);
        r += (DEEP[0] - r) * t; g += (DEEP[1] - g) * t; b += (DEEP[2] - b) * t;
      }
      col[idx * 3] = r; col[idx * 3 + 1] = g; col[idx * 3 + 2] = b;
      rock[idx * 3] = rr; rock[idx * 3 + 1] = rg; rock[idx * 3 + 2] = rb;
      const bare = (1 - dt) * (1 - stt) * (1 - cap) * (1 - sd) * (1 - mesa);
      tmat[idx * 4] = Math.max(0, wGrass) * bare * (h > 0.2 ? 1 : 0);
      tmat[idx * 4 + 1] = Math.min(1, wDesert * (1 - mesa) + sd);
      tmat[idx * 4 + 2] = Math.min(1, wSnow + cap);
      tmat[idx * 4 + 3] = lava;
      dens[idx] = gd * bare;
      swamp[idx] = wSwamp;
    }
  }
  return { col, rock, tmat, dens, swamp, map };
}

// ---------- 장식물 템플릿 ----------
function buildTemplates() {
  const T = {};
  const bark = 0x7a5a3a;
  const bark2 = 0x5f4630;

  T[PROP.OAK] = [0, 1, 2].map((v) => {
    const g = new Geo();
    g.cyl(0.2, 0.34, 2.4, 5, M(0, 1.2, 0), bark2, bark);
    g.ico(1.75, 0, M(0, 3.7, 0, 0, v, 0, 1, 0.85, 1), 0x3f8f38, 0x7cc653, 0.32, 11 + v, 1);
    g.ico(1.25, 0, M(0.95, 3.0, 0.4, 0, v * 2, 0), 0x3a8534, 0x6fbe4c, 0.3, 21 + v, 0.8);
    g.ico(1.15, 0, M(-0.85, 3.15, -0.5, 0, v * 3, 0), 0x3f8f38, 0x74c250, 0.3, 31 + v, 0.8);
    g.ico(1.0, 0, M(0.1, 3.2, -1.0, 0, v * 4, 0, 1, 0.9, 1), 0x377f32, 0x69b848, 0.3, 37 + v, 0.8);
    g.cyl(0.07, 0.11, 1.0, 4, M(0.45, 2.3, 0.2, 0, 0, -0.8), bark2, bark);
    return g.template();
  });

  const autumnCols = [[0xc9541f, 0xf2a63a], [0xa8321f, 0xe2603a], [0xcf9a22, 0xf7e05c]];
  T[PROP.AUTUMN] = autumnCols.map(([c1, c2], v) => {
    const g = new Geo();
    g.cyl(0.2, 0.34, 2.4, 5, M(0, 1.2, 0), bark2, bark);
    g.ico(1.75, 0, M(0, 3.7, 0, 0, v, 0, 1, 0.85, 1), c1, c2, 0.32, 41 + v, 1);
    g.ico(1.25, 0, M(0.95, 3.0, 0.4, 0, v * 2, 0), c1, c2, 0.3, 51 + v, 0.8);
    g.ico(1.15, 0, M(-0.85, 3.15, -0.5, 0, v * 3, 0), c1, c2, 0.3, 61 + v, 0.8);
    g.ico(1.0, 0, M(0.1, 3.2, -1.0, 0, v * 4, 0, 1, 0.9, 1), c1, c2, 0.3, 67 + v, 0.8);
    g.cyl(0.07, 0.11, 1.0, 4, M(0.45, 2.3, 0.2, 0, 0, -0.8), bark2, bark);
    return g.template();
  });

  const pine = (c1, c2, tip) => {
    const g = new Geo();
    g.cyl(0.15, 0.27, 1.7, 5, M(0, 0.85, 0), bark2, bark);
    g.cone(1.55, 2.1, 6, M(0, 2.3, 0), c1, tip || c2, 0.5);
    g.cone(1.2, 1.9, 6, M(0, 3.5, 0, 0, 0.5, 0), c1, tip || c2, 0.7);
    g.cone(0.82, 1.7, 6, M(0, 4.65, 0, 0, 1, 0), c1, tip || c2, 0.9);
    g.cone(0.5, 1.3, 6, M(0, 5.6, 0, 0, 1.5, 0), c1, tip || c2, 1.0);
    return g.template();
  };
  T[PROP.PINE] = [pine(0x24603a, 0x4f9a55), pine(0x2a6a45, 0x58a862)];
  T[PROP.SNOWPINE] = [pine(0x2f6a4c, 0, 0xf4f8ff), pine(0x35705a, 0, 0xe4eefc)];

  T[PROP.PALM] = [0, 1].map((v) => {
    const g = new Geo();
    const lean = v ? 0.22 : -0.16;
    g.cyl(0.19, 0.24, 1.5, 5, M(0, 0.75, 0, 0, 0, lean * 0.5), 0x8a6a45, 0x9a7a50);
    g.cyl(0.16, 0.19, 1.5, 5, M(-lean * 0.9, 2.15, 0, 0, 0, lean), 0x8a6a45, 0x9a7a50);
    g.cyl(0.13, 0.16, 1.5, 5, M(-lean * 2.4, 3.5, 0, 0, 0, lean * 1.5), 0x8a6a45, 0x9a7a50);
    const tx = -lean * 3.5;
    const ty = 4.25;
    for (let k = 0; k < 6; k++) {
      const a = (k / 6) * Math.PI * 2 + v;
      const ca = Math.cos(a);
      const sa = Math.sin(a);
      const px = -sa * 0.45;
      const pz = ca * 0.45;
      const A = [tx, ty, 0];
      const B = [tx + ca * 1.3 + px, ty + 0.25, sa * 1.3 + pz];
      const Cc = [tx + ca * 2.5, ty - 0.75, sa * 2.5];
      const D = [tx + ca * 1.3 - px, ty + 0.25, sa * 1.3 - pz];
      g.quad(A, B, Cc, D, 0x3f8f3a, 0x6fbe4c, 1.2);
      g.quad(A, D, Cc, B, 0x3f8f3a, 0x6fbe4c, 1.2);
    }
    return g.template();
  });

  T[PROP.DEAD] = [0, 1].map((v) => {
    const g = new Geo();
    g.cyl(0.1, 0.3, 3.2, 5, M(0, 1.6, 0, 0, 0, v ? 0.08 : -0.06), 0x4f443c, 0x6a5d52);
    g.cyl(0.04, 0.11, 1.5, 4, M(0.55, 2.3, 0, 0, 0, -0.95), 0x5c5048);
    g.cyl(0.04, 0.1, 1.3, 4, M(-0.45, 2.8, 0.1, 0.2, 0, 0.85), 0x5c5048);
    g.cyl(0.03, 0.08, 1.0, 4, M(0.1, 2.0, -0.4, -0.9, 0, 0), 0x5c5048);
    return g.template();
  });

  T[PROP.WILLOW] = [0, 1].map((v) => {
    const g = new Geo();
    g.cyl(0.24, 0.42, 2.8, 5, M(0, 1.4, 0), 0x4a4034, 0x5f5444);
    g.ico(2.0, 0, M(0, 3.6, 0, 0, v, 0, 1, 0.55, 1), 0x3f6f45, 0x7fa860, 0.3, 71 + v, 0.8);
    for (let k = 0; k < 7; k++) {
      const a = (k / 7) * Math.PI * 2 + v;
      g.cone(0.28, 1.9, 4, M(Math.cos(a) * 1.55, 2.5, Math.sin(a) * 1.55, Math.PI, 0, 0), 0x6f9a5a, 0x4f7f4a, 1.6);
    }
    return g.template();
  });

  T[PROP.CACTUS] = [0, 1].map((v) => {
    const g = new Geo();
    g.cyl(0.3, 0.36, 2.4, 6, M(0, 1.2, 0), 0x3f8a4f, 0x66b56a);
    g.ico(0.3, 0, M(0, 2.4, 0, 0, 0, 0, 1, 0.7, 1), 0x66b56a);
    g.cyl(0.17, 0.17, 0.8, 5, M(0.55, 1.3, 0, 0, 0, Math.PI / 2), 0x4a9558);
    g.cyl(0.15, 0.17, 0.9, 5, M(0.9, 1.75, 0), 0x4a9558, 0x66b56a);
    if (v) {
      g.cyl(0.15, 0.15, 0.7, 5, M(-0.5, 0.95, 0, 0, 0, Math.PI / 2), 0x4a9558);
      g.cyl(0.13, 0.15, 0.7, 5, M(-0.8, 1.3, 0), 0x4a9558, 0x66b56a);
    }
    g.ico(0.14, 0, M(0, 2.66, 0), 0xff7ab0);
    return g.template();
  });

  T[PROP.ROCK] = [0, 1, 2].map((v) => {
    const g = new Geo();
    g.ico(1, 0, M(0, 0.4, 0, 0.2 * v, v, 0, 1.25, 0.75 + v * 0.12, 1.0), 0x7f848c, 0xb0b5bd, 0.5, 81 + v * 7);
    if (v === 2) g.ico(0.55, 0, M(0.9, 0.2, 0.4, 0, 1, 0, 1.1, 0.7, 1), 0x7f848c, 0xa5aab2, 0.5, 97);
    return g.template();
  });

  T[PROP.BUSH] = [0, 1].map((v) => {
    const g = new Geo();
    g.ico(0.7, 0, M(0, 0.45, 0, 0, v, 0, 1.2, 0.8, 1.1), 0x3f8f38, 0x6fbe4c, 0.35, 101 + v, 0.4);
    g.ico(0.5, 0, M(0.55, 0.38, 0.2, 0, v * 2, 0), 0x3a8534, 0x66b548, 0.35, 111 + v, 0.4);
    return g.template();
  });

  T[PROP.DRYBUSH] = [0].map(() => {
    const g = new Geo();
    for (let k = 0; k < 5; k++) {
      const a = (k / 5) * Math.PI * 2;
      g.cone(0.07, 0.9, 3, M(Math.cos(a) * 0.15, 0.4, Math.sin(a) * 0.15, Math.sin(a) * 0.6, 0, -Math.cos(a) * 0.6), 0x8f7448, 0xc9ad74, 0.5);
    }
    return g.template();
  });

  const flowerCols = [0xff6f91, 0xffd34f, 0xffffff, 0x8fb4ff, 0xd58cff];
  T[PROP.FLOWER] = flowerCols.map((c, v) => {
    const g = new Geo();
    for (let k = 0; k < 3; k++) {
      const ox = Math.cos(k * 2.1 + v) * 0.3;
      const oz = Math.sin(k * 2.1 + v) * 0.3;
      const hh = 0.3 + k * 0.07;
      g.box(0.04, hh, 0.04, M(ox, hh / 2, oz), 0x4f9a3f, null, 0.5);
      g.ico(0.11, 0, M(ox, hh + 0.05, oz, 0, 0, 0, 1, 0.7, 1), c, null, 0, 1, 0.8);
    }
    return g.template();
  });

  const shroomCols = [0xd9483b, 0xe89a3c, 0x9b6fd1];
  T[PROP.MUSHROOM] = shroomCols.map((c, v) => {
    const g = new Geo();
    g.cyl(0.08, 0.11, 0.4, 5, M(0, 0.2, 0), 0xe8e0cc);
    g.cone(0.34, 0.26, 6, M(0, 0.5, 0), c, 0xfff0e0);
    g.cyl(0.05, 0.07, 0.24, 5, M(0.35, 0.12, 0.15 + v * 0.05), 0xe8e0cc);
    g.cone(0.2, 0.17, 6, M(0.35, 0.3, 0.15 + v * 0.05), c, 0xfff0e0);
    return g.template();
  });

  T[PROP.REED] = [0].map(() => {
    const g = new Geo();
    for (let k = 0; k < 5; k++) {
      const a = k * 1.9;
      g.cone(0.05, 1.5 + (k % 3) * 0.35, 3, M(Math.cos(a) * 0.22, 0.8 + (k % 3) * 0.17, Math.sin(a) * 0.22, Math.sin(a) * 0.08, 0, Math.cos(a) * 0.08), 0x5f8a45, 0xc9c070, 1.0);
    }
    return g.template();
  });

  T[PROP.ICE] = [0, 1].map((v) => {
    const g = new Geo();
    g.cone(0.42, 2.4, 5, M(0, 1.2, 0, 0.08, v, 0.05), 0x8fcfff, 0xeefaff);
    g.cone(0.3, 1.5, 5, M(0.5, 0.7, 0.2, 0.3, v, -0.35), 0x8fcfff, 0xeefaff);
    g.cone(0.25, 1.1, 5, M(-0.4, 0.5, -0.2, -0.3, v, 0.4), 0x9ad6ff, 0xeefaff);
    return g.template();
  });

  T[PROP.SPIKE] = [0, 1].map((v) => {
    const g = new Geo();
    g.cone(0.55, 2.6, 5, M(0, 1.3, 0, 0.1, v, -0.08), 0x2f292a, 0x5a4a48);
    g.cone(0.4, 1.6, 5, M(0.6, 0.75, 0.25, 0.25, v, -0.4), 0x2f292a, 0x55464a);
    if (v) g.cone(0.3, 1.2, 5, M(-0.5, 0.55, -0.3, -0.35, v, 0.35), 0x2f292a, 0x55464a);
    return g.template();
  });

  return T;
}

const ROCK_TINT = [
  [1, 1, 1], [0.88, 0.95, 0.88], [1.12, 1.16, 1.28], [1.4, 1.08, 0.74], [0.72, 0.78, 0.66], [0.46, 0.42, 0.43], [1.06, 0.98, 0.88],
];

export class Terrain {
  constructor(gfx, world, pois) {
    this.gfx = gfx;
    this.world = world;
    this.pois = pois;
    this.group = new THREE.Group();
    gfx.scene.add(this.group);
    this.propChunks = [];
    this.terrainChunks = [];
    this.templates = buildTemplates();
    const info = computeTerrainColors(world, pois);
    this.info = info;
    this.colors = info.col;
    this.mapPixels = info.map;
    this.grass = null;
    this._buildTextures();
  }

  // 셰이더가 읽는 지형 데이터 텍스처들
  _buildTextures() {
    const N = W.VERTS;
    const { col, dens, swamp, tmat } = this.info;
    const H = this.world.heights;
    // (1) 높이 / 늪 / 풀 밀도 / 용암 (반정밀도 실수)
    const data = new Uint16Array(N * N * 4);
    const hf = THREE.DataUtils.toHalfFloat;
    for (let i = 0; i < N * N; i++) {
      data[i * 4] = hf(H[i]);
      data[i * 4 + 1] = hf(swamp[i]);
      data[i * 4 + 2] = hf(dens[i]);
      data[i * 4 + 3] = hf(tmat[i * 4 + 3]);
    }
    const tData = new THREE.DataTexture(data, N, N, THREE.RGBAFormat, THREE.HalfFloatType);
    tData.magFilter = THREE.LinearFilter;
    tData.minFilter = THREE.LinearFilter;
    tData.wrapS = tData.wrapT = THREE.ClampToEdgeWrapping;
    tData.needsUpdate = true;
    env.uData.value = tData;
    // (2) 지면 색
    const gcol = new Uint8Array(N * N * 4);
    for (let i = 0; i < N * N; i++) {
      gcol[i * 4] = Math.round(toSRGB(Math.min(1, col[i * 3])) * 255);
      gcol[i * 4 + 1] = Math.round(toSRGB(Math.min(1, col[i * 3 + 1])) * 255);
      gcol[i * 4 + 2] = Math.round(toSRGB(Math.min(1, col[i * 3 + 2])) * 255);
      gcol[i * 4 + 3] = 255;
    }
    const tGround = new THREE.DataTexture(gcol, N, N, THREE.RGBAFormat, THREE.UnsignedByteType);
    tGround.colorSpace = THREE.SRGBColorSpace;
    tGround.magFilter = THREE.LinearFilter;
    tGround.minFilter = THREE.LinearFilter;
    tGround.needsUpdate = true;
    env.uGround.value = tGround;
    // (3) 나무·바위·집 아래의 그늘을 미리 구워 둔다
    const S = 2048;
    const k = S / W.SIZE;
    const shade = new Float32Array(S * S);
    const stamp = (x, z, radius, strength) => {
      const cx = (x + W.HALF) * k;
      const cz = (z + W.HALF) * k;
      const r = radius * k;
      const x0 = Math.max(0, Math.floor(cx - r));
      const x1 = Math.min(S - 1, Math.ceil(cx + r));
      const z0 = Math.max(0, Math.floor(cz - r));
      const z1 = Math.min(S - 1, Math.ceil(cz + r));
      for (let pz = z0; pz <= z1; pz++) {
        for (let px = x0; px <= x1; px++) {
          const d2 = ((px - cx) * (px - cx) + (pz - cz) * (pz - cz)) / (r * r);
          if (d2 >= 1) continue;
          const a = strength * (1 - d2) * (1 - d2);
          const o = pz * S + px;
          shade[o] = 1 - (1 - shade[o]) * (1 - a);
        }
      }
    };
    const TREE = new Set([PROP.OAK, PROP.PINE, PROP.AUTUMN, PROP.SNOWPINE, PROP.PALM, PROP.WILLOW, PROP.DEAD]);
    for (let cz = 0; cz < W.CHUNKS; cz++) {
      for (let cx = 0; cx < W.CHUNKS; cx++) {
        for (const p of this.world.chunkProps(cx, cz)) {
          if (TREE.has(p.t)) stamp(p.x, p.z, (p.t === PROP.DEAD ? 1.3 : 2.6) * p.s, p.t === PROP.DEAD ? 0.4 : 0.8);
          else if (p.t === PROP.ROCK || p.t === PROP.SPIKE || p.t === PROP.ICE || p.t === PROP.CACTUS) stamp(p.x, p.z, 1.3 * p.s, 0.5);
          else if (p.t === PROP.BUSH) stamp(p.x, p.z, 1.0 * p.s, 0.45);
        }
      }
    }
    for (const h of VILLAGE_LAYOUT.houses) stamp(VILLAGE.x + h.x, VILLAGE.z + h.z, Math.max(h.w, h.d) * 0.78, 0.55);
    for (const s of VILLAGE_LAYOUT.stalls) stamp(VILLAGE.x + s.x, VILLAGE.z + s.z, 2.6, 0.45);
    for (const b of this.pois.bushes) stamp(b.x, b.z, 1.1, 0.45);
    const sdata = new Uint8Array(S * S);
    for (let i = 0; i < S * S; i++) sdata[i] = Math.round(shade[i] * 255);
    const tShade = new THREE.DataTexture(sdata, S, S, THREE.RedFormat, THREE.UnsignedByteType);
    tShade.magFilter = THREE.LinearFilter;
    tShade.minFilter = THREE.LinearMipmapLinearFilter;
    tShade.generateMipmaps = true;
    tShade.needsUpdate = true;
    env.uShade.value = tShade;
  }

  buildTerrain() {
    const n = W.CHUNK_CELLS + 1;
    const N = W.VERTS;
    const H = this.world.heights;
    const { col: C, rock: R, tmat: T } = this.info;
    const idx = new Uint16Array(W.CHUNK_CELLS * W.CHUNK_CELLS * 6);
    let o = 0;
    for (let j = 0; j < W.CHUNK_CELLS; j++) {
      for (let i = 0; i < W.CHUNK_CELLS; i++) {
        const a = j * n + i;
        const b = a + 1;
        const c = a + n;
        const d = c + 1;
        idx[o++] = a; idx[o++] = c; idx[o++] = b;
        idx[o++] = b; idx[o++] = c; idx[o++] = d;
      }
    }
    const indexAttr = new THREE.BufferAttribute(idx, 1);
    for (let cz = 0; cz < W.CHUNKS; cz++) {
      for (let cx = 0; cx < W.CHUNKS; cx++) {
        const pos = new Float32Array(n * n * 3);
        const nor = new Float32Array(n * n * 3);
        const col = new Float32Array(n * n * 3);
        const rock = new Float32Array(n * n * 3);
        const tmat = new Float32Array(n * n * 4);
        let maxH = -99;
        let k = 0;
        let m = 0;
        for (let j = 0; j < n; j++) {
          for (let i = 0; i < n; i++) {
            const gi = cx * W.CHUNK_CELLS + i;
            const gj = cz * W.CHUNK_CELLS + j;
            const g = gj * N + gi;
            const h = H[g];
            if (h > maxH) maxH = h;
            pos[k] = -W.HALF + gi * W.CELL;
            pos[k + 1] = h;
            pos[k + 2] = -W.HALF + gj * W.CELL;
            // 높이맵에서 부드러운 법선 계산
            const hl = H[g - (gi > 0 ? 1 : 0)];
            const hr = H[g + (gi < W.GRID ? 1 : 0)];
            const hu = H[g - (gj > 0 ? N : 0)];
            const hd = H[g + (gj < W.GRID ? N : 0)];
            const nx = -(hr - hl) / (2 * W.CELL);
            const nz = -(hd - hu) / (2 * W.CELL);
            const nl = 1 / Math.sqrt(nx * nx + 1 + nz * nz);
            nor[k] = nx * nl;
            nor[k + 1] = nl;
            nor[k + 2] = nz * nl;
            col[k] = C[g * 3]; col[k + 1] = C[g * 3 + 1]; col[k + 2] = C[g * 3 + 2];
            rock[k] = R[g * 3]; rock[k + 1] = R[g * 3 + 1]; rock[k + 2] = R[g * 3 + 2];
            tmat[m] = T[g * 4]; tmat[m + 1] = T[g * 4 + 1]; tmat[m + 2] = T[g * 4 + 2]; tmat[m + 3] = T[g * 4 + 3];
            k += 3;
            m += 4;
          }
        }
        if (maxH < -20) continue; // 깊은 바다는 그리지 않는다
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        geo.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
        geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
        geo.setAttribute('rock', new THREE.BufferAttribute(rock, 3));
        geo.setAttribute('tmat', new THREE.BufferAttribute(tmat, 4));
        geo.setIndex(indexAttr);
        geo.computeBoundingSphere();
        const mesh = new THREE.Mesh(geo, this.gfx.matTerrain);
        mesh.receiveShadow = true;
        mesh.matrixAutoUpdate = false;
        mesh.userData.cx = -W.HALF + (cx + 0.5) * W.CHUNK;
        mesh.userData.cz = -W.HALF + (cz + 0.5) * W.CHUNK;
        this.group.add(mesh);
        this.terrainChunks.push(mesh);
      }
    }
  }

  buildProps() {
    const T = this.templates;
    for (let cz = 0; cz < W.CHUNKS; cz++) {
      for (let cx = 0; cx < W.CHUNKS; cx++) {
        const props = this.world.chunkProps(cx, cz);
        if (!props.length) continue;
        let nv = 0;
        let ni = 0;
        for (const p of props) {
          const vars = T[p.t];
          const t = vars[Math.floor(p.r * 997) % vars.length];
          nv += t.nv;
          ni += t.ni;
        }
        const mb = new MergeBuffer(nv, ni);
        for (const p of props) {
          const vars = T[p.t];
          const t = vars[Math.floor(p.r * 997) % vars.length];
          const tone = 0.88 + ((p.r * 131) % 1) * 0.24;
          if (p.t === PROP.ROCK) {
            const tint = ROCK_TINT[p.b];
            mb.add(t, p.x, p.y - 0.1 * p.s, p.z, p.s, p.r * 6.283, tint[0] * tone, tint[1] * tone, tint[2] * tone);
          } else {
            mb.add(t, p.x, p.y - 0.05, p.z, p.s, p.r * 6.283, tone, tone, tone);
          }
        }
        const mesh = new THREE.Mesh(mb.build(true), this.gfx.matProp);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        mesh.matrixAutoUpdate = false;
        mesh.userData.cx = -W.HALF + (cx + 0.5) * W.CHUNK;
        mesh.userData.cz = -W.HALF + (cz + 0.5) * W.CHUNK;
        this.group.add(mesh);
        this.propChunks.push(mesh);
      }
    }
  }

  // 풀: 플레이어 주변 격자에 심어 두고, 위치·높이·색은 셰이더가 지형 텍스처에서 읽는다
  setupGrass() {
    if (this.grass) {
      this.group.remove(this.grass);
      this.grass.geometry.dispose();
      this.grass = null;
    }
    const q = this.gfx.quality;
    const count = q.grass;
    if (!count) return;
    const R = q.grassR;
    this.gfx.uGrassR.value = R;
    // 풀 한 포기 = 휘어진 잎 5장
    const pos = [];
    const gcol = [];
    const sway = [];
    const index = [];
    for (let b = 0; b < 5; b++) {
      const a = b * 1.2566 + 0.4;
      const lx = Math.cos(a);
      const lz = Math.sin(a);
      const px = -lz;
      const pz = lx;
      const bx = lx * 0.09;
      const bz = lz * 0.09;
      const hh = 0.4 + (b % 3) * 0.09;
      const w0 = 0.034;
      const w1 = 0.024;
      const base = pos.length / 3;
      pos.push(bx - px * w0, 0, bz - pz * w0, bx + px * w0, 0, bz + pz * w0);
      pos.push(bx + lx * 0.07 - px * w1, hh * 0.55, bz + lz * 0.07 - pz * w1, bx + lx * 0.07 + px * w1, hh * 0.55, bz + lz * 0.07 + pz * w1);
      pos.push(bx + lx * 0.2, hh, bz + lz * 0.2);
      gcol.push(0, 0, 0.55, 0.55, 1);
      sway.push(0, 0, 0.32, 0.32, 1);
      index.push(base, base + 1, base + 3, base, base + 3, base + 2, base + 2, base + 3, base + 4);
    }
    const geo = new THREE.InstancedBufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pos), 3));
    geo.setAttribute('gcol', new THREE.BufferAttribute(new Float32Array(gcol), 1));
    geo.setAttribute('sway', new THREE.BufferAttribute(new Float32Array(sway), 1));
    geo.setIndex(index);
    const side = Math.ceil(Math.sqrt(count));
    const n = side * side;
    const cell = (2 * R) / side;
    const off = new Float32Array(n * 2);
    const rnd = new Float32Array(n * 4);
    for (let j = 0; j < side; j++) {
      for (let i = 0; i < side; i++) {
        const k = j * side + i;
        off[k * 2] = (i + rand2(i, j, 501)) * cell - R;
        off[k * 2 + 1] = (j + rand2(i, j, 502)) * cell - R;
        rnd[k * 4] = rand2(i, j, 503);
        rnd[k * 4 + 1] = rand2(i, j, 504);
        rnd[k * 4 + 2] = rand2(i, j, 505);
        rnd[k * 4 + 3] = rand2(i, j, 506);
      }
    }
    geo.setAttribute('aOff', new THREE.InstancedBufferAttribute(off, 2));
    geo.setAttribute('aRnd', new THREE.InstancedBufferAttribute(rnd, 4));
    geo.instanceCount = n;
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
    this.grass = new THREE.Mesh(geo, this.gfx.matGrass);
    this.grass.frustumCulled = false;
    this.grass.receiveShadow = true;
    this.grass.matrixAutoUpdate = false;
    this.group.add(this.grass);
  }

  // 멀리 있는 지형·장식물은 그리지 않는다
  update(px, pz) {
    const tr = this.gfx.quality.fogFar + 110;
    const tr2 = tr * tr;
    for (const m of this.terrainChunks) {
      const dx = m.userData.cx - px;
      const dz = m.userData.cz - pz;
      m.visible = dx * dx + dz * dz < tr2;
    }
    const r = this.gfx.quality.propRange + 75;
    const r2 = r * r;
    for (const m of this.propChunks) {
      const dx = m.userData.cx - px;
      const dz = m.userData.cz - pz;
      m.visible = dx * dx + dz * dz < r2;
    }
  }
}

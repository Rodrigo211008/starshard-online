// 효과음과 배경음악 (파일 없이 WebAudio 로 직접 합성)
export class GameAudio {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.musicGain = null;
    this.soundOn = true;
    this.musicOn = true;
    this.noiseBuf = null;
    this.musicTimer = null;
    this.step16 = 0;
    this.night = 0;
  }

  // 사용자 입력(버튼 클릭) 이후에 호출해야 소리가 난다
  start() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try {
      this.ctx = new AC();
    } catch {
      return;
    }
    this.master = this.ctx.createGain();
    this.master.gain.value = this.soundOn ? 0.5 : 0;
    this.master.connect(this.ctx.destination);
    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.value = this.musicOn ? 0.16 : 0;
    this.musicGain.connect(this.ctx.destination);
    const len = this.ctx.sampleRate * 0.5;
    this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this._startMusic();
  }

  setSound(on) {
    this.soundOn = on;
    if (this.master) this.master.gain.value = on ? 0.5 : 0;
  }

  setMusic(on) {
    this.musicOn = on;
    if (this.musicGain) this.musicGain.gain.value = on ? 0.16 : 0;
  }

  _tone(freq, dur, type = 'sine', vol = 0.3, slide = 0, delay = 0, dest = null) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(dest || this.master);
    o.start(t);
    o.stop(t + dur + 0.03);
  }

  _noise(dur, vol = 0.3, freq = 1200, q = 0.8, slide = 0, delay = 0, type = 'bandpass') {
    if (!this.ctx) return;
    const t = this.ctx.currentTime + delay;
    const s = this.ctx.createBufferSource();
    s.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(freq, t);
    if (slide) f.frequency.exponentialRampToValueAtTime(Math.max(60, freq + slide), t + dur);
    f.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f);
    f.connect(g);
    g.connect(this.master);
    s.start(t);
    s.stop(t + dur + 0.03);
  }

  swing(k = 0) { this._noise(0.16 + k * 0.03, 0.22, 900 + k * 250, 0.7, 2200); }
  hit(vol = 1) { this._noise(0.09, 0.4 * vol, 500, 0.6, -300, 0, 'lowpass'); this._tone(170, 0.09, 'square', 0.12 * vol, -80); }
  hurt() { this._tone(300, 0.22, 'sawtooth', 0.22, -200); this._noise(0.12, 0.25, 400, 0.6, -200, 0, 'lowpass'); }
  jump() { this._tone(330, 0.13, 'sine', 0.14, 240); }
  land() { this._noise(0.1, 0.18, 220, 0.6, -100, 0, 'lowpass'); }
  step(wet) { this._noise(0.05, wet ? 0.1 : 0.05, wet ? 900 : 320, 0.8, 0, 0, wet ? 'bandpass' : 'lowpass'); }
  splash() { this._noise(0.4, 0.3, 1400, 0.5, -900); }
  glide() { this._noise(0.35, 0.16, 500, 0.5, 900); }
  bow() { this._tone(520, 0.08, 'triangle', 0.2, -300); this._noise(0.14, 0.14, 2600, 1.2, -1200, 0.02); }
  throwSound() { this._noise(0.14, 0.1, 700, 0.8, 600); }
  thud() { this._tone(70, 0.35, 'sine', 0.5, -30); this._noise(0.22, 0.35, 180, 0.5, -100, 0, 'lowpass'); }
  pop(big) { this._tone(big ? 160 : 420, big ? 0.5 : 0.14, 'triangle', 0.26, big ? -100 : 380); this._noise(big ? 0.5 : 0.12, 0.2, 1000, 0.6, -600); }
  roar() { this._tone(90, 0.9, 'sawtooth', 0.28, -40); this._tone(63, 0.9, 'square', 0.16, -20); }
  heal() { this._tone(523, 0.14, 'sine', 0.2); this._tone(784, 0.2, 'sine', 0.18, 0, 0.09); }
  pickup() { this._tone(880, 0.07, 'square', 0.1); this._tone(1320, 0.1, 'square', 0.1, 0, 0.06); }
  coin() { this._tone(1320, 0.05, 'square', 0.08); this._tone(1760, 0.12, 'square', 0.08, 0, 0.05); }
  click() { this._tone(660, 0.05, 'triangle', 0.12); }
  deny() { this._tone(180, 0.14, 'square', 0.12, -40); }
  chest() { [523, 659, 784, 1047].forEach((f, i) => this._tone(f, 0.16, 'triangle', 0.2, 0, i * 0.09)); }
  levelUp() { [523, 659, 784, 1047, 1319].forEach((f, i) => this._tone(f, 0.22, 'square', 0.13, 0, i * 0.1)); }
  shard() { [659, 784, 988, 1319, 1568, 1976].forEach((f, i) => { this._tone(f, 0.5, 'sine', 0.2, 0, i * 0.12); this._tone(f * 2, 0.4, 'triangle', 0.06, 0, i * 0.12); }); }
  stone() { [392, 523, 659].forEach((f, i) => this._tone(f, 0.4, 'sine', 0.2, 0, i * 0.12)); }
  death() { [392, 330, 262, 196].forEach((f, i) => this._tone(f, 0.35, 'triangle', 0.2, 0, i * 0.22)); }
  victory() { [523, 523, 523, 659, 784, 1047, 784, 1047].forEach((f, i) => this._tone(f, 0.3, 'square', 0.14, 0, i * 0.16)); }
  chat() { this._tone(900, 0.05, 'sine', 0.1); }

  // 잔잔한 배경음악: 5음계 아르페지오를 계속 만들어 낸다
  _startMusic() {
    if (this.musicTimer) return;
    const day = [261.6, 293.7, 329.6, 392.0, 440.0, 523.3, 587.3, 659.3];
    const night = [220.0, 261.6, 293.7, 329.6, 392.0, 440.0, 523.3, 587.3];
    const chords = [[0, 2, 4], [3, 5, 7], [1, 3, 5], [2, 4, 6]];
    let idx = 2;
    this.musicTimer = setInterval(() => {
      if (!this.ctx || !this.musicOn || this.ctx.state !== 'running') return;
      const scale = this.night > 0.5 ? night : day;
      const s = this.step16++;
      const bar = Math.floor(s / 8) % chords.length;
      if (s % 8 === 0) {
        for (const c of chords[bar]) this._tone(scale[c] / 2, 2.6, 'sine', 0.1, 0, 0, this.musicGain);
      }
      if (Math.random() < (this.night > 0.5 ? 0.45 : 0.7)) {
        idx += Math.floor(Math.random() * 5) - 2;
        idx = Math.max(0, Math.min(scale.length - 1, idx));
        this._tone(scale[idx], 0.5, 'triangle', 0.16, 0, 0, this.musicGain);
        if (Math.random() < 0.25) this._tone(scale[idx] * 2, 0.4, 'sine', 0.07, 0, 0.17, this.musicGain);
      }
    }, 340);
  }
}

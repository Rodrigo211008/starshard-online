// 움직이는 것들: 다른 플레이어, 몬스터, 화살·투사체, 몬스터 공격 판정
import * as THREE from '/vendor/three/three.module.js';
import { ANIM, MON, MON_TYPES, MSTATE, ELITE_NAMES, GOLEM_NAMES, monStats, cycleScale } from '/shared/defs.js';
import { readSnap } from '/shared/proto.js';
import { Geo, M } from './geo.js';
import { makeHumanoid, animateHumanoid, makeMonster, animateMonster, playerLook } from './models.js';
import { makeLabel } from './objects.js';

const INTERP_MS = 200; // 이만큼 과거의 모습을 그려서 끊김 없이 보간한다
const TAU = Math.PI * 2;

function angDiff(a, b) {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}

// 시간순 상태 버퍼에서 보간
function sample(buf, t, out) {
  const n = buf.length;
  if (n === 0) return false;
  if (t <= buf[0].t || n === 1) {
    Object.assign(out, buf[0]);
    out.k = 0;
    return true;
  }
  for (let i = n - 1; i >= 1; i--) {
    const a = buf[i - 1];
    const b = buf[i];
    if (t >= a.t) {
      if (t >= b.t) {
        Object.assign(out, b);
        return true;
      }
      const k = (t - a.t) / (b.t - a.t || 1);
      out.x = a.x + (b.x - a.x) * k;
      out.y = a.y + (b.y - a.y) * k;
      out.z = a.z + (b.z - a.z) * k;
      out.yaw = a.yaw + angDiff(a.yaw, b.yaw) * k;
      out.anim = b.anim;
      out.state = b.state;
      out.hp = b.hp;
      out.maxHp = b.maxHp;
      return true;
    }
  }
  Object.assign(out, buf[n - 1]);
  return true;
}
const _s = { t: 0, x: 0, y: 0, z: 0, yaw: 0, anim: 0, state: 0, hp: 0, maxHp: 0 };

export class Entities {
  constructor(game) {
    this.game = game;
    this.scene = game.gfx.scene;
    this.players = new Map();
    this.monsters = new Map();
    this.spawnInfo = [];
    this.rigPool = new Map();
    this.snapSeq = 0;
    this.clockOff = null;
    this.projectiles = [];
    this.strikes = [];
    this.colliders = [];
    this.objects = null;
    this.myId = 0;
    this.target = null; // 최근에 때린/가까운 몬스터 (상단 정보창용)
    this.targetT = 0;

    // 체력 막대
    this.barGeo = new THREE.PlaneGeometry(1, 1);
    this.barBg = new THREE.MeshBasicMaterial({ color: 0x1a1a22, transparent: true, opacity: 0.7, depthWrite: false, fog: false });
    this.barFg = new THREE.MeshBasicMaterial({ color: 0xff4a4a, depthWrite: false, fog: false });
    this.barElite = new THREE.MeshBasicMaterial({ color: 0xffb02a, depthWrite: false, fog: false });

    // 투사체 모델
    const ag = new Geo();
    ag.box(0.05, 0.05, 1.0, M(0, 0, 0), 0x8a623c, 0xc9a05a);
    ag.cone(0.09, 0.22, 4, M(0, 0, 0.6, Math.PI / 2, 0, 0), 0xdfe7ee);
    ag.box(0.2, 0.02, 0.22, M(0, 0, -0.42), 0xf2f2f2);
    ag.box(0.02, 0.2, 0.22, M(0, 0, -0.42), 0xf2f2f2);
    this.arrowGeo = ag.build(false);
    const rg = new Geo();
    rg.ico(0.26, 0, null, 0x7f848c, 0xb0b5bd, 0.4, 3);
    this.rockGeo = rg.build(false);
    const fg = new Geo();
    fg.ico(0.34, 0, null, 0xff7a1a, 0xffd35a, 0.3, 5);
    this.fireGeo = fg.build(false);
    const mg = new Geo();
    mg.ico(0.9, 0, null, 0x7a2a8a, 0xff5ad0, 0.4, 7);
    this.meteorGeo = mg.build(false);
  }

  setSpawns(list, cycle) {
    this.cycle = cycle;
    this.spawnInfo = list.map((s, id) => {
      const type = MON_TYPES[s[0]];
      const elite = !!(s[5] & 1);
      const def = MON[type];
      let name = def.name;
      if (elite) name = ELITE_NAMES[type] || name;
      if (type === 'golem') name = GOLEM_NAMES[s[4]] || name;
      return { id, type, level: s[1], x: s[2], z: s[3], biome: s[4], elite, boss: !!(s[5] & 2), minion: !!(s[5] & 4), shard: s[6], def, name, radius: def.radius * (elite ? 1.45 : 1) };
    });
  }

  maxHpOf(info) {
    return Math.round(monStats(info.type, info.level, info.elite).hp * cycleScale(this.cycle));
  }

  // ---------------- 다른 플레이어 ----------------
  addPlayer(p) {
    this.removePlayer(p.id);
    const rig = makeHumanoid(playerLook(p));
    this.scene.add(rig.root);
    const label = makeLabel(p.name, '#ffffff', `Lv.${p.lvl}`);
    this.scene.add(label);
    const blob = this.game.fx.makeBlob(0.55);
    this.scene.add(blob);
    rig.root.visible = false;
    label.visible = false;
    blob.visible = false;
    const e = { id: p.id, prof: p, rig, label, blob, buf: [], x: 0, y: 0, z: 0, yaw: 0, anim: 0, hp: 6, maxHp: 6, atkT: 0, lastAnim: 0, seen: false, px: 0, pz: 0 };
    this.players.set(p.id, e);
    return e;
  }

  updatePlayerProfile(p) {
    const old = this.players.get(p.id);
    const e = this.addPlayer(p);
    if (old) {
      e.buf = old.buf;
      e.seen = old.seen;
    }
  }

  removePlayer(id) {
    const e = this.players.get(id);
    if (!e) return;
    this.scene.remove(e.rig.root, e.label, e.blob);
    disposeTree(e.rig.root);
    e.label.material.map.dispose();
    e.label.material.dispose();
    this.players.delete(id);
  }

  clearPlayers() {
    for (const id of [...this.players.keys()]) this.removePlayer(id);
  }

  // ---------------- 몬스터 ----------------
  _getRig(info) {
    const key = `${info.type}|${info.biome}|${info.elite ? 1 : 0}|${info.minion ? 1 : 0}`;
    const pool = this.rigPool.get(key);
    if (pool && pool.length) return pool.pop();
    const rig = makeMonster(info.type, info.biome, info.elite, info.minion);
    rig.poolKey = key;
    return rig;
  }

  _addMonster(id) {
    const info = this.spawnInfo[id];
    if (!info) return null;
    const rig = this._getRig(info);
    rig.root.visible = false;
    this.scene.add(rig.root);
    const bar = new THREE.Group();
    const w = info.boss || info.type === 'golem' ? 3.2 : info.elite ? 2.2 : 1.5;
    const bg = new THREE.Mesh(this.barGeo, this.barBg);
    bg.scale.set(w + 0.1, 0.24, 1);
    const fg = new THREE.Mesh(this.barGeo, info.elite || info.type === 'golem' || info.boss ? this.barElite : this.barFg);
    fg.scale.set(w, 0.15, 1);
    fg.position.z = 0.01;
    fg.renderOrder = 12;
    bg.renderOrder = 11;
    bar.add(bg, fg);
    bar.visible = false;
    this.scene.add(bar);
    const blob = this.game.fx.makeBlob(info.radius * 1.05);
    this.scene.add(blob);
    const e = {
      id, info, rig, bar, barFg: fg, barW: w, blob, buf: [], seq: 0, lastSeen: performance.now(),
      x: info.x, z: info.z, y: 0, yaw: 0, state: 0, hp5: 31, hp: this.maxHpOf(info), maxHp: this.maxHpOf(info),
      pattern: null, strikeT: 9, flash: 0, speed: 0, px: info.x, pz: info.z, shown: false, lastState: 0,
    };
    this.monsters.set(id, e);
    return e;
  }

  _removeMonster(e) {
    this.scene.remove(e.rig.root, e.bar, e.blob);
    e.rig.root.scale.setScalar(e.rig.root.userData.baseScale || e.rig.root.scale.x);
    let pool = this.rigPool.get(e.rig.poolKey);
    if (!pool) this.rigPool.set(e.rig.poolKey, (pool = []));
    if (pool.length < 6) pool.push(e.rig);
    else disposeTree(e.rig.root);
    this.monsters.delete(e.id);
    if (this.target === e) this.target = null;
  }

  clearMonsters() {
    for (const e of [...this.monsters.values()]) this._removeMonster(e);
  }

  // ---------------- 스냅샷 수신 ----------------
  onSnapshot(dv) {
    const net = this.game.net;
    const t = net.expandTime(dv.getUint32(1));
    const seq = ++this.snapSeq;
    const nowMs = performance.now();
    // 스냅샷 도착 시각으로 서버 시계를 추정한다 (가장 빨리 도착한 패킷 기준, 천천히 보정)
    const d = t - Date.now();
    if (this.clockOff === null || Math.abs(d - this.clockOff) > 2000) this.clockOff = d;
    else this.clockOff = Math.max(d, this.clockOff - 0.4);
    readSnap(
      dv,
      (id, x, y, z, yaw, anim, hp, maxHp) => {
        const e = this.players.get(id);
        if (!e) return;
        e.buf.push({ t, x, y, z, yaw, anim, hp, maxHp, state: 0 });
        if (e.buf.length > 12) e.buf.shift();
      },
      (id, x, z, yaw, sb) => {
        let e = this.monsters.get(id);
        if (!e) e = this._addMonster(id);
        if (!e || e.dying) return;
        e.seq = seq;
        e.lastSeen = nowMs;
        e.buf.push({ t, x, y: 0, z, yaw, state: sb & 7, hp: sb >> 3, anim: 0, maxHp: 31 });
        if (e.buf.length > 12) e.buf.shift();
      }
    );
    // 한동안 스냅샷에 없으면 시야 밖으로 나간 것 (가만히 있는 몬스터는 0.5초마다 온다)
    for (const e of this.monsters.values()) {
      if (e.seq !== seq && !e.dying && nowMs - e.lastSeen > 1400) this._removeMonster(e);
    }
  }

  // ---------------- 이벤트 ----------------
  onHit(msg) {
    const e = this.monsters.get(msg.id);
    if (!e) return;
    e.hp = msg.hp;
    e.flash = 0.16;
    e.hitShow = 4;
    this.target = e;
    this.targetT = 5;
    const g = this.game;
    const y = e.y + e.info.def.height * (e.info.elite ? 1.45 : 1) * 0.8;
    g.fx.text(e.x, y + 0.4, e.z, String(msg.d), msg.c ? 'crit' : msg.by === this.myId ? 'dmg' : 'dmg other');
    g.fx.burst(e.x, y - 0.3, e.z, msg.c ? 0xffe27a : 0xffffff, msg.c ? 12 : 6, 4, { size: 0.26, life: 0.3, grav: 9 });
    if (msg.by !== this.myId) g.audio.hit(0.4);
    if (msg.s) this.cancelStrikes(msg.id);
  }

  onMonsterDead(msg) {
    const e = this.monsters.get(msg.id);
    const g = this.game;
    this.cancelStrikes(msg.id);
    if (!e) return null;
    const info = e.info;
    const col = info.type === 'slime' ? 0x9fe89a : info.type === 'golem' ? 0xb0b5bd : info.boss ? 0xff5ad0 : 0xfff0c0;
    const h = info.def.height * 0.5;
    g.fx.burst(e.x, e.y + h, e.z, col, info.boss ? 60 : 18, info.boss ? 9 : 5, { size: info.boss ? 0.7 : 0.4, life: 0.8, grav: 5 });
    g.fx.ring(e.x, e.y + 0.3, e.z, col, info.radius * 3 + 1, 0.45);
    g.audio.pop(info.boss || info.type === 'golem');
    e.dying = 0.28;
    e.bar.visible = false;
    return e;
  }

  // 몬스터 공격 예고 -> 바닥 표시 + 내 캐릭터 피격 판정 예약
  onMonsterAttack(msg) {
    const g = this.game;
    const e = this.monsters.get(msg.id);
    if (e) {
      e.pattern = msg.k;
      e.windupUntil = performance.now() + msg.d;
      e.strikeT = -msg.d / 1000;
      e.atkYaw = msg.yaw;
    }
    const now = performance.now();
    const add = (shape, delay, opts = {}) => {
      const tele = g.fx.telegraph(shape, msg.d, delay, msg.k === 'meteor' ? 0xc04aff : 0xff3a2a);
      this.strikes.push({ id: msg.id, at: now + msg.d + delay, shape, dmg: msg.dmg, tele, kind: msg.k, ...opts });
    };
    const big = e && (e.info.boss || e.info.type === 'golem' || e.info.type === 'yeti');
    if (msg.k === 'arc') add({ kind: 'arc', x: msg.x, z: msg.z, yaw: msg.yaw, r: msg.r, half: msg.half }, 0, { knock: big ? 11 : 7 });
    else if (msg.k === 'slam') add({ kind: 'circle', x: msg.x, z: msg.z, r: msg.r }, 0, { knock: 11, jumpable: true, big: true });
    else if (msg.k === 'lunge') add({ kind: 'line', x: msg.x, z: msg.z, yaw: msg.yaw, len: msg.dash + msg.r * 0.6, w: msg.r }, 0, { knock: big ? 12 : 7 });
    else if (msg.k === 'meteor') {
      for (const p of msg.pts) add({ kind: 'circle', x: p[0], z: p[1], r: msg.r }, p[2], { knock: 8, jumpable: false, big: true, meteor: true });
      g.audio.roar();
    } else if (msg.k === 'roar') g.audio.roar();
  }

  cancelStrikes(id) {
    for (const s of this.strikes) {
      if (s.id === id && !s.meteor) {
        s.dead = true;
        this.game.fx.cancelTelegraph(s.tele);
      }
    }
    const e = this.monsters.get(id);
    if (e) e.pattern = null;
  }

  _inShape(shape, px, pz) {
    const dx = px - shape.x;
    const dz = pz - shape.z;
    if (shape.kind === 'circle') return dx * dx + dz * dz <= (shape.r + 0.3) * (shape.r + 0.3);
    if (shape.kind === 'arc') {
      const d = Math.hypot(dx, dz);
      if (d > shape.r + 0.3) return false;
      if (d < 1.0) return true;
      return Math.abs(angDiff(shape.yaw, Math.atan2(dx, dz))) <= shape.half + 0.1;
    }
    // line: yaw 방향으로 len, 폭 w
    const fx = Math.sin(shape.yaw);
    const fz = Math.cos(shape.yaw);
    const along = dx * fx + dz * fz;
    const side = Math.abs(dx * fz - dz * fx);
    return along >= -0.6 && along <= shape.len + 0.4 && side <= shape.w + 0.3;
  }

  _resolveStrike(s) {
    const g = this.game;
    const pl = g.player;
    const sx = s.shape.x;
    const sz = s.shape.z;
    const gy = Math.max(g.world.heightAt(sx, sz), 0);
    if (s.big) {
      g.fx.ring(sx, gy + 0.2, sz, s.meteor ? 0xc04aff : 0xffc08a, (s.shape.r || 3) * 1.1, 0.4);
      g.fx.dust(sx, gy, sz, 10);
      const d = Math.hypot(pl.pos.x - sx, pl.pos.z - sz);
      if (d < 40) {
        pl.shake = Math.max(pl.shake, 0.5 * (1 - d / 40));
        g.audio.thud();
      }
    }
    if (pl.state === 'dead') return;
    if (Math.abs(pl.pos.y - gy) > 5) return;
    if (s.jumpable && pl.pos.y - pl.groundH > 1.2) return;
    if (!this._inShape(s.shape, pl.pos.x, pl.pos.z)) return;
    const e = this.monsters.get(s.id);
    pl.damage(s.dmg, e ? e.x : sx, e ? e.z : sz, { knock: s.knock });
  }

  onProjectile(msg) {
    const geo = msg.k === 'fire' ? this.fireGeo : this.rockGeo;
    const m = new THREE.Mesh(geo, msg.k === 'fire' ? this.game.gfx.matGlow : this.game.gfx.matChar);
    m.position.set(msg.x, msg.y, msg.z);
    this.scene.add(m);
    this.projectiles.push({ m, kind: msg.k, vx: msg.vx, vy: msg.vy, vz: msg.vz, g: msg.g, dmg: msg.dmg, life: 4, hostile: true, fromX: msg.x, fromZ: msg.z });
    this.game.audio.throwSound();
  }

  spawnArrow(x, y, z, dx, dy, dz, mine) {
    const m = new THREE.Mesh(this.arrowGeo, this.game.gfx.matChar);
    m.position.set(x, y, z);
    this.scene.add(m);
    const sp = 55;
    this.projectiles.push({ m, kind: 'arrow', vx: dx * sp, vy: dy * sp, vz: dz * sp, g: 9, life: 2.6, hostile: false, mine });
  }

  // ---------------- 플레이어 전투 보조 ----------------
  // 가까운 몬스터 (정면 기준 각도 제한)
  nearestMonster(x, z, range, yaw, halfAngle) {
    let best = null;
    let bs = Infinity;
    for (const e of this.monsters.values()) {
      if (e.dying || !e.shown) continue;
      const dx = e.x - x;
      const dz = e.z - z;
      const d = Math.hypot(dx, dz) - e.info.radius;
      if (d > range) continue;
      const a = Math.abs(angDiff(yaw, Math.atan2(dx, dz)));
      if (a > halfAngle && d > 1.2) continue;
      const score = d + a * 1.5;
      if (score < bs) {
        bs = score;
        best = { x: e.x, z: e.z, dist: Math.max(0, d), e };
      }
    }
    return best;
  }

  // 주목(대상 고정)할 몬스터 고르기: 시점 정면에 있고 가까운 것이 우선
  pickLockTarget(x, z, yaw, range) {
    let best = null;
    let bs = Infinity;
    for (const e of this.monsters.values()) {
      if (e.dying || !e.shown) continue;
      const dx = e.x - x;
      const dz = e.z - z;
      const d = Math.hypot(dx, dz);
      if (d > range) continue;
      const a = Math.abs(angDiff(yaw, Math.atan2(dx, dz)));
      const score = d + a * 9;
      if (score < bs) {
        bs = score;
        best = e;
      }
    }
    return best;
  }

  monstersInArc(x, y, z, yaw, reach, halfAngle) {
    const ids = [];
    for (const e of this.monsters.values()) {
      if (e.dying || !e.shown) continue;
      const dx = e.x - x;
      const dz = e.z - z;
      const d = Math.hypot(dx, dz);
      if (d > reach + e.info.radius) continue;
      if (Math.abs(e.y - y) > 3.5 + e.info.def.height) continue;
      if (d > e.info.radius + 0.9 && Math.abs(angDiff(yaw, Math.atan2(dx, dz))) > halfAngle) continue;
      ids.push(e.id);
    }
    return ids;
  }

  aimTarget(pos, yaw, maxAngle, range) {
    let best = null;
    let bs = Infinity;
    for (const e of this.monsters.values()) {
      if (e.dying || !e.shown) continue;
      const dx = e.x - pos.x;
      const dz = e.z - pos.z;
      const d = Math.hypot(dx, dz);
      if (d > range || d < 0.5) continue;
      const a = Math.abs(angDiff(yaw, Math.atan2(dx, dz)));
      if (a > maxAngle) continue;
      const score = a + d * 0.006;
      if (score < bs) {
        bs = score;
        best = { x: e.x, y: e.y + e.info.def.height * (e.info.elite ? 1.45 : 1) * 0.55, z: e.z, e };
      }
    }
    return best;
  }

  flashMonster(id) {
    const e = this.monsters.get(id);
    if (e) e.flash = 0.12;
  }

  nearRest(x, z) {
    return this.objects ? this.objects.nearRest(x, z) : false;
  }

  // ---------------- 매 프레임 ----------------
  update(dt, time) {
    const g = this.game;
    const net = g.net;
    const rt = (this.clockOff === null ? net.serverNow() : Date.now() + this.clockOff) - INTERP_MS;
    const cam = g.gfx.camera;
    const pl = g.player;
    const blobs = !g.gfx.quality.shadows;
    const world = g.world;

    // 다른 플레이어
    for (const e of this.players.values()) {
      if (!sample(e.buf, rt, _s)) {
        continue;
      }
      const moved = Math.hypot(_s.x - e.x, _s.z - e.z);
      const speed = e.seen ? moved / Math.max(dt, 1e-3) : 0;
      e.x = _s.x;
      e.y = _s.y;
      e.z = _s.z;
      e.yaw = _s.yaw;
      e.hp = _s.hp;
      e.maxHp = _s.maxHp;
      const anim = _s.anim;
      if (anim !== e.lastAnim) {
        e.lastAnim = anim;
        e.atkT = 0;
      }
      e.atkT += dt;
      e.anim = anim;
      const dur = anim === ANIM.ATK3 ? 0.5 : 0.36;
      const dxp = e.x - pl.pos.x;
      const dzp = e.z - pl.pos.z;
      const d2 = dxp * dxp + dzp * dzp;
      const vis = d2 < 260 * 260;
      e.rig.root.visible = vis;
      e.label.visible = d2 < 90 * 90;
      e.blob.visible = vis && blobs;
      e.seen = true;
      if (!vis) continue;
      e.rig.root.position.set(e.x, e.y, e.z);
      e.rig.root.rotation.y = e.yaw;
      animateHumanoid(e.rig, anim, dt, Math.min(12, speed), Math.min(1, e.atkT / (dur * 0.75)));
      e.label.position.set(e.x, e.y + 2.35, e.z);
      if (blobs) {
        const gh = Math.max(world.heightAt(e.x, e.z), 0);
        e.blob.position.set(e.x, gh + 0.06, e.z);
      }
    }

    // 몬스터
    this.targetT -= dt;
    if (this.targetT <= 0) this.target = null;
    for (const e of this.monsters.values()) {
      if (e.dying) {
        e.dying -= dt;
        const k = Math.max(0.01, e.dying / 0.28);
        e.rig.root.scale.setScalar((e.rig.root.userData.baseScale || 1) * k);
        if (e.dying <= 0) this._removeMonster(e);
        continue;
      }
      if (!sample(e.buf, rt, _s)) continue;
      if (!e.shown) {
        e.shown = true;
        e.rig.root.visible = true;
        if (e.rig.root.userData.baseScale === undefined) e.rig.root.userData.baseScale = e.rig.root.scale.x;
        e.rig.root.scale.setScalar(e.rig.root.userData.baseScale);
        e.px = _s.x;
        e.pz = _s.z;
      }
      e.x = _s.x;
      e.z = _s.z;
      e.yaw = _s.yaw;
      e.y = Math.max(world.heightAt(e.x, e.z), -0.4);
      const st = _s.state;
      e.hp5 = _s.hp;
      const frac = Math.min(1, Math.max(e.hp5 / 31, 0));
      const moved = Math.hypot(e.x - e.px, e.z - e.pz);
      e.speed += (moved / Math.max(dt, 1e-3) - e.speed) * Math.min(1, dt * 8);
      e.px = e.x;
      e.pz = e.z;
      if (st !== e.lastState) {
        if (st === MSTATE.RECOVER) e.strikeT = 0;
        e.lastState = st;
      }
      e.strikeT += dt;
      let as = 'idle';
      if (st === MSTATE.WALK) as = 'walk';
      else if (st === MSTATE.CHASE || st === MSTATE.RETURN) as = e.speed > 0.4 ? 'run' : 'idle';
      else if (st === MSTATE.WINDUP) as = 'windup';
      else if (st === MSTATE.RECOVER) as = 'strike';
      else if (st === MSTATE.STAGGER) as = 'stagger';
      animateMonster(e.rig, as, e.pattern || e.info.def.atk.kind, dt, e.speed, Math.min(1, e.strikeT / 0.3));
      e.rig.root.position.set(e.x, e.y, e.z);
      e.rig.root.rotation.y = e.yaw;
      if (e.flash > 0) {
        e.flash -= dt;
        const base = e.rig.root.userData.baseScale || 1;
        e.rig.root.scale.setScalar(base * (1 + Math.max(0, e.flash) * 0.9));
      }
      // 체력 막대
      e.hitShow = (e.hitShow || 0) - dt;
      const showBar = frac < 0.999 || e.hitShow > 0;
      e.bar.visible = showBar && !(e.info.boss);
      if (e.bar.visible) {
        e.bar.position.set(e.x, e.y + e.rig.height + 0.6, e.z);
        e.bar.quaternion.copy(cam.quaternion);
        e.barFg.scale.x = Math.max(0.001, e.barW * frac);
        e.barFg.position.x = -(e.barW * (1 - frac)) / 2;
      }
      e.blob.visible = blobs;
      if (blobs) e.blob.position.set(e.x, Math.max(e.y, 0) + 0.06, e.z);

      // 몸으로 밀어내기
      const dx = pl.pos.x - e.x;
      const dz = pl.pos.z - e.z;
      const rr = e.info.radius * 0.8 + 0.35;
      const d2 = dx * dx + dz * dz;
      if (d2 < rr * rr && d2 > 1e-4 && pl.state === 'ground') {
        const d = Math.sqrt(d2);
        const push = (rr - d) * 0.5;
        pl.pos.x += (dx / d) * push;
        pl.pos.z += (dz / d) * push;
      }
    }

    // 몬스터 공격 판정
    if (this.strikes.length) {
      const now = performance.now();
      for (let i = this.strikes.length - 1; i >= 0; i--) {
        const s = this.strikes[i];
        if (s.dead) {
          this.strikes.splice(i, 1);
          continue;
        }
        if (now >= s.at) {
          this.strikes.splice(i, 1);
          this._resolveStrike(s);
        }
      }
    }

    // 투사체
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= dt;
      const m = p.m;
      const ox = m.position.x;
      const oy = m.position.y;
      const oz = m.position.z;
      p.vy -= p.g * dt;
      m.position.x += p.vx * dt;
      m.position.y += p.vy * dt;
      m.position.z += p.vz * dt;
      let done = p.life <= 0;
      if (p.kind === 'arrow') {
        m.lookAt(m.position.x + p.vx, m.position.y + p.vy, m.position.z + p.vz);
        if (p.mine && !done) {
          // 선분-구 충돌 (빠른 화살이 몬스터를 통과하지 않도록)
          const sx = m.position.x - ox;
          const sy = m.position.y - oy;
          const sz = m.position.z - oz;
          const sl2 = sx * sx + sy * sy + sz * sz || 1;
          for (const e of this.monsters.values()) {
            if (e.dying || !e.shown) continue;
            const hgt = e.info.def.height * (e.info.elite ? 1.45 : 1);
            const cx = e.x;
            const cy = e.y + hgt * 0.5;
            const cz = e.z;
            let t = ((cx - ox) * sx + (cy - oy) * sy + (cz - oz) * sz) / sl2;
            t = t < 0 ? 0 : t > 1 ? 1 : t;
            const qx = ox + sx * t - cx;
            const qy = (oy + sy * t - cy) * (e.info.radius / Math.max(hgt * 0.55, e.info.radius));
            const qz = oz + sz * t - cz;
            const rr = e.info.radius + 0.35;
            if (qx * qx + qy * qy + qz * qz < rr * rr) {
              net.send({ t: 'ar', id: e.id });
              g.fx.burst(ox + sx * t, oy + sy * t, oz + sz * t, 0xffffff, 6, 3, { size: 0.24, life: 0.25 });
              e.flash = 0.12;
              done = true;
              break;
            }
          }
        }
      } else {
        m.rotation.x += dt * 9;
        m.rotation.y += dt * 7;
        if (p.kind === 'fire' && Math.random() < 0.6) g.fx.spawn(m.position.x, m.position.y, m.position.z, 0, 0.5, 0, 0xff9a3a, 0.4, 0.35, -1, 0.8);
        // 내 캐릭터에 맞았는지
        if (p.hostile && pl.state !== 'dead') {
          const dx = m.position.x - pl.pos.x;
          const dy = m.position.y - (pl.pos.y + 0.95);
          const dz = m.position.z - pl.pos.z;
          if (dx * dx + dz * dz < 0.75 * 0.75 && Math.abs(dy) < 1.15) {
            pl.damage(p.dmg, p.fromX, p.fromZ, { knock: 5 });
            g.fx.burst(m.position.x, m.position.y, m.position.z, p.kind === 'fire' ? 0xff9a3a : 0xb0b5bd, 10, 4, { size: 0.3, life: 0.35 });
            done = true;
          }
        }
      }
      if (!done && m.position.y < Math.max(world.heightAt(m.position.x, m.position.z), 0) + 0.05) {
        g.fx.burst(m.position.x, m.position.y + 0.1, m.position.z, p.kind === 'fire' ? 0xff9a3a : 0xd8cfb8, 6, 2.5, { size: 0.28, life: 0.3 });
        done = true;
      }
      if (done) {
        this.scene.remove(m);
        this.projectiles.splice(i, 1);
      }
    }
  }
}

export function disposeTree(root) {
  root.traverse((o) => {
    if (o.geometry) o.geometry.dispose();
  });
}

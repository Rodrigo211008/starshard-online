// 캐릭터·몬스터 모델과 절차적 애니메이션
import * as THREE from '/vendor/three/three.module.js';
import { ANIM, SWORDS, TUNIC_COLORS, HAIR_COLORS } from '/shared/defs.js';
import { Geo, M } from './geo.js';

export const POSE = {
  ...ANIM,
  RAISE: 40, SMASH: 41, THROWBACK: 42, THROW: 43, SWEEPBACK: 44, SWEEP: 45, ROAR: 46, CROUCH: 47, LUNGE: 48, STAGGER: 49, WALK: 50,
};

let MAT = null;
let GLOW = null;
let JELLY = null;
export function initModels(gfx) {
  MAT = gfx.matChar;
  GLOW = gfx.matGlow;
  JELLY = gfx.matJelly;
}

function mesh(geo, glow) {
  const m = new THREE.Mesh(geo.build(false), glow ? GLOW : MAT);
  m.castShadow = !glow;
  return m;
}

const shade = (hex, k) => {
  const r = Math.min(255, Math.round(((hex >> 16) & 255) * k));
  const g = Math.min(255, Math.round(((hex >> 8) & 255) * k));
  const b = Math.min(255, Math.round((hex & 255) * k));
  return (r << 16) | (g << 8) | b;
};

// ============================================================
// 사람형 리그 (플레이어, NPC, 도깨비, 설인, 수호자, 보스)
// ============================================================
export function makeHumanoid(o) {
  const S = o.scale || 1;
  const bulk = o.bulk || 1;
  const armLen = o.armLen || 1;
  const legLen = o.legLen || 1;
  const headS = o.headSize || 1;
  const skin = o.skin ?? 0xf2c9a0;
  const tunic = o.tunic ?? 0xd9483b;
  const pants = o.pants ?? 0x4a4a5a;
  const boots = o.boots ?? 0x5a3d25;
  const hair = o.hair ?? 0x3a2a1e;

  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  const hipY = 0.63 * legLen;
  const torso = new THREE.Group();
  torso.position.y = hipY;
  body.add(torso);

  // --- 몸통 ---
  {
    const g = new Geo();
    const w = 0.46 * bulk;
    if (o.kind === 'golem') {
      g.ico(0.62, 0, M(0, 0.42, 0, 0.3, 0.4, 0, 1.25, 1.0, 0.95), o.rock, o.rock2, 0.4, 5);
      g.ico(0.3, 0, M(0.3, 0.75, -0.15, 0, 1, 0), o.rock, o.rock2, 0.4, 9);
      if (o.accent) g.ico(0.2, 0, M(-0.25, 0.8, 0.1, 0, 2, 0, 1.2, 0.6, 1), o.accent, null, 0.3, 4);
    } else {
      g.taperBox(w, 0.56, 0.28 * bulk, 1.12, M(0, 0.3, 0), shade(tunic, 0.82), tunic);
      if (o.skirt !== false) g.taperBox(w * 1.22, 0.2, 0.34 * bulk, 0.82, M(0, -0.04, 0), shade(tunic, 0.7), shade(tunic, 0.85));
      if (o.belt !== false) {
        g.box(w * 1.08, 0.07, 0.31 * bulk, M(0, 0.06, 0), o.beltColor ?? 0x5a3d25);
        g.box(0.08, 0.08, 0.03, M(0, 0.06, 0.16 * bulk), 0xe6c14a);
      }
      if (o.scarf != null) {
        g.box(0.4 * bulk, 0.1, 0.34, M(0, 0.6, 0), o.scarf);
        g.box(0.12, 0.32, 0.05, M(0.12, 0.42, -0.19, 0.25, 0, 0), shade(o.scarf, 0.85));
      }
      if (o.backpack) {
        g.box(0.32, 0.34, 0.16, M(0, 0.33, -0.23), 0x8a623c, 0x9c7449);
        g.cyl(0.08, 0.08, 0.38, 6, M(0, 0.56, -0.23, 0, 0, Math.PI / 2), 0xd9c9a0);
      }
      if (o.apron != null) g.box(w * 0.8, 0.5, 0.03, M(0, 0.2, 0.15 * bulk), o.apron);
      if (o.robe != null) g.taperBox(w * 1.5, 0.62, 0.42, 0.72, M(0, -0.3, 0), shade(o.robe, 0.75), o.robe);
      if (o.cape != null) g.taperBox(w * 1.5, 1.05, 0.06, 0.62, M(0, 0.02, -0.2 * bulk, 0.12, 0, 0), shade(o.cape, 0.7), o.cape);
      if (o.tail != null) g.cone(0.06, 0.6, 4, M(0, 0.0, -0.3, -1.9, 0, 0), o.tail);
      if (o.pauldrons != null) {
        g.ico(0.2, 0, M(0.34 * bulk, 0.56, 0, 0, 0, 0, 1.2, 0.8, 1.2), o.pauldrons);
        g.ico(0.2, 0, M(-0.34 * bulk, 0.56, 0, 0, 0, 0, 1.2, 0.8, 1.2), o.pauldrons);
      }
    }
    torso.add(mesh(g));
    if (o.core != null) {
      const gg = new Geo();
      gg.ico(0.11, 0, M(0, 0.36, 0.17 * bulk + (o.kind === 'golem' ? 0.42 : 0)), o.core);
      torso.add(mesh(gg, true));
    }
  }

  // --- 머리 ---
  const neckY = o.kind === 'golem' ? 0.9 : 0.6;
  const head = new THREE.Group();
  head.position.set(0, neckY, o.kind === 'golem' ? 0.12 : 0);
  torso.add(head);
  {
    const g = new Geo();
    const hs = headS;
    if (o.kind === 'golem') {
      g.ico(0.3, 0, M(0, 0.2, 0, 0, 0.6, 0, 1.1, 0.9, 1), o.rock, o.rock2, 0.35, 13);
    } else {
      g.ico(0.26 * hs, 1, M(0, 0.26 * hs, 0, 0, 0, 0, 1, 1, 0.95), shade(skin, 0.92), skin);
      const hy = 0.33 * hs;
      if (o.hairStyle !== 'bald') {
        g.ico(0.265 * hs, 1, M(0, hy, -0.06 * hs, 0, 0, 0, 1.03, 0.8, 1.03), shade(hair, 0.8), hair);
        g.box(0.3 * hs, 0.07 * hs, 0.08 * hs, M(0, 0.435 * hs, 0.18 * hs, 0.35, 0, 0), hair);
      }
      if (o.hairStyle === 'bun') g.ico(0.11 * hs, 0, M(0, 0.52 * hs, -0.2 * hs), hair);
      if (o.hairStyle === 'long') g.box(0.34 * hs, 0.34 * hs, 0.1 * hs, M(0, 0.1 * hs, -0.2 * hs), shade(hair, 0.85));
      if (o.eyes !== false) {
        const ec = o.eyeColor ?? 0x1f1a1a;
        g.box(0.055 * hs, 0.085 * hs, 0.03, M(0.1 * hs, 0.25 * hs, 0.235 * hs), ec);
        g.box(0.055 * hs, 0.085 * hs, 0.03, M(-0.1 * hs, 0.25 * hs, 0.235 * hs), ec);
      }
      if (o.band != null) g.box(0.55 * hs, 0.065 * hs, 0.53 * hs, M(0, 0.4 * hs, -0.01), o.band);
      if (o.hat === 'straw') g.cone(0.44 * hs, 0.22 * hs, 8, M(0, 0.55 * hs, 0), 0xc9ad5a, 0xe6d08a);
      if (o.hat === 'hood') g.ico(0.3 * hs, 0, M(0, 0.32 * hs, -0.07 * hs, 0, 0, 0, 1.05, 0.95, 1.05), shade(o.hatColor ?? 0x6a5a45, 0.8), o.hatColor ?? 0x6a5a45, 0.1, 3);
      if (o.beard != null) g.ico(0.16 * hs, 0, M(0, 0.09 * hs, 0.17 * hs, 0, 0, 0, 1.1, 1.3, 0.7), o.beard, null, 0.2, 2);
      if (o.horns === 1) g.cone(0.07 * hs, 0.26 * hs, 5, M(0, 0.6 * hs, 0.06 * hs, 0.25, 0, 0), 0xcfc4a0, 0xf5efd8);
      if (o.horns === 2) {
        g.cone(0.06 * hs, 0.24 * hs, 5, M(0.13 * hs, 0.56 * hs, 0.04, 0.2, 0, -0.35), 0xcfc4a0, 0xf5efd8);
        g.cone(0.06 * hs, 0.24 * hs, 5, M(-0.13 * hs, 0.56 * hs, 0.04, 0.2, 0, 0.35), 0xcfc4a0, 0xf5efd8);
      }
      if (o.horns === 3) {
        // 보스의 큰 뿔
        for (const sx of [1, -1]) {
          g.cone(0.09, 0.4, 5, M(0.24 * sx * hs, 0.5 * hs, 0, 0, 0, -1.1 * sx), 0x2a2030, 0x8a6fd0);
          g.cone(0.07, 0.36, 5, M(0.46 * sx * hs, 0.72 * hs, 0, 0, 0, -0.25 * sx), 0x5a4a80, 0xd9c8ff);
        }
      }
      if (o.tusks) {
        g.cone(0.03 * hs, 0.1 * hs, 4, M(0.09 * hs, 0.13 * hs, 0.22 * hs), 0xffffff);
        g.cone(0.03 * hs, 0.1 * hs, 4, M(-0.09 * hs, 0.13 * hs, 0.22 * hs), 0xffffff);
      }
      if (o.ears) {
        g.cone(0.06 * hs, 0.22 * hs, 4, M(0.27 * hs, 0.28 * hs, 0, 0, 0, -1.25), skin);
        g.cone(0.06 * hs, 0.22 * hs, 4, M(-0.27 * hs, 0.28 * hs, 0, 0, 0, 1.25), skin);
      }
      if (o.crown) {
        for (let k = 0; k < 5; k++) {
          const a = (k / 5) * Math.PI * 2;
          g.cone(0.05, 0.14, 4, M(Math.cos(a) * 0.14, 0.58 * hs, Math.sin(a) * 0.14), 0xe6b83a, 0xfff0a0);
        }
      }
    }
    head.add(mesh(g));
    if (o.glowEyes != null) {
      const gg = new Geo();
      const ez = o.kind === 'golem' ? 0.27 : 0.24 * hs;
      const ey = o.kind === 'golem' ? 0.22 : 0.25 * hs;
      gg.box(0.07 * hs, 0.06 * hs, 0.03, M(0.1 * hs, ey, ez), o.glowEyes);
      gg.box(0.07 * hs, 0.06 * hs, 0.03, M(-0.1 * hs, ey, ez), o.glowEyes);
      head.add(mesh(gg, true));
    }
  }

  // --- 팔 ---
  const shoulderX = (o.kind === 'golem' ? 0.72 : 0.31) * bulk;
  const shoulderY = o.kind === 'golem' ? 0.72 : 0.5;
  const mkArm = (side) => {
    const arm = new THREE.Group();
    arm.position.set(shoulderX * side, shoulderY, 0);
    arm.rotation.order = 'YXZ';
    const g = new Geo();
    const L = armLen;
    if (o.kind === 'golem') {
      g.ico(0.3, 0, M(0, -0.1, 0, 0, side, 0, 1, 1.1, 1), o.rock, o.rock2, 0.4, 17 + side);
      g.ico(0.36, 0, M(0, -0.62 * L, 0.02, 0.4, side * 2, 0, 1, 1.25, 1), o.rock, o.rock2, 0.45, 23 + side);
    } else {
      const sleeve = o.sleeve ?? tunic;
      const aw = 0.14 * (o.armBulk || 1);
      g.box(aw, 0.3 * L, aw * 1.07, M(0, -0.13 * L, 0), shade(sleeve, 0.9), sleeve);
      g.box(aw * 0.86, 0.24 * L, aw * 0.93, M(0, -0.38 * L, 0), o.bareArms ? skin : (o.glove ?? skin));
      g.box(aw * 0.93, 0.1, aw, M(0, -0.54 * L, 0), skin);
    }
    arm.add(mesh(g));
    torso.add(arm);
    return arm;
  };
  const armL = mkArm(1);
  const armR = mkArm(-1);
  const handY = -0.56 * armLen;

  // --- 다리 ---
  const mkLeg = (side) => {
    const leg = new THREE.Group();
    leg.position.set((o.kind === 'golem' ? 0.3 : 0.12 * bulk) * side, hipY, 0);
    const g = new Geo();
    const L = legLen;
    if (o.kind === 'golem') {
      g.ico(0.28, 0, M(0, -0.3 * L, 0, 0, side, 0, 1, 1.3, 1), o.rock, o.rock2, 0.4, 31 + side);
    } else {
      const lw = 0.19 * (o.legBulk || 1);
      g.box(lw, 0.38 * L, lw * 1.05, M(0, -0.2 * L, 0), shade(pants, 0.85), pants);
      g.box(lw * 1.06, 0.26 * L, lw * 1.28, M(0, -0.5 * L, 0.02), shade(boots, 0.85), boots);
    }
    leg.add(mesh(g));
    body.add(leg);
    return leg;
  };
  const legL = mkLeg(1);
  const legR = mkLeg(-1);

  // --- 무기 ---
  const weapon = new THREE.Group();
  weapon.position.set(0, handY, 0.03);
  armR.add(weapon);
  const rig = {
    kind: 'humanoid', root, body, torso, head, armL, armR, legL, legR, weapon, opts: o,
    glider: null, bow: null, weaponMesh: null,
    p: null, phase: 0, t: Math.random() * 10, atkT: -1, lastAnim: -1, height: (hipY + neckY + 0.55 * headS) * S,
  };
  setWeapon(rig, o.weapon || 'none', o.swordTier || 0);

  // --- 활공 천 ---
  if (o.glider) {
    const g = new Geo();
    const c = o.gliderColor ?? o.scarf ?? 0xe8b730;
    g.box(1.35, 0.04, 1.0, M(0.66, 1.52, 0, 0, 0, 0.14), shade(c, 0.85), c);
    g.box(1.35, 0.04, 1.0, M(-0.66, 1.52, 0, 0, 0, -0.14), shade(c, 0.85), c);
    g.box(0.16, 0.045, 1.02, M(0, 1.44, 0), 0xffffff);
    g.box(1.0, 0.04, 0.04, M(0, 1.02, 0.02), 0x7a5a3a);
    g.box(0.02, 0.5, 0.02, M(0.45, 1.27, 0.02, 0, 0, -0.5), 0x7a5a3a);
    g.box(0.02, 0.5, 0.02, M(-0.45, 1.27, 0.02, 0, 0, 0.5), 0x7a5a3a);
    rig.glider = mesh(g);
    rig.glider.visible = false;
    torso.add(rig.glider);
  }
  // --- 활 ---
  if (o.bow) {
    const g = new Geo();
    g.box(0.04, 0.34, 0.04, M(0, 0, 0.06), 0x8a623c);
    g.box(0.035, 0.36, 0.035, M(0, 0.31, -0.02, 0.5, 0, 0), 0x9c7449);
    g.box(0.035, 0.36, 0.035, M(0, -0.31, -0.02, -0.5, 0, 0), 0x9c7449);
    g.box(0.012, 0.92, 0.012, M(0, 0, -0.1), 0xeeeeee);
    rig.bow = mesh(g);
    rig.bow.position.set(0, handY, 0.08);
    rig.bow.rotation.x = -1.4;
    rig.bow.visible = false;
    armL.add(rig.bow);
  }

  root.scale.setScalar(S);
  rig.p = newPose();
  return rig;
}

export function setWeapon(rig, kind, tier = 0) {
  if (rig.weaponMesh) {
    rig.weapon.remove(rig.weaponMesh);
    rig.weaponMesh.geometry.dispose();
    rig.weaponMesh = null;
  }
  const g = new Geo();
  if (kind === 'sword') {
    const c = SWORDS[tier].color;
    g.box(0.065, 0.028, 0.78, M(0, 0, 0.5), shade(c, 0.8), c);
    g.taperBox(0.065, 0.14, 0.028, 0.05, M(0, 0, 0.96, Math.PI / 2, 0, 0), c);
    g.box(0.24, 0.05, 0.055, M(0, 0, 0.1), tier >= 3 ? 0x8fd8ff : 0xd9a93a);
    g.box(0.045, 0.045, 0.17, M(0, 0, 0), 0x5a3d25);
    g.ico(0.04, 0, M(0, 0, -0.1), tier >= 2 ? 0x8fd8ff : 0xd9a93a);
  } else if (kind === 'club') {
    g.cyl(0.12, 0.05, 0.95, 6, M(0, 0, 0.42, Math.PI / 2, 0, 0), 0x5a3d25, 0x7a5a3a);
    g.ico(0.05, 0, M(0.1, 0, 0.75), 0xbfbfbf);
    g.ico(0.05, 0, M(-0.1, 0, 0.7), 0xbfbfbf);
    g.ico(0.05, 0, M(0, 0.1, 0.8), 0xbfbfbf);
  } else if (kind === 'rock') {
    g.ico(0.13, 0, M(0, 0, 0.05), 0x8a8f98, 0xb0b5bd, 0.4, 3);
  } else if (kind === 'staff') {
    g.cyl(0.03, 0.04, 1.7, 5, M(0, 0.35, 0.05), 0x7a5a3a);
    g.ico(0.09, 0, M(0, 1.25, 0.05), 0xffe27a);
  } else if (kind === 'bigsword') {
    g.box(0.2, 0.05, 1.5, M(0, 0, 0.9), 0x241c30, 0x6a50a8);
    g.taperBox(0.2, 0.3, 0.05, 0.05, M(0, 0, 1.8, Math.PI / 2, 0, 0), 0x8a6fd0);
    g.box(0.5, 0.08, 0.08, M(0, 0, 0.12), 0x8a6fd0);
    g.box(0.07, 0.07, 0.3, M(0, 0, -0.05), 0x1a1420);
  } else return;
  rig.weaponMesh = mesh(g);
  rig.weapon.add(rig.weaponMesh);
}

function newPose() {
  return { tRx: 0, tRy: 0, tRz: 0, hRx: 0, hRy: 0, aLf: 0, aLs: 0.1, aLy: 0, aRf: 0, aRs: 0.1, aRy: 0, lLf: 0, lRf: 0, bodyY: 0, bodyRx: 0, wRx: 0.4 };
}
const TGT = newPose();
const ease = (p) => 1 - (1 - p) * (1 - p) * (1 - p);
const lerp = (a, b, t) => a + (b - a) * t;

// anim: POSE 값, speed: 이동 속도(달리기 주기), atkP: 공격 진행도(0..1), dt
export function animateHumanoid(rig, anim, dt, speed = 0, atkP = 0) {
  rig.t += dt;
  const t = rig.t;
  const T = TGT;
  T.tRx = T.tRy = T.tRz = T.hRx = T.hRy = T.aLf = T.aLy = T.aRf = T.aRy = T.lLf = T.lRf = T.bodyY = T.bodyRx = 0;
  T.aLs = 0.1;
  T.aRs = 0.12;
  T.wRx = 0.4;
  let snap = 14;
  let direct = false;
  let glider = false;
  let bow = false;
  let stow = false; // 무기를 넣어 두는 동작
  const hunch = rig.opts.hunch || 0;

  if (anim === POSE.RUN || anim === POSE.SPRINT || anim === POSE.WALK) {
    rig.phase += Math.max(1.5, speed) * dt * (anim === POSE.WALK ? 2.6 : 1.85);
    const s = Math.sin(rig.phase);
    const c = Math.cos(rig.phase);
    const amp = anim === POSE.SPRINT ? 1.1 : anim === POSE.WALK ? 0.5 : 0.85;
    T.lLf = s * amp;
    T.lRf = -s * amp;
    T.aLf = -s * amp * 0.75;
    T.aRf = s * amp * 0.6 + 0.15;
    T.tRx = anim === POSE.SPRINT ? 0.3 : 0.12;
    T.tRy = s * 0.1;
    T.bodyY = Math.abs(c) * 0.05 * amp;
    snap = 22;
  } else if (anim === POSE.JUMP) {
    T.lLf = 0.55; T.lRf = -0.25; T.aLs = 0.7; T.aRs = 0.7; T.aLf = 0.3; T.aRf = 0.3;
  } else if (anim === POSE.FALL) {
    T.aLs = 1.3 + Math.sin(t * 9) * 0.12; T.aRs = 1.3 - Math.sin(t * 9) * 0.12; T.lLf = 0.25; T.lRf = -0.2;
  } else if (anim === POSE.GLIDE) {
    T.aLf = 3.0; T.aRf = 3.0; T.aLs = 0.22; T.aRs = 0.22; T.lLf = -0.25 + Math.sin(t * 2) * 0.06; T.lRf = -0.38; T.bodyRx = 0.28; T.wRx = 1.4;
    glider = true;
    stow = true;
  } else if (anim === POSE.SWIM) {
    stow = true;
    rig.phase += dt * 6.5;
    T.bodyRx = 1.15; T.bodyY = 0.72;
    T.aLf = Math.PI + Math.sin(rig.phase) * 1.3; T.aRf = Math.PI - Math.sin(rig.phase) * 1.3;
    T.aLs = 0.3; T.aRs = 0.3;
    T.lLf = Math.sin(rig.phase * 2) * 0.4; T.lRf = -Math.sin(rig.phase * 2) * 0.4; T.hRx = -0.9;
    snap = 18;
  } else if (anim === POSE.SWIMIDLE) {
    stow = true;
    T.bodyRx = 0.15; T.bodyY = -0.12;
    T.aLs = 1.2 + Math.sin(t * 3) * 0.25; T.aRs = 1.2 + Math.sin(t * 3 + 1) * 0.25; T.aLf = 0.4; T.aRf = 0.4;
    T.lLf = Math.sin(t * 4) * 0.3; T.lRf = -Math.sin(t * 4) * 0.3;
  } else if (anim === POSE.CLIMB || anim === POSE.CLIMBIDLE) {
    stow = true;
    if (anim === POSE.CLIMB) rig.phase += dt * 7;
    const s = Math.sin(rig.phase);
    T.bodyRx = 0.5; T.aLf = 2.5 + s * 0.5; T.aRf = 2.5 - s * 0.5; T.lLf = 0.7 - s * 0.5; T.lRf = 0.7 + s * 0.5; T.hRx = -0.4;
  } else if (anim === POSE.ATK1 || anim === POSE.SWEEP || anim === POSE.SWEEPBACK) {
    const e = anim === POSE.SWEEPBACK ? 0 : ease(atkP);
    T.aRf = 1.45; T.aRy = lerp(-1.5, 1.3, e); T.wRx = 1.35; T.tRy = lerp(-0.55, 0.5, e); T.tRx = 0.15; T.aLs = 0.45; T.lLf = 0.4; T.lRf = -0.3;
    direct = anim !== POSE.SWEEPBACK;
  } else if (anim === POSE.ATK2) {
    const e = ease(atkP);
    T.aRf = 1.45; T.aRy = lerp(1.3, -1.5, e); T.wRx = 1.35; T.tRy = lerp(0.5, -0.55, e); T.tRx = 0.15; T.aLs = 0.45; T.lLf = -0.3; T.lRf = 0.4;
    direct = true;
  } else if (anim === POSE.ATK3 || anim === POSE.SMASH) {
    const e = ease(atkP);
    T.aRf = lerp(3.2, 0.45, e); T.aLf = lerp(2.9, 0.4, e); T.aLs = -0.15; T.aRs = -0.1; T.wRx = 1.2; T.tRx = lerp(-0.25, 0.5, e); T.lLf = 0.45; T.lRf = -0.35;
    T.bodyY = Math.sin(Math.min(1, atkP * 1.6) * Math.PI) * 0.16;
    direct = true;
  } else if (anim === POSE.RAISE) {
    T.aRf = 3.1; T.aLf = 2.8; T.aLs = -0.1; T.aRs = -0.1; T.wRx = 1.2; T.tRx = -0.28; T.bodyY = 0.04 + Math.sin(t * 30) * 0.008;
    snap = 9;
  } else if (anim === POSE.THROWBACK) {
    T.aRf = -1.2; T.aRs = 0.5; T.tRy = -0.5; T.aLf = 1.2; T.tRx = -0.1; snap = 10;
  } else if (anim === POSE.THROW) {
    T.aRf = 1.9; T.tRy = 0.45; T.tRx = 0.3; snap = 30;
  } else if (anim === POSE.ROAR) {
    T.aLs = 1.5; T.aRs = 1.5; T.aLf = 0.6; T.aRf = 0.6; T.tRx = -0.35; T.hRx = -0.5; T.bodyY = Math.sin(t * 40) * 0.01;
  } else if (anim === POSE.LUNGE) {
    T.tRx = 0.6; T.aRf = 1.5; T.wRx = 1.4; T.lLf = 0.8; T.lRf = -0.7; snap = 30;
  } else if (anim === POSE.CROUCH) {
    T.bodyY = -0.14; T.tRx = 0.35; T.aRf = -0.6; T.lLf = 0.5; T.lRf = 0.5; T.wRx = 1.2; snap = 9;
  } else if (anim === POSE.BOW) {
    T.aLf = 1.5; T.aLs = -0.1; T.aRf = 1.35; T.aRs = 0.55; T.tRx = -0.03; T.wRx = 0.2;
    bow = true; snap = 30;
  } else if (anim === POSE.HURT || anim === POSE.STAGGER) {
    T.tRx = -0.4; T.aLs = 0.9; T.aRs = 0.9; T.hRx = -0.3; snap = 25;
  } else if (anim === POSE.DEAD) {
    T.bodyRx = -1.52; T.bodyY = 0.16; T.aLs = 0.9; T.aRs = 0.9; snap = 6;
  } else if (anim === POSE.SIT) {
    T.bodyY = -0.5; T.lLf = 1.5; T.lRf = 1.45; T.aLs = 0.25; T.aRs = 0.25; T.aLf = 0.5; T.aRf = 0.5; T.tRx = -0.08;
  } else if (anim === POSE.WAVE) {
    T.aRs = 2.5 + Math.sin(t * 9) * 0.35; T.aRf = 0.1; T.hRy = 0.15; T.wRx = 1.4;
  } else if (anim === POSE.CHEER) {
    T.aLs = 2.6; T.aRs = 2.6; T.bodyY = Math.abs(Math.sin(t * 8)) * 0.16; T.wRx = 1.4;
  } else {
    // IDLE
    T.bodyY = Math.sin(t * 2) * 0.012;
    T.aRf = 0.15 + Math.sin(t * 2) * 0.02;
    T.hRy = Math.sin(t * 0.6) * 0.18;
  }
  T.tRx += hunch;
  T.hRx -= hunch * 0.6;

  const p = rig.p;
  const k = direct ? 1 : Math.min(1, snap * dt);
  for (const key in T) p[key] += (T[key] - p[key]) * k;

  rig.torso.rotation.set(p.tRx, p.tRy, p.tRz);
  rig.head.rotation.set(p.hRx, p.hRy, 0);
  rig.armL.rotation.set(-p.aLf, p.aLy, p.aLs);
  rig.armR.rotation.set(-p.aRf, p.aRy, -p.aRs);
  rig.legL.rotation.x = -p.lLf;
  rig.legR.rotation.x = -p.lRf;
  rig.body.position.y = p.bodyY;
  rig.body.rotation.x = p.bodyRx;
  rig.weapon.rotation.x = p.wRx;
  if (rig.glider) rig.glider.visible = glider;
  if (rig.bow) rig.bow.visible = bow;
  if (rig.weaponMesh && rig.bow) rig.weaponMesh.visible = !bow && !stow;
}

// ---------- 플레이어/NPC 외형 ----------
export function playerLook(profile) {
  const tunic = TUNIC_COLORS[profile.tunic % TUNIC_COLORS.length];
  const hair = HAIR_COLORS[profile.hair % HAIR_COLORS.length];
  const armor = profile.armor || 0;
  return {
    scale: 1, skin: 0xf2c9a0, tunic, hair, hairStyle: profile.hair % 2 ? 'bun' : 'short',
    pants: armor === 2 ? 0x6a7482 : 0x4a4a5a, boots: armor ? 0x4a3524 : 0x6a4a2c,
    scarf: 0xf4ede0, band: shade(tunic, 0.7), backpack: true, glider: true, bow: true,
    gliderColor: tunic, weapon: 'sword', swordTier: profile.sword || 0,
    pauldrons: armor === 2 ? 0xaab4c2 : armor === 1 ? 0x7a5a3a : null,
    sleeve: armor === 2 ? 0x8a94a2 : tunic,
  };
}

export function npcLook(kind) {
  switch (kind) {
    case 'elder':
      return { scale: 1.02, skin: 0xe8bf98, tunic: 0x6a4f9a, robe: 0x6a4f9a, hair: 0xe9e9ee, hairStyle: 'long', beard: 0xf2f2f5, weapon: 'staff', pants: 0x4a3a6a, belt: false, skirt: false };
    case 'merchant':
      return { scale: 1, skin: 0xf0c49a, tunic: 0x4f8a5a, apron: 0xe8dcc0, hair: 0x3a2a1e, hat: 'straw', backpack: true };
    case 'smith':
      return { scale: 1.08, skin: 0xd9a57a, tunic: 0x5a4a44, apron: 0x3a3030, hairStyle: 'bald', beard: 0x3a2a1e, bulk: 1.25, armBulk: 1.4, bareArms: true };
    case 'kid':
      return { scale: 0.68, skin: 0xf6d2ae, tunic: 0xf2c53a, hair: 0x5a3a22, hairStyle: 'bun', headSize: 1.18, pants: 0x4f6fa8 };
    default:
      return { scale: 1, skin: 0xe9bd92, tunic: 0x7a6a50, hair: 0x3a2a1e, hat: 'hood', hatColor: 0x6a5a45, backpack: true, scarf: 0xb5523a, pants: 0x4a4038 };
  }
}

// ---------- 몬스터 외형 ----------
// 바이옴별 색: 초원, 숲, 설산, 사막, 늪, 화산, 단풍
const SLIME_COL = [0x6fd06a, 0x3fae8f, 0xbfe9ff, 0xe9c040, 0x9a7fd0, 0xf0703a, 0xf0a040];
const GOBLIN_COL = [0x5fae8a, 0x4a8f6a, 0x8fb4c9, 0xc9a05a, 0x6a8f5a, 0x8a5a5a, 0x9a8a4a];
const WOLF_COL = [0x7a7f88, 0x6a6f78, 0xe8edf5, 0xb59a6a, 0x5a6058, 0x4a4044, 0x9a6a45];
const GOLEM_COL = [
  [0x7f848c, 0xa9aeb6, 0x6fbe4c], [0x6f7a70, 0x98a498, 0x4f9a48], [0x9fb4d0, 0xe4eefc, 0xbfe9ff], [0xc98f5f, 0xe9c890, 0xe9cf8c],
  [0x5a6050, 0x7f8a70, 0x6f8a4e], [0x3a3233, 0x5a4a48, 0xff6a2a], [0x8f8478, 0xb5a898, 0xe07a2a],
];
const GOLEM_EYE = [0x8fffd0, 0x8fffd0, 0x9ad6ff, 0xffe27a, 0xc8ff7a, 0xff8a3a, 0xffb05a];

export function makeMonster(type, biome, elite, minion) {
  const b = biome % 7;
  let rig;
  if (type === 'slime') rig = makeSlime(minion ? 0x5a4a8a : SLIME_COL[b], elite);
  else if (type === 'wolf') rig = makeWolf(WOLF_COL[b], elite);
  else if (type === 'scorpion') rig = makeScorpion(elite);
  else if (type === 'goblin') {
    rig = makeHumanoid({ scale: elite ? 1.5 : 1.02, skin: GOBLIN_COL[b], tunic: 0x7a5a3a, pants: 0x5a4030, boots: GOBLIN_COL[b], hairStyle: 'bald', horns: elite ? 2 : 1, tusks: true, ears: true, weapon: 'club', hunch: 0.22, bareArms: true, sleeve: GOBLIN_COL[b], belt: false, headSize: 1.12, armLen: 1.12, eyeColor: 0xffe27a, pauldrons: elite ? 0x5a5a66 : null });
  } else if (type === 'thrower') {
    rig = makeHumanoid({ scale: 0.95, skin: GOBLIN_COL[b], tunic: 0x8a4a3a, pants: 0x5a4030, boots: GOBLIN_COL[b], hairStyle: 'bald', horns: 1, ears: true, weapon: 'rock', hunch: 0.15, bareArms: true, sleeve: GOBLIN_COL[b], band: 0xd9483b, headSize: 1.1, eyeColor: 0xffe27a });
  } else if (type === 'imp') {
    rig = makeHumanoid({ scale: elite ? 1.3 : 0.86, skin: minion ? 0x6a4a9a : 0xd9502f, tunic: 0x4a2a2a, pants: 0x3a2224, boots: 0x3a2224, hairStyle: 'bald', horns: 2, ears: true, weapon: 'none', hunch: 0.12, bareArms: true, sleeve: minion ? 0x6a4a9a : 0xd9502f, belt: false, headSize: 1.2, tail: 0xb03a22, glowEyes: 0xffe27a, eyes: false });
  } else if (type === 'yeti') {
    rig = makeHumanoid({ scale: elite ? 2.1 : 1.65, skin: 0x8fa0b5, tunic: 0xf0f4fa, pants: 0xe4eaf2, boots: 0xcfd8e4, hair: 0xf0f4fa, hairStyle: 'short', bulk: 1.55, armLen: 1.3, armBulk: 1.7, legBulk: 1.5, legLen: 0.8, weapon: 'none', hunch: 0.25, sleeve: 0xf0f4fa, glove: 0xe4eaf2, belt: false, skirt: false, headSize: 0.95, horns: elite ? 2 : 0, eyeColor: 0x2a3a5a });
  } else if (type === 'golem') {
    const c = GOLEM_COL[b];
    rig = makeHumanoid({ kind: 'golem', scale: 2.4, rock: c[0], rock2: c[1], accent: c[2], glowEyes: GOLEM_EYE[b], core: GOLEM_EYE[b], bulk: 1, armLen: 1.25, legLen: 0.75, weapon: 'none', hunch: 0.1 });
  } else if (type === 'lord') {
    rig = makeHumanoid({ scale: 3.3, skin: 0x2a2438, tunic: 0x241c30, pants: 0x1a1424, boots: 0x120e1a, hairStyle: 'bald', horns: 3, weapon: 'bigsword', bulk: 1.35, armBulk: 1.5, legBulk: 1.3, sleeve: 0x2a2438, glove: 0x1a1424, cape: 0x4a2a6a, pauldrons: 0x5a4a80, glowEyes: 0xff5ad0, eyes: false, core: 0xff5ad0, beltColor: 0x8a6fd0, headSize: 0.9 });
  } else rig = makeSlime(0xffffff, false);
  rig.type = type;
  return rig;
}

// ---- 말랑이 ----
function makeSlime(color, elite) {
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  // 몸통: 매끈하고 속이 비치는 젤리
  const bg = new Geo();
  bg.ico(0.8, 2, M(0, 0.6, 0, 0, 0, 0, 1, 0.78, 1), shade(color, 0.7), shade(color, 1.18));
  const bgeo = bg.build(false);
  bgeo.computeVertexNormals();
  const jelly = new THREE.Mesh(bgeo, JELLY);
  jelly.castShadow = true;
  body.add(jelly);
  // 속에 비치는 핵과 눈
  const g = new Geo();
  g.ico(0.34, 1, M(0.05, 0.48, -0.08, 0, 0, 0, 1, 0.8, 1), shade(color, 0.42), shade(color, 0.78));
  g.ico(0.12, 1, M(0.26, 0.72, 0.68), 0x1f1a1a);
  g.ico(0.12, 1, M(-0.26, 0.72, 0.68), 0x1f1a1a);
  g.ico(0.045, 0, M(0.29, 0.78, 0.77), 0xffffff);
  g.ico(0.045, 0, M(-0.23, 0.78, 0.77), 0xffffff);
  if (elite) {
    for (let k = 0; k < 5; k++) {
      const a = (k / 5) * Math.PI * 2;
      g.cone(0.1, 0.3, 4, M(Math.cos(a) * 0.28, 1.28, Math.sin(a) * 0.28), 0xe6b83a, 0xfff0a0);
    }
    g.cyl(0.32, 0.32, 0.1, 8, M(0, 1.14, 0), 0xe6b83a);
  }
  body.add(mesh(g));
  if (elite) root.scale.setScalar(1.45);
  return { kind: 'slime', root, body, t: Math.random() * 10, phase: 0, sy: 1, height: elite ? 1.9 : 1.2 };
}

// ---- 늑대 ----
function makeWolf(color, elite) {
  const root = new THREE.Group();
  const body = new THREE.Group();
  body.position.y = 0.62;
  root.add(body);
  const dark = shade(color, 0.7);
  const g = new Geo();
  g.taperBox(0.46, 0.46, 1.15, 0.85, M(0, 0.12, 0), dark, color);
  g.box(0.36, 0.38, 0.4, M(0, 0.28, 0.72), dark, color);
  g.taperBox(0.2, 0.18, 0.34, 0.7, M(0, 0.2, 1.02, Math.PI / 2, 0, 0), color);
  g.box(0.08, 0.06, 0.06, M(0, 0.23, 1.2), 0x1f1a1a);
  g.cone(0.07, 0.2, 4, M(0.12, 0.56, 0.66), dark);
  g.cone(0.07, 0.2, 4, M(-0.12, 0.56, 0.66), dark);
  g.box(0.05, 0.05, 0.03, M(0.11, 0.36, 0.925), 0xffe27a);
  g.box(0.05, 0.05, 0.03, M(-0.11, 0.36, 0.925), 0xffe27a);
  body.add(mesh(g));
  const tail = new THREE.Group();
  tail.position.set(0, 0.22, -0.55);
  const tg = new Geo();
  tg.cone(0.11, 0.6, 5, M(0, 0, -0.28, -Math.PI / 2, 0, 0), dark, color);
  tail.add(mesh(tg));
  body.add(tail);
  const legs = [];
  for (const [x, z] of [[0.16, 0.42], [-0.16, 0.42], [0.16, -0.42], [-0.16, -0.42]]) {
    const leg = new THREE.Group();
    leg.position.set(x, -0.02, z);
    const lg = new Geo();
    lg.box(0.13, 0.6, 0.15, M(0, -0.3, 0), dark, color);
    leg.add(mesh(lg));
    body.add(leg);
    legs.push(leg);
  }
  if (elite) root.scale.setScalar(1.45);
  return { kind: 'wolf', root, body, tail, legs, t: Math.random() * 10, phase: 0, height: elite ? 1.7 : 1.2 };
}

// ---- 전갈 ----
function makeScorpion(elite) {
  const root = new THREE.Group();
  const body = new THREE.Group();
  body.position.y = 0.35;
  root.add(body);
  const c1 = elite ? 0x7a3a8a : 0xb5653a;
  const c2 = elite ? 0x4a2458 : 0x6a3a26;
  const g = new Geo();
  g.ico(0.5, 0, M(0, 0.05, 0.25, 0, 0, 0, 1.1, 0.5, 1.2), c2, c1, 0.2, 3);
  g.ico(0.42, 0, M(0, 0.05, -0.4, 0, 0, 0, 1, 0.5, 1.1), c2, c1, 0.2, 5);
  g.box(0.06, 0.06, 0.04, M(0.12, 0.2, 0.8), 0xffe27a);
  g.box(0.06, 0.06, 0.04, M(-0.12, 0.2, 0.8), 0xffe27a);
  for (let k = 0; k < 3; k++) {
    for (const s of [1, -1]) g.box(0.6, 0.06, 0.07, M(0.6 * s, -0.08, 0.3 - k * 0.32, 0, s * (0.3 - k * 0.3), s * -0.5), c2);
  }
  body.add(mesh(g));
  const claws = [];
  for (const s of [1, -1]) {
    const claw = new THREE.Group();
    claw.position.set(0.4 * s, 0.05, 0.6);
    const cg = new Geo();
    cg.box(0.14, 0.12, 0.5, M(0.08 * s, 0, 0.25, 0, 0.3 * s, 0), c1);
    cg.ico(0.2, 0, M(0.2 * s, 0, 0.6, 0, 0, 0, 1, 0.7, 1.4), c2, c1, 0.2, 7);
    claw.add(mesh(cg));
    body.add(claw);
    claws.push(claw);
  }
  // 꼬리: 3마디 사슬
  const tail = [];
  let parent = body;
  for (let k = 0; k < 3; k++) {
    const seg = new THREE.Group();
    seg.position.set(0, k === 0 ? 0.15 : 0.42, k === 0 ? -0.75 : 0);
    const sg = new Geo();
    sg.ico(0.17 - k * 0.02, 0, M(0, 0.2, 0, 0, 0, 0, 1, 1.5, 1), c2, c1, 0.2, 11 + k);
    if (k === 2) sg.cone(0.08, 0.36, 4, M(0, 0.5, 0.08, 0.9, 0, 0), 0x2a1a1a, 0xffe27a);
    seg.add(mesh(sg));
    parent.add(seg);
    parent = seg;
    tail.push(seg);
  }
  if (elite) root.scale.setScalar(1.45);
  return { kind: 'scorpion', root, body, claws, tail, t: Math.random() * 10, phase: 0, height: elite ? 1.7 : 1.2 };
}

// 몬스터 애니메이션. state: 'idle'|'walk'|'run'|'windup'|'strike'|'stagger', pattern: 공격 종류
export function animateMonster(rig, state, pattern, dt, speed, p) {
  rig.t += dt;
  const t = rig.t;
  if (rig.kind === 'humanoid') {
    let pose = POSE.IDLE;
    if (state === 'walk') pose = POSE.WALK;
    else if (state === 'run') pose = POSE.RUN;
    else if (state === 'stagger') pose = POSE.STAGGER;
    else if (state === 'windup') {
      pose = pattern === 'throw' ? POSE.THROWBACK : pattern === 'arc' && rig.type === 'lord' ? POSE.SWEEPBACK : pattern === 'roar' || pattern === 'meteor' ? POSE.ROAR : pattern === 'lunge' ? POSE.CROUCH : POSE.RAISE;
    } else if (state === 'strike') {
      pose = pattern === 'throw' ? POSE.THROW : pattern === 'arc' && rig.type === 'lord' ? POSE.SWEEP : pattern === 'roar' || pattern === 'meteor' ? POSE.ROAR : pattern === 'lunge' ? POSE.LUNGE : POSE.SMASH;
    }
    animateHumanoid(rig, pose, dt, speed, p);
    return;
  }
  if (rig.kind === 'slime') {
    let sy = 1 + Math.sin(t * 4) * 0.06;
    let y = 0;
    if (state === 'walk' || state === 'run') {
      rig.phase += dt * (state === 'run' ? 9 : 6);
      const h = Math.abs(Math.sin(rig.phase));
      y = h * (state === 'run' ? 0.45 : 0.25);
      sy = 0.85 + h * 0.3;
    } else if (state === 'windup') sy = 0.62 + Math.sin(t * 40) * 0.02;
    else if (state === 'strike') { sy = 1.3; y = Math.sin(Math.min(1, p) * Math.PI) * 0.9; }
    else if (state === 'stagger') sy = 0.75;
    rig.sy += (sy - rig.sy) * Math.min(1, dt * 18);
    const sxz = 1 / Math.sqrt(rig.sy);
    rig.body.scale.set(sxz, rig.sy, sxz);
    rig.body.position.y += (y - rig.body.position.y) * Math.min(1, dt * 20);
    return;
  }
  if (rig.kind === 'wolf') {
    let amp = 0;
    let by = 0.62;
    let rx = 0;
    if (state === 'walk') { rig.phase += dt * 7; amp = 0.4; }
    else if (state === 'run') { rig.phase += dt * 15; amp = 0.9; by = 0.62 + Math.abs(Math.sin(rig.phase)) * 0.08; }
    else if (state === 'windup') { by = 0.48; rx = -0.2; }
    else if (state === 'strike') { by = 0.8; rx = 0.25; amp = 1.2; }
    else if (state === 'stagger') { rx = -0.3; }
    const s = Math.sin(rig.phase);
    const k = Math.min(1, dt * 20);
    const tg = state === 'strike' ? [1.2, 1.2, -1.2, -1.2] : [s * amp, -s * amp, -s * amp, s * amp];
    for (let i = 0; i < 4; i++) rig.legs[i].rotation.x += (-tg[i] - rig.legs[i].rotation.x) * k;
    rig.body.position.y += (by - rig.body.position.y) * k;
    rig.body.rotation.x += (rx - rig.body.rotation.x) * k;
    rig.tail.rotation.y = Math.sin(t * 6) * 0.3;
    rig.tail.rotation.x = state === 'run' ? 0.3 : -0.4;
    return;
  }
  if (rig.kind === 'scorpion') {
    if (state === 'walk' || state === 'run') rig.phase += dt * (state === 'run' ? 16 : 9);
    rig.body.position.y = 0.35 + Math.sin(rig.phase) * 0.03;
    rig.body.rotation.z = Math.sin(rig.phase) * 0.05;
    let curl = 0.75 + Math.sin(t * 2) * 0.05;
    let base = 0.55;
    if (state === 'windup') { curl = 0.35; base = -0.1; }
    else if (state === 'strike') { curl = 0.95; base = 1.25; }
    const k = Math.min(1, dt * (state === 'strike' ? 30 : 10));
    rig.tail[0].rotation.x += (base - rig.tail[0].rotation.x) * k;
    rig.tail[1].rotation.x += (curl - rig.tail[1].rotation.x) * k;
    rig.tail[2].rotation.x += (curl - rig.tail[2].rotation.x) * k;
    const open = state === 'windup' ? 0.6 : 0.15 + Math.sin(t * 3) * 0.1;
    rig.claws[0].rotation.y = open;
    rig.claws[1].rotation.y = -open;
  }
}

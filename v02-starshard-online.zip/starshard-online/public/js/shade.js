// 셰이더 공용 부품: 모든 재질이 함께 쓰는 환경 값, 대기(안개) 계산, 재질 패치 도우미, 노이즈 텍스처
import * as THREE from '/vendor/three/three.module.js';

// 모든 재질이 공유하는 유니폼 (매 프레임 gfx.update 에서 갱신)
export const env = {
  uTime: { value: 0 },
  uSunDir: { value: new THREE.Vector3(0.3, 0.9, 0.3) }, // 빛이 오는 방향 (낮에는 해, 밤에는 달)
  uSunCol: { value: new THREE.Color(1, 1, 1) },
  uFogColor: { value: new THREE.Color(0.75, 0.88, 1) },
  uFogSun: { value: new THREE.Color(1, 0.95, 0.85) },
  uFogDensity: { value: 0.004 },
  uCloud: { value: 0.8 }, // 구름 그림자 세기
  uDay: { value: 1 }, // 낮 1 ~ 밤 0
  uNoise: { value: null },
  uShade: { value: null }, // 나무 그늘(구워 둔 그림자) 텍스처
  uShadeK: { value: 0.45 },
  uData: { value: null }, // 지형 데이터 (높이, 늪, 풀 밀도, 용암)
  uGround: { value: null }, // 지면 색 텍스처
  uPlayer: { value: new THREE.Vector3() },
};

// 낮은 품질에서는 셰이더를 가볍게 만든다 (GFX_LITE 정의). gfx.setQuality 가 바꾼다.
export const flags = { lite: false };

// 밝은 부분만 부드럽게 눌러 주는 톤 곡선 (중간 밝기까지는 원래 색 그대로)
export const TONE_FN = /* glsl */ `
vec3 gameTone(vec3 c) {
  float peak = max(c.r, max(c.g, c.b));
  const float start = 0.78;
  if (peak < start) return c;
  float d = 1.0 - start;
  float newPeak = 1.0 - d * d / (peak + d - start);
  c *= newPeak / peak;
  float g = 1.0 - 1.0 / (0.18 * (peak - newPeak) + 1.0);
  return mix(c, vec3(newPeak), g);
}
`;

// 거리·높이·태양 방향에 따른 대기 안개
export const ATMO_PARS = /* glsl */ `
uniform vec3 uFogColor;
uniform vec3 uFogSun;
uniform vec3 uSunDir;
uniform float uFogDensity;
vec3 applyAtmo(vec3 col, vec3 wp) {
  vec3 v = wp - cameraPosition;
  #ifdef GFX_LITE
    float f = 1.0 - exp(-dot(v, v) * uFogDensity * uFogDensity * 0.9);
    return mix(col, uFogColor, f);
  #else
    float dist = length(v);
    float f = 1.0 - exp(-pow(dist * uFogDensity, 1.6));
    float hf = exp(-max(wp.y - 14.0, 0.0) * 0.009);
    f *= mix(0.62, 1.0, hf);
    float s = pow(max(dot(v / max(dist, 0.001), uSunDir), 0.0), 5.0);
    return mix(col, mix(uFogColor, uFogSun, s * 0.75), clamp(f, 0.0, 1.0));
  #endif
}
`;

const CLOUD_SHADOW = /* glsl */ `
#ifndef GFX_LITE
{
  float cs = texture2D(uNoise, vWorldPos.xz * 0.0011 + uTime * vec2(0.0035, 0.0017)).r;
  outgoingLight *= mix(1.0, mix(0.66, 1.0, smoothstep(0.38, 0.62, cs)), uCloud);
}
#endif
`;

// three.js 기본 재질(Lambert/Phong/Basic)에 대기 안개·구름 그림자와 사용자 코드를 끼워 넣는다.
// hooks: uniforms, vertexPars, vertexBegin(대체), vertexAfterBegin, vertexProject(대체), vertexWorldpos(대체),
//        fragPars, fragColor, fragNormal(대체), fragLight, cloud(false 면 구름 그림자 없음)
export function patchMaterial(mat, key, h = {}) {
  mat.fog = false;
  mat.onBeforeCompile = (shader) => {
    for (const k of Object.keys(env)) shader.uniforms[k] = env[k];
    if (h.uniforms) Object.assign(shader.uniforms, h.uniforms);
    const def = flags.lite ? '#define GFX_LITE\n' : '';

    let vs = shader.vertexShader;
    vs = vs.replace('#include <common>', `${def}#include <common>\nvarying vec3 vWorldPos;\nuniform float uTime;\n${h.vertexPars || ''}`);
    if (h.vertexBegin) vs = vs.replace('#include <begin_vertex>', h.vertexBegin);
    else if (h.vertexAfterBegin) vs = vs.replace('#include <begin_vertex>', `#include <begin_vertex>\n${h.vertexAfterBegin}`);
    if (h.vertexProject) vs = vs.replace('#include <project_vertex>', h.vertexProject);
    else {
      vs = vs.replace(
        '#include <project_vertex>',
        `#include <project_vertex>
        {
          vec4 wp4 = vec4(transformed, 1.0);
          #ifdef USE_INSTANCING
            wp4 = instanceMatrix * wp4;
          #endif
          vWorldPos = (modelMatrix * wp4).xyz;
        }`
      );
    }
    if (h.vertexWorldpos) vs = vs.replace('#include <worldpos_vertex>', h.vertexWorldpos);
    shader.vertexShader = vs;

    let fs = shader.fragmentShader;
    fs = fs.replace(
      '#include <common>',
      `${def}#include <common>
      varying vec3 vWorldPos;
      uniform float uTime;
      uniform float uCloud;
      uniform float uDay;
      uniform vec3 uSunCol;
      uniform sampler2D uNoise;
      ${ATMO_PARS}
      ${h.fragPars || ''}`
    );
    if (h.fragColor) fs = fs.replace('#include <color_fragment>', `#include <color_fragment>\n${h.fragColor}`);
    if (h.fragNormal) fs = fs.replace('#include <normal_fragment_begin>', h.fragNormal);
    fs = fs.replace('#include <envmap_fragment>', `${h.fragLight || ''}\n${h.cloud === false ? '' : CLOUD_SHADOW}`);
    fs = fs.replace('#include <opaque_fragment>', '#include <opaque_fragment>\n gl_FragColor.rgb = applyAtmo(gl_FragColor.rgb, vWorldPos);');
    shader.fragmentShader = fs;
  };
  mat.customProgramCacheKey = () => (flags.lite ? key + ':lite' : key);
  return mat;
}

// 직접 화면에 그릴 때(낮은 품질)도 같은 톤 곡선을 쓰도록 three.js 의 사용자 정의 톤매핑을 교체
export function installToneMapping() {
  const chunk = THREE.ShaderChunk.tonemapping_pars_fragment;
  if (chunk.includes('gameTone')) return;
  THREE.ShaderChunk.tonemapping_pars_fragment = chunk.replace(
    'vec3 CustomToneMapping( vec3 color ) { return color; }',
    `${TONE_FN}\nvec3 CustomToneMapping( vec3 color ) { return gameTone( color * toneMappingExposure ); }`
  );
}

// ---------- 타일처럼 이어지는 노이즈 텍스처 (RGBA 4채널, 256x256) ----------
function hashI(x, y, s) {
  let h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(s | 0, 1274126177);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

function tileNoise(x, y, period, seed) {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const x0 = ((xi % period) + period) % period;
  const y0 = ((yi % period) + period) % period;
  const x1 = (x0 + 1) % period;
  const y1 = (y0 + 1) % period;
  const a = hashI(x0, y0, seed);
  const b = hashI(x1, y0, seed);
  const c = hashI(x0, y1, seed);
  const d = hashI(x1, y1, seed);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

export function makeNoiseTexture() {
  const S = 256;
  const data = new Uint8Array(S * S * 4);
  const bases = [4, 4, 8, 16];
  for (let ch = 0; ch < 4; ch++) {
    const base = bases[ch];
    const tmp = new Float32Array(S * S);
    let mn = Infinity;
    let mx = -Infinity;
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        let sum = 0;
        let amp = 1;
        let norm = 0;
        let p = base;
        for (let o = 0; o < 4; o++) {
          sum += amp * tileNoise((x / S) * p, (y / S) * p, p, 17 + ch * 31 + o * 7);
          norm += amp;
          amp *= 0.5;
          p *= 2;
        }
        const v = sum / norm;
        tmp[y * S + x] = v;
        if (v < mn) mn = v;
        if (v > mx) mx = v;
      }
    }
    for (let i = 0; i < S * S; i++) data[i * 4 + ch] = Math.round(((tmp[i] - mn) / (mx - mn)) * 255);
  }
  const tex = new THREE.DataTexture(data, S, S, THREE.RGBAFormat, THREE.UnsignedByteType);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.generateMipmaps = true;
  tex.needsUpdate = true;
  return tex;
}

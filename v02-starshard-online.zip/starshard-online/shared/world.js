// 서버와 클라이언트가 함께 쓰는 월드 생성기.
// 같은 seed 라면 어디서 실행해도 완전히 같은 섬이 만들어진다 (사칙연산과 sqrt 만 사용).
import { makeNoise, fbm, ridged, rand2, smoothstep } from './noise.js';

export const W = {
  SIZE: 1600,
  HALF: 800,
  CELL: 4,
  GRID: 400,
  VERTS: 401,
  CHUNK_CELLS: 25,
  CHUNK: 100,
  CHUNKS: 16,
  SEA: 0,
};

export const BIOME = { MEADOW: 0, FOREST: 1, SNOW: 2, DESERT: 3, SWAMP: 4, VOLCANO: 5, AUTUMN: 6 };
export const NB = 7;

export const BIOME_INFO = [
  { key: 'meadow', name: '새벽 초원', level: 1 },
  { key: 'forest', name: '속삭임 숲', level: 3 },
  { key: 'snow', name: '서리봉 설산', level: 9 },
  { key: 'desert', name: '황금 사막', level: 6 },
  { key: 'swamp', name: '안개 늪', level: 7 },
  { key: 'volcano', name: '잿불 화산', level: 11 },
  { key: 'autumn', name: '단풍 고원', level: 4 },
];

// 바이옴 중심 (x, z, 크기 보정)
const CX = [0, 470, -140, 120, -400, 460, -520];
const CZ = [0, 100, -480, 520, 320, -370, -110];
const CS = [1.0, 1.0, 1.0, 1.0, 1.0, 1.2, 1.0];

export const BIOME_CENTERS = CX.map((x, i) => [x, CZ[i]]);

export const VILLAGE = { x: 0, z: 0, h: 9, r: 44 };
export const VOLCANO = { x: 460, z: -370, floor: 60, arenaR: 28, notchX: -0.7071067811865476, notchZ: 0.7071067811865476 };

export const PROP = {
  OAK: 0,
  PINE: 1,
  AUTUMN: 2,
  SNOWPINE: 3,
  PALM: 4,
  DEAD: 5,
  WILLOW: 6,
  CACTUS: 7,
  ROCK: 8,
  BUSH: 9,
  DRYBUSH: 10,
  FLOWER: 11,
  MUSHROOM: 12,
  REED: 13,
  ICE: 14,
  SPIKE: 15,
};

export function createWorld(seed, opts = {}) {
  const nA = makeNoise(seed + 11);
  const nB = makeNoise(seed + 23);
  const nC = makeNoise(seed + 37);
  const nD = makeNoise(seed + 41);
  const nM = makeNoise(seed + 53);
  const nL = makeNoise(seed + 67);
  const nW1 = makeNoise(seed + 71);
  const nW2 = makeNoise(seed + 83);
  const nCoast = makeNoise(seed + 97);
  const nV = makeNoise(seed + 103);
  const nGrove = makeNoise(seed + 131);

  const N = W.VERTS;
  const heights = new Float32Array(N * N);
  const biome = new Uint8Array(N * N);
  const bw = opts.weights ? new Uint8Array(N * N * NB) : null;

  const wSoft = new Float64Array(NB);
  const wSharp = new Float64Array(NB);
  let dom = 0;

  function biomeWeights(x, z) {
    const wx = x + 80 * nW1(x * 0.0032, z * 0.0032);
    const wz = z + 80 * nW2(x * 0.0032 + 31.7, z * 0.0032 - 12.3);
    let sSoft = 0;
    let sSharp = 0;
    let bestW = -1;
    for (let i = 0; i < NB; i++) {
      const dx = wx - CX[i];
      const dz = wz - CZ[i];
      const d2 = (dx * dx + dz * dz) * CS[i];
      const a = 1 / (d2 + 3500);
      const soft = a * a;
      const b = 1 / (d2 + 600);
      const b2 = b * b;
      const sharp = b2 * b2 * b2;
      wSoft[i] = soft;
      wSharp[i] = sharp;
      sSoft += soft;
      sSharp += sharp;
      if (sharp > bestW) {
        bestW = sharp;
        dom = i;
      }
    }
    for (let i = 0; i < NB; i++) {
      wSoft[i] /= sSoft;
      wSharp[i] /= sSharp;
    }
  }

  const EPS = 0.004;

  function rawHeight(x, z) {
    biomeWeights(x, z);
    const nBase = fbm(nA, x * 0.003, z * 0.003, 4);
    const nDet = fbm(nB, x * 0.013, z * 0.013, 3);
    let h = 0;
    let w;

    // 초원: 완만한 언덕 + 호수
    if ((w = wSoft[0]) > EPS) {
      let hm = 8.5 + 9 * nBase + 1.6 * nDet;
      const lk = nL(x * 0.0055 + 40.3, z * 0.0055 - 17.9);
      hm -= 15 * smoothstep(0.42, 0.62, lk);
      h += w * hm;
    }
    // 숲: 굴곡진 언덕
    if ((w = wSoft[1]) > EPS) {
      h += w * (13 + 17 * nBase + 4.5 * nDet);
    }
    // 설산: 높은 능선
    if ((w = wSoft[2]) > EPS) {
      const r = ridged(nC, x * 0.0038, z * 0.0038, 4);
      h += w * (22 + 150 * r * r + 14 * nBase + 5 * nDet);
    }
    // 사막: 모래 언덕 + 탁상지(메사)
    if ((w = wSoft[3]) > EPS) {
      let dn = nD(x * 0.011 + 0.6 * nBase, z * 0.0045);
      if (dn < 0) dn = -dn;
      let du = 1 - dn;
      if (du < 0) du = 0;
      const ms = smoothstep(0.24, 0.33, nM(x * 0.0058 + 7.7, z * 0.0058 + 3.1));
      h += w * (6.5 + 5 * du * du + 20 * ms + 1.5 * nBase + ms * 1.5 * nDet);
    }
    // 늪: 수면 근처의 낮은 땅
    if ((w = wSoft[4]) > EPS) {
      h += w * (0.25 + 2.0 * nBase + 2.6 * nDet);
    }
    // 화산 지대 기반
    if ((w = wSoft[5]) > EPS) {
      const r = ridged(nV, x * 0.009, z * 0.009, 3);
      h += w * (9 + 7 * nBase + 3 * nDet + 7 * r);
    }
    // 단풍 고원
    if ((w = wSoft[6]) > EPS) {
      h += w * (19 + 15 * nBase + 4.5 * nDet);
    }

    // 화산 원뿔 + 분화구 + 협곡 입구
    const vx = x - VOLCANO.x;
    const vz = z - VOLCANO.z;
    const dV = Math.sqrt(vx * vx + vz * vz);
    if (dV < 250) {
      const t = 1 - dV / 250;
      h += 100 * t * t * (3 - 2 * t);
      if (dV < 56) {
        const k = smoothstep(VOLCANO.arenaR + 2, 56, dV);
        h = VOLCANO.floor + (h - VOLCANO.floor) * k;
      }
      if (dV > 20 && dV < 140) {
        const dot = (vx * VOLCANO.notchX + vz * VOLCANO.notchZ) / dV;
        const nf = smoothstep(0.972, 0.995, dot);
        if (nf > 0) {
          const target = VOLCANO.floor + 1.2;
          if (h > target) h = h + (target - h) * nf;
        }
      }
    }

    // 섬 모양 마스크 (바다로 떨어지는 해안)
    const dn2 = Math.sqrt(x * x + z * z) / 770 + 0.09 * nCoast(x * 0.005, z * 0.005);
    const m = smoothstep(0.86, 1.0, dn2);
    h = h + (-26 - h) * m;
    if (h < -26) h = -26;
    return h;
  }

  // 높이맵 생성
  {
    let idx = 0;
    for (let j = 0; j < N; j++) {
      const z = -W.HALF + j * W.CELL;
      for (let i = 0; i < N; i++) {
        const x = -W.HALF + i * W.CELL;
        heights[idx] = rawHeight(x, z);
        biome[idx] = dom;
        if (bw) {
          const o = idx * NB;
          for (let k = 0; k < NB; k++) bw[o + k] = Math.round(wSharp[k] * 255);
        }
        idx++;
      }
    }
  }

  function clampCoord(v) {
    return v < -W.HALF ? -W.HALF : v > W.HALF - 0.001 ? W.HALF - 0.001 : v;
  }

  // 메시의 삼각형 분할과 동일한 방식으로 보간한 지면 높이
  function heightAt(x, z) {
    const fx = (clampCoord(x) + W.HALF) / W.CELL;
    const fz = (clampCoord(z) + W.HALF) / W.CELL;
    const i = Math.floor(fx);
    const j = Math.floor(fz);
    const u = fx - i;
    const v = fz - j;
    const a = j * N + i;
    const ha = heights[a];
    const hb = heights[a + 1];
    const hc = heights[a + N];
    const hd = heights[a + N + 1];
    if (u + v <= 1) return ha + (hb - ha) * u + (hc - ha) * v;
    return hd + (hc - hd) * (1 - u) + (hb - hd) * (1 - v);
  }

  // 지면 기울기 (dh/dx, dh/dz)
  function gradAt(x, z, out) {
    const fx = (clampCoord(x) + W.HALF) / W.CELL;
    const fz = (clampCoord(z) + W.HALF) / W.CELL;
    const i = Math.floor(fx);
    const j = Math.floor(fz);
    const u = fx - i;
    const v = fz - j;
    const a = j * N + i;
    const ha = heights[a];
    const hb = heights[a + 1];
    const hc = heights[a + N];
    const hd = heights[a + N + 1];
    if (u + v <= 1) {
      out.x = (hb - ha) / W.CELL;
      out.z = (hc - ha) / W.CELL;
    } else {
      out.x = (hd - hc) / W.CELL;
      out.z = (hd - hb) / W.CELL;
    }
    return out;
  }

  const _g = { x: 0, z: 0 };
  function slopeAt(x, z) {
    gradAt(x, z, _g);
    return Math.sqrt(_g.x * _g.x + _g.z * _g.z);
  }

  function vertIndex(x, z) {
    let i = Math.round((x + W.HALF) / W.CELL);
    let j = Math.round((z + W.HALF) / W.CELL);
    if (i < 0) i = 0;
    if (i > W.GRID) i = W.GRID;
    if (j < 0) j = 0;
    if (j > W.GRID) j = W.GRID;
    return j * N + i;
  }

  function biomeAt(x, z) {
    return biome[vertIndex(x, z)];
  }

  // 지형 평탄화 패치 적용: { x, z, r, f, h }
  function applyPatches(patches) {
    for (const p of patches) {
      const R = p.r + p.f;
      const i0 = Math.max(0, Math.floor((p.x - R + W.HALF) / W.CELL));
      const i1 = Math.min(W.GRID, Math.ceil((p.x + R + W.HALF) / W.CELL));
      const j0 = Math.max(0, Math.floor((p.z - R + W.HALF) / W.CELL));
      const j1 = Math.min(W.GRID, Math.ceil((p.z + R + W.HALF) / W.CELL));
      for (let j = j0; j <= j1; j++) {
        for (let i = i0; i <= i1; i++) {
          const x = -W.HALF + i * W.CELL;
          const z = -W.HALF + j * W.CELL;
          const dx = x - p.x;
          const dz = z - p.z;
          const d = Math.sqrt(dx * dx + dz * dz);
          if (d >= R) continue;
          const t = 1 - smoothstep(p.r, R, d);
          const idx = j * N + i;
          heights[idx] = heights[idx] + (p.h - heights[idx]) * t;
        }
      }
    }
  }

  // ---- 장식물(나무/바위 등) 배치 ----
  let exclusions = [];
  const propCache = new Map();

  function setExclusions(list) {
    exclusions = list || [];
    propCache.clear();
  }

  const PSTEP = 5;
  const PCELLS = W.CHUNK / PSTEP;

  function chunkProps(cx, cz) {
    const key = cz * W.CHUNKS + cx;
    let list = propCache.get(key);
    if (list) return list;
    list = [];
    propCache.set(key, list);
    if (cx < 0 || cz < 0 || cx >= W.CHUNKS || cz >= W.CHUNKS) return list;
    const x0 = -W.HALF + cx * W.CHUNK;
    const z0 = -W.HALF + cz * W.CHUNK;
    const ex = [];
    for (const e of exclusions) {
      if (e.x + e.r < x0 || e.x - e.r > x0 + W.CHUNK || e.z + e.r < z0 || e.z - e.r > z0 + W.CHUNK) continue;
      ex.push(e);
    }
    for (let gz = 0; gz < PCELLS; gz++) {
      for (let gx = 0; gx < PCELLS; gx++) {
        const ix = cx * PCELLS + gx;
        const iz = cz * PCELLS + gz;
        const pick = rand2(ix, iz, seed + 201);
        const x = x0 + (gx + 0.1 + 0.8 * rand2(ix, iz, seed + 202)) * PSTEP;
        const z = z0 + (gz + 0.1 + 0.8 * rand2(ix, iz, seed + 203)) * PSTEP;
        const h = heightAt(x, z);
        if (h < -0.7) continue;
        const b = biomeAt(x, z);
        const sl = slopeAt(x, z);
        const r1 = rand2(ix, iz, seed + 204);
        const r2 = rand2(ix, iz, seed + 205);
        let t = -1;
        let s = 1;
        let cr = 0;
        const land = h > 0.9;
        const flat = sl < 0.75;
        const gv = nGrove(x * 0.011, z * 0.011);

        if (b === BIOME.MEADOW) {
          const tp = gv > 0.25 ? 0.14 : 0.012;
          if (land && flat && pick < tp) { t = PROP.OAK; s = 0.9 + r1 * 0.7; cr = 0.45 * s; }
          else if (land && pick < tp + 0.012) { t = PROP.BUSH; s = 0.7 + r1 * 0.6; }
          else if (land && pick < tp + 0.02) { t = PROP.ROCK; s = 0.5 + r1 * 1.1; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && sl < 0.5 && pick < tp + 0.075) { t = PROP.FLOWER; s = 0.8 + r1 * 0.5; }
        } else if (b === BIOME.FOREST) {
          const tp = 0.2 + 0.16 * (gv + 0.5);
          if (land && flat && pick < tp) { t = r2 < 0.55 ? PROP.PINE : PROP.OAK; s = 1.0 + r1 * 0.9; cr = 0.45 * s; }
          else if (land && pick < tp + 0.04) { t = PROP.BUSH; s = 0.7 + r1 * 0.7; }
          else if (land && pick < tp + 0.055) { t = PROP.ROCK; s = 0.5 + r1 * 1.2; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && pick < tp + 0.085) { t = PROP.MUSHROOM; s = 0.7 + r1 * 0.8; }
        } else if (b === BIOME.AUTUMN) {
          const tp = gv > -0.1 ? 0.13 : 0.03;
          if (land && flat && pick < tp) { t = PROP.AUTUMN; s = 0.9 + r1 * 0.8; cr = 0.45 * s; }
          else if (land && pick < tp + 0.02) { t = PROP.ROCK; s = 0.5 + r1 * 1.3; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && pick < tp + 0.045) { t = PROP.BUSH; s = 0.7 + r1 * 0.6; }
          else if (land && sl < 0.5 && pick < tp + 0.07) { t = PROP.FLOWER; s = 0.8 + r1 * 0.4; }
        } else if (b === BIOME.SNOW) {
          if (land && flat && h < 100 && pick < (gv > 0.1 ? 0.07 : 0.015)) { t = PROP.SNOWPINE; s = 1.0 + r1 * 0.8; cr = 0.45 * s; }
          else if (land && pick < 0.1) { t = PROP.ROCK; s = 0.6 + r1 * 1.6; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && flat && pick < 0.108) { t = PROP.ICE; s = 0.8 + r1 * 1.2; cr = 0.6 * s; }
        } else if (b === BIOME.DESERT) {
          if (land && flat && h < 3.2 && pick < 0.1) { t = PROP.PALM; s = 1.0 + r1 * 0.5; cr = 0.4 * s; }
          else if (land && flat && pick < 0.014) { t = PROP.CACTUS; s = 0.8 + r1 * 0.9; cr = 0.5 * s; }
          else if (land && pick < 0.034) { t = PROP.ROCK; s = 0.5 + r1 * 1.4; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && pick < 0.052) { t = PROP.DRYBUSH; s = 0.7 + r1 * 0.6; }
        } else if (b === BIOME.SWAMP) {
          if (h > 0.5 && flat && pick < 0.07) { t = r2 < 0.5 ? PROP.WILLOW : PROP.DEAD; s = 0.9 + r1 * 0.8; cr = 0.45 * s; }
          else if (h < 1.3 && pick < 0.2) { t = PROP.REED; s = 0.8 + r1 * 0.6; }
          else if (land && pick < 0.21) { t = PROP.ROCK; s = 0.5 + r1 * 1.0; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && pick < 0.235) { t = PROP.MUSHROOM; s = 0.8 + r1 * 1.0; }
        } else if (b === BIOME.VOLCANO) {
          if (land && flat && pick < 0.012) { t = PROP.DEAD; s = 0.9 + r1 * 0.7; cr = 0.4 * s; }
          else if (land && pick < 0.06) { t = PROP.ROCK; s = 0.6 + r1 * 1.7; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && flat && pick < 0.072) { t = PROP.SPIKE; s = 0.8 + r1 * 1.4; cr = 0.6 * s; }
        }
        if (t < 0) continue;
        let blocked = false;
        for (const e of ex) {
          const dx = x - e.x;
          const dz = z - e.z;
          if (dx * dx + dz * dz < e.r * e.r) { blocked = true; break; }
        }
        if (blocked) continue;
        list.push({ t, x, z, y: h, s, r: r2, b, cr });
      }
    }
    return list;
  }

  return {
    seed,
    heights,
    biome,
    bw,
    heightAt,
    gradAt,
    slopeAt,
    biomeAt,
    vertIndex,
    applyPatches,
    setExclusions,
    chunkProps,
  };
}

// 장식물이 놓이면 안 되는 구역 목록 (서버/클라이언트 공통 규칙)
export function exclusionsFor(pois) {
  const ex = [{ x: pois.village.x, z: pois.village.z, r: 50 }, { x: pois.arena.x, z: pois.arena.z, r: 36 }];
  for (const s of pois.shards) ex.push({ x: s.x, z: s.z, r: 13 });
  for (const s of pois.stones) ex.push({ x: s.x, z: s.z, r: 6 });
  for (const c of pois.camps) ex.push({ x: c.x, z: c.z, r: 10 });
  for (const c of pois.chests) ex.push({ x: c.x, z: c.z, r: 2.5 });
  for (const b of pois.bushes) ex.push({ x: b.x, z: b.z, r: 2 });
  for (const n of pois.npcs) ex.push({ x: n.x, z: n.z, r: 2.5 });
  return ex;
}

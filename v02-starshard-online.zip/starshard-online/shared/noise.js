// 결정적(deterministic) 난수 + 2D 그래디언트 노이즈.
// 서버와 모든 브라우저에서 완전히 같은 결과가 나오도록 사칙연산/정수연산만 사용한다.

export function mulberry32(seed) {
  let a = seed | 0;
  return function () {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hash2i(x, y, seed) {
  let h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(seed | 0, 1274126177);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  h = Math.imul(h, 2246822519);
  h ^= h >>> 15;
  return h >>> 0;
}

// [0,1) 범위 해시 난수
export function rand2(x, y, seed) {
  return hash2i(x, y, seed) / 4294967296;
}

const D = 0.7071067811865476;
const GX = new Float64Array([1, -1, 0, 0, D, -D, D, -D]);
const GY = new Float64Array([0, 0, 1, -1, D, D, -D, -D]);

// 대략 [-1, 1] 범위의 2D 그래디언트 노이즈 함수를 만든다.
export function makeNoise(seed) {
  const rnd = mulberry32(seed);
  const base = new Uint8Array(256);
  for (let i = 0; i < 256; i++) base[i] = i;
  for (let i = 255; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    const t = base[i];
    base[i] = base[j];
    base[j] = t;
  }
  const p = new Uint8Array(512);
  for (let i = 0; i < 512; i++) p[i] = base[i & 255];

  return function noise(x, y) {
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    const xf = x - xi;
    const yf = y - yi;
    const X = xi & 255;
    const Y = yi & 255;
    const u = xf * xf * xf * (xf * (xf * 6 - 15) + 10);
    const v = yf * yf * yf * (yf * (yf * 6 - 15) + 10);
    const a = p[X] + Y;
    const b = p[X + 1] + Y;
    const g00 = p[a] & 7;
    const g10 = p[b] & 7;
    const g01 = p[a + 1] & 7;
    const g11 = p[b + 1] & 7;
    const n00 = GX[g00] * xf + GY[g00] * yf;
    const n10 = GX[g10] * (xf - 1) + GY[g10] * yf;
    const n01 = GX[g01] * xf + GY[g01] * (yf - 1);
    const n11 = GX[g11] * (xf - 1) + GY[g11] * (yf - 1);
    const nx0 = n00 + (n10 - n00) * u;
    const nx1 = n01 + (n11 - n01) * u;
    return (nx0 + (nx1 - nx0) * v) * 1.5;
  };
}

export function fbm(noise, x, y, octaves) {
  let sum = 0;
  let amp = 1;
  let norm = 0;
  let f = 1;
  for (let i = 0; i < octaves; i++) {
    sum += amp * noise(x * f, y * f);
    norm += amp;
    amp *= 0.5;
    f *= 2.03;
  }
  return sum / norm;
}

// 산맥 느낌의 능선 노이즈, [0, 1]
export function ridged(noise, x, y, octaves) {
  let sum = 0;
  let amp = 1;
  let norm = 0;
  let f = 1;
  for (let i = 0; i < octaves; i++) {
    let n = noise(x * f, y * f);
    if (n < 0) n = -n;
    if (n > 1) n = 1;
    n = 1 - n;
    sum += amp * n * n;
    norm += amp;
    amp *= 0.5;
    f *= 2.07;
  }
  return sum / norm;
}

export function clamp(v, a, b) {
  return v < a ? a : v > b ? b : v;
}

export function smoothstep(e0, e1, x) {
  let t = (x - e0) / (e1 - e0);
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return t * t * (3 - 2 * t);
}

export function lerp(a, b, t) {
  return a + (b - a) * t;
}

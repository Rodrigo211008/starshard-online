// 서버와 클라이언트가 함께 쓰는 게임 규칙/수치 정의

export const GAME_TITLE = '별조각 원정대';
export const TICK_MS = 100; // 서버 시뮬레이션 주기 (10Hz)
export const SEND_MS = 80; // 클라이언트 위치 전송 주기
export const MAX_PLAYERS = 20;
export const DAY_MS = 14 * 60 * 1000; // 게임 속 하루 길이
export const SHARD_COUNT = 12;
export const DEFAULT_SEED = 20261111;

// 플레이어 애니메이션 상태 (네트워크 전송용)
export const ANIM = {
  IDLE: 0,
  RUN: 1,
  SPRINT: 2,
  JUMP: 3,
  FALL: 4,
  GLIDE: 5,
  SWIM: 6,
  CLIMB: 7,
  ATK1: 8,
  ATK2: 9,
  ATK3: 10,
  BOW: 11,
  HURT: 12,
  DEAD: 13,
  SIT: 14,
  WAVE: 15,
  CHEER: 16,
  SWIMIDLE: 17,
  CLIMBIDLE: 18,
};

// 몬스터 상태 (네트워크 전송용)
export const MSTATE = { IDLE: 0, WALK: 1, CHASE: 2, WINDUP: 3, RECOVER: 4, STAGGER: 5, RETURN: 6 };

export const MON_TYPES = ['slime', 'goblin', 'thrower', 'wolf', 'scorpion', 'yeti', 'imp', 'golem', 'lord'];

// atk.kind: arc(부채꼴 근접) / lunge(돌진) / throw(투사체) / slam(원형 내려찍기)
export const MON = {
  slime: {
    name: '말랑이', hp: 12, dmg: 1, speed: 2.7, aggro: 11, leash: 34, radius: 0.8, height: 1.0,
    atk: { kind: 'lunge', range: 3.2, reach: 1.5, dash: 3.4, windup: 520, cd: 1500 },
    xp: 5, gold: [1, 4], stagger: true, respawn: 150,
  },
  goblin: {
    name: '도깨비', hp: 22, dmg: 2, speed: 4.5, aggro: 16, leash: 42, radius: 0.7, height: 1.7,
    atk: { kind: 'arc', range: 2.3, reach: 2.9, half: 1.05, windup: 560, cd: 1500 },
    xp: 11, gold: [4, 9], stagger: true, respawn: 200,
  },
  thrower: {
    name: '돌팔매 도깨비', hp: 16, dmg: 2, speed: 3.9, aggro: 24, leash: 46, radius: 0.7, height: 1.6,
    atk: { kind: 'throw', range: 17, keep: 9, speed: 17, windup: 700, cd: 2500, proj: 'rock' },
    xp: 12, gold: [4, 10], stagger: true, respawn: 200,
  },
  wolf: {
    name: '늑대', hp: 20, dmg: 2, speed: 7.4, aggro: 19, leash: 52, radius: 0.8, height: 1.1,
    atk: { kind: 'lunge', range: 5.0, reach: 1.5, dash: 5.5, windup: 420, cd: 1700 },
    xp: 11, gold: [2, 6], stagger: true, respawn: 180,
  },
  scorpion: {
    name: '모래 전갈', hp: 30, dmg: 3, speed: 5.0, aggro: 14, leash: 40, radius: 0.9, height: 1.0,
    atk: { kind: 'arc', range: 2.4, reach: 3.0, half: 0.9, windup: 500, cd: 1600 },
    xp: 14, gold: [5, 11], stagger: true, respawn: 200,
  },
  yeti: {
    name: '설인', hp: 64, dmg: 4, speed: 4.4, aggro: 17, leash: 44, radius: 1.2, height: 2.8,
    atk: { kind: 'slam', range: 3.4, reach: 4.2, windup: 800, cd: 2200 },
    xp: 30, gold: [10, 20], stagger: false, respawn: 240,
  },
  imp: {
    name: '불도깨비', hp: 30, dmg: 3, speed: 4.8, aggro: 24, leash: 46, radius: 0.65, height: 1.5,
    atk: { kind: 'throw', range: 16, keep: 7, speed: 20, windup: 600, cd: 2100, proj: 'fire' },
    xp: 16, gold: [6, 12], stagger: true, respawn: 200,
  },
  golem: {
    name: '바위 수호자', hp: 170, dmg: 4, speed: 3.0, aggro: 22, leash: 40, radius: 1.9, height: 4.2,
    atk: { kind: 'slam', range: 4.6, reach: 6.2, windup: 1050, cd: 2500 },
    xp: 110, gold: [45, 70], stagger: false, respawn: 600, boss: true,
  },
  lord: {
    name: '그림자 군주', hp: 1500, dmg: 6, speed: 4.2, aggro: 60, leash: 60, radius: 2.4, height: 6.0,
    atk: { kind: 'slam', range: 6.0, reach: 8.0, windup: 1150, cd: 2000 },
    xp: 1500, gold: [400, 500], stagger: false, respawn: 0, boss: true,
  },
};

export function monStats(type, level, elite) {
  const d = MON[type];
  const L = level - 1;
  let hp = Math.round(d.hp * (1 + 0.2 * L));
  let dmg = d.dmg + Math.floor(L / 3);
  let xp = Math.round(d.xp * (1 + 0.3 * L));
  let gmin = Math.round(d.gold[0] * (1 + 0.15 * L));
  let gmax = Math.round(d.gold[1] * (1 + 0.15 * L));
  if (elite) {
    hp = Math.round(hp * 3.5);
    dmg += 1;
    xp *= 4;
    gmin *= 4;
    gmax *= 4;
  }
  return { hp, dmg, xp, gmin, gmax };
}

export const ELITE_NAMES = {
  slime: '왕 말랑이',
  goblin: '도깨비 대장',
  wolf: '우두머리 늑대',
  yeti: '설인 족장',
  imp: '불도깨비 두목',
  scorpion: '여왕 전갈',
  thrower: '명사수 도깨비',
};

export const GOLEM_NAMES = ['바위 수호자', '이끼 수호자', '서리 수호자', '모래 수호자', '늪의 수호자', '용암 수호자', '단풍 수호자'];

// ---- 플레이어 성장 ----
export const MAX_LEVEL = 30;
export function xpNeed(level) {
  const l = level - 1;
  return 30 + 22 * l + 6 * l * l;
}
export function maxHpFor(level) {
  return 6 + 2 * Math.floor((level - 1) / 2);
}
export function maxStaminaFor(level) {
  return Math.min(190, 100 + 3 * (level - 1));
}

export const SWORDS = [
  { name: '낡은 검', dmg: 4, price: 0, color: 0xb9c2cc },
  { name: '강철 검', dmg: 8, price: 120, color: 0xdfe7ee },
  { name: '은빛 검', dmg: 13, price: 420, color: 0xbfe9ff },
  { name: '별빛 검', dmg: 20, price: 1300, color: 0xfff2a8 },
];
export const ARMORS = [
  { name: '여행자 옷', def: 0, price: 0 },
  { name: '가죽 갑옷', def: 1, price: 160 },
  { name: '강철 갑옷', def: 2, price: 650 },
];
export const BOWS = [
  { name: '사냥꾼 활', dmg: 5, price: 0 },
  { name: '장궁', dmg: 10, price: 380 },
  { name: '별빛 활', dmg: 16, price: 1100 },
];
export const SHOP = {
  berry: { name: '회복 열매', price: 15, desc: '하트 3칸 회복' },
  arrows: { name: '화살 10개', price: 20, desc: '활 공격에 사용' },
};
export const BERRY_HEAL = 6;

export function playerAtk(level, sword) {
  return SWORDS[sword].dmg + Math.floor((level - 1) * 0.8);
}
export function playerBowAtk(level, bow) {
  return BOWS[bow].dmg + Math.floor((level - 1) * 0.6);
}

// 캐릭터 색상 팔레트
export const TUNIC_COLORS = [0xd9483b, 0x3b7dd9, 0xe8b730, 0x8a4fd1, 0x2aa59a, 0xe07a2f, 0xdb5fa0, 0x5c6b7a];
export const HAIR_COLORS = [0x3a2a1e, 0x1f1f24, 0xc98a3d, 0xe6d27a, 0xb5432e, 0xe9e9ee];

// ---- 마을 배치 (마을 중심 기준 좌표, 북쪽 = -z) ----
export const VILLAGE_LAYOUT = {
  spawn: { x: 0, z: 21 },
  altar: { x: 0, z: 0, r: 3.2 },
  well: { x: -10, z: -7, r: 1.5 },
  campfire: { x: -5, z: 13 },
  houses: [
    { x: -23, z: -17, w: 9, d: 7, rot: 0, roof: 0xb5523a },
    { x: 23, z: -15, w: 8, d: 8, rot: 0, roof: 0x4f7fb5 },
    { x: -27, z: 16, w: 8, d: 7, rot: 0, roof: 0x5c9a55 },
    { x: 26, z: 20, w: 9, d: 7, rot: 0, roof: 0xb5523a },
    { x: 0, z: -31, w: 12, d: 8, rot: 0, roof: 0x8a5fb0 },
  ],
  stalls: [
    { x: 15, z: 5, kind: 'merchant' },
    { x: -16, z: 4, kind: 'smith' },
  ],
};

export const NPC_DEFS = {
  elder: { name: '촌장 한울', x: 3.6, z: -4.2, yaw: 0.4 },
  merchant: { name: '상인 보리', x: 15, z: 7.2, yaw: 0 },
  smith: { name: '대장장이 무쇠', x: -16, z: 6.2, yaw: 0 },
  kid: { name: '꼬마 다래', x: 6, z: 14, yaw: 2.6 },
};

// 순환(NG+) 배율
export function cycleScale(cycle) {
  return 1 + 0.3 * cycle;
}

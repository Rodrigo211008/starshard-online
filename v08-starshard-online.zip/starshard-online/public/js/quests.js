// 의뢰(퀘스트): 마을 사람들과 길잡이들이 맡기는 일, 그리고 게시판의 현상금.
// 진행 상황은 각자의 저장(save.q)에 들어 있다. 보상은 맡긴 사람에게 돌아가 보고하면 받는다 (현상금은 어디서든).
import { POTIONS, POTION_CAP, rollItem, itemName, RARITY } from '/shared/defs.js';
import { BIOME_INFO } from '/shared/world.js';

// goal.type
//   kill   몬스터 처치 (mon: 종류, biome: 지역, strong: 우두머리·수호자만, far: 먼바다 너머의 땅에서만, distinct: 지역마다 한 번씩만 센다)
//          chest 보물상자   bush 열매 따기
//   charge 말을 타고 달리며 벤 횟수   duel 결투 승리   — 여기까지는 맡은 뒤부터 센다
//   seals 별의 인장   stones 깨운 귀환석   shards 모인 별조각   dfound 찾아낸 던전   dclear 정복한 던전
//   enh 가장 높은 강화 단계   mounts 길들인 탈것   level 레벨   — 이것들은 지금 상태를 그대로 본다
const COUNTED = new Set(['kill', 'chest', 'bush', 'charge', 'duel']);
const FAR_BIOME = 11; // 이 번호부터가 먼바다 너머의 땅

const STORY = [
  // ---- 촌장 한울: 모험의 큰 줄기 ----
  {
    id: 'e1', giver: 'elder', name: '첫 사냥', short: '몬스터 5마리 쓰러뜨리기',
    intro: ['모험을 떠나기 전에 몸부터 풀어 보게나.', '마을 밖 초원의 몬스터를 다섯 마리만 쓰러뜨리고 오게. 말랑이쯤은 식은 죽 먹기일 걸세.'],
    done: ['벌써 다녀왔나? 제법이군! 이건 내 작은 성의일세.'],
    goal: { type: 'kill', n: 5 }, reward: { gold: 60, xp: 40, pots: { hp: 2 } },
  },
  {
    id: 'e2', giver: 'elder', after: 'e1', name: '별의 문', short: '별의 시련장 한 곳 통과하기',
    intro: ['섬 곳곳에 별이 떠 있는 돌문이 있다네. 옛사람들이 남긴 「별의 시련장」이지.', '마을 남서쪽에도 하나 있으니 들어가서 끝까지 가 보게. 전보다 훨씬 험해졌다고들 하니 단단히 준비하고.'],
    done: ['별의 인장을 받았군! 몸에 별빛이 깃든 게 보이네.'],
    goal: { type: 'seals', n: 1 }, reward: { gold: 150, dust: 5, pots: { power: 1 } },
  },
  {
    id: 'e3', giver: 'elder', after: 'e2', name: '흩어진 별조각', short: '별조각 3개 모으기 (친구가 찾은 것도 셉니다)',
    intro: ['이제 별조각을 찾아 나설 때가 됐네.', '숲과 고원, 사막에 하나씩 있을 걸세. 수호자가 지키는 곳도 있으니 친구들과 함께 가게나.'],
    done: ['제단이 밝아지기 시작했네. 자네들 덕분일세!'],
    goal: { type: 'shards', n: 3 }, reward: { gold: 250, xp: 300, pots: { hp: 2, guard: 1 } },
  },
  {
    id: 'e4', giver: 'elder', after: 'e3', name: '땅속의 문', short: '숨겨진 던전 한 곳 찾아내기',
    intro: ['이 섬에는 땅속에 숨겨진 던전이 셋 있다네.', '외진 곳에 서 있는 이끼 낀 돌등에 모두 불을 밝히면 문이 솟아오르지. 귀환석 옆 길잡이들이 소문을 알고 있을 걸세.'],
    done: ['정말로 찾아냈군! 이 사과는 귀한 것이니 잘 간직하게. 쓸 데가 있을 걸세.'],
    goal: { type: 'dfound', n: 1 }, reward: { gold: 300, apples: 1 },
  },
  {
    id: 'e5', giver: 'elder', after: 'e4', name: '던전의 주인', short: '숨겨진 던전 한 곳 정복하기',
    intro: ['문을 찾았다면 이제 그 안의 주인을 쓰러뜨릴 차례일세.', '아주 위험하니 물약을 넉넉히 챙기고, 될 수 있으면 친구와 함께 들어가게.'],
    done: ['던전의 주인을 쓰러뜨리다니… 자네는 이제 어엿한 영웅일세!'],
    goal: { type: 'dclear', n: 1 }, reward: { gold: 500, core: 3, apples: 2 },
  },
  {
    id: 'e6', giver: 'elder', after: 'e5', name: '열두 인장', short: '별의 인장 12개 모두 모으기',
    intro: ['시련장은 모두 열두 곳이라네. 본섬에 여덟, 바깥 섬에 넷.', '열두 인장을 모두 모은 이에게는 마을의 석판이 잠든 검을 내어 준다는 전설이 있지.'],
    done: ['열두 인장을 모두… 내 평생 이런 모험가는 처음 보네!'],
    goal: { type: 'seals', n: 12 }, reward: { gold: 1200, core: 6, apples: 2 },
  },
  {
    id: 'e7', giver: 'elder', after: 'e3', name: '그림자 군주', short: '그림자 군주 쓰러뜨리기',
    intro: ['별조각 열두 개가 모이면 화산 분화구에서 그림자 군주가 깨어난다네.', '그 녀석을 쓰러뜨려야 섬에 빛이 돌아오지. 이것이 자네에게 맡기는 가장 큰 일일세.'],
    done: ['해냈군! 섬에 빛이 돌아왔네. 온 마을이 자네 이름을 기억할 걸세.'],
    goal: { type: 'kill', mon: 'lord', n: 1 }, reward: { gold: 1500, core: 5, apples: 3 },
  },
  {
    id: 'e8', giver: 'elder', after: 'e3', name: '먼바다 너머', short: '먼바다 너머 여섯 땅의 수호자를 하나씩 쓰러뜨리기',
    intro: ['본섬 동서남북 끝에서 아주 긴 모랫길이 먼바다로 뻗어 있다네. 그 너머에 여섯 땅이 있지.', '협곡, 얼음 호수, 거인의 계단, 산호 군도, 그리고 그보다 더 먼 하늘 기둥과 별똥 분지. 땅마다 한가운데를 수호자가 지키고 있다네.', '여섯 수호자를 모두 쓰러뜨린다면 자네는 이 세계의 끝을 본 걸세. 서두를 것 없네. 충분히 강해진 다음에 떠나게.'],
    done: ['여섯 땅을 모두 밟고 돌아오다니… 이 세계에 자네가 가 보지 못한 곳은 이제 없겠군!'],
    goal: { type: 'kill', mon: 'golem', far: true, distinct: true, n: 6 }, reward: { gold: 3000, core: 8, apples: 3, item: { src: 'golem', lv: 44 } },
  },
  // ---- 대장장이 무쇠 ----
  {
    id: 's1', giver: 'smith', name: '손에 맞는 무기', short: '장비 하나를 +3 까지 강화하기',
    intro: ['무기는 길들여야 제 힘을 내는 법이지.', '별가루를 모아 와서 아무 장비나 +3 까지 강화해 보게. 방법은 내가 알려 주지.'],
    done: ['좋아, 이제 좀 쓸 만해 보이는군. 이 별가루도 가져가게.'],
    goal: { type: 'enh', n: 3 }, reward: { gold: 80, dust: 10 },
  },
  {
    id: 's2', giver: 'smith', after: 's1', name: '더 단단하게', short: '장비 하나를 +6 까지 강화하기',
    intro: ['+6 부터는 별의 핵이 필요하네. 강한 녀석들이 떨어뜨리지.', '+6 짜리 장비를 만들어 오면 내 비장의 재료를 나눠 주겠네.'],
    done: ['훌륭해! 빛깔부터 다르군.'],
    goal: { type: 'enh', n: 6 }, reward: { dust: 15, core: 3 },
  },
  {
    id: 's3', giver: 'smith', after: 's2', name: '명장의 길', short: '장비 하나를 +10 까지 강화하기',
    intro: ['+10. 대장장이라면 누구나 꿈꾸는 숫자지.', '해낸다면 자네는 이 섬 최고의 장비를 가진 걸세.'],
    done: ['허허… 내 평생 +10 을 직접 보게 될 줄이야!'],
    goal: { type: 'enh', n: 10 }, reward: { gold: 1000, core: 6 },
  },
  // ---- 상인 보리 ----
  {
    id: 'm1', giver: 'merchant', name: '보물 사냥꾼', short: '보물상자 5개 열기',
    intro: ['섬 여기저기에 주인 없는 보물상자가 있다는 거 아세요?', '다섯 개만 열어 보고 오세요. 뭐가 들었는지 저도 궁금하거든요!'],
    done: ['와, 정말 다섯 개나! 이건 수고비예요.'],
    goal: { type: 'chest', n: 5 }, reward: { gold: 120, pots: { swift: 2 } },
  },
  {
    id: 'm2', giver: 'merchant', after: 'm1', name: '먼 길 장사', short: '귀환석 6개 깨우기',
    intro: ['귀환석이 깨어 있어야 물건을 멀리까지 나를 수 있어요.', '본섬 곳곳의 귀환석을 여섯 개까지 깨워 주시겠어요?'],
    done: ['덕분에 장삿길이 훨씬 편해졌어요!'],
    goal: { type: 'stones', n: 6 }, reward: { gold: 300, pots: { sta: 3 } },
  },
  {
    id: 'm3', giver: 'merchant', after: 'm2', name: '바깥 섬 소식', short: '귀환석 11개 깨우기',
    intro: ['모랫길 너머 바깥 섬에도 귀환석이 있대요.', '본섬과 바깥 섬의 귀환석 열한 개를 깨우면… 아껴 둔 황금 사과를 드릴게요.'],
    done: ['섬 구석구석을 다 다니셨군요! 약속한 황금 사과예요.'],
    goal: { type: 'stones', n: 11 }, reward: { gold: 800, apples: 2 },
  },
  {
    id: 'm5', giver: 'merchant', after: 'm3', name: '먼바다 장삿길', short: '귀환석 17개를 모두 깨우기',
    intro: ['먼바다 너머에도 땅이 여섯이나 더 있다는 소문 들으셨어요? 거기에도 귀환석이 하나씩 있대요.', '세상의 귀환석 열일곱 개를 모두 깨워 주시면, 제 평생의 장삿길이 열리는 거예요. 사례는 톡톡히 할게요!'],
    done: ['세상 끝까지 다녀오셨군요! 이제 어디든 물건을 보낼 수 있어요. 약속한 사례예요.'],
    goal: { type: 'stones', n: 17 }, reward: { gold: 2500, core: 3, apples: 3 },
  },
  {
    id: 'm4', giver: 'merchant', name: '돌격 연습', short: '말을 타고 달리며 몬스터를 12번 베기 (돌격)', need: 'mount',
    intro: ['말을 타고 달리면서 무기를 휘두르면 「돌격」이 된다는 거 아세요?', '달리는 말 위에서 몬스터를 열두 번만 베어 보세요. 달릴수록 세답니다!'],
    done: ['이제 어엿한 기수네요! 싸울 때 쓰라고 물약을 챙겼어요.'],
    goal: { type: 'charge', n: 12 }, reward: { gold: 150, pots: { power: 2, guard: 2 } },
  },
  // ---- 꼬마 다래 ----
  {
    id: 'k1', giver: 'kid', name: '빨간 열매', short: '덤불에서 회복 열매 5번 따기',
    intro: ['있잖아, 빨간 열매가 달린 덤불 봤어? 지나가기만 해도 딸 수 있어!', '다섯 번만 따 와 줘. 나도 먹고 싶단 말이야.'],
    done: ['우와, 고마워! 이건 내가 아끼던 거야.'],
    goal: { type: 'bush', n: 5 }, reward: { gold: 40, pots: { hp: 1 } },
  },
  {
    id: 'k2', giver: 'kid', after: 'k1', name: '말랑이 소동', short: '말랑이 12마리 쓰러뜨리기',
    intro: ['말랑이들이 자꾸 우리 집 텃밭에 들어와!', '열두 마리만 혼내 줘. 부탁이야!'],
    done: ['이제 텃밭이 조용해졌어. 최고야!'],
    goal: { type: 'kill', mon: 'slime', n: 12 }, reward: { gold: 90, pots: { sta: 2 } },
  },
  {
    id: 'k3', giver: 'kid', after: 'k2', name: '반짝이는 말', short: '숨어 사는 특별한 말 한 마리 길들이기',
    intro: ['불꽃 갈기 빨간 말, 얼음 발굽 하얀 말, 밤에만 나오는 까만 말!', '진짜 있는지 보고 싶어. 한 마리만 길들여서 보여 줘!'],
    done: ['진짜였어! 나도 크면 꼭 탈 거야. 이거 받아!'],
    goal: { type: 'mounts', n: 1 }, reward: { gold: 600, pots: { swift: 3 } },
  },
];

// 길잡이들: 지역마다 「정리」와 「강적」 두 가지 (귀환석 번호, 지역 번호)
const GUIDE_AREAS = [[1, 1], [2, 3], [3, 4], [4, 2], [5, 5], [6, 6], [7, 7], [8, 8], [9, 9], [10, 10], [11, 11], [12, 12], [13, 13], [14, 14], [15, 15], [16, 16]];
for (const [stone, biome] of GUIDE_AREAS) {
  const b = BIOME_INFO[biome];
  const lv = b.level;
  STORY.push({
    id: `g${stone}a`, giver: 'guide' + stone, name: `${b.name} 정리`, short: `${b.name}의 몬스터 15마리 쓰러뜨리기`,
    intro: [`요즘 ${b.name}에 몬스터가 부쩍 늘어서 길을 다니기가 무서워요.`, '이 근처에서 열다섯 마리만 쓰러뜨려 주시겠어요?'],
    done: ['덕분에 한결 조용해졌어요. 고마워요!'],
    goal: { type: 'kill', biome, n: 15 }, reward: { gold: 40 + lv * 14, xp: 60 + lv * 40, dust: 2 + Math.floor(lv / 4), pots: { hp: 2 } },
  });
  STORY.push({
    id: `g${stone}b`, giver: 'guide' + stone, after: `g${stone}a`, name: `${b.name}의 강적`, short: `${b.name}의 우두머리나 수호자 쓰러뜨리기`,
    intro: [`${b.name}에는 유난히 크고 사나운 녀석이 있어요. 이름표에 빛이 나는 우두머리나, 제단을 지키는 수호자 말이에요.`, '그 녀석을 쓰러뜨려 주시면 제가 아껴 둔 장비를 드릴게요.'],
    done: ['그 녀석을 정말 쓰러뜨리다니! 약속한 장비예요.'],
    goal: { type: 'kill', biome, strong: true, n: 1 }, reward: { gold: 100 + lv * 25, core: 1, apples: lv >= 9 ? 1 : 0, item: { src: 'golem', lv } },
  });
}

export const QUESTS = STORY;
const BY_ID = new Map(QUESTS.map((q) => [q.id, q]));
export const GIVER_NAME = { elder: '촌장 한울', merchant: '상인 보리', smith: '대장장이 무쇠', kid: '꼬마 다래' };
const BOUNTY_SLOTS = 3;

// 보상을 글로: "골드 120 · 체력 물약 2"
export function rewardText(r) {
  const out = [];
  if (r.gold) out.push(`골드 ${r.gold}`);
  if (r.xp) out.push(`경험치 ${r.xp}`);
  if (r.dust) out.push(`별가루 ${r.dust}`);
  if (r.core) out.push(`별의 핵 ${r.core}`);
  if (r.apples) out.push(`황금 사과 ${r.apples}`);
  for (const k in r.pots || {}) out.push(`${POTIONS[k].name} ${r.pots[k]}`);
  if (r.item) out.push('장비 1개');
  return out.join(' · ');
}

export class Quests {
  constructor(game) {
    this.game = game;
    const s = game.save;
    if (!s.q || typeof s.q !== 'object') s.q = {};
    const q = s.q;
    q.done = Array.isArray(q.done) ? q.done.filter((id) => BY_ID.has(id)) : [];
    const act = {};
    if (q.act && typeof q.act === 'object') {
      for (const id in q.act) {
        if (!BY_ID.has(id) || q.done.includes(id)) continue;
        act[id] = { n: Math.max(0, q.act[id].n | 0), told: !!q.act[id].told };
        if (q.act[id].m) act[id].m = q.act[id].m | 0; // 지역마다 한 번씩 세는 일: 이미 센 지역
      }
    }
    q.act = act;
    q.b = (Array.isArray(q.b) ? q.b : []).filter((b) => b && typeof b === 'object' && typeof b.type === 'string' && b.r && b.need > 0).slice(0, BOUNTY_SLOTS);
    q.bn = q.bn | 0; // 지금까지 받은 현상금 수
    this.state = q;
    this.dirty = true; // 표시(머리 위 느낌표, 화면의 목록)를 새로 그려야 하는지
    this.pollT = 0;
    this.names = { ...GIVER_NAME };
    for (const n of game.pois.npcs) if (n.kind === 'guide') this.names['guide' + n.stone] = n.name;
    this.fillBounties();
  }

  giverName(q) {
    return this.names[q.giver] || '의뢰인';
  }

  // ---------- 진행 상황 ----------
  isDone(id) {
    return this.state.done.includes(id);
  }

  isActive(id) {
    return !!this.state.act[id];
  }

  // 지금 상태로 계산하는 목표의 값
  stateValue(type) {
    const g = this.game;
    const s = g.save;
    switch (type) {
      case 'seals': return s.trials.length;
      case 'stones': return s.stones.length;
      case 'shards': return g.shards.size;
      case 'dfound': return g.zones.list.filter((z) => !z.trial && z.found).length;
      case 'dclear': return s.dclear.length;
      case 'mounts': return s.mounts.length;
      case 'level': return s.level;
      case 'enh': {
        let m = 0;
        for (const k in s.eq) if (s.eq[k]) m = Math.max(m, s.eq[k].e || 0);
        for (const it of s.inv) m = Math.max(m, it.e || 0);
        return m;
      }
      default: return 0;
    }
  }

  progress(q) {
    const goal = q.goal;
    const cur = COUNTED.has(goal.type) ? (this.state.act[q.id] ? this.state.act[q.id].n : 0) : this.stateValue(goal.type);
    return Math.min(goal.n, cur);
  }

  ready(q) {
    return this.isActive(q.id) && this.progress(q) >= q.goal.n;
  }

  // 받을 수 있는지: 앞선 의뢰를 마쳤고, 필요한 것(탈것)이 있다
  canAccept(q) {
    if (this.isDone(q.id) || this.isActive(q.id)) return false;
    if (q.after && !this.isDone(q.after)) return false;
    if (q.need === 'mount' && !this.game.player.hasMount()) return false;
    return true;
  }

  // 이 사람(giver)과 얽힌 의뢰: 보고할 것, 진행 중인 것, 새로 받을 것
  forGiver(giver) {
    const mine = QUESTS.filter((q) => q.giver === giver);
    return {
      ready: mine.filter((q) => this.ready(q)),
      active: mine.filter((q) => this.isActive(q.id) && !this.ready(q)),
      offer: mine.filter((q) => this.canAccept(q)),
    };
  }

  // 머리 위 표시: '?' 보고할 의뢰 / '!' 받을 의뢰 / '' 없음
  marker(giver) {
    const f = this.forGiver(giver);
    return f.ready.length ? '?' : f.offer.length ? '!' : '';
  }

  activeList() {
    return QUESTS.filter((q) => this.isActive(q.id));
  }

  offerList() {
    return QUESTS.filter((q) => this.canAccept(q));
  }

  accept(q) {
    if (!this.canAccept(q)) return false;
    this.state.act[q.id] = { n: 0, told: false };
    this.changed();
    return true;
  }

  // 보상 받기
  claim(q) {
    if (!this.ready(q)) return false;
    delete this.state.act[q.id];
    this.state.done.push(q.id);
    this.give(q.reward);
    this.changed();
    return true;
  }

  give(r) {
    const g = this.game;
    const s = g.save;
    if (r.gold) s.gold += r.gold;
    if (r.dust) s.mats.dust += r.dust;
    if (r.core) s.mats.core += r.core;
    if (r.apples) s.apples += r.apples;
    for (const k in r.pots || {}) s.pots[k] = Math.min(POTION_CAP, (s.pots[k] || 0) + r.pots[k]);
    if (r.item) {
      // 희귀 등급 이상이 나올 때까지 다시 뽑는다
      let it = rollItem(r.item.src, r.item.lv + 3 * g.cycle);
      for (let k = 0; k < 20 && it.r < 2; k++) it = rollItem(r.item.src, r.item.lv + 3 * g.cycle);
      const p = g.player.pos;
      if (g.inv.add(it)) g.ui.toast(`[${RARITY[it.r].name}] ${itemName(it)} 획득`, true, 'r' + it.r);
      else g.loot.dropItem(it, p.x, p.y, p.z);
    }
    if (r.xp) g.player.addXp(r.xp);
    g.ui.dirty = true;
    g.ui.bagDirty = true;
  }

  changed() {
    this.dirty = true;
    this.game.saveSoon();
  }

  // ---------- 일이 생길 때마다 불린다 ----------
  // ev: 'kill' (info: 쓰러뜨린 몬스터) / 'chest' / 'bush' / 'charge' (n: 벤 수) / 'duel'
  on(ev, info, n = 1) {
    const st = this.state;
    let hit = false;
    // 던전의 주인은 저마다 종류가 다르므로 'dboss' 로 묶어서 본다
    const kind = ev === 'kill' ? (info.dungeon && info.boss ? 'dboss' : info.type) : '';
    const test = (goal) => {
      if (goal.type !== ev) return false;
      if (ev === 'kill') {
        if (goal.mon && kind !== goal.mon) return false;
        if (goal.biome !== undefined && (info.biome !== goal.biome || info.zone)) return false;
        if (goal.strong && !(info.elite || info.type === 'golem')) return false;
        if (goal.far && (info.biome < FAR_BIOME || info.zone)) return false;
        if (info.minion) return false;
      }
      return true;
    };
    for (const id in st.act) {
      const q = BY_ID.get(id);
      const a = st.act[id];
      if (!q || a.n >= q.goal.n || !test(q.goal)) continue;
      if (q.goal.distinct) {
        // 같은 지역에서는 한 번만 센다
        const bit = 1 << info.biome;
        if ((a.m | 0) & bit) continue;
        a.m = (a.m | 0) | bit;
      }
      a.n = Math.min(q.goal.n, a.n + n);
      hit = true;
    }
    for (const b of st.b) {
      if (!b.acc || b.n >= b.need || !test(b)) continue;
      b.n = Math.min(b.need, b.n + n);
      hit = true;
    }
    if (hit) {
      this.changed();
      this.announce();
    }
  }

  // 방금 채운 의뢰를 한 번 알려 준다
  announce() {
    const g = this.game;
    for (const q of this.activeList()) {
      const a = this.state.act[q.id];
      if (a.told || !this.ready(q)) continue;
      a.told = true;
      g.ui.toast(`의뢰 달성: 「${q.name}」 — ${this.giverName(q)}에게 돌아가 보고하세요`, true);
      g.audio.puzzleOk();
      this.changed();
    }
    for (const b of this.state.b) {
      if (!b.acc || b.told || b.n < b.need) continue;
      b.told = true;
      g.ui.toast(`현상금 달성: ${this.bountyText(b)} — 의뢰 화면에서 보상을 받으세요`, true);
      g.audio.puzzleOk();
      this.changed();
    }
  }

  // 상태로 따지는 목표(인장 · 귀환석 …)는 가끔 살펴본다
  update(dt) {
    this.pollT -= dt;
    if (this.pollT > 0) return;
    this.pollT = 1;
    this.announce();
  }

  // ---------- 현상금 (되풀이되는 의뢰) ----------
  // 내 레벨에 맞는 지역을 고른다: 권장 레벨이 내 레벨 +2 이하인 곳 가운데 높은 쪽에서
  bountyBiome() {
    const lv = this.game.save.level;
    const list = BIOME_INFO.map((b, i) => ({ i, lv: b.level })).filter((b) => b.lv <= lv + 2).sort((a, b) => b.lv - a.lv).slice(0, 3);
    return list[Math.floor(Math.random() * list.length)] || { i: 0, lv: 1 };
  }

  makeBounty() {
    const g = this.game;
    const s = g.save;
    const kinds = ['kill', 'kill', 'strong', 'chest'];
    if (g.player.hasMount()) kinds.push('charge');
    if (g.zones.list.some((z) => !z.trial && z.found)) kinds.push('dungeon');
    // 같은 종류가 겹치지 않게
    const used = new Set(this.state.b.map((b) => b.k));
    let k = kinds[Math.floor(Math.random() * kinds.length)];
    for (let i = 0; i < 12 && used.has(k); i++) k = kinds[Math.floor(Math.random() * kinds.length)];
    const area = this.bountyBiome();
    const lv = Math.max(1, s.level);
    const id = ++this.state.bn;
    const base = { id, k, n: 0, acc: false, told: false, lv };
    if (k === 'kill') return { ...base, type: 'kill', biome: area.i, need: 20, r: { gold: 50 + area.lv * 12, xp: 80 + area.lv * 45, dust: 2 } };
    if (k === 'strong') return { ...base, type: 'kill', strong: true, need: 2, r: { gold: 120 + lv * 15, core: 1, dust: 3 } };
    if (k === 'chest') return { ...base, type: 'chest', need: 3, r: { gold: 80 + lv * 8, pots: { hp: 1, sta: 1 } } };
    if (k === 'charge') return { ...base, type: 'charge', need: 15, r: { gold: 80 + lv * 8, pots: { power: 1 } } };
    return { ...base, type: 'kill', mon: 'dboss', need: 1, r: { gold: 300 + lv * 15, apples: 1, core: 2 } };
  }

  fillBounties() {
    while (this.state.b.length < BOUNTY_SLOTS) this.state.b.push(this.makeBounty());
  }

  bountyText(b) {
    if (b.type === 'kill' && b.mon === 'dboss') return '던전의 주인 쓰러뜨리기';
    if (b.type === 'kill' && b.strong) return `우두머리나 수호자 ${b.need}마리 쓰러뜨리기`;
    if (b.type === 'kill') return `${BIOME_INFO[b.biome].name}의 몬스터 ${b.need}마리 쓰러뜨리기`;
    if (b.type === 'chest') return `보물상자 ${b.need}개 열기`;
    if (b.type === 'charge') return `말을 타고 달리며 ${b.need}번 베기 (돌격)`;
    return '';
  }

  acceptBounty(b) {
    if (b.acc) return;
    b.acc = true;
    this.changed();
  }

  claimBounty(b) {
    const i = this.state.b.indexOf(b);
    if (i < 0 || !b.acc || b.n < b.need) return false;
    this.state.b.splice(i, 1);
    this.give(b.r);
    this.fillBounties();
    this.changed();
    return true;
  }

  // 화면 왼쪽 위에 보여 줄 진행 중인 의뢰 (보고할 것부터, 많아야 셋)
  tracked() {
    const out = [];
    for (const q of this.activeList()) {
      const rdy = this.ready(q);
      out.push({ rdy, text: rdy ? `${q.name} — ${this.giverName(q)}에게 보고` : `${q.name} ${this.progress(q)}/${q.goal.n}` });
    }
    for (const b of this.state.b) {
      if (!b.acc) continue;
      const rdy = b.n >= b.need;
      out.push({ rdy, text: rdy ? '현상금 달성 — 의뢰 화면에서 보상 받기' : `현상금: ${this.bountyText(b)} ${b.n}/${b.need}` });
    }
    out.sort((a, b) => (b.rdy ? 1 : 0) - (a.rdy ? 1 : 0));
    return out.slice(0, 3);
  }
}

// 서버와 클라이언트가 함께 쓰는 월드 생성기.
// 같은 seed 라면 어디서 실행해도 완전히 같은 섬이 만들어진다 (사칙연산과 sqrt 만 사용).
import { makeNoise, fbm, ridged, rand2, smoothstep } from './noise.js';

const abs = (v) => (v < 0 ? -v : v);

// 세계는 가로세로 4.8km. 한 칸은 6m (예전에는 2.4km, 4m 였다)
export const W = {
  SIZE: 4800,
  HALF: 2400,
  CELL: 6,
  GRID: 800,
  VERTS: 801,
  CHUNK_CELLS: 25,
  CHUNK: 150,
  CHUNKS: 32,
  SEA: 0,
};
// 세계를 넓히기 전의 크기. 가운데 큰 섬(본섬)의 지형·나무·주요 지점이 그대로 유지되도록 배치 기준으로 쓴다.
export const OLD_HALF = 800;
// 시련장·던전(실내)은 세계의 북쪽 바깥(z < ZONE_Z)에 따로 있다. 그곳의 바닥은 평평하다.
export const ZONE_Z = -W.HALF - 20;
export const ZONE_FLOOR = 40;

export const BIOME = {
  MEADOW: 0, FOREST: 1, SNOW: 2, DESERT: 3, SWAMP: 4, VOLCANO: 5, AUTUMN: 6, BLOSSOM: 7, MUSHROOM: 8, CRYSTAL: 9, SHADOW: 10,
  CANYON: 11, GLACIER: 12, TERRACE: 13, REEF: 14, PILLARS: 15, CRATER: 16,
};
export const NB = 17;
const NB_OLD = 7; // 본섬의 지역 수

export const BIOME_INFO = [
  { key: 'meadow', name: '새벽 초원', level: 1 },
  { key: 'forest', name: '속삭임 숲', level: 3 },
  { key: 'snow', name: '서리봉 설산', level: 9 },
  { key: 'desert', name: '황금 사막', level: 6 },
  { key: 'swamp', name: '안개 늪', level: 7 },
  { key: 'volcano', name: '잿불 화산', level: 11 },
  { key: 'autumn', name: '단풍 고원', level: 4 },
  { key: 'blossom', name: '벚꽃 언덕', level: 13 },
  { key: 'mushroom', name: '버섯 숲', level: 15 },
  { key: 'crystal', name: '수정 고원', level: 17 },
  { key: 'shadow', name: '그림자 황무지', level: 20 },
  // ---- 먼바다 너머의 여섯 땅: 저마다 땅 모양이 전혀 다르다 ----
  { key: 'canyon', name: '바람 협곡', level: 23 }, // 평평한 고원을 깊은 협곡이 미로처럼 가른다
  { key: 'glacier', name: '얼음 호수', level: 26 }, // 꽁꽁 언 드넓은 호수와 그 위로 솟은 얼음 송곳
  { key: 'terrace', name: '거인의 계단', level: 29 }, // 층층이 쌓인 계단식 언덕
  { key: 'reef', name: '산호 군도', level: 32 }, // 얕은 바다에 흩어진 수많은 작은 섬
  { key: 'pillars', name: '하늘 기둥', level: 36 }, // 안개 낀 분지에 솟은 높다란 돌기둥들
  { key: 'crater', name: '별똥 분지', level: 40 }, // 별이 떨어져 생긴 거대한 구덩이
];

// 본섬 바깥의 네 섬 (b: 지역, r: 반지름). 본섬과는 모래톱 길로 이어진다.
export const ISLES = [
  { b: 7, x: 850, z: 850, r: 285 },
  { b: 8, x: -850, z: 850, r: 285 },
  { b: 9, x: -850, z: -850, r: 285 },
  { b: 10, x: 850, z: -850, r: 285 },
];

// 먼바다 너머의 여섯 땅 (b: 지역, r: 반지름, from: 모래톱 길이 시작되는 곳 — -1 본섬, 0~3 바깥 섬)
export const LANDS = [
  { b: 11, x: 1650, z: 0, r: 520, from: -1 }, // 동쪽: 바람 협곡
  { b: 12, x: 0, z: -1680, r: 540, from: -1 }, // 북쪽: 얼음 호수
  { b: 13, x: -1650, z: 0, r: 520, from: -1 }, // 서쪽: 거인의 계단
  { b: 14, x: 0, z: 1680, r: 560, from: -1 }, // 남쪽: 산호 군도
  { b: 15, x: 1720, z: -1720, r: 430, from: 3 }, // 북동쪽 끝 (그림자 황무지 너머): 하늘 기둥
  { b: 16, x: -1720, z: 1720, r: 430, from: 1 }, // 남서쪽 끝 (버섯 숲 너머): 별똥 분지
];

// 바이옴 중심 (x, z, 크기 보정)
const CX = [0, 470, -140, 120, -400, 460, -520];
const CZ = [0, 100, -480, 520, 320, -370, -110];
const CS = [1.0, 1.0, 1.0, 1.0, 1.0, 1.2, 1.0];

export const BIOME_CENTERS = [...CX.map((x, i) => [x, CZ[i]]), ...ISLES.map((q) => [q.x, q.z]), ...LANDS.map((q) => [q.x, q.z])];

export const VILLAGE = { x: 0, z: 0, h: 9, r: 44 };
export const VOLCANO = { x: 460, z: -370, floor: 60, arenaR: 28, notchX: -0.7071067811865476, notchZ: 0.7071067811865476 };

export const PROP = {
  OAK: 0,
  PINE: 1,
  AUTUMN: 2,
  SNOWPINE: 3,
  PALM: 4,
  DEAD: 5,
  WILLOW: 6,
  CACTUS: 7,
  ROCK: 8,
  BUSH: 9,
  DRYBUSH: 10,
  FLOWER: 11,
  MUSHROOM: 12,
  REED: 13,
  ICE: 14,
  SPIKE: 15,
  CHERRY: 16,
  SHROOMTREE: 17,
  CRYSTAL: 18,
  OBELISK: 19,
  HOODOO: 20, // 바람 협곡의 버섯바위
  BAMBOO: 21, // 거인의 계단의 대나무
  CORAL: 22, // 산호 군도의 산호
};

export function createWorld(seed, opts = {}) {
  const nA = makeNoise(seed + 11);
  const nB = makeNoise(seed + 23);
  const nC = makeNoise(seed + 37);
  const nD = makeNoise(seed + 41);
  const nM = makeNoise(seed + 53);
  const nL = makeNoise(seed + 67);
  const nW1 = makeNoise(seed + 71);
  const nW2 = makeNoise(seed + 83);
  const nCoast = makeNoise(seed + 97);
  const nV = makeNoise(seed + 103);
  const nGrove = makeNoise(seed + 131);
  const nIsle = makeNoise(seed + 149);
  const nLand = makeNoise(seed + 163);
  const nFar = makeNoise(seed + 181);

  const N = W.VERTS;
  const heights = new Float32Array(N * N);
  const biome = new Uint8Array(N * N);
  const added = new Uint8Array(N * N); // 1: 세계를 넓히며 새로 생긴 땅(바깥 섬·모래톱 길), 2: 그 가운데 모래톱 길
  let wasAdded = false;
  let wasRoad = false;
  const bw = opts.weights ? new Uint8Array(N * N * NB) : null;

  const wSoft = new Float64Array(NB_OLD);
  const wSharp = new Float64Array(NB);
  let dom = 0;

  function biomeWeights(x, z) {
    const wx = x + 80 * nW1(x * 0.0032, z * 0.0032);
    const wz = z + 80 * nW2(x * 0.0032 + 31.7, z * 0.0032 - 12.3);
    let sSoft = 0;
    let sSharp = 0;
    let bestW = -1;
    for (let i = 0; i < NB_OLD; i++) {
      const dx = wx - CX[i];
      const dz = wz - CZ[i];
      const d2 = (dx * dx + dz * dz) * CS[i];
      const a = 1 / (d2 + 3500);
      const soft = a * a;
      const b = 1 / (d2 + 600);
      const b2 = b * b;
      const sharp = b2 * b2 * b2;
      wSoft[i] = soft;
      wSharp[i] = sharp;
      sSoft += soft;
      sSharp += sharp;
      if (sharp > bestW) {
        bestW = sharp;
        dom = i;
      }
    }
    for (let i = 0; i < NB_OLD; i++) {
      wSoft[i] /= sSoft;
      wSharp[i] /= sSharp;
    }
    for (let i = NB_OLD; i < NB; i++) wSharp[i] = 0;
  }

  // 본섬에서 바깥 섬으로 이어지는 모래톱 길: 본섬 안쪽에서 시작해 섬 안쪽까지 닿는다
  const BRIDGES = ISLES.map((q, i) => {
    const d = Math.sqrt(q.x * q.x + q.z * q.z);
    const ux = q.x / d;
    const uz = q.z / d;
    return { ux, uz, x0: ux * 585, z0: uz * 585, len: d - q.r * 0.6 - 585, k: i * 7.3 };
  });
  // 새 땅으로 가는 길: 본섬의 동서남북 끝, 또는 바깥 섬에서 뻗어 나간다
  for (let i = 0; i < LANDS.length; i++) {
    const q = LANDS[i];
    const o = q.from < 0 ? { x: 0, z: 0, r: 1030 } : ISLES[q.from]; // 본섬은 해안이 들쭉날쭉하므로 넉넉히 안쪽(0.6 × 1030)에서 시작한다
    const dx = q.x - o.x;
    const dz = q.z - o.z;
    const d = Math.sqrt(dx * dx + dz * dz);
    const ux = dx / d;
    const uz = dz / d;
    const s0 = o.r * 0.6;
    BRIDGES.push({ ux, uz, x0: o.x + ux * s0, z0: o.z + uz * s0, len: d - s0 - q.r * 0.72, k: 31.7 + i * 5.9 });
  }

  const EPS = 0.004;

  function rawHeight(x, z) {
    // 본섬에서 아주 먼 곳은 깊은 바다이거나 바깥 섬이다 (본섬의 계산은 반지름 852 밖에서 늘 -26 이다)
    const far = x * x + z * z > 852 * 852;
    wasAdded = false;
    wasRoad = false;
    let h = -26;
    let nBase = 0;
    let nDet = 0;
    if (far) {
      // 가장 가까운 지역을 대표로 삼는다
      let bd = Infinity;
      for (let i = 0; i < NB; i++) {
        wSharp[i] = 0;
        const dx = x - BIOME_CENTERS[i][0];
        const dz = z - BIOME_CENTERS[i][1];
        const d2 = dx * dx + dz * dz;
        if (d2 < bd) {
          bd = d2;
          dom = i;
        }
      }
      wSharp[dom] = 1;
    } else {
      nBase = fbm(nA, x * 0.003, z * 0.003, 4);
      nDet = fbm(nB, x * 0.013, z * 0.013, 3);
      h = mainIsland(x, z, nBase, nDet);
    }

    // 바깥 섬
    for (let i = 0; i < ISLES.length; i++) {
      const q = ISLES[i];
      const dx = x - q.x;
      const dz = z - q.z;
      const d = Math.sqrt(dx * dx + dz * dz);
      if (d > q.r * 1.14) continue;
      const m = 1 - smoothstep(0.7, 1.0, d / q.r + 0.1 * nCoast(x * 0.006 + 9.1 * (i + 1), z * 0.006 - 4.7 * (i + 1)));
      if (m <= 0) continue;
      if (far) {
        nBase = fbm(nA, x * 0.003, z * 0.003, 4);
        nDet = fbm(nB, x * 0.013, z * 0.013, 3);
      }
      const t = d / q.r;
      let hi;
      if (q.b === BIOME.BLOSSOM) {
        // 벚꽃 언덕: 완만한 구릉, 가운데 큰 언덕, 작은 연못
        hi = 8.5 + 9 * nBase + 2.2 * nDet + 9 * smoothstep(0.42, 0.05, t);
        hi -= 13 * smoothstep(0.46, 0.64, nL(x * 0.0062 + 11.3, z * 0.0062 + 5.9)) * smoothstep(0.2, 0.34, t);
      } else if (q.b === BIOME.MUSHROOM) {
        // 버섯 숲: 낮고 울퉁불퉁한 습지대
        hi = 4.2 + 6 * nBase + 3.4 * nDet + 5 * ridged(nIsle, x * 0.012, z * 0.012, 2);
      } else if (q.b === BIOME.CRYSTAL) {
        // 수정 고원: 두 단으로 솟은 탁상지와 능선
        const r = ridged(nIsle, x * 0.007, z * 0.007, 3);
        hi = 9 + 17 * smoothstep(-0.12, 0.08, nBase) + 15 * smoothstep(0.22, 0.4, nBase) + 16 * r * r + 2.5 * nDet;
      } else {
        // 그림자 황무지: 날카로운 능선과 깊은 골
        const r = ridged(nIsle, x * 0.0085, z * 0.0085, 4);
        hi = 7 + 58 * r * r * r + 9 * nBase + 3.5 * nDet;
      }
      const hn = -26 + (hi + 26) * m;
      if (hn > h) {
        h = hn;
        wasAdded = true;
        // 물 위로 나온 곳은 온전히 새 지역으로 본다
        const wn = smoothstep(0.0, 0.3, m);
        for (let k = 0; k < NB_OLD; k++) wSharp[k] *= 1 - wn;
        for (let k = NB_OLD; k < NB; k++) wSharp[k] = 0;
        wSharp[q.b] = wn;
        if (wn > 0.5) dom = q.b;
      }
    }

    // 먼바다 너머의 여섯 땅
    for (let i = 0; i < LANDS.length; i++) {
      const q = LANDS[i];
      const dx = x - q.x;
      const dz = z - q.z;
      const lim = q.r * 1.16;
      if (dx > lim || dx < -lim || dz > lim || dz < -lim) continue;
      const d = Math.sqrt(dx * dx + dz * dz);
      if (d > lim) continue;
      const m = 1 - smoothstep(0.74, 1.0, d / q.r + 0.11 * nCoast(x * 0.0042 + 3.3 * (i + 1), z * 0.0042 - 7.1 * (i + 1)));
      if (m <= 0) continue;
      if (far) {
        nBase = fbm(nA, x * 0.003, z * 0.003, 4);
        nDet = fbm(nB, x * 0.013, z * 0.013, 3);
      }
      const hi = landform(q.b, x, z, d / q.r, nBase, nDet);
      const hn = -26 + (hi + 26) * m;
      if (hn > h) {
        h = hn;
        wasAdded = true;
        const wn = smoothstep(0.0, 0.3, m);
        for (let k = 0; k < NB; k++) wSharp[k] *= 1 - wn;
        wSharp[q.b] = wn;
        if (wn > 0.5) dom = q.b;
      }
    }

    // 모래톱 길
    for (let i = 0; i < BRIDGES.length; i++) {
      const b = BRIDGES[i];
      const rx = x - b.x0;
      const rz = z - b.z0;
      const along = rx * b.ux + rz * b.uz;
      if (along < -24 || along > b.len + 24) continue;
      let side = rx * b.uz - rz * b.ux;
      if (side > 60 || side < -60) continue;
      const ac = along < 0 ? 0 : along > b.len ? b.len : along;
      // 길이 살짝 구불거린다 (양 끝에서는 곧게)
      const wob = 16 * nCoast(ac * 0.011 + b.k, 3.7) * smoothstep(0, 60, ac) * smoothstep(b.len, b.len - 60, ac);
      side -= wob;
      const ex = along - ac;
      const d = Math.sqrt(side * side + ex * ex);
      const tb = 1 - smoothstep(7, 23, d);
      if (tb <= 0) continue;
      if (far && nDet === 0) nDet = fbm(nB, x * 0.013, z * 0.013, 3);
      const hb = -26 + (1.55 + 0.5 * nDet + 26) * tb;
      if (hb > h) {
        h = hb;
        wasAdded = true;
        wasRoad = true;
      }
    }
    return h;
  }

  // 새 땅의 모양. t: 한가운데 0 ~ 가장자리 1
  function landform(b, x, z, t, nBase, nDet) {
    if (b === BIOME.CANYON) {
      // 바람 협곡: 두 단으로 된 평평한 고원을, 구불구불한 깊은 협곡이 미로처럼 가른다
      // 노이즈가 0 을 지나는 선은 끊기지 않고 구불구불 이어진다. 두 겹을 겹쳐 미로를 만든다
      const a1 = abs(nLand(x * 0.0041 + 0.3 * nBase, z * 0.0041 + 13.7));
      const a2 = abs(nFar(x * 0.0036 - 8.2, z * 0.0036 + 0.3 * nBase + 2.9));
      const v = a1 < a2 ? a1 : a2;
      const top = 27 + 13 * smoothstep(0.02, 0.1, nBase) + 1.2 * nDet;
      const cut = 1 - smoothstep(0.05, 0.095, v); // 협곡 (벽이 가파르다)
      const bed = 1 - smoothstep(0.004, 0.022, v); // 한가운데를 흐르는 얕은 물길
      return top + (3.4 + 1.2 * nDet - top) * cut - 3.9 * bed;
    }
    if (b === BIOME.GLACIER) {
      // 얼음 호수: 한가운데는 판판하게 언 호수, 그 위로 얼음 송곳이 솟고, 가장자리는 눈 덮인 봉우리
      const rim = smoothstep(0.5, 0.82, t + 0.12 * nBase);
      const peaks = 12 + 44 * ridged(nLand, x * 0.0052, z * 0.0052, 3) + 8 * nBase + 3 * nDet;
      const sp = smoothstep(0.5, 0.74, nFar(x * 0.017 + 5.1, z * 0.017 - 3.3) + 0.25 * nDet);
      return 0.75 + (peaks - 0.75) * rim + (1 - rim) * 30 * sp * sp;
    }
    if (b === BIOME.TERRACE) {
      // 거인의 계단: 한가운데로 갈수록 높아지는 언덕이 7m 높이의 판판한 층으로 끊어져 있다
      const base = 4 + 70 * smoothstep(1.0, 0.0, t) * (0.72 + 0.5 * nBase) + 10 * (nFar(x * 0.005, z * 0.005) + 0.5);
      const k = (base < 0 ? 0 : base) / 13;
      const f = Math.floor(k);
      // 층과 층 사이는 대부분 절벽이지만, 군데군데 걸어 오를 수 있는 비탈이 있다
      const ramp = smoothstep(0.1, 0.4, nLand(x * 0.006 + 40.1, z * 0.006 - 22.6));
      return 3 + (f + smoothstep(0.95 - 0.3 * ramp, 1.0, k - f)) * 13 + 0.35 * nDet;
    }
    if (b === BIOME.REEF) {
      // 산호 군도: 걸어서 건널 수 있는 얕은 바다에 작은 섬들이 흩어져 있다. 군데군데 깊은 물웅덩이
      const n1 = nFar(x * 0.0085 + 21.3, z * 0.0085 + 8.8) + 0.3 * nLand(x * 0.021, z * 0.021);
      const isle = smoothstep(0.12, 0.42, n1);
      const sea = -0.72 + 0.2 * nDet - 5.5 * smoothstep(-0.38, -0.62, n1);
      return sea + (2.6 + 5 * smoothstep(0.4, 0.95, n1) + 1.4 * nBase - sea) * isle;
    }
    if (b === BIOME.PILLARS) {
      // 하늘 기둥: 낮은 분지 위로 꼭대기가 판판한 돌기둥이 높이 솟아 있다
      const ground = 4 + 3.2 * nBase + 2.2 * nDet;
      const G = 58; // 칸 크기: 칸마다 기둥이 하나 있거나 없다
      const cx = Math.floor(x / G);
      const cz = Math.floor(z / G);
      let hi = ground;
      for (let oz = -1; oz <= 1; oz++) {
        for (let ox = -1; ox <= 1; ox++) {
          const ix = cx + ox;
          const iz = cz + oz;
          if (rand2(ix, iz, seed + 311) > 0.62) continue;
          const px = (ix + 0.2 + 0.6 * rand2(ix, iz, seed + 312)) * G;
          const pz = (iz + 0.2 + 0.6 * rand2(ix, iz, seed + 313)) * G;
          const pr = 11 + 12 * rand2(ix, iz, seed + 314);
          const ddx = x - px;
          const ddz = z - pz;
          const dd = Math.sqrt(ddx * ddx + ddz * ddz) + 2.5 * nDet;
          if (dd > pr + 7) continue;
          const top = 30 + 46 * rand2(ix, iz, seed + 315);
          const hp = ground + (top - ground) * (1 - smoothstep(pr, pr + 6, dd));
          if (hp > hi) hi = hp;
        }
      }
      return hi;
    }
    // 별똥 분지: 높은 둘레 산, 움푹 꺼진 바닥의 동심원 물결, 한가운데 솟은 봉우리
    const a = (t - 0.6) / 0.1;
    const wall = 1 / (1 + a * a);
    const c = t / 0.085;
    const peak = 1 / (1 + c * c);
    const inside = smoothstep(0.6, 0.42, t);
    const u = t * 13;
    const fr = u - Math.floor(u);
    const ripple = (fr < 0.5 ? fr : 1 - fr) * 2;
    return 11 + 5 * nBase + 2 * nDet + 52 * wall * wall - 7.5 * inside + 3.2 * ripple * inside + 34 * peak * peak;
  }

  // 본섬의 높이 (세계를 넓히기 전과 완전히 같은 계산)
  function mainIsland(x, z, nBase, nDet) {
    biomeWeights(x, z);
    let h = 0;
    let w;

    // 초원: 완만한 언덕 + 호수 + 굽이굽이 흐르는 얕은 시내 (마을 근처는 비켜 간다)
    if ((w = wSoft[0]) > EPS) {
      let hm = 8.5 + 9 * nBase + 1.6 * nDet;
      const lk = nL(x * 0.0055 + 40.3, z * 0.0055 - 17.9);
      hm -= 15 * smoothstep(0.42, 0.62, lk);
      const rv = abs(nFar(x * 0.0026 + 60.4, z * 0.0026 - 33.1));
      const river = (1 - smoothstep(0.012, 0.05, rv)) * smoothstep(75, 135, Math.sqrt(x * x + z * z));
      if (hm > -0.85) hm += (-0.85 - hm) * river;
      h += w * hm;
    }
    // 숲: 둥근 봉우리가 올록볼록 솟은 깊은 숲. 봉우리 사이로 골짜기가 패어 있다
    if ((w = wSoft[1]) > EPS) {
      const knoll = smoothstep(0.1, 0.62, nLand(x * 0.0105 + 5.5, z * 0.0105 - 9.1));
      const gully = 1 - smoothstep(0.02, 0.085, abs(nFar(x * 0.0048 - 71.3, z * 0.0048 + 12.8)));
      h += w * (11 + 13 * nBase + 3.5 * nDet + 15 * knoll * knoll - 7.5 * gully);
    }
    // 설산: 높은 능선
    if ((w = wSoft[2]) > EPS) {
      const r = ridged(nC, x * 0.0038, z * 0.0038, 4);
      h += w * (22 + 150 * r * r + 14 * nBase + 5 * nDet);
    }
    // 사막: 모래 언덕 + 탁상지(메사)
    if ((w = wSoft[3]) > EPS) {
      let dn = nD(x * 0.011 + 0.6 * nBase, z * 0.0045);
      if (dn < 0) dn = -dn;
      let du = 1 - dn;
      if (du < 0) du = 0;
      const ms = smoothstep(0.24, 0.33, nM(x * 0.0058 + 7.7, z * 0.0058 + 3.1));
      // 큰 모래 언덕이 물결치듯 이어지고(마루는 날카롭다), 그 사이로 붉은 탁상지가 솟는다
      h += w * (5.5 + 11 * du * du * du + 26 * ms + 1.5 * nBase + ms * 1.5 * nDet);
    }
    // 늪: 수면 근처의 낮은 땅을 물길이 그물처럼 가른다 (걸어서 건널 수 있는 깊이)
    if ((w = wSoft[4]) > EPS) {
      let hs = 0.6 + 2.0 * nBase + 2.6 * nDet;
      const c1 = abs(nFar(x * 0.0075 + 50.2, z * 0.0075 + 18.4));
      const c2 = abs(nLand(x * 0.0062 - 14.9, z * 0.0062 + 66.1));
      const ch = 1 - smoothstep(0.03, 0.11, c1 < c2 ? c1 : c2);
      if (hs > -0.8) hs += (-0.8 - hs) * ch;
      h += w * hs;
    }
    // 화산 지대 기반
    if ((w = wSoft[5]) > EPS) {
      const r = ridged(nV, x * 0.009, z * 0.009, 3);
      h += w * (9 + 7 * nBase + 3 * nDet + 7 * r);
    }
    // 단풍 고원: 판판한 단이 층층이 높아지는 고원 (단과 단 사이는 가파른 비탈)
    if ((w = wSoft[6]) > EPS) {
      const k = (21 + 20 * nBase) / 10;
      const f = Math.floor(k);
      h += w * ((f + smoothstep(0.72, 1.0, k - f)) * 10 + 1.8 * nDet);
    }

    // 화산 원뿔 + 분화구 + 협곡 입구
    const vx = x - VOLCANO.x;
    const vz = z - VOLCANO.z;
    const dV = Math.sqrt(vx * vx + vz * vz);
    if (dV < 250) {
      const t = 1 - dV / 250;
      h += 100 * t * t * (3 - 2 * t);
      if (dV < 56) {
        const k = smoothstep(VOLCANO.arenaR + 2, 56, dV);
        h = VOLCANO.floor + (h - VOLCANO.floor) * k;
      }
      if (dV > 20 && dV < 140) {
        const dot = (vx * VOLCANO.notchX + vz * VOLCANO.notchZ) / dV;
        const nf = smoothstep(0.972, 0.995, dot);
        if (nf > 0) {
          const target = VOLCANO.floor + 1.2;
          if (h > target) h = h + (target - h) * nf;
        }
      }
    }

    // 섬 모양 마스크 (바다로 떨어지는 해안)
    const dn2 = Math.sqrt(x * x + z * z) / 770 + 0.09 * nCoast(x * 0.005, z * 0.005);
    const m = smoothstep(0.86, 1.0, dn2);
    h = h + (-26 - h) * m;
    if (h < -26) h = -26;
    return h;
  }

  // 높이맵 생성
  {
    let idx = 0;
    for (let j = 0; j < N; j++) {
      const z = -W.HALF + j * W.CELL;
      for (let i = 0; i < N; i++) {
        const x = -W.HALF + i * W.CELL;
        heights[idx] = rawHeight(x, z);
        biome[idx] = dom;
        added[idx] = (wasAdded ? 1 : 0) | (wasRoad ? 2 : 0);
        if (bw) {
          const o = idx * NB;
          let bsum = 0;
          for (let k = 0; k < NB; k++) bsum += bw[o + k] = Math.round(wSharp[k] * 255);
          if (bsum === 0) bw[o + dom] = 255;
        }
        idx++;
      }
    }
  }

  function clampCoord(v) {
    return v < -W.HALF ? -W.HALF : v > W.HALF - 0.001 ? W.HALF - 0.001 : v;
  }

  // 메시의 삼각형 분할과 동일한 방식으로 보간한 지면 높이
  function heightAt(x, z) {
    if (z < ZONE_Z) return ZONE_FLOOR;
    const fx = (clampCoord(x) + W.HALF) / W.CELL;
    const fz = (clampCoord(z) + W.HALF) / W.CELL;
    const i = Math.floor(fx);
    const j = Math.floor(fz);
    const u = fx - i;
    const v = fz - j;
    const a = j * N + i;
    const ha = heights[a];
    const hb = heights[a + 1];
    const hc = heights[a + N];
    const hd = heights[a + N + 1];
    if (u + v <= 1) return ha + (hb - ha) * u + (hc - ha) * v;
    return hd + (hc - hd) * (1 - u) + (hb - hd) * (1 - v);
  }

  // 지면 기울기 (dh/dx, dh/dz)
  function gradAt(x, z, out) {
    if (z < ZONE_Z) {
      out.x = 0;
      out.z = 0;
      return out;
    }
    const fx = (clampCoord(x) + W.HALF) / W.CELL;
    const fz = (clampCoord(z) + W.HALF) / W.CELL;
    const i = Math.floor(fx);
    const j = Math.floor(fz);
    const u = fx - i;
    const v = fz - j;
    const a = j * N + i;
    const ha = heights[a];
    const hb = heights[a + 1];
    const hc = heights[a + N];
    const hd = heights[a + N + 1];
    if (u + v <= 1) {
      out.x = (hb - ha) / W.CELL;
      out.z = (hc - ha) / W.CELL;
    } else {
      out.x = (hd - hc) / W.CELL;
      out.z = (hd - hb) / W.CELL;
    }
    return out;
  }

  const _g = { x: 0, z: 0 };
  function slopeAt(x, z) {
    gradAt(x, z, _g);
    return Math.sqrt(_g.x * _g.x + _g.z * _g.z);
  }

  function vertIndex(x, z) {
    let i = Math.round((x + W.HALF) / W.CELL);
    let j = Math.round((z + W.HALF) / W.CELL);
    if (i < 0) i = 0;
    if (i > W.GRID) i = W.GRID;
    if (j < 0) j = 0;
    if (j > W.GRID) j = W.GRID;
    return j * N + i;
  }

  function biomeAt(x, z) {
    return biome[vertIndex(x, z)];
  }

  function addedAt(x, z) {
    return (added[vertIndex(x, z)] & 1) === 1;
  }

  // 모래톱 길 위인지 (길에는 나무도 바위도 놓지 않는다)
  function roadAt(x, z) {
    return (added[vertIndex(x, z)] & 2) !== 0;
  }

  // 지형 평탄화 패치 적용: { x, z, r, f, h }
  function applyPatches(patches) {
    for (const p of patches) {
      const R = p.r + p.f;
      const i0 = Math.max(0, Math.floor((p.x - R + W.HALF) / W.CELL));
      const i1 = Math.min(W.GRID, Math.ceil((p.x + R + W.HALF) / W.CELL));
      const j0 = Math.max(0, Math.floor((p.z - R + W.HALF) / W.CELL));
      const j1 = Math.min(W.GRID, Math.ceil((p.z + R + W.HALF) / W.CELL));
      for (let j = j0; j <= j1; j++) {
        for (let i = i0; i <= i1; i++) {
          const x = -W.HALF + i * W.CELL;
          const z = -W.HALF + j * W.CELL;
          const dx = x - p.x;
          const dz = z - p.z;
          const d = Math.sqrt(dx * dx + dz * dz);
          if (d >= R) continue;
          const t = 1 - smoothstep(p.r, R, d);
          const idx = j * N + i;
          heights[idx] = heights[idx] + (p.h - heights[idx]) * t;
        }
      }
    }
  }

  // ---- 장식물(나무/바위 등) 배치 ----
  let exclusions = [];
  const propCache = new Map();

  function setExclusions(list) {
    exclusions = list || [];
    propCache.clear();
  }

  const PSTEP = 5;
  const PCELLS = W.CHUNK / PSTEP;
  const POFF = (W.HALF - OLD_HALF) / PSTEP; // 세계를 넓히기 전의 칸 번호와 맞추기 위한 보정

  function chunkProps(cx, cz) {
    const key = cz * W.CHUNKS + cx;
    let list = propCache.get(key);
    if (list) return list;
    list = [];
    propCache.set(key, list);
    if (cx < 0 || cz < 0 || cx >= W.CHUNKS || cz >= W.CHUNKS) return list;
    const x0 = -W.HALF + cx * W.CHUNK;
    const z0 = -W.HALF + cz * W.CHUNK;
    const ex = [];
    for (const e of exclusions) {
      if (e.x + e.r < x0 || e.x - e.r > x0 + W.CHUNK || e.z + e.r < z0 || e.z - e.r > z0 + W.CHUNK) continue;
      ex.push(e);
    }
    for (let gz = 0; gz < PCELLS; gz++) {
      for (let gx = 0; gx < PCELLS; gx++) {
        const ix = cx * PCELLS + gx - POFF;
        const iz = cz * PCELLS + gz - POFF;
        const pick = rand2(ix, iz, seed + 201);
        const x = x0 + (gx + 0.1 + 0.8 * rand2(ix, iz, seed + 202)) * PSTEP;
        const z = z0 + (gz + 0.1 + 0.8 * rand2(ix, iz, seed + 203)) * PSTEP;
        const h = heightAt(x, z);
        const b = biomeAt(x, z);
        // 물에 잠긴 곳에는 아무것도 놓지 않는다 (산호 군도의 얕은 바다만 예외)
        if (h < -0.7 && !(b === BIOME.REEF && h > -1.7)) continue;
        // 섬과 섬을 잇는 모래톱 길은 비워 둔다
        if (roadAt(x, z)) continue;
        const sl = slopeAt(x, z);
        const r1 = rand2(ix, iz, seed + 204);
        const r2 = rand2(ix, iz, seed + 205);
        let t = -1;
        let s = 1;
        let cr = 0;
        const land = h > 0.9;
        const flat = sl < 0.75;
        const gv = nGrove(x * 0.011, z * 0.011);

        if (b === BIOME.MEADOW) {
          const tp = gv > 0.25 ? 0.14 : 0.012;
          if (land && flat && pick < tp) { t = PROP.OAK; s = 0.9 + r1 * 0.7; cr = 0.45 * s; }
          else if (land && pick < tp + 0.012) { t = PROP.BUSH; s = 0.7 + r1 * 0.6; }
          else if (land && pick < tp + 0.02) { t = PROP.ROCK; s = 0.5 + r1 * 1.1; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && sl < 0.5 && pick < tp + 0.075) { t = PROP.FLOWER; s = 0.8 + r1 * 0.5; }
        } else if (b === BIOME.FOREST) {
          const tp = 0.2 + 0.16 * (gv + 0.5);
          if (land && flat && pick < tp) {
            t = r2 < 0.55 ? PROP.PINE : PROP.OAK;
            s = 1.0 + r1 * 0.9;
            if (pick < 0.012) s = 2.3 + r1 * 0.9; // 숲의 어른 나무: 아주 크다
            cr = 0.45 * s;
          }
          else if (land && pick < tp + 0.04) { t = PROP.BUSH; s = 0.7 + r1 * 0.7; }
          else if (land && pick < tp + 0.055) { t = PROP.ROCK; s = 0.5 + r1 * 1.2; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && pick < tp + 0.085) { t = PROP.MUSHROOM; s = 0.7 + r1 * 0.8; }
        } else if (b === BIOME.AUTUMN) {
          const tp = gv > -0.1 ? 0.13 : 0.03;
          if (land && flat && pick < tp) { t = PROP.AUTUMN; s = 0.9 + r1 * 0.8; cr = 0.45 * s; }
          else if (land && pick < tp + 0.02) { t = PROP.ROCK; s = 0.5 + r1 * 1.3; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && pick < tp + 0.045) { t = PROP.BUSH; s = 0.7 + r1 * 0.6; }
          else if (land && sl < 0.5 && pick < tp + 0.07) { t = PROP.FLOWER; s = 0.8 + r1 * 0.4; }
        } else if (b === BIOME.SNOW) {
          if (land && flat && h < 100 && pick < (gv > 0.1 ? 0.07 : 0.015)) { t = PROP.SNOWPINE; s = 1.0 + r1 * 0.8; cr = 0.45 * s; }
          else if (land && pick < 0.1) { t = PROP.ROCK; s = 0.6 + r1 * 1.6; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && flat && pick < 0.108) { t = PROP.ICE; s = 0.8 + r1 * 1.2; cr = 0.6 * s; }
        } else if (b === BIOME.DESERT) {
          if (land && flat && h < 3.2 && pick < 0.1) { t = PROP.PALM; s = 1.0 + r1 * 0.5; cr = 0.4 * s; }
          else if (land && flat && pick < 0.014) { t = PROP.CACTUS; s = 0.8 + r1 * 0.9; cr = 0.5 * s; }
          else if (land && pick < 0.034) { t = PROP.ROCK; s = 0.5 + r1 * 1.4; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && pick < 0.052) { t = PROP.DRYBUSH; s = 0.7 + r1 * 0.6; }
        } else if (b === BIOME.SWAMP) {
          if (h > 0.5 && flat && pick < 0.07) { t = r2 < 0.5 ? PROP.WILLOW : PROP.DEAD; s = 0.9 + r1 * 0.8; cr = 0.45 * s; }
          else if (h < 1.3 && pick < 0.2) { t = PROP.REED; s = 0.8 + r1 * 0.6; }
          else if (land && pick < 0.21) { t = PROP.ROCK; s = 0.5 + r1 * 1.0; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && pick < 0.235) { t = PROP.MUSHROOM; s = 0.8 + r1 * 1.0; }
        } else if (b === BIOME.VOLCANO) {
          if (land && flat && pick < 0.012) { t = PROP.DEAD; s = 0.9 + r1 * 0.7; cr = 0.4 * s; }
          else if (land && pick < 0.06) { t = PROP.ROCK; s = 0.6 + r1 * 1.7; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && flat && pick < 0.072) { t = PROP.SPIKE; s = 0.8 + r1 * 1.4; cr = 0.6 * s; }
        } else if (b === BIOME.BLOSSOM) {
          const tp = gv > -0.15 ? 0.12 : 0.035;
          if (land && flat && pick < tp) { t = PROP.CHERRY; s = 0.9 + r1 * 0.8; cr = 0.45 * s; }
          else if (land && pick < tp + 0.02) { t = PROP.BUSH; s = 0.7 + r1 * 0.6; }
          else if (land && pick < tp + 0.03) { t = PROP.ROCK; s = 0.5 + r1 * 1.1; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && sl < 0.5 && pick < tp + 0.12) { t = PROP.FLOWER; s = 0.8 + r1 * 0.5; }
        } else if (b === BIOME.MUSHROOM) {
          if (h > 0.6 && flat && pick < (gv > 0 ? 0.13 : 0.06)) { t = PROP.SHROOMTREE; s = 0.75 + r1 * 1.25; cr = 0.42 * s; }
          else if (land && pick < 0.22) { t = PROP.MUSHROOM; s = 0.8 + r1 * 1.3; }
          else if (land && pick < 0.24) { t = PROP.ROCK; s = 0.5 + r1 * 1.1; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (h < 1.3 && pick < 0.32) { t = PROP.REED; s = 0.8 + r1 * 0.6; }
        } else if (b === BIOME.CRYSTAL) {
          if (land && flat && pick < (gv > 0.05 ? 0.07 : 0.025)) { t = PROP.CRYSTAL; s = 0.8 + r1 * 1.7; cr = 0.5 * s; }
          else if (land && pick < 0.1) { t = PROP.ROCK; s = 0.6 + r1 * 1.5; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && flat && pick < 0.112) { t = PROP.ICE; s = 0.8 + r1 * 1.1; cr = 0.6 * s; }
        } else if (b === BIOME.SHADOW) {
          if (land && flat && pick < 0.022) { t = PROP.DEAD; s = 0.9 + r1 * 0.9; cr = 0.4 * s; }
          else if (land && pick < 0.07) { t = PROP.ROCK; s = 0.6 + r1 * 1.8; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && flat && pick < 0.1) { t = PROP.OBELISK; s = 0.8 + r1 * 1.5; cr = 0.55 * s; }
        } else if (b === BIOME.CANYON) {
          // 고원 위는 메마른 덤불과 선인장, 협곡 바닥의 물가에는 갈대와 야자
          if (h < 6) {
            if (h < 1.5 && pick < 0.3) { t = PROP.REED; s = 0.8 + r1 * 0.6; }
            else if (land && flat && pick < 0.34) { t = PROP.PALM; s = 0.9 + r1 * 0.5; cr = 0.4 * s; }
            else if (land && sl < 1.3 && pick < 0.4) { t = PROP.ROCK; s = 0.6 + r1 * 1.5; cr = s > 0.8 ? 0.8 * s : 0; }
          } else if (land && flat && pick < 0.016) { t = PROP.HOODOO; s = 0.9 + r1 * r1 * 2.2; cr = 0.75 * s; }
          else if (land && flat && pick < 0.032) { t = PROP.CACTUS; s = 0.9 + r1 * 1.1; cr = 0.5 * s; }
          else if (land && flat && pick < 0.04) { t = PROP.DEAD; s = 0.9 + r1 * 0.8; cr = 0.4 * s; }
          else if (land && sl < 1.3 && pick < 0.07) { t = PROP.ROCK; s = 0.6 + r1 * 1.8; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && sl < 1.3 && pick < 0.108) { t = PROP.DRYBUSH; s = 0.7 + r1 * 0.7; }
        } else if (b === BIOME.GLACIER) {
          // 얼음판 위에는 드문드문 얼음 조각, 둘레의 눈 언덕에는 눈 덮인 나무
          if (h < 1.3) {
            if (h > 0.3 && pick < 0.014) { t = PROP.ICE; s = 0.9 + r1 * 1.6; cr = 0.6 * s; }
          } else if (land && flat && pick < (gv > 0 ? 0.08 : 0.02)) { t = PROP.SNOWPINE; s = 1.0 + r1 * 0.9; cr = 0.45 * s; }
          else if (land && pick < 0.11) { t = PROP.ROCK; s = 0.6 + r1 * 1.6; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && flat && pick < 0.13) { t = PROP.ICE; s = 0.8 + r1 * 1.4; cr = 0.6 * s; }
        } else if (b === BIOME.TERRACE) {
          // 층마다 나무와 꽃이 우거진 푸른 계단
          const grove = gv > 0.16; // 대나무 숲
          const tp = grove ? 0.2 : gv > -0.2 ? 0.1 : 0.035;
          if (land && flat && pick < tp) {
            if (grove) { t = PROP.BAMBOO; s = 0.9 + r1 * 0.9; cr = 0.32 * s; }
            else { t = r2 < 0.5 ? PROP.PINE : PROP.OAK; s = 1.0 + r1 * 1.0; cr = 0.45 * s; }
          }
          else if (land && sl < 1.3 && pick < tp + 0.03) { t = PROP.BUSH; s = 0.7 + r1 * 0.7; }
          else if (land && sl < 1.3 && pick < tp + 0.04) { t = PROP.ROCK; s = 0.5 + r1 * 1.2; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && sl < 0.5 && pick < tp + 0.1) { t = PROP.FLOWER; s = 0.8 + r1 * 0.5; }
        } else if (b === BIOME.REEF) {
          // 작은 섬마다 야자가 서 있고, 얕은 물에는 산호빛 바위
          if (h > 1.6 && flat && pick < 0.1) { t = PROP.PALM; s = 1.0 + r1 * 0.6; cr = 0.4 * s; }
          else if (h < 0.6 && pick < 0.14) { t = PROP.CORAL; s = 0.7 + r1 * 1.5; cr = s > 1.5 ? 0.45 * s : 0; }
          else if (h > -0.9 && pick < 0.17) { t = PROP.ROCK; s = 0.5 + r1 * 1.3; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (h > 1.6 && pick < 0.195) { t = PROP.BUSH; s = 0.7 + r1 * 0.6; }
          else if (h > 1.6 && sl < 0.5 && pick < 0.26) { t = PROP.FLOWER; s = 0.8 + r1 * 0.5; }
        } else if (b === BIOME.PILLARS) {
          // 기둥 꼭대기에는 소나무가, 안개 낀 바닥에는 버섯과 덤불이 자란다
          if (h > 24) {
            if (flat && pick < 0.14) { t = PROP.PINE; s = 0.9 + r1 * 0.8; cr = 0.45 * s; }
            else if (sl < 1.3 && pick < 0.2) { t = PROP.BUSH; s = 0.7 + r1 * 0.6; }
          } else if (land && flat && pick < 0.03) { t = PROP.PINE; s = 1.0 + r1 * 0.8; cr = 0.45 * s; }
          else if (land && sl < 1.3 && pick < 0.1) { t = PROP.MUSHROOM; s = 0.8 + r1 * 1.2; }
          else if (land && sl < 1.3 && pick < 0.14) { t = PROP.ROCK; s = 0.6 + r1 * 1.6; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && sl < 1.3 && pick < 0.17) { t = PROP.BUSH; s = 0.7 + r1 * 0.6; }
        } else if (b === BIOME.CRATER) {
          // 별이 떨어진 자리에 돋은 수정과 검은 돌
          if (land && flat && pick < (gv > 0 ? 0.06 : 0.02)) { t = PROP.CRYSTAL; s = 0.9 + r1 * 2.0; cr = 0.5 * s; }
          else if (land && pick < 0.1) { t = PROP.ROCK; s = 0.6 + r1 * 1.7; cr = s > 0.8 ? 0.8 * s : 0; }
          else if (land && flat && pick < 0.118) { t = PROP.OBELISK; s = 0.8 + r1 * 1.4; cr = 0.55 * s; }
          else if (land && flat && pick < 0.13) { t = PROP.SPIKE; s = 0.8 + r1 * 1.3; cr = 0.6 * s; }
        }
        if (t < 0) continue;
        let blocked = false;
        for (const e of ex) {
          const dx = x - e.x;
          const dz = z - e.z;
          if (dx * dx + dz * dz < e.r * e.r) { blocked = true; break; }
        }
        if (blocked) continue;
        list.push({ t, x, z, y: h, s, r: r2, b, cr });
      }
    }
    return list;
  }

  return {
    seed,
    heights,
    biome,
    bw,
    heightAt,
    gradAt,
    slopeAt,
    biomeAt,
    addedAt,
    roadAt,
    flags: added,
    vertIndex,
    applyPatches,
    setExclusions,
    chunkProps,
  };
}

// 장식물이 놓이면 안 되는 구역 목록 (서버/클라이언트 공통 규칙)
export function exclusionsFor(pois) {
  const ex = [{ x: pois.village.x, z: pois.village.z, r: 50 }, { x: pois.arena.x, z: pois.arena.z, r: 36 }];
  for (const s of pois.shards) ex.push({ x: s.x, z: s.z, r: 13 });
  for (const s of pois.stones) ex.push({ x: s.x, z: s.z, r: 6 });
  for (const c of pois.camps) ex.push({ x: c.x, z: c.z, r: 10 });
  for (const c of pois.chests) ex.push({ x: c.x, z: c.z, r: 2.5 });
  for (const b of pois.bushes) ex.push({ x: b.x, z: b.z, r: 2 });
  for (const n of pois.npcs) ex.push({ x: n.x, z: n.z, r: 2.5 });
  for (const q of pois.zones || []) {
    ex.push({ x: q.x, z: q.z, r: 8 });
    for (const l of q.lamps) ex.push({ x: l.x, z: l.z, r: 2.5 });
  }
  return ex;
}

// 히든 탈것: 외진 곳에 사는 야생마. 황금 사과를 모아 가면 길들일 수 있다.
import { MOUNTS } from '/shared/defs.js';
import { makeHorse, animateHorse } from './models.js';
import { josa } from './dom.js';

export class WildMounts {
  constructor(game) {
    this.game = game;
    const { world, pois, objects, save } = game;
    this.list = (pois.mounts || []).map((m) => {
      const rig = makeHorse(0, 0, m.k, true);
      const y = world.heightAt(m.x, m.z);
      rig.root.position.set(m.x, y, m.z);
      rig.root.rotation.y = (m.x * 0.37) % 6.28;
      rig.root.visible = false;
      objects.group.add(rig.root);
      const w = { k: m.k, def: MOUNTS[m.k], x: m.x, y, z: m.z, rig, yaw: rig.root.rotation.y, t: Math.random() * 10, met: false, col: { x: m.x, z: m.z, r: 1.0, off: true } };
      objects.interactables.push({
        kind: 'wmount', ref: w, x: m.x, z: m.z, r: 4.4,
        active: () => !game.zone && this.shown(w),
        label: () => `${w.def.name} 길들이기 — 황금 사과 ${w.def.need}개 (가진 것 ${save.apples}개)`,
      });
      objects.colliders.push(w.col);
      objects.lightSrc.push({ x: m.x, y: y + 2, z: m.z, color: rig.look.mane, power: 20, wild: w });
      return w;
    });
  }

  // 아직 길들이지 않았고, 모습을 드러내는 때인지 (그림자갈기는 밤에만)
  shown(w) {
    const g = this.game;
    if (g.save.mounts.includes(w.k)) return false;
    return w.k !== 'shade' || g.gfx.night > 0.5;
  }

  tame(w) {
    const g = this.game;
    const s = g.save;
    if (s.mounts.includes(w.k)) return;
    if (s.apples < w.def.need) {
      g.ui.toast(`${w.def.name}${josa(w.def.name, '이', '가')} 고개를 돌립니다. 황금 사과가 ${w.def.need - s.apples}개 더 필요해요. (우두머리 · 수호자 · 던전에서 얻을 수 있습니다)`);
      g.audio.deny();
      return;
    }
    s.apples -= w.def.need;
    s.mounts.push(w.k);
    s.mountKind = w.k;
    g.player.buildHorse();
    g.net.send({ t: 'prof', prof: g.player.profile() });
    g.audio.tame();
    g.fx.ring(w.x, w.y + 0.3, w.z, w.rig.look.mane, 6, 0.9);
    g.fx.burst(w.x, w.y + 1.6, w.z, w.rig.look.tip, 40, 6, { size: 0.36, life: 1.1, grav: 2, glow: 2.4 });
    g.ui.banner(`${w.def.name}${josa(w.def.name, '을', '를')} 길들였습니다!`, g.input.isTouch ? '탈것 버튼으로 부를 수 있어요' : 'G 키로 부를 수 있어요 · 모험가 화면(P)에서 탈것을 바꿉니다');
    g.net.send({ t: 'chat', text: `★ 히든 탈것 「${w.def.name}」${josa(w.def.name, '을', '를')} 길들였습니다!` });
    g.ui.dirty = true;
    g.saveSoon();
  }

  update(dt, time) {
    const g = this.game;
    const p = g.player.pos;
    for (const w of this.list) {
      const dx = p.x - w.x;
      const dz = p.z - w.z;
      const d2 = dx * dx + dz * dz;
      const vis = !g.zone && d2 < 240 * 240 && this.shown(w);
      w.rig.root.visible = vis;
      w.col.off = !vis;
      if (!vis) continue;
      w.t += dt;
      // 가까이 가면 이쪽을 바라본다
      if (d2 < 22 * 22) {
        const want = Math.atan2(dx, dz);
        let diff = (want - w.yaw) % 6.2832;
        if (diff > 3.1416) diff -= 6.2832;
        if (diff < -3.1416) diff += 6.2832;
        w.yaw += diff * Math.min(1, dt * 2);
        w.rig.root.rotation.y = w.yaw;
        if (!w.met && d2 < 14 * 14) {
          w.met = true;
          g.ui.region(w.def.name, w.def.desc);
          g.tip('wild-' + w.k, `야생의 ${w.def.name}입니다. 황금 사과 ${w.def.need}개를 주면 길들일 수 있어요.`);
        }
      }
      animateHorse(w.rig, dt, 0);
      if (d2 < 70 * 70 && Math.random() < dt * 7) {
        g.fx.spawn(w.x + (Math.random() - 0.5) * 1.2, w.y + 1.2 + Math.random() * 1.2, w.z + (Math.random() - 0.5) * 1.2, (Math.random() - 0.5) * 0.4, 0.6 + Math.random() * 0.8, (Math.random() - 0.5) * 0.4, Math.random() < 0.4 ? w.rig.look.tip : w.rig.look.mane, 0.14, 0.9, -0.3, 1, 3, 0.4);
      }
    }
  }
}

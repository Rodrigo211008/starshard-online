// 캐릭터 진행 상황을 브라우저(localStorage)에 저장한다.
import { cleanItem, makeItem, newItemId, INV_CAP, SLOTS, slotOf, MOUNTS, POTION_KEYS, POTION_CAP, UNIQUES, MAX_LEVEL } from '/shared/defs.js';

const KEY = 'starshard-save-v1';

export function defaultSave() {
  return {
    v: 2,
    name: '',
    tunic: Math.floor(Math.random() * 8),
    hair: Math.floor(Math.random() * 6),
    level: 1,
    xp: 0,
    gold: 0,
    hp: 6,
    // 착용 장비와 가방 (아이템: { id, t, r, l, e, a })
    eq: { weapon: makeItem('sword', 0, 1), bow: makeItem('bow', 0, 1), armor: null, helm: null, charm: null },
    inv: [],
    mats: { dust: 0, core: 0 },
    mount: false,
    mountColor: Math.floor(Math.random() * 5),
    mounts: [], // 길들인 히든 탈것
    mountKind: 'horse', // 지금 타는 탈것
    apples: 0, // 황금 사과 (히든 탈것을 길들일 때 쓴다)
    pots: { hp: 0, sta: 0, power: 0, guard: 0, swift: 0 }, // 물약
    uqGot: [], // 얻어 본 히든 무기
    uqPity: {}, // 히든 무기가 안 나온 횟수 (나올 확률이 조금씩 오른다)
    uqDrop: [], // 바닥에 떨어져 있는 히든 무기 (주울 때까지 사라지지 않는다)
    tablet: false, // 마을의 별의 석판에서 여명의 대검을 받았는지
    berries: 2,
    arrows: 15,
    glider: false,
    talkedElder: false,
    stones: [0],
    lastStone: 0,
    chestKey: '',
    chests: [],
    bushes: {},
    world: null,
    kills: 0,
    // 별의 시련장과 숨겨진 던전
    trials: [], // 인장을 받은 시련장 번호
    zfound: [], // 찾아낸 입구 (지도에 표시된다)
    lamps: {}, // 던전 번호 -> 밝힌 돌등 (비트 묶음)
    dclear: [], // 정복한 던전
    zchest: {}, // 던전 번호 -> 마지막으로 보물상자를 연 회차
    bonusHp: 0, // 인장으로 늘어난 체력(하트 반 칸 단위)과 기력
    bonusSta: 0,
    pvpWins: 0, // 결투에서 이긴 횟수
    settings: { quality: '', sound: true, music: true, sens: 1, follow: false, pvp: false },
  };
}

// 예전 저장(검·갑옷·활이 단계 숫자였던 때)을 아이템으로 바꾼다
function migrate(s, d) {
  const sw = [[0, 1], [1, 6], [2, 12], [3, 18]][Math.min(3, Math.max(0, d.sword | 0))];
  const bw = [[0, 1], [1, 10], [2, 18]][Math.min(2, Math.max(0, d.bow | 0))];
  const ar = [null, [1, 6], [2, 14]][Math.min(2, Math.max(0, d.armor | 0))];
  s.eq = {
    weapon: makeItem('sword', sw[0], sw[1]),
    bow: makeItem('bow', bw[0], bw[1]),
    armor: ar ? makeItem('armor', ar[0], ar[1]) : null,
    helm: null,
    charm: null,
  };
  s.inv = [];
}

export function loadSave() {
  const base = defaultSave();
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return base;
    const d = JSON.parse(raw);
    if (!d || typeof d !== 'object') return base;
    const s = { ...base, ...d };
    s.settings = { ...base.settings, ...(d.settings || {}) };
    if (!Array.isArray(s.stones) || !s.stones.includes(0)) s.stones = [0];
    if (!Array.isArray(s.chests)) s.chests = [];
    if (!s.bushes || typeof s.bushes !== 'object') s.bushes = {};
    for (const k of ['level', 'xp', 'gold', 'hp', 'berries', 'arrows', 'lastStone', 'kills']) {
      s[k] = Number.isFinite(+s[k]) ? Math.max(0, Math.floor(+s[k])) : base[k];
    }
    s.level = Math.max(1, Math.min(MAX_LEVEL, s.level));
    if (!(d.v >= 2) || !d.eq || typeof d.eq !== 'object') migrate(s, d);
    else {
      // 저장된 장비를 검사한다 (칸에 맞지 않는 것은 가방으로)
      const eq = {};
      const extra = [];
      for (const slot of SLOTS) {
        const it = cleanItem(d.eq[slot]);
        if (it && slotOf(it.t) === slot) eq[slot] = it;
        else {
          eq[slot] = null;
          if (it) extra.push(it);
        }
      }
      s.eq = eq;
      s.inv = (Array.isArray(d.inv) ? d.inv : []).map(cleanItem).filter(Boolean).concat(extra).slice(0, INV_CAP);
    }
    const seen = new Set();
    for (const it of [...SLOTS.map((k) => s.eq[k]), ...s.inv]) {
      if (!it) continue;
      if (!it.id || seen.has(it.id)) it.id = newItemId();
      seen.add(it.id);
    }
    if (!s.eq.weapon) s.eq.weapon = makeItem('sword', 0, 1);
    const m = d.mats && typeof d.mats === 'object' ? d.mats : {};
    s.mats = { dust: Math.max(0, Math.floor(+m.dust || 0)), core: Math.max(0, Math.floor(+m.core || 0)) };
    s.mount = !!s.mount;
    s.mountColor = Math.max(0, Math.min(4, s.mountColor | 0));
    s.mounts = Array.isArray(d.mounts) ? [...new Set(d.mounts.filter((k) => MOUNTS[k] && k !== 'horse'))] : [];
    s.mountKind = s.mountKind === 'horse' ? 'horse' : s.mounts.includes(s.mountKind) ? s.mountKind : s.mounts[0] && !s.mount ? s.mounts[0] : 'horse';
    s.apples = Math.max(0, Math.min(999, s.apples | 0));
    const pots = d.pots && typeof d.pots === 'object' ? d.pots : {};
    s.pots = {};
    for (const k of POTION_KEYS) s.pots[k] = Math.max(0, Math.min(POTION_CAP, pots[k] | 0));
    s.uqGot = Array.isArray(d.uqGot) ? [...new Set(d.uqGot.filter((k) => UNIQUES[k]))] : [];
    s.uqPity = d.uqPity && typeof d.uqPity === 'object' ? { ...d.uqPity } : {};
    s.uqDrop = (Array.isArray(d.uqDrop) ? d.uqDrop : []).map(cleanItem).filter((it) => it && it.u && it.id).slice(0, 8);
    s.tablet = !!d.tablet;
    s.pvpWins = Math.max(0, s.pvpWins | 0);
    s.settings.pvp = !!s.settings.pvp;
    const ids = (v) => (Array.isArray(v) ? [...new Set(v.map((n) => n | 0).filter((n) => n > 0 && n < 64))] : []);
    s.trials = ids(d.trials);
    s.zfound = ids(d.zfound);
    s.dclear = ids(d.dclear);
    s.lamps = d.lamps && typeof d.lamps === 'object' ? { ...d.lamps } : {};
    s.zchest = d.zchest && typeof d.zchest === 'object' ? { ...d.zchest } : {};
    // 인장 하나마다 번갈아 하트 한 칸(2) 또는 기력 10 (저장된 값이 어긋나 있으면 인장 수에 맞춘다)
    s.bonusHp = Math.ceil(s.trials.length / 2) * 2;
    s.bonusSta = Math.floor(s.trials.length / 2) * 10;
    s.v = 2;
    delete s.sword;
    delete s.armor;
    delete s.bow;
    return s;
  } catch {
    return base;
  }
}

let pending = null;
export function storeSave(save) {
  if (pending) return;
  pending = setTimeout(() => {
    pending = null;
    try {
      localStorage.setItem(KEY, JSON.stringify(save));
    } catch {
      /* 저장 공간을 쓸 수 없으면 무시 */
    }
  }, 400);
}

export function storeSaveNow(save) {
  try {
    localStorage.setItem(KEY, JSON.stringify(save));
  } catch {
    /* 무시 */
  }
}

// 가방 · 장비 · 상점(사기 / 팔기 / 강화) · 친구와 교환 화면. UI 클래스에 기능을 덧붙인다.
import {
  RARITY, SLOTS, SLOT_NAME, TYPE_NAME, WEAPONS, WEAPON_KINDS, INV_CAP, MAX_ENH, MOUNT_PRICE, SHOP, POTIONS, POTION_KEYS, POTION_CAP, UNIQUES, LEGEND_CRIT,
  slotOf, itemName, itemPower, itemStatText, itemValue, canEnhance, enhanceCost, enhanceChance,
} from '/shared/defs.js';
import { $, esc, icon } from './dom.js';

const TRADE_MAX = 6;

export function installItemsUI(UI) {
  Object.assign(UI.prototype, {
    // ---------- 아이템 칸 ----------
    _mkCell(it, cls = '') {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = `cell r${it.r} ${cls}`;
      b.dataset.id = it.id;
      b.innerHTML = `${icon(it.t)}${it.e > 0 ? `<i class="enh">+${it.e}</i>` : ''}<i class="lv">${it.l}</i>`;
      return b;
    },

    // 아이템 설명 (이름 · 등급 · 능력치 · 지금 착용한 것과 비교)
    _itemInfo(it, equipped) {
      const s = this.game.save;
      const rar = RARITY[it.r];
      const cur = s.eq[slotOf(it.t)];
      let cmp = '';
      if (!equipped && cur && cur.id !== it.id && it.t !== 'charm') {
        const d = itemPower(it) - itemPower(cur);
        const unit = it.t === 'helm' ? d / 2 : d;
        cmp = d > 0 ? `<b class="up">▲ +${unit}</b>` : d < 0 ? `<b class="down">▼ ${unit}</b>` : '<b class="same">＝ 같음</b>';
        if (WEAPONS[it.t] && cur.t !== it.t) cmp += ` <small>(지금: ${TYPE_NAME[cur.t]})</small>`;
      } else if (!equipped && !cur) cmp = '<b class="up">빈 칸에 착용</b>';
      let h = `<div class="it-head"><span class="cell r${it.r} big">${icon(it.t)}</span><div><h3 style="color:${rar.css}">${esc(itemName(it))}</h3>`;
      h += `<small>${rar.name} · ${TYPE_NAME[it.t]} · Lv.${it.l}${it.t !== 'charm' ? ` · 강화 ${it.e || 0}/${MAX_ENH}` : ''}${equipped ? ' · <em>착용 중</em>' : ''}</small></div></div>`;
      h += `<p class="it-stat">${esc(itemStatText(it))} ${cmp}</p>`;
      if (it.u && UNIQUES[it.u]) h += `<p class="it-desc" style="color:#ff9ab0">★ 히든 무기 — ${esc(UNIQUES[it.u].desc)} · 치명타 확률 +${Math.round(LEGEND_CRIT * 100)}%</p>`;
      else if (it.r >= 4 && (WEAPONS[it.t] || it.t === 'bow')) h += `<p class="it-desc" style="color:#ffd27a">전설의 예리함 — 치명타 확률 +${Math.round(LEGEND_CRIT * 100)}%</p>`;
      if (WEAPONS[it.t]) h += `<p class="it-desc">${esc(WEAPONS[it.t].desc)}</p>`;
      h += `<p class="it-desc">상인에게 팔면 ${itemValue(it)} 골드</p>`;
      return h;
    },

    // ================= 가방 =================
    refreshInv(keepId) {
      const g = this.game;
      const s = g.save;
      const eqEl = $('inv-eq');
      eqEl.innerHTML = '';
      const bind = (cell, it) => {
        cell._act = { click: () => this._invPrimary(it.id) };
        cell._onFocus = () => this._invShow(it.id);
        cell.addEventListener('click', () => {
          this.setFocus(cell, false);
          this._invShow(it.id);
        });
      };
      for (const slot of SLOTS) {
        const it = s.eq[slot];
        const wrap = document.createElement('div');
        wrap.className = 'eq-slot';
        let cell;
        if (it) {
          cell = this._mkCell(it, 'eq');
          bind(cell, it);
        } else {
          cell = document.createElement('div');
          cell.className = 'cell empty';
          cell.innerHTML = icon(slot === 'weapon' ? 'sword' : slot);
        }
        const lab = document.createElement('small');
        lab.textContent = SLOT_NAME[slot];
        wrap.append(cell, lab);
        eqEl.appendChild(wrap);
      }
      const grid = $('inv-grid');
      grid.innerHTML = '';
      for (let i = 0; i < INV_CAP; i++) {
        const it = s.inv[i];
        if (it) {
          const cell = this._mkCell(it, g.inv.better(it) ? 'better' : '');
          bind(cell, it);
          grid.appendChild(cell);
        } else {
          const e = document.createElement('div');
          e.className = 'cell empty';
          grid.appendChild(e);
        }
      }
      $('inv-count').textContent = `${s.inv.length}/${INV_CAP}`;
      $('inv-mats').innerHTML =
        `<div>${icon('dust')}별가루 <b>${s.mats.dust}</b></div><div>${icon('core')}별의 핵 <b>${s.mats.core}</b></div>` +
        `<div>${icon('berry')}열매 <b>${s.berries}</b></div><div>${icon('arrows')}화살 <b>${s.arrows}</b></div><div>${icon('coin')}골드 <b>${s.gold}</b></div>` +
        POTION_KEYS.map((k) => (s.pots[k] > 0 ? `<div style="color:${POTIONS[k].css}">${icon('potion')}<span style="color:var(--cream)">${POTIONS[k].name} <b>${s.pots[k]}</b></span></div>` : '')).join('') +
        (s.apples > 0 ? `<div>${icon('apple')}황금 사과 <b>${s.apples}</b></div>` : '');
      // 고르던 아이템을 계속 고른 채로 둔다 (없어졌으면 첫 칸)
      const box = $('panel-inv');
      let cell = keepId ? box.querySelector(`.cell[data-id="${keepId}"]`) : null;
      if (!cell) cell = grid.querySelector('button.cell') || eqEl.querySelector('button.cell');
      if (cell) {
        this.setFocus(cell, false);
        this._invShow(cell.dataset.id);
      } else this._invShow(null);
    },

    _invShow(id) {
      const g = this.game;
      const f = id ? g.inv.find(id) : null;
      this.invSel = f ? id : null;
      const el = $('inv-detail');
      for (const c of $('panel-inv').querySelectorAll('.cell.sel')) c.classList.remove('sel');
      if (!f) {
        el.innerHTML = '<p class="it-desc">아직 가방이 비어 있습니다.<br>몬스터를 사냥하거나 보물상자를 열면 장비와 강화 재료를 얻을 수 있어요.</p>';
        return;
      }
      const cell = $('panel-inv').querySelector(`.cell[data-id="${id}"]`);
      if (cell) cell.classList.add('sel');
      const eq = !!f.slot;
      let h = this._itemInfo(f.item, eq);
      h += '<div class="row-btns">';
      h += `<button class="primary" data-act="primary" data-nonav><kbd>Enter</kbd>${eq ? '벗기' : '착용하기'}</button>`;
      if (!eq) h += '<button data-act="discard" data-nonav><kbd>X</kbd>버리기</button>';
      h += '</div><p class="it-desc">파는 것은 마을 상인에게, 강화는 대장장이에게 맡기세요.</p>';
      el.innerHTML = h;
      el.querySelector('[data-act="primary"]').addEventListener('click', () => this._invPrimary(id));
      const d = el.querySelector('[data-act="discard"]');
      if (d) d.addEventListener('click', () => this._invDiscard(id));
    },

    _invPrimary(id) {
      const g = this.game;
      const f = g.inv.find(id);
      if (!f) return;
      if (f.slot) g.inv.unequip(f.slot);
      else if (g.inv.equip(id)) {
        const it = f.item;
        this.toast(`${itemName(it)} 착용${WEAPONS[it.t] ? ' — ' + WEAPONS[it.t].desc : ''}`, true);
      }
      this.bagDirty = false;
      this.refreshInv(id);
    },

    // 버리기는 두 번 눌러야 한다
    _invDiscard(id) {
      const g = this.game;
      const f = g.inv.find(id);
      if (!f || f.slot) return;
      if (this._discardId !== id || Date.now() - this._discardAt > 2500) {
        this._discardId = id;
        this._discardAt = Date.now();
        this.toast('정말 버릴까요? 한 번 더 누르면 버립니다.');
        return;
      }
      this._discardId = null;
      const next = g.save.inv[f.index + 1] || g.save.inv[f.index - 1];
      g.inv.discard(id);
      this.bagDirty = false;
      this.refreshInv(next ? next.id : null);
    },

    // ================= 상점: 사기 / 팔기 / 강화 =================
    openShop(kind, mode = 'buy') {
      this.closeAll();
      this.game.input.unlock();
      this.game.input.autoRun = false;
      this.shopKind = kind;
      this.shopMode = mode;
      $('panel-shop').classList.remove('hidden');
      $('shop-flash').className = '';
      $('shop-flash').textContent = '';
      $('shop-title').textContent = kind === 'merchant' ? '상인 보리의 가게' : '무쇠의 대장간';
      const modes = kind === 'merchant' ? [['buy', '사기'], ['sell', '팔기']] : [['buy', '장비 사기'], ['enh', '강화']];
      this.shopModes = modes.map((m) => m[0]);
      const seg = $('shop-modes');
      seg.innerHTML = modes.map(([m, label]) => `<button data-m="${m}" data-nonav>${label}</button>`).join('');
      for (const b of seg.querySelectorAll('button')) {
        b.addEventListener('click', () => {
          this.shopMode = b.dataset.m;
          this.game.audio.click();
          this.refreshShop(0);
        });
      }
      const k = (keys, label) => `<span>${keys.map((x) => `<kbd>${x}</kbd>`).join('')}${label}</span>`;
      $('menu-foot').innerHTML = k(['↑', '↓'], '고르기') + k(['Enter'], '선택') + k(['Q', 'E'], modes.map((m) => m[1]).join(' · ')) + k(['Tab'], '닫기');
      $('menu-foot').classList.remove('hidden');
      this.refreshShop(0);
    },

    shopStep(d) {
      const i = this.shopModes.indexOf(this.shopMode);
      this.shopMode = this.shopModes[(i + d + this.shopModes.length) % this.shopModes.length];
      this.game.audio.click();
      this.refreshShop(0);
    },

    _shopFlash(text, good) {
      const el = $('shop-flash');
      el.textContent = text;
      el.className = good ? 'good' : 'bad';
      el.style.animation = 'none';
      void el.offsetWidth;
      el.style.animation = '';
    },

    refreshShop(focusIndex) {
      const g = this.game;
      const s = g.save;
      const inv = g.inv;
      const mode = this.shopMode;
      for (const b of $('shop-modes').querySelectorAll('button')) b.classList.toggle('on', b.dataset.m === mode);
      $('shop-gold').innerHTML = mode === 'enh' ? `별가루 <b>${s.mats.dust}</b> · 별의 핵 <b>${s.mats.core}</b> · <b>${s.gold}</b> 골드` : `<b>${s.gold}</b> 골드`;
      const body = $('shop-body');
      body.innerHTML = '';
      const rows = [];
      // row: { html, btn, off (누를 수 없음), why (못 누르는 까닭), run(i) }
      const add = (o) => {
        const i = rows.length;
        const row = document.createElement('div');
        row.className = 'shop-item';
        row.setAttribute('data-nav', '');
        row.innerHTML = o.html;
        const b = document.createElement('button');
        b.setAttribute('data-nonav', '');
        b.textContent = o.btn;
        b.disabled = !!o.off;
        b.addEventListener('click', () => {
          if (!b.disabled) o.run(i, b);
        });
        row._act = {
          click: () => {
            if (b.disabled) this.toast(o.why || '지금은 할 수 없습니다.');
            else b.click();
          },
        };
        row.appendChild(b);
        body.appendChild(row);
        rows.push(row);
      };
      const info = (name, desc, it) =>
        `${it ? `<span class="cell r${it.r} mini">${icon(it.t)}${it.e > 0 ? `<i class="enh">+${it.e}</i>` : ''}</span>` : ''}<div class="info"><b${it ? ` style="color:${RARITY[it.r].css}"` : ''}>${esc(name)}</b><small>${desc}</small></div>`;
      const poor = '골드가 모자랍니다.';

      if (mode === 'buy') {
        const buy = (name, desc, price, fn, it) =>
          add({
            html: info(name, desc, it), btn: `${price} 골드`, off: s.gold < price, why: poor,
            run: (i) => {
              if (s.gold < price || fn() === false) return;
              g.saveSoon();
              this.refreshShop(i);
            },
          });
        const pay = (price, fn) => () => {
          s.gold -= price;
          fn();
          g.audio.coin();
        };
        if (this.shopKind === 'merchant') {
          buy(SHOP.berry.name, `${SHOP.berry.desc} · 보유 ${s.berries}개`, SHOP.berry.price, pay(SHOP.berry.price, () => s.berries++));
          buy(SHOP.arrows.name, `${SHOP.arrows.desc} · 보유 ${s.arrows}개`, SHOP.arrows.price, pay(SHOP.arrows.price, () => (s.arrows += 10)));
          // 물약
          for (const k of POTION_KEYS) {
            const d = POTIONS[k];
            buy(d.name, `${d.desc} · 보유 ${s.pots[k]}개`, d.price, () => {
              if (s.pots[k] >= POTION_CAP) {
                this.toast(`${d.name}은 ${POTION_CAP}개까지만 들 수 있습니다.`);
                return false;
              }
              s.gold -= d.price;
              s.pots[k]++;
              g.audio.coin();
            });
          }
          buy(SHOP.apple.name, `${SHOP.apple.desc} · 보유 ${s.apples}개`, SHOP.apple.price, pay(SHOP.apple.price, () => s.apples++));
          if (s.mount) add({ html: info('말 피리', '이미 갖고 있어요 — ' + (g.input.isTouch ? '탈것 버튼' : 'G 키') + '로 말을 부릅니다'), btn: '완료', off: true, why: '이미 갖고 있어요.' });
          else buy('말 피리', '말을 불러 타고 빠르게 달린다 (달리기 키로 더 빠르게)', MOUNT_PRICE, pay(MOUNT_PRICE, () => g.onMountBought()));
          const L = Math.max(1, Math.min(18, s.level));
          const bow = { t: 'bow', r: 0, l: L, e: 0 };
          const cur = s.eq.bow ? itemPower(s.eq.bow) : 0;
          buy(itemName(bow), `활 공격력 ${itemPower(bow)} (지금 ${cur}) · 사면 바로 착용`, itemValue(bow) * 4, () => inv.buy('bow', L, itemValue(bow) * 4), bow);
        } else {
          // 대장간: 내 레벨에 맞춘 기본 장비를 종류별로 판다
          const L = Math.max(1, Math.min(18, s.level));
          for (const t of [...WEAPON_KINDS, 'armor', 'helm']) {
            const it = { t, r: 0, l: L, e: 0 };
            const price = itemValue(it) * 4;
            const desc = WEAPONS[t] ? `${itemStatText(it)} · ${WEAPONS[t].desc}` : `${itemStatText(it)} · 사면 바로 착용`;
            buy(itemName(it), esc(desc), price, () => inv.buy(t, L, price), it);
          }
        }
      } else if (mode === 'sell') {
        const junk = inv.junk();
        if (junk.length) {
          const total = junk.reduce((a, it) => a + itemValue(it), 0);
          add({
            html: info('일반 등급 모두 팔기', `강화하지 않은 일반 등급 장비 ${junk.length}개`), btn: `${total} 골드`,
            run: () => {
              inv.sellJunk();
              this.refreshShop(0);
            },
          });
        }
        if (!s.inv.length) body.innerHTML = '<p class="it-desc" style="padding:8px 4px">팔 물건이 없습니다. 사냥해서 얻은 장비가 가방에 쌓이면 여기서 팔 수 있어요.</p>';
        for (const it of s.inv) {
          const v = itemValue(it);
          const up = inv.better(it) ? ' · <b class="up">▲ 지금 것보다 좋음</b>' : '';
          add({
            html: info(itemName(it), `${RARITY[it.r].name} · Lv.${it.l} · ${esc(itemStatText(it))}${up}`, it), btn: `${v} 골드`,
            run: (i, b) => {
              // 좋은 물건은 한 번 더 물어본다
              if ((it.r >= 2 || it.e > 0 || inv.better(it)) && b.dataset.sure !== '1') {
                b.dataset.sure = '1';
                b.textContent = '정말 팔기?';
                setTimeout(() => {
                  if (b.isConnected) {
                    delete b.dataset.sure;
                    b.textContent = `${v} 골드`;
                  }
                }, 2500);
                return;
              }
              inv.sell(it.id);
              this.refreshShop(i);
            },
          });
        }
      } else {
        // 강화: 착용한 것부터, 그다음 가방 안의 것
        const list = [];
        for (const slot of SLOTS) if (canEnhance(s.eq[slot])) list.push([s.eq[slot], true]);
        for (const it of s.inv) if (canEnhance(it)) list.push([it, false]);
        if (!list.length) body.innerHTML = '<p class="it-desc" style="padding:8px 4px">강화할 장비가 없습니다.</p>';
        for (const [it, eq] of list) {
          const c = enhanceCost(it);
          const pct = Math.round(enhanceChance(it) * 100);
          const lack = s.mats.dust < c.dust ? '별가루가 모자랍니다. 몬스터를 사냥하면 얻을 수 있어요.' : s.mats.core < c.core ? '별의 핵이 모자랍니다. 우두머리 몬스터나 수호자가 떨어뜨려요.' : s.gold < c.gold ? poor : '';
          const need = `별가루 ${c.dust}${c.core ? ` · 별의 핵 ${c.core}` : ''} · ${c.gold} 골드`;
          add({
            html: info(`${itemName(it)} → +${(it.e || 0) + 1}`, `${eq ? '<em>착용 중</em> · ' : ''}성공 ${pct}% · ${need}<br>${esc(itemStatText(it))} → ${esc(itemStatText({ ...it, e: (it.e || 0) + 1 }))}`, it),
            btn: '강화', off: !!lack, why: lack,
            run: (i) => {
              const res = inv.enhance(it.id);
              if (!res || res.lack) return;
              g.audio.anvil();
              if (res.ok) {
                g.audio.enhanceOk();
                this._shopFlash(`강화 성공!  +${it.e}`, true);
                if (res.equipped) g.onEnhanced(it);
              } else {
                g.audio.enhanceFail();
                this._shopFlash('강화 실패…  다음에는 성공 확률이 오릅니다', false);
              }
              this.refreshShop(i);
            },
          });
        }
      }
      if (focusIndex !== undefined) this.setFocus(rows[Math.min(focusIndex, rows.length - 1)] || null);
    },

    // ================= 친구와 교환 =================
    requestTrade(id) {
      const g = this.game;
      const e = g.ents.players.get(id);
      if (!e) return;
      this.closeAll();
      g.net.send({ t: 'tr', a: 'req', to: id });
      this.toast(`${e.prof.name} 님에게 교환을 신청했습니다. 수락을 기다리는 중…`);
    },

    answerTrade(accept) {
      const r = this.tradeReq;
      if (!r) return;
      this.tradeReq = null;
      $('trade-req').classList.add('hidden');
      this.game.net.send({ t: 'tr', a: accept ? 'acc' : 'dec', from: r.from });
    },

    onTradeMsg(m) {
      const g = this.game;
      const t = this.trade;
      switch (m.a) {
        case 'req':
          if (this.trade) {
            g.net.send({ t: 'tr', a: 'dec', from: m.from });
            return;
          }
          this.tradeReq = { from: m.from, name: m.name, t: 25 };
          $('trade-req-text').textContent = `${m.name} 님이 교환을 신청했습니다`;
          $('trade-req').classList.remove('hidden');
          g.audio.chat();
          break;
        case 'busy':
          this.toast(`${m.name} 님은 지금 다른 교환을 하고 있습니다.`);
          break;
        case 'dec':
          this.toast(`${m.name} 님이 교환을 거절했습니다.`);
          break;
        case 'open':
          this.openTrade(m.with, m.name);
          break;
        case 'offer':
          if (!t) return;
          t.theirs = { items: m.items || [], gold: m.gold || 0, ok: false, ver: m.ver | 0 };
          t.mine.ok = false;
          this.refreshTrade(this._tradeFocus());
          break;
        case 'ok':
          if (!t) return;
          t.theirs.ok = !!m.v;
          this.refreshTrade(this._tradeFocus());
          break;
        case 'done': {
          this.trade = null;
          g.inv.applyTrade(m.give, m.get);
          this.closeAll();
          g.audio.trade();
          this.toast('교환이 이루어졌습니다!', true);
          const got = m.get.items.map((it) => itemName(it));
          if (m.get.gold) got.push(`${m.get.gold} 골드`);
          this.chatAdd('', `${m.name} 님에게서 받은 것: ${got.length ? got.join(', ') : '없음'}`, 'sys');
          break;
        }
        case 'cancel':
          if (!t) return;
          this.trade = null;
          this.closeAll();
          this.toast(m.name ? `${m.name} 님이 교환을 취소했습니다.` : '교환이 취소되었습니다.');
          break;
        default:
      }
    },

    openTrade(id, name) {
      this.closeAll();
      const g = this.game;
      g.input.unlock();
      g.input.autoRun = false;
      this.tradeReq = null;
      $('trade-req').classList.add('hidden');
      this.trade = { with: id, name, mine: { items: [], gold: 0, ok: false }, theirs: { items: [], gold: 0, ok: false, ver: 0 } };
      $('panel-trade').classList.remove('hidden');
      $('trade-title').textContent = `${name} 님과 교환`;
      const k = (keys, label) => `<span>${keys.map((x) => `<kbd>${x}</kbd>`).join('')}${label}</span>`;
      $('menu-foot').innerHTML = k(['↑', '↓', '←', '→'], '고르기') + k(['Enter'], '올리기 · 내리기') + k(['Tab'], '취소');
      $('menu-foot').classList.remove('hidden');
      g.audio.trade();
      this.refreshTrade();
    },

    // 지금 고르고 있는 칸의 자리 (화면을 다시 그려도 그 자리에 머물도록)
    _tradeFocus() {
      const f = this.focusEl;
      if (!f || !f.classList || !f.classList.contains('cell') || !f.parentElement) return null;
      return { grid: f.parentElement.id, index: [...f.parentElement.querySelectorAll('button.cell')].indexOf(f) };
    },

    _tradeSend() {
      const t = this.trade;
      t.mine.ok = false;
      t.theirs.ok = false;
      this.game.net.send({ t: 'tr', a: 'offer', items: t.mine.items, gold: t.mine.gold });
    },

    // keep: 다시 그린 뒤 고를 칸 { grid: 칸이 들어 있는 묶음의 id, index: 몇 번째 }
    refreshTrade(keep) {
      const t = this.trade;
      if (!t) return;
      const g = this.game;
      const s = g.save;
      const offered = new Set(t.mine.items.map((q) => q.id));
      // 가방에서 없어진 물건은 올린 목록에서도 뺀다
      t.mine.items = t.mine.items.filter((q) => s.inv.some((v) => v.id === q.id));
      t.mine.gold = Math.min(t.mine.gold, s.gold);
      const show = (it) => {
        $('trade-detail').innerHTML = it ? this._itemInfo(it, false) : '';
      };
      const fill = (el, list, onClick, pad) => {
        el.innerHTML = '';
        list.forEach((it, i) => {
          const c = this._mkCell(it);
          c._onFocus = () => show(it);
          c.addEventListener('click', () => {
            show(it);
            if (onClick) onClick(it, i);
          });
          el.appendChild(c);
        });
        for (let i = list.length; i < pad; i++) {
          const e = document.createElement('div');
          e.className = 'cell empty';
          el.appendChild(e);
        }
      };
      fill($('trade-mine'), t.mine.items, (it, i) => {
        t.mine.items = t.mine.items.filter((q) => q.id !== it.id);
        this._tradeSend();
        this.refreshTrade({ grid: 'trade-mine', index: i });
      }, TRADE_MAX);
      fill($('trade-theirs'), t.theirs.items, null, TRADE_MAX);
      fill($('trade-inv'), s.inv.filter((q) => !offered.has(q.id)), (it, i) => {
        if (t.mine.items.length >= TRADE_MAX) {
          this.toast(`한 번에 ${TRADE_MAX}개까지만 올릴 수 있습니다.`);
          return;
        }
        t.mine.items.push(it);
        this._tradeSend();
        this.refreshTrade({ grid: 'trade-inv', index: i });
      }, 0);
      $('trade-my-gold').textContent = t.mine.gold;
      $('trade-their-gold').textContent = t.theirs.gold;
      $('trade-my-ok').textContent = t.mine.ok ? '✓ 확인했습니다' : '확인 전';
      $('trade-my-ok').classList.toggle('on', t.mine.ok);
      $('trade-their-ok').textContent = t.theirs.ok ? '✓ 상대가 확인했습니다' : '상대가 고르는 중…';
      $('trade-their-ok').classList.toggle('on', t.theirs.ok);
      const room = s.inv.length - t.mine.items.length + t.theirs.items.length <= INV_CAP;
      const ok = $('trade-ok');
      ok.disabled = !room;
      ok.textContent = !room ? '가방 자리가 모자랍니다' : t.mine.ok ? '확인 취소' : '이대로 교환 (확인)';
      // 고르던 자리를 유지한다 (올리거나 내린 뒤에는 같은 자리의 다음 물건)
      const box = $('panel-trade');
      let cell = null;
      if (keep) {
        const cells = $(keep.grid).querySelectorAll('button.cell');
        cell = cells[Math.min(keep.index, cells.length - 1)] || null;
      }
      const f = this.focusEl && box.contains(this.focusEl) && this.focusEl.isConnected ? this.focusEl : null;
      this.setFocus(cell || f || $('trade-inv').querySelector('button.cell') || $('trade-mine').querySelector('button.cell') || ok, false);
    },

    _bindTrade() {
      const g = this.game;
      for (const b of document.querySelectorAll('#trade-gold-btns [data-d]')) {
        b.addEventListener('click', () => {
          const t = this.trade;
          if (!t) return;
          const v = Math.max(0, Math.min(g.save.gold, t.mine.gold + +b.dataset.d));
          if (v === t.mine.gold) return;
          t.mine.gold = v;
          this._tradeSend();
          this.refreshTrade(this._tradeFocus());
        });
      }
      $('trade-ok').addEventListener('click', () => {
        const t = this.trade;
        if (!t) return;
        t.mine.ok = !t.mine.ok;
        g.net.send({ t: 'tr', a: 'ok', v: t.mine.ok ? 1 : 0, seen: t.theirs.ver });
        g.audio.click();
        this.refreshTrade(this._tradeFocus());
      });
      $('trade-cancel').addEventListener('click', () => this.closeAll());
      for (const b of document.querySelectorAll('#trade-req [data-a]')) b.addEventListener('click', () => this.answerTrade(b.dataset.a === 'acc'));
    },
  });
}

// 실내 구역: 별의 시련장과 던전. 서버와 클라이언트가 함께 쓴다.
// 구역은 세계 북쪽 바깥(z < ZONE_Z)의 평평한 바닥 위에 따로 놓여 있고, 입구를 통해서만 드나든다.
// 지도는 글자 그림으로 그린다 (한 글자 = 한 칸, 한 칸 = TILE 미터):
//   #  벽            .  바닥           (빈칸) 아무것도 없음
//   S  들어오는 곳    E  나가는 문       R  시련의 제단(보상)    C  보물상자
//   1~9 관문 (같은 번호의 무리가 모두 쓰러지면 열린다. 퍼즐 관문은 퍼즐을 풀면 열린다)
//   o  화로(불빛)     p  발판(순서 퍼즐)  f F  불기둥 함정 (서로 엇박)
//   a~n 몬스터 (구역마다 sym 표에서 종류·무리·우두머리 여부를 정한다)   B  보스
import { ZONE_Z, ZONE_FLOOR } from './world.js';

export const TILE = 3;
export const WALL_H = 4.4;
export { ZONE_FLOOR };

// ---------- 시련장 그림 ----------
const COMBAT = [
  '#############',
  '#.....S.....#',
  '#...........#',
  '#o.........o#',
  '######.######',
  '#...........#',
  '#..a.....a..#',
  '#.b...a...b.#',
  '#..a.....a..#',
  '#o.........o#',
  '######1######',
  '#...........#',
  '#..c.....c..#',
  '#.....d.....#',
  '#..c.....c..#',
  '#o.........o#',
  '######2######',
  '#...........#',
  '#.g.......g.#',
  '#.....e.....#',
  '#...........#',
  '#o.........o#',
  '######3######',
  '#..o.....o..#',
  '#.....R.....#',
  '#############',
];
const ORDER4 = [
  '###########',
  '#....S....#',
  '#.........#',
  '#.p..o..p.#',
  '#.........#',
  '#.p.....p.#',
  '#.........#',
  '#####1#####',
  '#.o.....o.#',
  '#....R....#',
  '###########',
];
const ORDER5 = [
  '###########',
  '#....S....#',
  '#.........#',
  '#.p.....p.#',
  '#....p....#',
  '#.p.....p.#',
  '#.........#',
  '#o.......o#',
  '#####1#####',
  '#.o.....o.#',
  '#....R....#',
  '###########',
];
const ORDER6 = [
  '#############',
  '#.....S.....#',
  '#...........#',
  '#.p...p...p.#',
  '#...........#',
  '#.p...p...p.#',
  '#...........#',
  '#o.........o#',
  '######1######',
  '#..o.....o..#',
  '#.....R.....#',
  '#############',
];
const TRAP1 = [
  '#########',
  '#...S...#',
  '#.......#',
  '#o.....o#',
  '#f.f.f.f#',
  '#.......#',
  '#.F.F.F.#',
  '#.......#',
  '#fffffff#',
  '#.......#',
  '#FFFFFFF#',
  '#.......#',
  '#f.F.f.F#',
  '#F.f.F.f#',
  '#.......#',
  '#fffffff#',
  '#FFFFFFF#',
  '#.......#',
  '#..a.a..#',
  '#.......#',
  '###111###',
  '#.o...o.#',
  '#...R...#',
  '#########',
];
const TRAP2 = [
  '#########',
  '#...S...#',
  '#.......#',
  '#o.....o#',
  '#fffffff#',
  '#.......#',
  '#FFFFFFF#',
  '#fffffff#',
  '#.......#',
  '#F.f.F.f#',
  '#f.F.f.F#',
  '#F.f.F.f#',
  '#.......#',
  '#..a.a..#',
  '#fffffff#',
  '#FFFFFFF#',
  '#.......#',
  '#fFfFfFf#',
  '#FfFfFfF#',
  '#.......#',
  '#.b...b.#',
  '#.......#',
  '###111###',
  '#.o...o.#',
  '#...R...#',
  '#########',
];
const TRAP3 = [
  '###########',
  '#....S....#',
  '#.........#',
  '#o.......o#',
  '#fFfFfFfFf#',
  '#FfFfFfFfF#',
  '#.........#',
  '#fffffffff#',
  '#FFFFFFFFF#',
  '#.........#',
  '#.a.....a.#',
  '#FFFFFFFFF#',
  '#fffffffff#',
  '#FFFFFFFFF#',
  '#.........#',
  '#f.F.f.F.f#',
  '#F.f.F.f.F#',
  '#f.F.f.F.f#',
  '#.........#',
  '#fffffffff#',
  '#FFFFFFFFF#',
  '#.........#',
  '#..c.b.c..#',
  '#.........#',
  '####111####',
  '#.o.....o.#',
  '#....R....#',
  '###########',
];

// ---------- 던전 그림 ----------
const SEWER = [
  '###########################',
  '#.......#.........#.......#',
  '#...S...#.a.....a.#..c.c..#',
  '#.......#....b....#.......#',
  '#.......#.a.....a.1...e...#',
  '#.......#....b....#.......#',
  '#o.....o#.........#..c.c..#',
  '###...###o.......o####2####',
  '  #...#######.#####.......#',
  '  #...........#   #fFfFfFf#',
  '  #...........#   #.......#',
  '  #############   #FfFfFfF#',
  '                  #.......#',
  '                  #fffffff#',
  '                  #.......#',
  '          #########...o...#',
  '          #...............#',
  '          #.g...g.#########',
  '          #...h...#        ',
  '          #.g...g.#        ',
  '          #.......#        ',
  '        ######3######      ',
  '        #...........#      ',
  '        #.m.......m.#      ',
  '        #.....B.....#      ',
  '        #.m.......m.#      ',
  '        #.o.......o.#      ',
  '        ######4######      ',
  '          #...C...#        ',
  '          #.o.E.o.#        ',
  '          #########        ',
];
const VAULT = [
  '      #########                ',
  '      #.......#                ',
  '      #...S...#                ',
  '      #.......#                ',
  '      #.o...o.#                ',
  '      ###...###                ',
  '#########...###################',
  '#.............#...............#',
  '#..a...b...a..1..c....d....c..#',
  '#.............#...............#',
  '#..a...b...a..#..c....e....c..#',
  '#.....o.......#.......o.......#',
  '###############.......#########',
  '              ####2####        ',
  '              #fFfFfFf#        ',
  '              #FfFfFfF#        ',
  '              #.......#        ',
  '              #fffffff#        ',
  '              #FFFFFFF#        ',
  '              #fffffff#        ',
  '              #.......#        ',
  '    ###########...o...#        ',
  '    #.................#        ',
  '    #.g.......g.#######        ',
  '    #.....h.....#              ',
  '    #.g.......g.#              ',
  '    #.....i.....#              ',
  '    #.o.......o.#              ',
  '   #######3#######             ',
  '   #.............#             ',
  '   #.m....B....m.#             ',
  '   #.............#             ',
  '   #.m.........m.#             ',
  '   #.o.........o.#             ',
  '   #######4#######             ',
  '      #...C...#                ',
  '      #.o.E.o.#                ',
  '      #########                ',
];
const TOMB = [
  '            #########            ',
  '            #.......#            ',
  '            #...S...#            ',
  '            #.o...o.#            ',
  '            ###...###            ',
  '   ############...############   ',
  '   #.........................#   ',
  '   #..a...a.....b.....a...a..#   ',
  '   #.........................#   ',
  '   #.....b.......o.......b...#   ',
  '   ####1###############1######   ',
  '   #......#           #......#   ',
  '   #.c..c.#           #.d..d.#   ',
  '   #......#           #......#   ',
  '   #..e...#           #...e..#   ',
  '   #......#           #......#   ',
  '   ###2####           ####2###   ',
  '   #fFfFf#             #fFfFf#   ',
  '   #FfFfF#             #FfFfF#   ',
  '   #.....#             #.....#   ',
  '   #fffff#             #FFFFF#   ',
  '   #FFFFF#             #fffff#   ',
  '   #.....###############.....#   ',
  '   #.........................#   ',
  '   #..g....g....h....g....g..#   ',
  '   #.........................#   ',
  '   #.....i.......o.......i...#   ',
  '   ############3##############   ',
  '          #.............#        ',
  '          #.m.........m.#        ',
  '          #......B......#        ',
  '          #.m.........m.#        ',
  '          #.............#        ',
  '          #.o.........o.#        ',
  '          #######4#######        ',
  '             #...C...#           ',
  '             #.o.E.o.#           ',
  '             #########           ',
];

// 몬스터 표: 글자 -> [종류, 무리(관문 번호), 우두머리(1) 또는 시련의 수호자(2: 우두머리이면서 레벨이 2 높다)]
const M = (t, g, e = 0) => ({ t, g, e });

// 구역 정의. theme: 몬스터 색과 벽 빛깔에 쓰는 지역 번호, level: 몬스터 레벨, anchor: 입구를 놓을 곳(월드 좌표 근처)
const DEFS = [
  // ---- 별의 시련장 12곳 ----
  { key: 't1', kind: 'trial', type: 'combat', name: '새벽의 시련장', sub: '힘의 시련', level: 2, theme: 0, anchor: [-150, 130], map: COMBAT, sym: { a: M('slime', 1), b: M('goblin', 1), c: M('goblin', 2), d: M('thrower', 2), e: M('slime', 3, 2), g: M('slime', 3) } },
  { key: 't2', kind: 'trial', type: 'order', name: '속삭임의 시련장', sub: '지혜의 시련', level: 3, theme: 1, anchor: [330, 250], map: ORDER4, puzzle: { gate: 1, len: 6, slot: 0.7 } },
  { key: 't3', kind: 'trial', type: 'trap', name: '단풍의 시련장', sub: '용기의 시련', level: 4, theme: 6, anchor: [-560, 40], map: TRAP1, sym: { a: M('wolf', 1) } },
  { key: 't4', kind: 'trial', type: 'combat', name: '모래의 시련장', sub: '힘의 시련', level: 7, theme: 3, anchor: [230, 420], map: COMBAT, sym: { a: M('scorpion', 1), b: M('thrower', 1), c: M('goblin', 2), d: M('scorpion', 2, 1), e: M('scorpion', 3, 2), g: M('thrower', 3) } },
  { key: 't5', kind: 'trial', type: 'order', name: '안개의 시련장', sub: '지혜의 시련', level: 7, theme: 4, anchor: [-250, 400], map: ORDER5, puzzle: { gate: 1, len: 7, slot: 0.62 } },
  { key: 't6', kind: 'trial', type: 'trap', name: '서리의 시련장', sub: '용기의 시련', level: 9, theme: 2, anchor: [-290, -330], map: TRAP2, sym: { a: M('thrower', 1), b: M('wolf', 1) } },
  { key: 't7', kind: 'trial', type: 'combat', name: '잿불의 시련장', sub: '힘의 시련', level: 12, theme: 5, anchor: [250, -180], map: COMBAT, sym: { a: M('imp', 1), b: M('goblin', 1), c: M('wolf', 2), d: M('imp', 2, 1), e: M('yeti', 3, 2), g: M('imp', 3) } },
  { key: 't8', kind: 'trial', type: 'order', name: '호숫가의 시련장', sub: '지혜의 시련', level: 5, theme: 0, anchor: [120, -150], map: ORDER5, puzzle: { gate: 1, len: 8, slot: 0.66 } },
  { key: 't9', kind: 'trial', type: 'combat', name: '꽃잎의 시련장', sub: '힘의 시련', level: 14, theme: 7, anchor: [905, 760], map: COMBAT, sym: { a: M('wolf', 1), b: M('thrower', 1), c: M('goblin', 2), d: M('wolf', 2, 1), e: M('goblin', 3, 2), g: M('thrower', 3) } },
  { key: 't10', kind: 'trial', type: 'order', name: '포자의 시련장', sub: '지혜의 시련', level: 16, theme: 8, anchor: [-760, 905], map: ORDER6, puzzle: { gate: 1, len: 10, slot: 0.56 } },
  { key: 't11', kind: 'trial', type: 'trap', name: '수정의 시련장', sub: '용기의 시련', level: 18, theme: 9, anchor: [-905, -760], map: TRAP3, sym: { a: M('imp', 1), b: M('thrower', 1, 1), c: M('yeti', 1) } },
  { key: 't12', kind: 'trial', type: 'combat', name: '그림자의 시련장', sub: '힘의 시련', level: 21, theme: 10, anchor: [760, -905], map: COMBAT, sym: { a: M('imp', 1), b: M('yeti', 1), c: M('wolf', 2), d: M('yeti', 2, 1), e: M('golem', 3), g: M('imp', 3) } },
  // ---- 숨겨진 던전 3곳 (lamps: 입구를 드러내려면 밝혀야 하는 돌등의 수) ----
  {
    key: 'd1', kind: 'dungeon', name: '잊힌 수로', sub: '숨겨진 던전', level: 14, theme: 4, anchor: [-616, 224], lamps: 3, night: false, map: SEWER,
    sym: { a: M('slime', 1), b: M('thrower', 1), c: M('goblin', 2), e: M('goblin', 2, 1), g: M('imp', 3), h: M('scorpion', 3, 1), m: M('slime', 4), B: M('kingslime', 4) },
  },
  {
    key: 'd2', kind: 'dungeon', name: '얼어붙은 금고', sub: '숨겨진 던전', level: 20, theme: 2, anchor: [80, -620], lamps: 4, night: false, map: VAULT,
    sym: { a: M('wolf', 1), b: M('thrower', 1, 1), c: M('yeti', 2), d: M('imp', 2), e: M('yeti', 2, 1), g: M('wolf', 3), h: M('yeti', 3, 1), i: M('imp', 3, 1), m: M('wolf', 4), B: M('tyrant', 4) },
  },
  {
    key: 'd3', kind: 'dungeon', name: '별무덤', sub: '숨겨진 던전', level: 26, theme: 10, anchor: [1010, -990], lamps: 5, night: true, map: TOMB,
    sym: { a: M('imp', 1), b: M('thrower', 1, 1), c: M('wolf', 2), d: M('yeti', 2), e: M('imp', 2, 1), g: M('yeti', 3), h: M('golem', 3), i: M('wolf', 3, 1), m: M('imp', 4), B: M('knight', 4) },
  },
];

function parse(def, index) {
  const rows = def.map;
  const tileH = rows.length;
  const tileW = rows[0].length;
  for (const r of rows) if (r.length !== tileW) throw new Error(`zone ${def.key}: 줄 길이가 다릅니다 (${r})`);
  // 시련장은 한 줄로, 던전은 그 뒤쪽 줄에 놓는다
  let cx;
  let cz;
  if (def.kind === 'trial') {
    cx = -660 + index * 120;
    cz = ZONE_Z - 110;
  } else {
    cx = (index - 13) * 500;
    cz = ZONE_Z - 280;
  }
  const ox = cx - (tileW * TILE) / 2;
  const oz = cz - (tileH * TILE) / 2;
  const z = {
    id: index + 1, key: def.key, kind: def.kind, type: def.type || 'dungeon', name: def.name, sub: def.sub, level: def.level, theme: def.theme,
    anchor: def.anchor, lamps: def.lamps || 0, night: !!def.night, puzzle: def.puzzle || null,
    rows, tileW, tileH, ox, oz, x0: ox, z0: oz, x1: ox + tileW * TILE, z1: oz + tileH * TILE,
    start: null, exit: null, altar: null, chests: [], torches: [], plates: [], flames: [], gates: [], spawns: [], ngates: 0,
  };
  const gateMap = new Map();
  for (let r = 0; r < tileH; r++) {
    for (let c = 0; c < tileW; c++) {
      const ch = rows[r][c];
      if (ch === '#' || ch === '.' || ch === ' ') continue;
      const x = ox + (c + 0.5) * TILE;
      const zz = oz + (r + 0.5) * TILE;
      if (ch === 'S') z.start = { x, z: zz };
      else if (ch === 'E') z.exit = { x, z: zz };
      else if (ch === 'R') z.altar = { x, z: zz };
      else if (ch === 'C') z.chests.push({ x, z: zz });
      else if (ch === 'o') z.torches.push({ x, z: zz });
      else if (ch === 'p') z.plates.push({ x, z: zz, i: z.plates.length });
      else if (ch === 'f' || ch === 'F') z.flames.push({ x, z: zz, phase: ch === 'F' ? 0.5 : 0 });
      else if (ch >= '1' && ch <= '9') {
        // 같은 번호가 가로나 세로로 이어져 있으면 하나의 문으로 본다
        const n = +ch;
        let g = (rows[r][c - 1] === ch && gateMap.get(r + ',' + (c - 1))) || (r > 0 && rows[r - 1][c] === ch && gateMap.get(r - 1 + ',' + c)) || null;
        if (!g) {
          // horiz: 벽이 가로(x 방향)로 뻗어 있고 문을 남북으로 지나간다
          g = { n, tiles: [], horiz: rows[r][c - 1] === '#' || rows[r][c + 1] === '#' || rows[r][c + 1] === ch, x: 0, z: 0 };
          z.gates.push(g);
        }
        gateMap.set(r + ',' + c, g);
        g.tiles.push({ x, z: zz });
        if (n > z.ngates) z.ngates = n;
      } else {
        const s = def.sym && def.sym[ch];
        if (!s) throw new Error(`zone ${def.key}: 알 수 없는 글자 '${ch}'`);
        const boss = ch === 'B';
        z.spawns.push({ type: s.t, level: def.level + (boss ? 2 : s.e || 0), x, z: zz, group: s.g, elite: s.e ? 1 : 0, boss: boss ? 1 : 0, minion: ch === 'm' ? 1 : 0 });
      }
    }
  }
  for (const g of z.gates) {
    g.x = g.tiles.reduce((a, t) => a + t.x, 0) / g.tiles.length;
    g.z = g.tiles.reduce((a, t) => a + t.z, 0) / g.tiles.length;
  }
  if (!z.start) throw new Error(`zone ${def.key}: 시작 지점(S)이 없습니다`);
  return z;
}

export const ZONES = DEFS.map(parse);
export const TRIAL_COUNT = ZONES.filter((z) => z.kind === 'trial').length;

// 불기둥 함정: 주기 FLAME_PERIOD 초 가운데 FLAME_ON 초 동안 타오른다. 켜지기 FLAME_WARN 초 전부터 불씨가 인다.
export const FLAME_PERIOD = 2.4;
export const FLAME_ON = 1.1;
export const FLAME_WARN = 0.5;
// 지금 불기둥의 상태: 0 = 꺼짐, 0~1 사이 = 곧 켜짐(예고), 1 = 타오르는 중.  timeSec: 서버 시각(초)
export function flameState(flame, timeSec) {
  const t = (((timeSec / FLAME_PERIOD + flame.phase) % 1) + 1) % 1 * FLAME_PERIOD;
  if (t < FLAME_ON) return 1;
  if (t > FLAME_PERIOD - FLAME_WARN) return (t - (FLAME_PERIOD - FLAME_WARN)) / FLAME_WARN * 0.99;
  return 0;
}

// 좌표가 속한 구역 (없으면 null)
let last = null;
export function zoneAt(x, z) {
  if (z >= ZONE_Z) return null;
  if (last && x >= last.x0 - 4 && x <= last.x1 + 4 && z >= last.z0 - 4 && z <= last.z1 + 4) return last;
  for (const q of ZONES) {
    if (x >= q.x0 - 4 && x <= q.x1 + 4 && z >= q.z0 - 4 && z <= q.z1 + 4) {
      last = q;
      return q;
    }
  }
  return null;
}
export function zoneIdAt(x, z) {
  const q = zoneAt(x, z);
  return q ? q.id : 0;
}

// 그 칸이 막혀 있는지 (벽, 빈 곳, 닫힌 관문). open: 열린 관문의 비트 묶음
export function tileSolid(zone, c, r, open) {
  if (c < 0 || r < 0 || c >= zone.tileW || r >= zone.tileH) return true;
  const ch = zone.rows[r].charCodeAt(c);
  if (ch === 35 || ch === 32) return true; // '#', ' '
  if (ch >= 49 && ch <= 57) return !((open >> (ch - 48)) & 1); // '1'~'9'
  return false;
}
export function zoneSolid(zone, x, z, open) {
  return tileSolid(zone, Math.floor((x - zone.ox) / TILE), Math.floor((z - zone.oz) / TILE), open);
}
// 두 점 사이가 벽에 가려지지 않았는지 (화살, 조준, 시야)
export function zoneClearLine(zone, x0, z0, x1, z1, open) {
  const dx = x1 - x0;
  const dz = z1 - z0;
  const n = Math.max(1, Math.ceil(Math.hypot(dx, dz) / 0.75));
  for (let i = 1; i < n; i++) {
    const k = i / n;
    if (zoneSolid(zone, x0 + dx * k, z0 + dz * k, open)) return false;
  }
  return true;
}
// 반지름 rad 인 원이 벽에 닿는지
export function zoneBlocked(zone, x, z, rad, open) {
  return zoneSolid(zone, x - rad, z - rad, open) || zoneSolid(zone, x + rad, z - rad, open) || zoneSolid(zone, x - rad, z + rad, open) || zoneSolid(zone, x + rad, z + rad, open);
}
// 화로(받침대 위의 불)는 가운데만 막는 작은 장애물이다
export const TORCH_R = 0.55;
export function zoneTorchHit(zone, x, z, rad) {
  const rr = (TORCH_R + rad) * (TORCH_R + rad);
  for (const t of zone.torches) {
    const dx = x - t.x;
    const dz = z - t.z;
    if (dx * dx + dz * dz < rr) return true;
  }
  return false;
}

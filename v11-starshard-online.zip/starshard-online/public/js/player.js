// 내 캐릭터: 이동(달리기·점프·활공·수영·등반), 전투, 카메라
import * as THREE from '/vendor/three/three.module.js';
import {
  ANIM, BERRY_HEAL, MAX_LEVEL, SEND_MS, TUNIC_COLORS, WEAPONS, RARITY, xpNeed, gearStats, enhGlow,
  MOUNTS, MOUNT_KEYS, POTIONS, POTION_KEYS, UNIQUES, GUARD_MULT, SWIFT_ADD, HP_SHOW,
} from '/shared/defs.js';
import { W, BIOME } from '/shared/world.js';
import { encodeState } from '/shared/proto.js';
import { makeHumanoid, animateHumanoid, playerLook, setWeapon, makeHorse, animateHorse, attackProgress, slopePitch, seatRider } from './models.js';
import { ZONE_FLOOR, WALL_H, zoneSolid } from '/shared/zones.js';
import { cleanJob, WARD_MULT } from '/shared/jobs.js';

const GRAV = 28;
const JUMP_V = 9.8;
const RUN = 6.6;
const SPRINT = 10.4;
const SWIM_Y = -0.95;
const STEEP = 2.0; // 이보다 가파르면(거의 절벽) 기어오른다
const ROLL_DUR = 0.46;
const ROLL_COST = 16;
const WATER_RUN = -0.12; // 물 위를 달리는 탈것의 발굽 높이
const ATK_ANIM = [ANIM.ATK1, ANIM.ATK2, ANIM.ATK3, ANIM.THRUST];
const TAU = Math.PI * 2;

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
function angDiff(a, b) {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}
const _grad = { x: 0, z: 0 };
const _v = new THREE.Vector3();

export class Player {
  constructor(game) {
    this.game = game;
    this.pos = new THREE.Vector3();
    this.vel = new THREE.Vector3();
    this.yaw = Math.PI;
    this.camYaw = Math.PI;
    this.camPitch = 0.3;
    this.camDist = 7.5;
    this.camCur = 7.5;
    this.camTarget = new THREE.Vector3();
    this.shake = 0;
    this.state = 'ground';
    this.anim = ANIM.IDLE;
    this.action = null;
    this.comboK = -1;
    this.comboT = 0;
    this.queued = false;
    this.atkCd = 0;
    this.bowCd = 0;
    this.healCd = 0;
    this.invuln = 0;
    this.hurtT = 0;
    this.deadT = 0;
    this.airT = 0;
    this.groundH = 0;
    this.stamina = 100;
    this.maxStamina = 100;
    this.staminaDelay = 0;
    this.exhausted = false;
    this.sprinting = false;
    this.hp = 6;
    this.maxHp = 6;
    this.lastSafe = new THREE.Vector3();
    this.safeT = 0;
    this.sendT = 0;
    this.restT = 0;
    this.resting = false;
    this.speedNow = 0;
    this.stepT = 0;
    this.lock = null; // 주목하고 있는 몬스터
    this.rollInv = 0; // 구르는 동안의 무적 시간
    this.rollCd = 0;
    this.mounted = false; // 탈것을 타고 있는지
    this.mountPitch = 0; // 탈것이 선 땅의 기울기
    this.mountCd = 0;
    this.horse = null;
    this.kick = 0; // 타격 순간 시점이 살짝 당겨지는 정도
    this.glowT = 0;
    this.md = MOUNTS.horse; // 지금 타는 탈것의 능력
    this.tameKind = null; // 길들이기 시험 중에 올라탄 야생마의 종류
    this.taming = null; // 시험 중인 말의 몸짓 { pitch, hop, roll } (mounts.js 가 채운다)
    this.buffs = { sta: 0, power: 0, guard: 0, swift: 0, ward: 0, hide: 0 }; // 물약과 기술의 효과가 남은 시간(초). ward: 수호의 함성, hide: 연막
    this.skillInv = 0; // 기술을 쓰는 동안의 무적 시간 (돌진 · 그림자 걸음 · 난무)
    this.skillQ = -1; // 다른 동작 도중에 눌러 둔 기술 (끝나자마자 쓴다)
    this.skillQT = 0;
    this.camAnchor = null; // 시점이 잠깐 머무는 자리 (달그림자 난무로 옮겨 다니는 동안)
    this.camAnchorT = 0;
    this.potCd = 0;
    this.leech = 0;
    this.trailT = 0;
    this.gutsCd = 0; // 「불굴」을 다시 쓸 수 있을 때까지 남은 시간
    this.chill = 0; // 결투에서 서리송곳에 맞아 느려진 시간
    this.rig = null;
    this.buildRig();
    this.refreshStats();
    this.hp = clamp(game.save.hp || this.maxHp, 1, this.maxHp);
    this.stamina = this.maxStamina;
  }

  buildRig() {
    const scene = this.game.gfx.scene;
    if (this.rig) scene.remove(this.rig.root);
    this.rig = makeHumanoid(playerLook(this.game.save));
    scene.add(this.rig.root);
    this.buildHorse();
    if (!this.blob && this.game.fx) {
      this.blob = this.game.fx.makeBlob(0.55);
      scene.add(this.blob);
    }
  }

  // 지금 고른 탈것 (갖고 있지 않은 것이 골라져 있으면 보통 말)
  mountKind() {
    const s = this.game.save;
    if (this.tameKind) return this.tameKind;
    if (s.mountKind !== 'horse' && s.mounts.includes(s.mountKind)) return s.mountKind;
    return !s.mount && s.mounts.length ? s.mounts[0] : 'horse';
  }

  hasMount() {
    const s = this.game.save;
    return s.mount || s.mounts.length > 0;
  }

  // 탈것 모델 (탈 때만 보인다)
  buildHorse() {
    const g = this.game;
    const scene = g.gfx.scene;
    if (this.horse) {
      scene.remove(this.horse.root);
      this.horse.root.traverse((o) => o.geometry && o.geometry.dispose());
    }
    const kind = this.mountKind();
    this.md = MOUNTS[kind];
    this.horse = makeHorse(g.save.mountColor, TUNIC_COLORS[g.save.tunic % TUNIC_COLORS.length], kind);
    this.horse.root.visible = this.mounted;
    scene.add(this.horse.root);
  }

  // 탈것 바꾸기
  setMountKind(kind) {
    const g = this.game;
    const s = g.save;
    if (kind !== 'horse' && !s.mounts.includes(kind)) return;
    if (kind === 'horse' && !s.mount) return;
    s.mountKind = kind;
    if (this.mounted) this.setMounted(false);
    this.buildHorse();
    g.net.send({ t: 'prof', prof: this.profile() });
    g.saveSoon();
  }

  // 시련 보상으로 늘어난 체력·기력
  bonus() {
    const s = this.game.save;
    return { hp: s.bonusHp || 0, sta: s.bonusSta || 0 };
  }

  // 레벨과 착용 장비로 능력치를 다시 계산한다
  refreshStats() {
    const s = this.game.save;
    const st = gearStats(s.level, s.eq, this.bonus(), cleanJob(s.job, s.level));
    this.cdK = st.cdK; // 직업의 숨은 힘: 기술을 다시 쓰기까지의 시간
    this.critMul = st.critMul;
    this.maxHp = st.maxHp;
    this.maxStamina = st.maxStamina;
    this.atk = st.atk;
    this.bowAtk = st.bowAtk;
    this.def = st.def;
    this.crit = st.crit;
    this.luck = st.luck;
    this.swift = st.swift;
    // 레벨 능력 (다섯 레벨마다 하나씩)
    this.rollCostK = st.rollCost;
    this.takenK = st.taken;
    this.regenK = st.regen;
    this.guts = st.guts;
    this.wkind = st.kind;
    this.wpn = WEAPONS[st.kind];
    this.fx = st.fx; // 히든 무기의 고유한 힘
    this.bowFx = st.bowFx;
    const w = s.eq.weapon;
    const uq = w && w.u ? UNIQUES[w.u] : null;
    // 베기 궤적 색: 히든 무기의 빛 > 강화 빛 > 등급 색 > 흰색
    this.wcolor = uq ? uq.color : w ? enhGlow(w.e || 0) || (w.r >= 1 ? RARITY[w.r].color : 0xffffff) : 0xffffff;
    this.wenh = w ? w.e || 0 : 0;
    this.wuq = !!uq;
    if (this.hp > this.maxHp) this.hp = this.maxHp;
    if (this.stamina > this.maxStamina) this.stamina = this.maxStamina;
  }

  profile() {
    const s = this.game.save;
    const b = this.bonus();
    return { name: s.name, tunic: s.tunic, hair: s.hair, lvl: s.level, eq: s.eq, mc: s.mountColor, mk: MOUNT_KEYS.indexOf(this.mountKind()), pv: s.settings.pvp ? 1 : 0, bh: b.hp, bs: b.sta, sp: s.sprite ? 1 : 0, rw: s.raidWins || 0, jc: (s.job && s.job.c) | 0, jt: (s.job && s.job.t) | 0 };
  }

  teleport(x, z, yaw) {
    const h = this.game.world.heightAt(x, z);
    this.pos.set(x, Math.max(h, SWIM_Y), z);
    this.vel.set(0, 0, 0);
    this.state = 'ground';
    this.action = null;
    this.setMounted(false);
    if (yaw !== undefined) {
      this.yaw = yaw;
      this.camYaw = yaw;
    }
    this.lock = null;
    this.camAnchorT = 0;
    this.game.input.autoRun = false;
    this.lastSafe.copy(this.pos);
    this.camTarget.set(x, this.pos.y + 1.45, z);
  }

  useStamina(n) {
    if (this.buffs.sta > 0) return; // 기력 물약: 한동안 닳지 않는다
    this.stamina -= n;
    this.staminaDelay = 0.8;
    if (this.stamina <= 0) {
      this.stamina = 0;
      this.exhausted = true;
    }
  }

  addXp(n) {
    const s = this.game.save;
    if (s.level >= MAX_LEVEL) return;
    s.xp += n;
    const from = s.level;
    const was = { atk: this.atk, bowAtk: this.bowAtk, maxHp: this.maxHp, maxStamina: this.maxStamina, def: this.def };
    while (s.level < MAX_LEVEL && s.xp >= xpNeed(s.level)) {
      s.xp -= xpNeed(s.level);
      s.level++;
    }
    if (s.level >= MAX_LEVEL) s.xp = 0;
    if (s.level > from) {
      this.refreshStats();
      this.hp = this.maxHp;
      this.stamina = this.maxStamina;
      this.exhausted = false;
      this.game.onLevelUp(from, was);
    }
  }

  heal(n) {
    this.hp = Math.min(this.maxHp, this.hp + n);
  }

  // 피해를 받는다. 실제로 맞았으면 true
  damage(amount, fromX, fromZ, opts = {}) {
    if (this.state === 'dead' || (this.invuln > 0 && !opts.force)) return false;
    if (this.skillInv > 0 && !opts.force) return false; // 기술로 내달리거나 옮겨 다니는 동안에는 맞지 않는다
    if (this.rollInv > 0 && !opts.force) {
      // 구르기로 피했다
      if (!this.dodged) {
        this.dodged = true;
        this.game.fx.text(this.pos.x, this.pos.y + 2.1, this.pos.z, '회피!', 'heal');
        this.stamina = Math.min(this.maxStamina, this.stamina + 8);
        this.game.jobs.on('dodge'); // 전직 시험: 구르기로 피하기
      }
      return false;
    }
    // pct: 레이드의 공격 — 이미 내 체력의 비율로 셈해진 피해라 갑옷으로 줄지 않는다 (물약과 레벨 능력은 듣는다)
    let dmg = opts.raw || opts.pct ? amount : Math.max(1, amount - this.def);
    if (!opts.raw && this.takenK < 1) dmg = Math.max(1, Math.round(dmg * this.takenK)); // 레벨 능력 「강철 심장」
    if (!opts.raw && this.buffs.guard > 0) dmg = Math.max(1, Math.round(dmg * GUARD_MULT)); // 수호의 물약
    if (!opts.raw && this.buffs.ward > 0) dmg = Math.max(1, Math.round(dmg * WARD_MULT)); // 검사의 「수호의 함성」
    if (this.guts && this.gutsCd <= 0 && dmg >= this.hp) {
      // 레벨 능력 「불굴」: 쓰러질 피해를 한 번 버틴다
      dmg = Math.max(0, this.hp - 1);
      this.gutsCd = 180;
      const g = this.game;
      g.fx.text(this.pos.x, this.pos.y + 2.5, this.pos.z, '불굴!', 'crit');
      g.fx.ring(this.pos.x, this.pos.y + 0.3, this.pos.z, 0xffd35a, 4, 0.6);
      g.ui.toast('「불굴」로 버텼습니다! (3분 뒤에 다시 쓸 수 있어요)', true);
    }
    // 말 위에서는 가벼운 공격쯤은 버틴다. 크게 맞으면 떨어진다 (그림자갈기는 떨어지지 않는다)
    if (this.mounted && !this.md.sturdy && (dmg >= this.maxHp * 0.3 || (opts.knock || 0) >= 11)) this.setMounted(false, true);
    this.hp = Math.max(0, this.hp - dmg);
    this.invuln = opts.inv || 0.9;
    this.hurtT = 0.32;
    this.shake = Math.max(this.shake, 0.35);
    if (!opts.noKnock) {
      let dx = this.pos.x - fromX;
      let dz = this.pos.z - fromZ;
      const d = Math.hypot(dx, dz) || 1;
      dx /= d;
      dz /= d;
      const kb = opts.knock || 7;
      if (this.mounted) {
        // 말 위에서는 조금만 밀린다
        this.vel.x += dx * kb * 0.4;
        this.vel.z += dz * kb * 0.4;
      } else {
        this.vel.x = dx * kb;
        this.vel.z = dz * kb;
        if (this.state === 'ground' || this.state === 'climb' || this.state === 'glide') {
          this.state = 'air';
          this.vel.y = 4.5;
          this.airT = 0.2;
        }
      }
    }
    if (this.action && this.action.type !== 'atk' && this.action.type !== 'skill') this.action = null;
    this.game.onPlayerHurt(dmg);
    if (this.hp <= 0) this.die();
    return true;
  }

  die() {
    this.state = 'dead';
    this.deadT = 4.2;
    this.action = null;
    this.setMounted(false);
    this.lock = null;
    this.game.input.autoRun = false;
    this.vel.set(0, 0, 0);
    this.game.onPlayerDead();
  }

  respawn() {
    const g = this.game;
    const stone = g.pois.stones[g.save.lastStone] || g.pois.stones[0];
    this.hp = this.maxHp;
    this.stamina = this.maxStamina;
    this.exhausted = false;
    this.invuln = 2.5;
    // 시련장·던전에서 쓰러지면 그 입구 앞에서, 그 밖에서는 마지막 귀환석에서 다시 일어난다
    const zs = g.zone;
    if (zs) g.zones.toEntrance(zs);
    else this.teleport(stone.x + 1.8, stone.z + 2.2);
    g.onPlayerRespawn(!!zs);
  }

  drown() {
    const g = this.game;
    this.stamina = this.maxStamina * 0.5;
    this.exhausted = false;
    this.hp = Math.max(0, this.hp - 2);
    g.onPlayerHurt(2);
    if (this.hp <= 0) {
      this.pos.copy(this.lastSafe);
      this.die();
      return;
    }
    this.teleport(this.lastSafe.x, this.lastSafe.z);
    this.invuln = 1.5;
    g.ui.toast('힘이 빠져 물가로 떠밀려 왔습니다…');
  }

  // ---------- 구르기 ----------
  // ---------- 탈것 ----------
  setMounted(v, knocked = false) {
    if (this.mounted === v) return;
    const g = this.game;
    this.mounted = v;
    this.mountCd = 0.5;
    if (this.horse) this.horse.root.visible = v;
    if (g.fx) g.fx.dust(this.pos.x, this.pos.y, this.pos.z, knocked ? 12 : 8);
    if (v) {
      this.action = null;
      this.lock = null;
    }
  }

  toggleMount() {
    const g = this.game;
    if (this.mountCd > 0 || this.state === 'dead') return;
    if (this.mounted) {
      this.setMounted(false);
      return;
    }
    if (!this.hasMount()) {
      g.ui.toast('탈것이 없습니다. 마을 상인에게서 말 피리를 살 수 있어요.');
      this.mountCd = 0.6;
      return;
    }
    if (g.zone) {
      g.ui.toast('이곳에서는 탈것을 부를 수 없습니다.');
      this.mountCd = 0.6;
      return;
    }
    if (this.state !== 'ground' || (this.action && this.action.type !== 'emote')) {
      g.ui.toast('땅 위에 서 있을 때만 탈 수 있습니다.');
      this.mountCd = 0.4;
      return;
    }
    this.setMounted(true);
    g.audio.whistle();
  }

  tryRoll(dirX, dirZ, hasInput) {
    const g = this.game;
    if (this.mounted) this.setMounted(false);
    if (this.state !== 'ground' || this.rollCd > 0 || (this.action && this.action.type === 'roll')) return;
    const cost = ROLL_COST * this.rollCostK;
    if (this.exhausted || this.stamina < cost * 0.6) {
      g.ui.toast('기력이 부족합니다.');
      return;
    }
    this.useStamina(cost);
    if (!hasInput) {
      dirX = Math.sin(this.yaw);
      dirZ = Math.cos(this.yaw);
    }
    this.yaw = Math.atan2(dirX, dirZ);
    this.action = { type: 'roll', t: 0, dur: ROLL_DUR, dx: dirX, dz: dirZ };
    this.rollInv = 0.36;
    this.rollCd = ROLL_DUR + 0.18;
    this.dodged = false;
    this.queued = false;
    g.audio.jump();
    g.fx.dust(this.pos.x, this.pos.y, this.pos.z, 4);
  }

  // ---------- 주목 (대상 고정) ----------
  toggleLock() {
    const g = this.game;
    if (this.lock) {
      this.lock = null;
      g.audio.click();
      return;
    }
    const e = g.ents.pickLockTarget(this.pos.x, this.pos.z, this.camYaw, 30);
    if (e) {
      this.lock = e;
      g.audio.click();
    } else g.ui.toast('주목할 몬스터가 근처에 없습니다.');
  }

  // ---------- 전투 ----------
  startAttack(dirX, dirZ, hasInput) {
    const g = this.game;
    const hits = this.wpn.hits;
    const k = this.comboT > 0 ? (this.comboK + 1) % hits.length : 0;
    const h = hits[k];
    this.comboK = k;
    this.action = { type: 'atk', k, h, t: 0, dur: h.dur, hitAt: h.at, done: false };
    this.queued = false;
    if (this.mounted) {
      // 기마전: 말이 달리는 방향은 그대로 두고, 지나가며 양옆을 넓게 벤다
      g.audio.swing(k, h.dur >= 0.6);
      return;
    }
    const base = hasInput ? Math.atan2(dirX, dirZ) : this.yaw;
    // 주목한 대상이 닿을 거리에 있으면 그쪽을, 아니면 가까운 몬스터를 향한다
    let tgt = null;
    const lk = this.lock;
    if (lk) {
      const d = Math.hypot(lk.x - this.pos.x, lk.z - this.pos.z) - lk.info.radius;
      if (d < h.reach + 4) tgt = { x: lk.x, z: lk.z, dist: Math.max(0, d), e: lk };
    }
    if (!tgt) tgt = g.ents.nearestMonster(this.pos.x, this.pos.z, h.reach + 3, base, hasInput ? 1.9 : 2.6);
    if (!tgt) tgt = g.ents.nearestRival(this.pos.x, this.pos.z, h.reach + 3, base, hasInput ? 1.9 : 2.6); // 결투 상대
    if (tgt) this.yaw = Math.atan2(tgt.x - this.pos.x, tgt.z - this.pos.z);
    else this.yaw = base;
    if (this.state === 'ground') {
      // 한 걸음 내디디며 공격한다 (가벼운 무기일수록 멀리)
      const step = tgt && tgt.dist < h.reach * 0.62 ? 1.5 : h.dur >= 0.6 ? 3.6 : this.wkind === 'dagger' ? 6.5 : 5.5;
      this.vel.x = Math.sin(this.yaw) * step;
      this.vel.z = Math.cos(this.yaw) * step;
    }
    g.audio.swing(k, h.dur >= 0.6);
  }

  doHit(act) {
    const g = this.game;
    const h = act.h;
    const fx = g.fx;
    const sx = Math.sin(this.yaw);
    const sz = Math.cos(this.yaw);
    // 말 위에서는 더 멀리, 더 넓게 닿는다. 빨리 달릴수록 돌격 피해가 붙는다 (ch: 0~1)
    const riding = this.mounted;
    const reach = h.reach + (riding ? 1.6 : 0);
    const half = riding ? Math.max(h.half, 2.6) : h.half;
    const ch = riding ? clamp((this.speedNow - 8) / (this.md.gallop - 8), 0, 1) : 0;
    const ids = g.ents.monstersInArc(this.pos.x, this.pos.y, this.pos.z, this.yaw, reach, half);
    const pids = g.ents.playersInArc(this.pos.x, this.pos.y, this.pos.z, this.yaw, reach, half); // 결투 상대
    fx.slash(this.pos.x, this.pos.y + (riding ? 2.0 : 1.0), this.pos.z, this.yaw, h.anim, this.wcolor, reach / 3.1, half);
    if (h.quake) {
      // 내려찍기: 앞쪽 땅이 울린다
      const qx = this.pos.x + sx * (h.half > 3 ? 0.6 : h.reach * 0.6);
      const qz = this.pos.z + sz * (h.half > 3 ? 0.6 : h.reach * 0.6);
      fx.quake(qx, Math.max(g.world.heightAt(qx, qz), 0), qz, h.half > 3 ? h.reach : h.reach * 0.55, this.wcolor);
      this.shake = Math.max(this.shake, h.shake * 0.6);
      g.audio.thud();
    }
    if (ids.length || pids.length) {
      const m = { t: 'a', ids, k: act.k };
      if (ch > 0) m.ch = +ch.toFixed(2);
      if (pids.length) m.pids = pids;
      g.net.send(m);
      for (const id of pids) g.ents.localHitPlayer(id, this.wcolor);
      // 타격감: 순간 멈춤 + 화면 흔들림 + 불꽃 + 밀려나는 몬스터
      this.shake = Math.max(this.shake, h.shake * (1 + ch * 0.6));
      this.kick = Math.max(this.kick, h.shake);
      g.hitStop = Math.max(g.hitStop || 0, h.stop * (riding ? 0.5 : 1));
      g.audio.hit(1, h.dur >= 0.6 || ch > 0.6);
      g.jobs.noteHit(ids, 'm');
      for (const id of ids) g.ents.localHit(id, this.pos.x, this.pos.z, h, this.wcolor);
      if (ch > 0.6) {
        fx.text(this.pos.x + sx * 2, this.pos.y + 3.1, this.pos.z + sz * 2, '돌격!', 'crit');
        g.quests.on('charge', null, ids.length);
      }
      if (navigator.vibrate && g.input.isTouch) navigator.vibrate(h.dur >= 0.6 ? 28 : 12);
    }
    // 여명의 대검: 마지막 일격이 빛의 파동이 되어 앞으로 뻗어 나간다
    if (this.fx === 'wave' && act.k === this.wpn.hits.length - 1) {
      const far = g.ents.monstersInLine(this.pos.x, this.pos.z, this.yaw, 16, 2.6);
      fx.lightWave(this.pos.x, this.pos.y + 1.1, this.pos.z, this.yaw, 16, this.wcolor);
      g.audio.wave();
      const farP = g.ents.playersInLine(this.pos.x, this.pos.z, this.yaw, 16, 2.6);
      if (far.length || farP.length) setTimeout(() => g.net.send(farP.length ? { t: 'a', ids: far, pids: farP, k: act.k, x: 1 } : { t: 'a', ids: far, k: act.k, x: 1 }), 110);
    }
  }

  // 그림자 송곳니: 두 번 벨 때마다 체력을 조금(최대 체력의 4%, 적어도 화면의 체력 10) 되찾는다
  onLeechHit(x, y, z) {
    if (this.fx !== 'leech' || this.state === 'dead') return;
    if (++this.leech < 2) return;
    this.leech = 0;
    if (this.hp >= this.maxHp) return;
    const n = Math.max(1, Math.round(this.maxHp * 0.04));
    this.heal(n);
    const g = this.game;
    g.fx.burst(this.pos.x, this.pos.y + 1.2, this.pos.z, 0xb06aff, 6, 1.8, { size: 0.22, life: 0.5, grav: -2 });
    g.fx.text(this.pos.x, this.pos.y + 2.2, this.pos.z, `+${n * HP_SHOW}`, 'heal');
  }

  startBow() {
    const g = this.game;
    if (!g.save.eq.bow) {
      g.ui.toast('활이 없습니다. 가방에서 활을 착용하세요.');
      this.bowCd = 0.6;
      return;
    }
    if (g.save.arrows <= 0) {
      g.ui.toast('화살이 없습니다. 상인에게서 살 수 있어요.');
      this.bowCd = 0.6;
      return;
    }
    // 조준: 주목한 대상 > 카메라 방향 + 가까운 적 보정 (마우스로 조준할 때만 보정을 좁게)
    const cy = this.camYaw;
    const lk = this.lock;
    const tgt = lk
      ? { x: lk.x, y: lk.y + lk.info.def.height * (lk.info.elite ? 1.45 : 1) * 0.55, z: lk.z }
      : g.ents.aimTarget(this.pos, cy, g.input.isTouch ? 0.6 : g.input.locked ? 0.24 : 0.5, 70);
    const dir = new THREE.Vector3();
    const ox = this.pos.x;
    const oy = this.pos.y + 1.3;
    const oz = this.pos.z;
    if (tgt) {
      const d = Math.hypot(tgt.x - ox, tgt.z - oz);
      const tf = d / 55;
      dir.set(tgt.x - ox, tgt.y + 0.5 * 9 * tf * tf - oy, tgt.z - oz).normalize();
    } else {
      const p = clamp(0.14 - this.camPitch * 0.55, -0.6, 0.5);
      dir.set(Math.sin(cy) * Math.cos(p), Math.sin(p), Math.cos(cy) * Math.cos(p));
    }
    if (!this.mounted) this.yaw = Math.atan2(dir.x, dir.z); // 말 위에서는 달리는 방향을 바꾸지 않고 쏜다
    this.action = { type: 'bow', t: 0, dur: 0.5, hitAt: 0.2, done: false, dir };
  }

  shoot(dir) {
    const g = this.game;
    g.save.arrows--;
    const ox = this.pos.x + dir.x * 0.6;
    const oy = this.pos.y + (this.mounted ? 2.3 : 1.3);
    const oz = this.pos.z + dir.z * 0.6;
    // 바람가르기: 화살 하나로 세 발이 부채꼴로 나간다
    const n = this.bowFx === 'multi' ? 3 : 1;
    for (let i = 0; i < n; i++) {
      const a = (i - (n - 1) / 2) * 0.13;
      const dx = dir.x * Math.cos(a) + dir.z * Math.sin(a);
      const dz = dir.z * Math.cos(a) - dir.x * Math.sin(a);
      g.ents.spawnArrow(ox, oy, oz, dx, dir.y, dz, true);
      g.net.send({ t: 'shot', x: ox, y: oy, z: oz, dx, dy: dir.y, dz });
    }
    g.audio.bow();
    g.ui.dirty = true;
  }

  // 물약 마시기
  usePotion(k) {
    const g = this.game;
    const s = g.save;
    const def = POTIONS[k];
    if (!def || this.state === 'dead' || this.potCd > 0) return;
    this.potCd = 0.5;
    if ((s.pots[k] || 0) <= 0) {
      g.ui.toast(`${def.name}이 없습니다. 상인에게서 살 수 있어요.`);
      return;
    }
    if (k === 'hp' && this.hp >= this.maxHp) {
      g.ui.toast('체력이 이미 가득합니다.');
      return;
    }
    s.pots[k]--;
    if (k === 'hp') this.heal(Math.max(8, Math.round(this.maxHp * 0.6)));
    else {
      this.buffs[k] = def.dur;
      if (k === 'sta') {
        this.stamina = this.maxStamina;
        this.exhausted = false;
      } else if (k === 'power') g.net.send({ t: 'pot', k: 'power' });
    }
    g.fx.burst(this.pos.x, this.pos.y + 1.3, this.pos.z, def.color, 18, 2.8, { size: 0.3, life: 0.7, grav: -1.5 });
    g.fx.ring(this.pos.x, this.pos.y + 0.2, this.pos.z, def.color, 2.2, 0.5);
    g.audio.drink();
    g.onPotionUsed(k);
    g.ui.dirty = true;
    g.saveSoon();
  }

  useBerry() {
    const g = this.game;
    if (this.healCd > 0 || this.state === 'dead') return;
    if (g.save.berries <= 0) {
      g.ui.toast('회복 열매가 없습니다.');
      this.healCd = 0.5;
      return;
    }
    if (this.hp >= this.maxHp) {
      g.ui.toast('체력이 이미 가득합니다.');
      this.healCd = 0.5;
      return;
    }
    g.save.berries--;
    this.heal(Math.max(BERRY_HEAL, Math.round(this.maxHp * 0.25))); // 화면의 체력 60, 체력이 많으면 최대 체력의 25%
    this.healCd = 0.8;
    g.fx.burst(this.pos.x, this.pos.y + 1.2, this.pos.z, 0x7dff8a, 14, 2.5);
    g.audio.heal();
    g.ui.dirty = true;
  }

  // ---------- 충돌 ----------
  pushOut(cx, cz, r) {
    const dx = this.pos.x - cx;
    const dz = this.pos.z - cz;
    const d2 = dx * dx + dz * dz;
    if (d2 >= r * r) return;
    const d = Math.sqrt(d2);
    if (d < 1e-4) {
      this.pos.x = cx + r;
      return;
    }
    this.pos.x = cx + (dx / d) * r;
    this.pos.z = cz + (dz / d) * r;
  }

  // (fromX, fromZ): 이번 프레임에 움직이기 전의 자리 (실내에서 벽을 뚫지 않게 따라가며 확인한다)
  collide(fromX, fromZ) {
    const p = this.pos;
    const world = this.game.world;
    const R = this.mounted ? 0.8 : 0.42;
    if (this.game.zone) {
      // 시련장·던전 안: 벽, 닫힌 관문, 화로
      this.game.zones.collide(p, R, fromX, fromZ);
      return;
    }
    if (p.y - this.groundH < 5) {
      const lx = p.x + W.HALF;
      const lz = p.z + W.HALF;
      const cx = Math.floor(lx / W.CHUNK);
      const cz = Math.floor(lz / W.CHUNK);
      const fx = lx - cx * W.CHUNK;
      const fz = lz - cz * W.CHUNK;
      const x0 = fx < 4 ? -1 : 0;
      const x1 = fx > W.CHUNK - 4 ? 1 : 0;
      const z0 = fz < 4 ? -1 : 0;
      const z1 = fz > W.CHUNK - 4 ? 1 : 0;
      for (let oz = z0; oz <= z1; oz++) {
        for (let ox = x0; ox <= x1; ox++) {
          const list = world.chunkProps(cx + ox, cz + oz);
          for (let i = 0; i < list.length; i++) {
            const q = list[i];
            if (q.cr > 0) this.pushOut(q.x, q.z, q.cr + R);
          }
        }
      }
      for (const c of this.game.ents.colliders) {
        if (c.off) continue;
        if (c.hw !== undefined) {
          // 축 정렬 상자
          const dx = p.x - c.x;
          const dz = p.z - c.z;
          const ax = Math.abs(dx) - c.hw - R;
          const az = Math.abs(dz) - c.hd - R;
          if (ax < 0 && az < 0) {
            if (ax > az) p.x = c.x + Math.sign(dx || 1) * (c.hw + R);
            else p.z = c.z + Math.sign(dz || 1) * (c.hd + R);
          }
        } else this.pushOut(c.x, c.z, c.r + R);
      }
    }
    const lim = W.HALF - 6;
    p.x = clamp(p.x, -lim, lim);
    p.z = clamp(p.z, -lim, lim);
  }

  // ---------- 메인 업데이트 ----------
  update(dt) {
    const g = this.game;
    const input = g.input;
    const world = g.world;
    const save = g.save;

    this.lookIdle = input.lookDX || input.lookDY ? 0 : (this.lookIdle || 0) + dt;
    this.camYaw -= input.lookDX;
    this.camPitch = clamp(this.camPitch + input.lookDY, -0.4, 1.38);
    input.lookDX = 0;
    input.lookDY = 0;
    if (input.consume('camreset')) {
      this.camYaw = this.yaw;
      this.camPitch = 0.3;
    }
    // 주목: 켜 두면 시점이 대상을 따라간다
    if (input.consume('lock') && this.state !== 'dead') this.toggleLock();
    const lock = this.lock;
    if (lock) {
      const dl = Math.hypot(lock.x - this.pos.x, lock.z - this.pos.z);
      if (lock.dying || !lock.shown || g.ents.monsters.get(lock.id) !== lock || dl > 38 || this.state === 'dead') this.lock = null;
      else {
        if (dl > 0.6) this.camYaw += angDiff(this.camYaw, Math.atan2(lock.x - this.pos.x, lock.z - this.pos.z)) * Math.min(1, 6 * dt);
        g.ents.target = lock;
        g.ents.targetT = 0.5;
      }
    }
    if (input.zoom) {
      this.camDist = clamp(this.camDist + input.zoom * 0.9, 3.5, 16);
      input.zoom = 0;
    }
    this.invuln -= dt;
    this.rollInv -= dt;
    this.rollCd -= dt;
    this.mountCd -= dt;
    this.kick = Math.max(0, this.kick - dt * 3.2);
    this.hurtT -= dt;
    this.atkCd -= dt;
    this.bowCd -= dt;
    this.healCd -= dt;
    this.potCd -= dt;
    this.gutsCd -= dt;
    this.chill -= dt;
    this.skillInv -= dt;
    this.camAnchorT -= dt;
    this.gustSafe = Math.max(0, (this.gustSafe || 0) - dt); // 바람 기둥을 탄 뒤 한동안은 떨어져도 다치지 않는다
    for (const k in this.buffs) if (this.buffs[k] > 0) this.buffs[k] = Math.max(0, this.buffs[k] - dt);
    this.comboT -= dt;
    this.shake = Math.max(0, this.shake - dt * 1.6);

    if (this.state === 'dead') {
      this.deadT -= dt;
      this.anim = ANIM.DEAD;
      this.resting = false;
      const gh = world.heightAt(this.pos.x, this.pos.z);
      this.pos.y = Math.max(this.pos.y - 6 * dt, Math.max(gh, SWIM_Y));
      input.consume('gust');
      for (let i = 1; i <= 4; i++) input.consume('skill' + i);
      this.skillQ = -1;
      if (this.deadT <= 0) this.respawn();
      this.finish(dt, 0);
      return;
    }

    // 입력 방향 (카메라 기준)
    const mx = input.moveX;
    const my = input.moveY;
    const mag = Math.min(1, Math.hypot(mx, my));
    let dirX = 0;
    let dirZ = 0;
    const hasInput = mag > 0.05;
    if (hasInput) {
      const sy = Math.sin(this.camYaw);
      const cy = Math.cos(this.camYaw);
      dirX = sy * my - cy * mx;
      dirZ = cy * my + sy * mx;
      const l = Math.hypot(dirX, dirZ) || 1;
      dirX /= l;
      dirZ /= l;
    }

    // 길들이기 시험 중: 말이 제멋대로 날뛴다. 좌우 입력은 균형 잡기에만 쓰이고(mounts.js), 열매와 물약만 쓸 수 있다
    if (this.taming) {
      for (const k of ['mount', 'roll', 'attack', 'bow', 'jump', 'gust', 'emote1', 'emote2', 'emote3', 'skill1', 'skill2', 'skill3', 'skill4']) input.consume(k);
      if (input.consume('heal')) this.useBerry();
      for (let i = 0; i < POTION_KEYS.length; i++) if (input.consume('pot' + (i + 1))) this.usePotion(POTION_KEYS[i]);
      this.vel.set(0, 0, 0);
      this.action = null;
      this.sprinting = false;
      this.speedNow = 0;
      this.state = 'ground';
      this.anim = this.hurtT > 0 ? ANIM.HURT : ANIM.RIDE;
      this.finish(dt, 13);
      return;
    }

    // 탈것: 타고 내리기. 말 위에서도 무기와 활을 쓸 수 있다 (구르기를 누르면 뛰어내린다)
    if (input.consume('mount')) this.toggleMount();
    // 바람 정령 하늬: 바람 기둥을 일으켜 솟구친다
    if (input.consume('gust')) g.sprite.cast();
    const md = this.md;
    const swiftK = (1 + (this.buffs.swift > 0 ? SWIFT_ADD : 0)) * (this.chill > 0 ? 0.6 : 1);
    // 구르기: 다른 행동을 끊고 바로 구른다
    if (input.consume('roll')) this.tryRoll(dirX, dirZ, hasInput);

    // 행동 (공격·활·구르기) 진행
    let moveScale = 1;
    let rollSp = 0;
    let dashing = false; // 기술로 내달리는 중 (돌진 베기)
    const act = this.action;
    if (act) {
      act.t += dt;
      if (act.type === 'skill') {
        // 직업 기술의 동작 (타격과 연출은 skills.js 가 따로 맡는다)
        moveScale = act.move;
        if (act.dashT > 0) {
          act.dashT -= dt;
          if (this.state === 'ground') {
            rollSp = act.dashSp;
            moveScale = 1;
            dashing = true;
          }
        }
        if (act.t >= act.dur) this.action = null;
      } else if (act.type === 'roll') {
        // 입력과 상관없이 구르는 방향으로 빠르게 움직인다 (처음에 빠르고 끝에 느려진다)
        rollSp = 13.5 - 8.5 * Math.min(1, act.t / act.dur);
        if (act.t >= act.dur || this.state !== 'ground') this.action = null;
      } else if (act.type === 'atk') {
        moveScale = this.mounted ? 1 : 0.22;
        if (!act.done && act.t >= act.hitAt) {
          act.done = true;
          this.doHit(act);
        }
        if (input.consume('attack')) this.queued = true;
        if (act.t >= act.dur) {
          this.action = null;
          this.comboT = 0.55;
          if (this.queued && this.state === 'ground') this.startAttack(dirX, dirZ, hasInput);
        }
      } else if (act.type === 'bow') {
        moveScale = this.mounted ? 1 : 0.35;
        if (!act.done && act.t >= act.hitAt) {
          act.done = true;
          this.shoot(act.dir);
        }
        if (act.t >= act.dur) {
          this.action = null;
          this.bowCd = 0.15;
        }
      } else if (act.type === 'emote') {
        if (hasInput || (act.dur > 0 && act.t >= act.dur)) this.action = null;
      }
    }
    const canAct = this.state === 'ground' || this.state === 'air';
    // 직업 기술 (공격이나 활 동작을 끊고 바로 쓸 수 있다). 다른 기술이나 구르기 도중에 누른 것은 잠깐 기억해 두었다가 끝나자마자 쓴다
    for (let i = 0; i < 4; i++) {
      if (!input.consume('skill' + (i + 1))) continue;
      this.skillQ = i;
      this.skillQT = 0.5;
    }
    if (this.skillQ >= 0) {
      this.skillQT -= dt;
      const busy = this.action && (this.action.type === 'skill' || this.action.type === 'roll');
      if (!busy) {
        const k = this.skillQ;
        this.skillQ = -1;
        g.skills.cast(k, dirX, dirZ, hasInput);
      } else if (this.skillQT <= 0) this.skillQ = -1;
    }
    if (!this.action || this.action.type === 'emote') {
      if (input.consume('attack') && canAct && this.atkCd <= 0) this.startAttack(dirX, dirZ, hasInput);
      else if (input.consume('bow') && canAct && this.bowCd <= 0) this.startBow();
      else if (input.consume('emote1')) this.action = { type: 'emote', anim: ANIM.WAVE, t: 0, dur: 2.2 };
      else if (input.consume('emote2')) this.action = { type: 'emote', anim: ANIM.CHEER, t: 0, dur: 2.2 };
      else if (input.consume('emote3') && this.state === 'ground') this.action = { type: 'emote', anim: ANIM.SIT, t: 0, dur: 0 };
    }
    if (input.consume('heal')) this.useBerry();
    for (let i = 0; i < POTION_KEYS.length; i++) if (input.consume('pot' + (i + 1))) this.usePotion(POTION_KEYS[i]);

    let jumpPressed = input.consume('jump');
    if (rollSp) {
      dirX = act.dx;
      dirZ = act.dz;
      jumpPressed = false;
    }
    this.sprinting = false;
    let moving = hasInput || rollSp > 0;
    const prevX = this.pos.x;
    const prevZ = this.pos.z;

    if (this.state === 'swim') {
      let sp = 3.7;
      let drain = hasInput ? 4.2 : 1.2;
      if (input.sprint && hasInput && !this.exhausted) {
        sp = 5.5;
        drain = 9.5;
      }
      this.useStamina(drain * dt);
      const k = Math.min(1, 5 * dt);
      this.vel.x += (dirX * sp * mag - this.vel.x) * k;
      this.vel.z += (dirZ * sp * mag - this.vel.z) * k;
      const nx = this.pos.x + this.vel.x * dt;
      const nz = this.pos.z + this.vel.z * dt;
      const ng = world.heightAt(nx, nz);
      this.groundH = ng;
      if (ng >= -1.1) {
        this.state = 'ground';
        this.pos.set(nx, ng, nz);
      } else {
        this.pos.set(nx, SWIM_Y + Math.sin(g.time * 2.6) * 0.05, nz);
        if (this.stamina <= 0) this.drown();
      }
      this.vel.y = 0;
    } else if (this.state === 'ground' || this.state === 'climb') {
      world.gradAt(this.pos.x, this.pos.z, _grad);
      let slope = Math.hypot(_grad.x, _grad.z);
      let here = world.heightAt(this.pos.x, this.pos.z);
      // 서리발굽: 물 위를 땅처럼 달린다
      const onWater = this.mounted && md.water;
      if (onWater && here < WATER_RUN) {
        here = WATER_RUN;
        slope = 0;
        _grad.x = _grad.z = 0;
      }
      this.groundH = here;
      let climbing = false;
      let cliffRun = false;
      if (this.mounted && md.climb && slope > STEEP && here > -0.5) {
        // 노을갈기: 절벽도 달려 오르내린다 (기력을 쓰지 않는다)
        cliffRun = true;
        const up = hasInput ? (dirX * _grad.x + dirZ * _grad.z) / slope : 0;
        const sp = (input.sprint ? 16 : 12) / Math.sqrt(1 + slope * slope * up * up);
        const k = Math.min(1, 8 * dt);
        this.vel.x += (dirX * sp * mag - this.vel.x) * k;
        this.vel.z += (dirZ * sp * mag - this.vel.z) * k;
        this.sprinting = hasInput;
      } else if (this.mounted && slope > STEEP && here > -0.5) {
        // 말은 절벽을 오르지 못한다: 오르막 쪽으로는 멈추고, 내리막이나 옆으로는 천천히 움직인다
        const up = hasInput ? (dirX * _grad.x + dirZ * _grad.z) / slope : 0;
        const k = Math.min(1, 6 * dt);
        const sp = up > 0.1 ? 0 : 4;
        this.vel.x += (dirX * sp * mag - this.vel.x) * k;
        this.vel.z += (dirZ * sp * mag - this.vel.z) * k;
        if (up > 0.3) g.tip('mountcliff', '이 말은 절벽을 오르지 못합니다. 내려서 직접 오르세요.');
      } else if (slope > STEEP && here > -0.5) {
        if (this.exhausted || this.stamina <= 0) {
          // 미끄러져 내려간다
          const inv = 1 / slope;
          const k = Math.min(1, 5 * dt);
          this.vel.x += (-_grad.x * inv * 9 - this.vel.x) * k;
          this.vel.z += (-_grad.z * inv * 9 - this.vel.z) * k;
          moving = false;
        } else {
          climbing = true;
          const up = hasInput ? (dirX * _grad.x + dirZ * _grad.z) / slope : 0;
          const upc = Math.max(0, up);
          const sp = 2.5 / Math.sqrt(1 + slope * slope * upc * upc);
          const k = Math.min(1, 12 * dt);
          this.vel.x += (dirX * sp * mag * moveScale - this.vel.x) * k;
          this.vel.z += (dirZ * sp * mag * moveScale - this.vel.z) * k;
          if (hasInput) this.useStamina((up > 0.15 ? 6.5 : 2) * dt);
          if (jumpPressed && this.stamina > 12) {
            // 힘껏 뛰어오르기
            this.useStamina(16);
            const inv = 1 / slope;
            const hop = 2.0 / Math.sqrt(1 + slope * slope);
            this.pos.x += _grad.x * inv * hop;
            this.pos.z += _grad.z * inv * hop;
            g.audio.jump();
          }
        }
      } else {
        let speed = RUN * (this.swift + swiftK) * mag;
        if (rollSp) speed = rollSp;
        else if (this.mounted) {
          // 말을 탄 동안에는 기력이 닳지 않는다
          speed = md.speed * swiftK * mag;
          if (input.sprint && mag > 0.5) {
            speed = md.gallop * swiftK;
            this.sprinting = true;
          }
        } else if (input.sprint && mag > 0.5 && !this.exhausted && this.stamina > 0 && moveScale === 1) {
          speed = SPRINT * (this.swift + swiftK);
          this.useStamina(11 * dt);
          this.sprinting = true;
        }
        const rise = dirX * _grad.x + dirZ * _grad.z;
        if (rise > 0.35) speed *= 1 - 0.45 * clamp((rise - 0.35) / 0.65, 0, 1);
        // 가파른 비탈(절벽 직전)은 걸어 오를 수 있지만 더 느리다
        if (rise > 1) speed *= 1 - 0.45 * clamp(rise - 1, 0, 1);
        // 물속을 걸으면 느려진다 (산호 군도의 얕은 바다는 바닥이 단단해서 덜 느려진다)
        if (here < -0.3) speed *= world.biomeAt(this.pos.x, this.pos.z) === BIOME.REEF ? 0.86 : 0.62;
        speed *= moveScale;
        // 얼음 호수의 얼음판 위에서는 발이 미끄러진다: 천천히 빨라지고 좀처럼 멈추지 않는다 (서리발굽은 미끄러지지 않는다)
        this.onIce = !rollSp && here > 0.3 && here < 1.3 && slope < 0.3 && !(this.mounted && md.water) && world.biomeAt(this.pos.x, this.pos.z) === BIOME.GLACIER;
        // 탈것은 천천히 빨라지고 천천히 멈춘다
        const k = dashing ? 1 : Math.min(1, (this.onIce ? (this.mounted ? 1.2 : 1.6) : this.mounted ? 3.6 : 14) * dt);
        this.vel.x += (dirX * speed - this.vel.x) * k;
        this.vel.z += (dirZ * speed - this.vel.z) * k;
        if (jumpPressed && (!this.action || this.action.type === 'emote')) {
          this.state = 'air';
          this.vel.y = this.mounted ? JUMP_V * 0.92 : JUMP_V;
          this.airT = 0;
          this.action = null;
          g.audio.jump();
        }
      }
      if (this.state !== 'air') {
        this.state = climbing ? 'climb' : 'ground';
        const nx = this.pos.x + this.vel.x * dt;
        const nz = this.pos.z + this.vel.z * dt;
        let ng = world.heightAt(nx, nz);
        if (onWater && ng < WATER_RUN) ng = WATER_RUN;
        const hs = Math.hypot(this.vel.x, this.vel.z);
        if (ng < -1.25) {
          this.state = 'swim';
          if (this.mounted) this.setMounted(false);
          this.pos.set(nx, Math.max(ng, SWIM_Y), nz);
          g.fx.splash(nx, nz);
          g.audio.splash();
        } else if (!climbing && !cliffRun && ng < this.pos.y - (0.5 + hs * dt * 1.4)) {
          this.state = 'air';
          this.vel.y = 0;
          this.airT = 0;
          this.pos.x = nx;
          this.pos.z = nz;
        } else {
          this.pos.set(nx, ng, nz);
        }
        this.groundH = ng;
      }
    } else {
      // 공중 / 활공
      this.airT += dt;
      if (jumpPressed && this.airT > 0.12) {
        if (this.mounted) this.setMounted(false);
        if (this.state === 'glide') this.state = 'air';
        else if (!save.glider) g.ui.toast('활공 천이 없습니다. 촌장과 이야기해 보세요.');
        else if (this.exhausted || this.stamina <= 0) g.ui.toast('기력이 부족합니다.');
        else if (this.pos.y - world.heightAt(this.pos.x, this.pos.z) > 1.2) {
          this.state = 'glide';
          this.action = null;
          g.audio.glide();
        }
      }
      if (this.state === 'glide') {
        this.useStamina(4.0 * dt);
        if (this.stamina <= 0) this.state = 'air';
        // 바람 협곡: 깊은 골짜기에서는 바람이 위로 솟구쳐 활공 천을 고원 위까지 밀어 올린다
        let sink = -2.3;
        this.updraft = false;
        if (this.pos.y < 60 && world.heightAt(this.pos.x, this.pos.z) < 10 && world.biomeAt(this.pos.x, this.pos.z) === BIOME.CANYON) {
          const k = clamp((this.pos.y - 44) / 14, 0, 1);
          sink = 3.6 - 5.9 * k * k * (3 - 2 * k);
          this.updraft = true;
          g.tip('updraft', '바람 협곡의 골짜기에서는 바람이 위로 솟구칩니다. 활공 천을 펴고 있으면 고원 위까지 떠올라요!');
        }
        if (this.vel.y < sink) this.vel.y = Math.min(sink, this.vel.y + (sink > 0 ? 16 : 55) * dt);
        else this.vel.y = Math.max(sink, this.vel.y - GRAV * 0.35 * dt);
        const fx = hasInput ? dirX : Math.sin(this.yaw);
        const fz = hasInput ? dirZ : Math.cos(this.yaw);
        const k = Math.min(1, 2.6 * dt);
        this.vel.x += (fx * 9.5 - this.vel.x) * k;
        this.vel.z += (fz * 9.5 - this.vel.z) * k;
        moving = true;
      } else {
        this.vel.y = Math.max(-48, this.vel.y - GRAV * dt);
        if (hasInput) {
          const k = Math.min(1, 2.4 * dt);
          this.vel.x += (dirX * RUN * mag - this.vel.x) * k;
          this.vel.z += (dirZ * RUN * mag - this.vel.z) * k;
        }
      }
      // 바람 기둥 안에서는 위로 밀려 올라간다. 꼭대기를 벗어나 오르던 기세가 다하면 활공 천이 저절로 펴진다
      const lift = g.sprite.liftAt(this.pos);
      if (lift > 0) {
        if (this.vel.y < lift) this.vel.y = Math.min(lift, this.vel.y + 75 * dt);
        this.lifted = true;
        this.gustSafe = 9;
        // 기둥 한가운데로 살짝 모인다 (밖으로 미끄러져 나가지 않게)
        if (!hasInput) {
          this.vel.x *= Math.max(0, 1 - 4 * dt);
          this.vel.z *= Math.max(0, 1 - 4 * dt);
        }
      } else if (this.lifted && this.vel.y < 1.5) {
        this.lifted = false;
        if (this.state === 'air' && save.glider && !this.exhausted && this.stamina > 0 && this.pos.y - world.heightAt(this.pos.x, this.pos.z) > 4) {
          this.state = 'glide';
          this.action = null;
          g.audio.glide();
        }
      }
      let nx = this.pos.x + this.vel.x * dt;
      let nz = this.pos.z + this.vel.z * dt;
      const ny = this.pos.y + this.vel.y * dt;
      let ng = world.heightAt(nx, nz);
      if (ng > ny + 0.8 && ng > this.pos.y + 0.8) {
        // 벽에 부딪힘
        nx = this.pos.x;
        nz = this.pos.z;
        this.vel.x *= 0.2;
        this.vel.z *= 0.2;
        ng = world.heightAt(nx, nz);
      }
      if (this.mounted && md.water && ng < WATER_RUN) ng = WATER_RUN; // 물 위에 내려선다
      this.groundH = ng;
      if (ng < -1.25 && ny <= SWIM_Y) {
        this.pos.set(nx, SWIM_Y, nz);
        this.state = 'swim';
        if (this.mounted) this.setMounted(false);
        if (this.vel.y < -6) {
          g.fx.splash(nx, nz);
          g.audio.splash();
        }
        this.vel.y = 0;
      } else if (ny <= ng) {
        const vy = this.vel.y;
        this.pos.set(nx, ng, nz);
        this.state = 'ground';
        this.vel.y = 0;
        this.lifted = false;
        if (vy < -24 && !(this.gustSafe > 0)) {
          const dmg = 2 + Math.floor((-vy - 24) / 4);
          this.damage(dmg, nx, nz, { raw: true, noKnock: true, force: true });
          if (this.state !== 'dead') g.ui.toast('높은 곳에서 떨어졌습니다!');
        }
        if (vy < -6) {
          g.fx.dust(nx, ng, nz);
          g.audio.land();
        }
      } else {
        this.pos.set(nx, ny, nz);
      }
    }

    if (this.state !== 'dead') this.collide(prevX, prevZ);
    // 충돌로 밀려난 뒤 지면 높이 보정
    if (this.state === 'ground' || this.state === 'climb') {
      let gh = world.heightAt(this.pos.x, this.pos.z);
      if (this.mounted && md.water && gh < WATER_RUN) gh = WATER_RUN;
      this.pos.y = gh;
      this.groundH = gh;
    }

    // 기력 회복
    const usingNow = this.staminaDelay > 0;
    this.staminaDelay -= dt;
    if (!usingNow && this.state === 'ground') this.stamina = Math.min(this.maxStamina, this.stamina + 32 * this.regenK * dt);
    if (this.exhausted && this.stamina >= this.maxStamina * 0.3) this.exhausted = false;

    // 안전한 위치 기억
    this.safeT -= dt;
    if (this.safeT <= 0 && this.state === 'ground' && this.groundH > 0.6) {
      this.safeT = 0.5;
      this.lastSafe.copy(this.pos);
    }

    // 모닥불 곁 / 마을에서는 서서히 회복
    this.resting = this.state === 'ground' && g.ents.nearRest(this.pos.x, this.pos.z);
    if (this.resting && this.hp < this.maxHp) {
      this.restT += dt;
      if (this.restT > 1.4) {
        this.restT = 0;
        this.heal(Math.max(1, Math.round(this.maxHp * 0.04)));
      }
    } else this.restT = 0;

    // 바라보는 방향
    const dxm = this.pos.x - prevX;
    const dzm = this.pos.z - prevZ;
    this.speedNow = Math.hypot(dxm, dzm) / Math.max(dt, 1e-4);
    // 설정에서 켰다면: 시점을 직접 돌리지 않는 동안, 움직이는 방향으로 시점이 천천히 따라간다
    if (save.settings.follow && hasInput && !this.lock && this.lookIdle > 0.7 && this.speedNow > 1.5) {
      const off = angDiff(this.camYaw, Math.atan2(dirX, dirZ));
      // 카메라 쪽으로 달려올 때는 돌리지 않는다 (시점이 뒤집히지 않게)
      if (Math.abs(off) < 2.2) this.camYaw += off * Math.min(1, 1.1 * dt);
    }
    const locked = this.action && (this.action.type === 'atk' || this.action.type === 'bow' || this.action.type === 'roll' || this.action.type === 'skill');
    if (hasInput && !locked) {
      const want = Math.atan2(dirX, dirZ);
      this.yaw += angDiff(this.yaw, want) * Math.min(1, (this.mounted ? 5 : 13) * dt);
    }

    // 애니메이션 선택
    let anim = ANIM.IDLE;
    const a = this.action;
    if (this.hurtT > 0) anim = ANIM.HURT;
    else if (this.mounted) anim = a && a.type === 'atk' ? ANIM.RIDEATK : a && a.type === 'bow' ? ANIM.RIDEBOW : this.speedNow > 1 ? ANIM.RIDE : ANIM.RIDEIDLE;
    else if (a && a.type === 'roll') anim = ANIM.ROLL;
    else if (a && a.type === 'skill') anim = a.anim;
    else if (a && a.type === 'atk') anim = ATK_ANIM[a.h.anim];
    else if (a && a.type === 'bow') anim = ANIM.BOW;
    else if (this.state === 'swim') anim = hasInput ? ANIM.SWIM : ANIM.SWIMIDLE;
    else if (this.state === 'climb') anim = hasInput ? ANIM.CLIMB : ANIM.CLIMBIDLE;
    else if (this.state === 'glide') anim = ANIM.GLIDE;
    else if (this.state === 'air') anim = this.vel.y > 1 ? ANIM.JUMP : ANIM.FALL;
    else if (a && a.type === 'emote') anim = a.anim;
    else if (moving && this.speedNow > 0.6) anim = this.sprinting ? ANIM.SPRINT : ANIM.RUN;
    this.anim = anim;

    // 발소리 / 먼지
    if (this.state === 'ground' && this.speedNow > 2) {
      this.stepT -= dt * this.speedNow;
      if (this.stepT <= 0) {
        this.stepT = 2.6;
        const wet = world.heightAt(this.pos.x, this.pos.z) < -0.2;
        g.audio.step(wet && !(this.mounted && md.water), this.mounted);
        if (this.mounted && md.water && wet) g.fx.ring(this.pos.x, 0.03, this.pos.z, 0xbfe9ff, 1.5, 0.45); // 발굽 아래 물이 언다
        else if (this.sprinting || this.mounted) g.fx.dust(this.pos.x, this.pos.y, this.pos.z, 3);
      }
    }
    this.finish(dt, this.speedNow);
  }

  finish(dt, speed) {
    const g = this.game;
    const rig = this.rig;
    const a = this.action;
    const sk = a && a.type === 'skill' ? a : null;
    const atkP = sk ? (sk.prog ? sk.prog(sk.t) : Math.min(1, sk.t / (sk.swing || sk.dur))) : a && a.type === 'atk' ? attackProgress(this.wkind, this.anim, a.t) : a && a.type === 'roll' ? a.t / a.dur : 0;
    animateHumanoid(rig, this.anim, dt, speed, atkP);
    rig.root.position.copy(this.pos);
    // 회전 베기: 몸이 한 바퀴 돈다
    rig.root.rotation.y = this.yaw + (sk && sk.spin ? Math.min(1, sk.t / sk.dur) * Math.PI * 2 * sk.spin : 0);
    rig.root.rotation.x = 0;
    rig.root.rotation.z = 0;
    const horse = this.horse;
    if (this.mounted && horse) {
      // 말 위에 앉힌다. 비탈에서는 땅의 기울기를 따라 몸이 기운다 (절벽을 달려 오르는 노을갈기도 땅을 딛고 있게)
      animateHorse(horse, dt, speed);
      const want = this.state === 'ground' ? slopePitch(g.world, this.pos.x, this.pos.z, this.yaw) : 0;
      this.mountPitch += (want - this.mountPitch) * Math.min(1, 9 * dt);
      const tm = this.taming;
      if (tm) {
        // 길들이기 시험: 말이 솟구치고 몸을 튼다. 탄 사람은 균형이 무너진 쪽으로 더 크게 기운다
        seatRider(horse, rig, this.pos.x, this.pos.y + tm.hop, this.pos.z, this.yaw, this.mountPitch + tm.pitch);
        horse.root.rotation.z = tm.roll * 0.45;
        rig.root.rotation.z = tm.roll;
      } else seatRider(horse, rig, this.pos.x, this.pos.y, this.pos.z, this.yaw, this.mountPitch);
      // 히든 탈것은 달릴 때 빛을 흩뿌린다
      if (horse.look && speed > 4) {
        this.trailT -= dt;
        if (this.trailT <= 0) {
          this.trailT = 0.05;
          const bx = this.pos.x - Math.sin(this.yaw) * (0.3 + Math.random() * 0.8) + (Math.random() - 0.5) * 0.5;
          const bz = this.pos.z - Math.cos(this.yaw) * (0.3 + Math.random() * 0.8) + (Math.random() - 0.5) * 0.5;
          g.fx.spawn(bx, this.pos.y + 0.15 + Math.random() * 0.5, bz, (Math.random() - 0.5) * 0.6, 0.8 + Math.random() * 1.2, (Math.random() - 0.5) * 0.6, Math.random() < 0.4 ? horse.look.tip : horse.look.mane, 0.16, 0.5, -0.6, 1, 3, 0.4);
        }
      }
    }
    if (this.blob) {
      const show = !g.gfx.quality.shadows && this.state !== 'swim' && rig.root.visible;
      this.blob.visible = show;
      if (show) {
        const gh = Math.max(g.world.heightAt(this.pos.x, this.pos.z), 0);
        const k = Math.max(0.35, 1 - (this.pos.y - gh) * 0.07);
        this.blob.position.set(this.pos.x, gh + 0.06, this.pos.z);
        this.blob.scale.setScalar((this.mounted ? 1.0 : 0.55) * k);
      }
    }
    // 강화한 무기에서는 빛 알갱이가 흩날린다 (+7 이상)
    if (rig.wglow && (this.wenh >= 7 || this.wuq) && rig.weapon.visible && rig.root.visible) {
      this.glowT -= dt;
      if (this.glowT <= 0) {
        this.glowT = this.wenh >= 10 || this.wuq ? 0.05 : 0.12;
        rig.weapon.localToWorld(_v.set(0, 0, 0.3 + Math.random() * 0.6));
        g.fx.spawn(_v.x, _v.y, _v.z, (Math.random() - 0.5) * 0.4, 0.5 + Math.random() * 0.5, (Math.random() - 0.5) * 0.4, rig.wglow, 0.1, 0.5, -0.4, 1, 3);
      }
    }
    // 피격 무적 중 깜빡임
    rig.root.visible = !(this.invuln > 0 && this.state !== 'dead' && Math.floor(g.time * 16) % 2 === 0 && this.invuln < 0.9);
    if (horse) horse.root.visible = this.mounted && rig.root.visible;

    // 서버로 상태 전송
    this.sendT -= dt * 1000;
    if (this.sendT <= 0) {
      this.sendT = SEND_MS;
      g.net.sendBin(encodeState(this.pos.x, this.pos.y, this.pos.z, this.yaw, this.anim, this.hp, 0));
    }
    this.updateCamera(dt);
  }

  updateCamera(dt) {
    const g = this.game;
    const world = g.world;
    const cam = g.gfx.camera;
    const an = this.camAnchorT > 0 && this.state !== 'dead' ? this.camAnchor : null;
    const tx = an ? an.x : this.pos.x;
    const ty = (an ? an.y : this.pos.y) + (this.state === 'swim' ? 1.0 : this.mounted ? 2.3 : 1.5);
    const tz = an ? an.z : this.pos.z;
    const k = Math.min(1, 14 * dt);
    this.camTarget.x += (tx - this.camTarget.x) * k;
    this.camTarget.y += (ty - this.camTarget.y) * Math.min(1, 9 * dt);
    this.camTarget.z += (tz - this.camTarget.z) * k;
    const cp = Math.cos(this.camPitch);
    const dx = -Math.sin(this.camYaw) * cp;
    const dy = Math.sin(this.camPitch);
    const dz = -Math.cos(this.camYaw) * cp;
    // 지형(실내에서는 벽)에 가려지지 않도록 거리 조절
    const full = this.camDist + (this.mounted ? 2 : 0);
    let want = full;
    const zs = g.zone;
    const STEPS = zs ? 20 : 10;
    const wallTop = ZONE_FLOOR + WALL_H + 0.3;
    for (let s = 1; s <= STEPS; s++) {
      const d = (full * s) / STEPS;
      const x = this.camTarget.x + dx * d;
      const y = this.camTarget.y + dy * d;
      const z = this.camTarget.z + dz * d;
      if (zs ? y < wallTop && zoneSolid(zs.def, x, z, zs.open) : y < world.heightAt(x, z) + 0.45) {
        want = Math.max(1.2, (full * (s - 1)) / STEPS);
        break;
      }
    }
    this.camCur += (want - this.camCur) * Math.min(1, (want < this.camCur ? 20 : 4) * dt);
    // 타격 순간에는 시점이 살짝 당겨진다
    const d = this.camCur * (1 - this.kick * 0.09);
    _v.set(this.camTarget.x + dx * d, this.camTarget.y + dy * d, this.camTarget.z + dz * d);
    const floor = Math.max(world.heightAt(_v.x, _v.z), 0) + 0.4;
    if (_v.y < floor) _v.y = floor;
    if (this.shake > 0) {
      _v.x += (Math.random() - 0.5) * this.shake * 0.5;
      _v.y += (Math.random() - 0.5) * this.shake * 0.5;
      _v.z += (Math.random() - 0.5) * this.shake * 0.5;
    }
    cam.position.copy(_v);
    cam.lookAt(this.camTarget);
  }
}

export { setWeapon };

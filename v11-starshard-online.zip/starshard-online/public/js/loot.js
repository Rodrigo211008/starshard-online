// 전리품: 몬스터와 보물상자에서 나오는 장비와 강화 재료.
// 각자 자기 몫이 자기 화면에만 떨어지므로 친구와 다툴 일이 없다.
import * as THREE from '/vendor/three/three.module.js';
import { RARITY, SLOT_NAME, POTIONS, POTION_KEYS, POTION_CAP, UNIQUES, rollItem, makeUnique, itemName, slotOf } from '/shared/defs.js';
import { Geo, M } from './geo.js';
import { josa } from './dom.js';
import { zoneBlocked } from '/shared/zones.js';

const LIFE = 150; // 바닥에 남아 있는 시간(초)

export class Loot {
  constructor(game) {
    this.game = game;
    this.scene = game.gfx.scene;
    this.drops = [];
    this.fullT = 0;
    this.owedT = 1.5;
    this.hinted = {};
    const mat = game.gfx.matGlow;
    // 장비: 등급 색의 마름모 보석
    this.gearGeo = RARITY.map((r) => {
      const g = new Geo();
      g.cone(0.2, 0.3, 4, M(0, 0.15, 0), r.color);
      g.cone(0.2, 0.3, 4, M(0, -0.15, 0, Math.PI, 0, 0), r.color);
      return g.build(false);
    });
    const dg = new Geo();
    dg.ico(0.13, 0, null, 0xfff2a8);
    dg.ico(0.07, 0, M(0.16, 0.1, 0.05), 0xffffff);
    dg.ico(0.06, 0, M(-0.13, -0.06, 0.1), 0xffe27a);
    this.dustGeo = dg.build(false);
    const cg = new Geo();
    cg.ico(0.2, 0, null, 0xc79bff);
    cg.cone(0.1, 0.2, 4, M(0, 0.26, 0), 0xffffff);
    cg.cone(0.1, 0.2, 4, M(0, -0.26, 0, Math.PI, 0, 0), 0xffffff);
    this.coreGeo = cg.build(false);
    // 물약: 색이 다른 작은 병
    this.potGeo = {};
    for (const k of POTION_KEYS) {
      const pg = new Geo();
      pg.cyl(0.13, 0.17, 0.26, 6, M(0, 0, 0), POTIONS[k].color);
      pg.cyl(0.06, 0.07, 0.13, 6, M(0, 0.19, 0), 0xffffff);
      pg.cyl(0.075, 0.075, 0.05, 6, M(0, 0.28, 0), 0xc9905a);
      this.potGeo[k] = pg.build(false);
    }
    // 황금 사과
    const ag = new Geo();
    ag.ico(0.19, 0, M(0, 0, 0, 0, 0, 0, 1, 0.92, 1), 0xffd35a);
    ag.cone(0.05, 0.16, 4, M(0.02, 0.21, 0, 0, 0, -0.3), 0x7a5a2c);
    ag.cone(0.07, 0.14, 4, M(0.1, 0.24, 0, 0, 0, -1.2), 0x7dff8a);
    this.appleGeo = ag.build(false);
    this.mat = mat;
    // 희귀 이상은 빛기둥이 선다
    this.beamGeo = new THREE.CylinderGeometry(0.08, 0.2, 7, 8, 1, true);
    this.beamGeo.translate(0, 3.5, 0);
    this.beamMat = RARITY.map((r) => new THREE.MeshBasicMaterial({ color: r.color, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false }));
  }

  _spawn(geo, x, y, z, data) {
    const g = this.game;
    const m = new THREE.Mesh(geo, this.mat);
    m.position.set(x, y + 0.8, z);
    this.scene.add(m);
    // 튀어 올랐다가 근처에 떨어진다
    const a = Math.random() * Math.PI * 2;
    const r = 1.2 + Math.random() * 1.4;
    let tx = x + Math.cos(a) * r;
    let tz = z + Math.sin(a) * r;
    if (g.zone ? zoneBlocked(g.zone.def, tx, tz, 0.5, g.zone.open) : g.world.heightAt(tx, tz) < -0.6 || g.world.slopeAt(tx, tz) > 1.6) {
      tx = x;
      tz = z;
    }
    const d = { m, beam: null, x, z, sx: x, sz: z, tx, tz, sy: y + 0.8, t: 0, age: 0, pull: 0, zone: g.zone ? g.zone.id : 0, ...data };
    if (data.item && data.item.r >= 2) {
      d.beam = new THREE.Mesh(this.beamGeo, this.beamMat[data.item.r]);
      d.beam.renderOrder = 6;
      d.beam.visible = false;
      this.scene.add(d.beam);
    }
    this.drops.push(d);
    return d;
  }

  dropItem(item, x, y, z) {
    if (item.u) {
      // 히든 무기는 주울 때까지 사라지지 않는다 (게임을 껐다 켜도 발밑에 다시 나타난다)
      const s = this.game.save;
      if (!s.uqDrop.some((q) => q.id === item.id)) s.uqDrop.push(item);
      this.game.saveSoon();
    }
    this._spawn(this.gearGeo[item.r], x, y, z, { item });
    if (item.r >= 2) this.game.audio.loot(item.r);
  }

  // kind: 'dust' 별가루, 'core' 별의 핵, 'apple' 황금 사과, 'pot:종류' 물약
  dropMat(kind, n, x, y, z) {
    const geo = kind === 'core' ? this.coreGeo : kind === 'apple' ? this.appleGeo : kind.startsWith('pot:') ? this.potGeo[kind.slice(4)] : this.dustGeo;
    for (let i = 0; i < n; i++) this._spawn(geo, x, y, z, { mat: kind });
  }

  // 몬스터를 쓰러뜨렸을 때의 전리품
  onKill(info, x, y, z) {
    const g = this.game;
    const R = Math.random;
    // 레이드 보스: 저마다 자기 레벨에 맞는 장비 하나 (큰 보상은 보물 방에 있다)
    const lvl = (info.raid ? g.save.level : info.level) + 3 * g.lap;
    const src = info.dungeon || info.raid ? (info.boss ? 'dboss' : 'dungeon') : info.final ? 'boss' : info.type === 'golem' ? 'golem' : info.elite ? 'elite' : 'mob';
    let chance = { mob: 0.075, elite: 0.6, golem: 1, boss: 1, dungeon: 0.14, dboss: 1 }[src];
    let count = info.raid ? 1 : { boss: 3, dboss: 3, golem: R() < 0.35 ? 2 : 1 }[src] || 1;
    let dust = { mob: R() < 0.32 ? 1 : 0, elite: 2 + (R() < 0.5 ? 1 : 0), golem: 4 + Math.floor(R() * 3), boss: 12, dungeon: R() < 0.6 ? 1 + (R() < 0.3 ? 1 : 0) : 0, dboss: 10 }[src];
    let core = { mob: R() < 0.015 ? 1 : 0, elite: R() < 0.35 ? 1 : 0, golem: 1, boss: 4, dungeon: R() < 0.07 ? 1 : 0, dboss: 3 }[src];
    if (info.tower) {
      // 별의 탑: 무리는 조금씩, 우두머리는 넉넉히 떨어뜨린다 (큰 보상은 층을 넘을 때마다 따로 받는다)
      if (info.boss) {
        chance = 1;
        count = 1;
        dust = 5 + Math.floor(R() * 3);
        core = 2;
      } else {
        chance = info.elite ? 0.3 : 0.05;
        count = 1;
        dust = R() < (info.elite ? 1 : 0.22) ? 1 : 0;
        core = R() < (info.elite ? 0.2 : 0.01) ? 1 : 0;
      }
    } else if (info.minion) {
      chance = 0.03;
      count = 1;
      dust = R() < 0.15 ? 1 : 0;
      core = 0;
    }
    chance *= 1 + g.player.luck;
    for (let i = 0; i < count; i++) {
      if (R() >= chance) continue;
      let it = rollItem(info.tower && info.boss ? 'dungeon' : src, lvl);
      // 2장 · 3장의 마지막 상대: 첫 번째 장비는 영웅(황혼의 용) · 전설(검은 태양) 등급 이상이다
      const min = i === 0 && info.final ? { dragon: 3, blacksun: 4 }[info.type] || 0 : 0;
      for (let k = 0; k < 60 && it.r < min; k++) it = rollItem(src, lvl);
      this.dropItem(it, x, y, z);
    }
    if (dust) this.dropMat('dust', dust, x, y, z);
    if (core) this.dropMat('core', core, x, y, z);
    // 물약과 황금 사과: 강한 적일수록 자주
    const big = src === 'boss' || src === 'dboss';
    const pot = info.tower ? (info.boss ? 1 : 0.05) : { mob: 0.03, elite: 0.3, golem: 0.8, boss: 1, dungeon: 0.07, dboss: 1 }[src] * (info.minion ? 0.3 : 1);
    if (R() < pot) for (let i = 0; i < (big ? 3 : 1); i++) this.dropMat('pot:' + POTION_KEYS[Math.floor(R() * POTION_KEYS.length)], 1, x, y, z);
    // (황금 사과는 귀하다: 상인은 팔지 않고, 수호자·우두머리·던전의 주인에게서 가끔 나온다)
    const apple = { mob: 0.002, elite: 0.04, golem: 0.2, boss: 1, dungeon: 0.01, dboss: 1 }[src];
    if (!info.minion && R() < apple) this.dropMat('apple', src === 'boss' ? 2 : 1, x, y, z);
    if (info.tower && info.boss && R() < 0.25) this.dropMat('apple', 1, x, y, z);
    this.rollUnique(info, lvl, x, y, z);
  }

  // 히든 무기: 정해진 상대만 떨어뜨린다. 안 나올 때마다 다음 확률이 오른다.
  rollUnique(info, lvl, x, y, z) {
    let key = null;
    let base = 0;
    if (info.dungeon && info.boss) {
      key = { kingslime: 'venom', tyrant: 'icicle', knight: 'fang' }[info.type];
      base = 0.25;
    } else if (info.type === 'lord') {
      key = 'thunder';
      base = 0.3;
    } else if (info.type === 'golem' && info.biome >= 7 && !info.zone) {
      key = 'gale';
      base = 0.12;
    }
    if (!key) return;
    const s = this.game.save;
    const miss = s.uqPity[key] || 0;
    if (Math.random() < base * (1 + miss)) {
      s.uqPity[key] = 0;
      this.dropItem(makeUnique(key, lvl), x, y, z);
    } else s.uqPity[key] = miss + 1;
  }

  // 보물상자: 재료는 늘 조금, 장비는 가끔 (큰 상자일수록 자주)
  onChest(chest, level, x, y, z) {
    const R = Math.random;
    const big = chest.kind !== 'wild';
    const chance = chest.kind === 'shrine' ? 1 : big ? 0.65 : 0.38;
    if (R() < chance * (1 + this.game.player.luck)) this.dropItem(rollItem('chest' + Math.max(1, Math.min(4, chest.tier)), level + 3 * this.game.lap), x, y, z);
    this.dropMat('dust', 1 + Math.floor(R() * chest.tier) + (big ? 1 : 0), x, y, z);
    if (chest.kind === 'shrine' && R() < 0.5) this.dropMat('core', 1, x, y, z);
    if (R() < 0.1 + 0.06 * chest.tier) this.dropMat('pot:' + POTION_KEYS[Math.floor(R() * POTION_KEYS.length)], 1, x, y, z);
    if (chest.tier >= 4 && R() < 0.12) this.dropMat('apple', 1, x, y, z);
  }

  _pickup(d) {
    const g = this.game;
    const { ui, fx, audio, save } = g;
    const p = g.player.pos;
    if (d.mat) {
      if (d.mat === 'apple') {
        save.apples++;
        fx.text(p.x, p.y + 2.0, p.z, '+1 황금 사과', 'r4');
        g.tip('apple', '황금 사과를 얻었습니다! 숨어 사는 특별한 말을 길들일 때 씁니다. (모험가 화면에서 소문을 볼 수 있어요)');
      } else if (d.mat.startsWith('pot:')) {
        const k = d.mat.slice(4);
        save.pots[k] = Math.min(POTION_CAP, save.pots[k] + 1);
        fx.text(p.x, p.y + 2.0, p.z, '+1 ' + POTIONS[k].name, 'r2');
        g.tip('potion', g.input.isTouch ? '물약을 얻었습니다! 물약 버튼을 눌러 마실 수 있어요.' : '물약을 얻었습니다! 숫자 키 5~9 로 마실 수 있어요.');
      } else {
        save.mats[d.mat]++;
        fx.text(p.x, p.y + 2.0, p.z, d.mat === 'core' ? '+1 별의 핵' : '+1 별가루', d.mat === 'core' ? 'r3' : 'gold');
      }
      audio.pickup();
      g.saveSoon();
      ui.bagDirty = true;
      ui.dirty = true;
      return true;
    }
    const it = d.item;
    if (!g.inv.add(it)) {
      if (this.fullT <= 0) {
        this.fullT = 4;
        ui.toast('가방이 가득 찼습니다. 상인에게 팔거나 버려서 자리를 만드세요.');
      }
      return false;
    }
    const name = `[${RARITY[it.r].name}] ${itemName(it)}`;
    if (it.u && UNIQUES[it.u]) {
      // 히든 무기를 손에 넣었다
      save.uqDrop = save.uqDrop.filter((q) => q.id !== it.id);
      g.saveSoon();
      ui.banner('히든 무기 획득!', `${UNIQUES[it.u].name} — ${UNIQUES[it.u].desc}`);
      audio.victory();
      g.net.send({ t: 'chat', text: `★ 히든 무기 「${UNIQUES[it.u].name}」${josa(UNIQUES[it.u].name, '을', '를')} 손에 넣었습니다!` });
    }
    fx.text(p.x, p.y + 2.2, p.z, itemName(it), 'r' + it.r);
    fx.burst(p.x, p.y + 1.2, p.z, RARITY[it.r].color, 10 + it.r * 5, 3.5, { size: 0.28, life: 0.6, grav: -1, glow: 2 });
    audio.loot(it.r);
    // 빈 칸이면 바로 착용하고, 더 좋은 장비면 알려 준다
    const slot = SLOT_NAME[slotOf(it.t)];
    if (!save.eq[slotOf(it.t)]) {
      g.inv.equip(it.id);
      ui.toast(`${name} 획득 — 바로 착용했습니다`, true, 'r' + it.r);
    } else if (g.inv.better(it)) {
      ui.toast(`${name} 획득 — 지금 ${slot}보다 좋아요! ${g.input.isTouch ? '메뉴의 가방' : 'B 키 가방'}에서 착용하세요`, true, 'r' + it.r);
    } else ui.toast(`${name} 획득`, false, 'r' + it.r);
    return true;
  }

  update(dt, time) {
    const g = this.game;
    const pl = g.player;
    // 지난번에 줍지 못한 히든 무기는 발밑에 다시 나타난다
    if (g.save.uqDrop.length && (this.owedT -= dt) <= 0) {
      this.owedT = 2;
      for (const it of g.save.uqDrop) {
        if (!this.drops.some((d) => d.item && d.item.id === it.id)) this._spawn(this.gearGeo[it.r], pl.pos.x, pl.pos.y, pl.pos.z, { item: it });
      }
    }
    if (!this.drops.length) return;
    const world = g.world;
    this.fullT -= dt;
    const alive = pl.state !== 'dead';
    const zid = g.zone ? g.zone.id : 0;
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      const keep = d.item && d.item.u; // 히든 무기는 시간이 지나도 남는다
      if (!keep) d.age += dt;
      const m = d.m;
      if (keep && d.zone !== zid) {
        // 두고 나왔다면 주인을 따라온다
        d.zone = zid;
        d.x = d.sx = d.tx = pl.pos.x;
        d.z = d.sz = d.tz = pl.pos.z;
        d.sy = pl.pos.y + 0.8;
        d.t = 0.5;
      }
      if (d.zone !== zid) {
        // 시련장·던전 안팎이 다르면 보이지 않는다 (돌아가면 다시 보인다)
        m.visible = false;
        if (d.beam) d.beam.visible = false;
        if (d.age > LIFE) {
          this.scene.remove(m);
          if (d.beam) this.scene.remove(d.beam);
          this.drops.splice(i, 1);
        }
        continue;
      }
      if (d.beam && d.t >= 1) d.beam.visible = true;
      if (d.t < 1) {
        // 포물선으로 튀어나온다
        d.t = Math.min(1, d.t + dt * 2.4);
        d.x = d.sx + (d.tx - d.sx) * d.t;
        d.z = d.sz + (d.tz - d.sz) * d.t;
        const gy = Math.max(world.heightAt(d.x, d.z), 0) + 0.75;
        m.position.set(d.x, d.sy + (gy - d.sy) * d.t + Math.sin(d.t * Math.PI) * 1.8, d.z);
        if (d.t >= 1 && d.beam) {
          d.beam.position.set(d.x, gy - 0.6, d.z);
          d.beam.visible = true;
        }
      } else {
        const dx = pl.pos.x - d.x;
        const dz = pl.pos.z - d.z;
        const dist = Math.hypot(dx, dz);
        const gy = Math.max(world.heightAt(d.x, d.z), 0) + 0.75;
        // 가까이 가면 끌려온다
        if (alive && dist < 5 && Math.abs(pl.pos.y - gy) < 4 && (d.mat || g.inv.free() > 0)) {
          d.pull = Math.min(16, d.pull + dt * 30);
          const k = Math.min(1, (d.pull * dt) / Math.max(dist, 0.01));
          d.x += dx * k;
          d.z += dz * k;
          if (d.beam) d.beam.position.set(d.x, gy - 0.6, d.z);
        } else d.pull = 0;
        m.position.set(d.x, gy + Math.sin(time * 3 + d.sx) * 0.12, d.z);
        if (alive && dist < 1.1 && Math.abs(pl.pos.y - gy) < 3 && this._pickup(d)) d.gone = true;
      }
      m.rotation.y += dt * 2.4;
      // 사라지기 직전에는 깜빡인다
      m.visible = keep || d.age < LIFE - 12 || Math.floor(time * 6) % 2 === 0;
      if (d.gone || (!keep && d.age > LIFE)) {
        this.scene.remove(m);
        if (d.beam) this.scene.remove(d.beam);
        this.drops.splice(i, 1);
      }
    }
  }
}

// 가방과 장비: 착용, 판매, 강화. 아이템은 저장 데이터(save.eq, save.inv)에 들어 있다.
import { INV_CAP, SLOTS, SLOT_NAME, slotOf, itemValue, itemPower, itemName, canEnhance, enhanceCost, enhanceChance, makeItem, WEAPONS } from '/shared/defs.js';
import { josa } from './dom.js';

export class Inventory {
  constructor(game) {
    this.game = game;
  }

  get save() {
    return this.game.save;
  }

  free() {
    return INV_CAP - this.save.inv.length;
  }

  // 아이템이 어디 있는지 찾는다: { item, slot (착용 중이면), index (가방 안이면) }
  find(id) {
    const s = this.save;
    for (const slot of SLOTS) if (s.eq[slot] && s.eq[slot].id === id) return { item: s.eq[slot], slot, index: -1 };
    const index = s.inv.findIndex((q) => q.id === id);
    return index >= 0 ? { item: s.inv[index], slot: null, index } : null;
  }

  changed() {
    this.game.saveSoon();
    this.game.ui.bagDirty = true;
  }

  // 가방에 넣는다 (가득 찼으면 false)
  add(item) {
    if (this.free() <= 0) return false;
    this.save.inv.push(item);
    this.note(item);
    this.changed();
    return true;
  }

  // 얻어 본 히든 무기를 적어 둔다 (모험가 화면의 목록에 이름이 드러난다)
  note(item) {
    const s = this.save;
    if (item && item.u && !s.uqGot.includes(item.u)) s.uqGot.push(item.u);
  }

  // 지금 착용한 것보다 좋은지 (주 능력치 비교)
  better(item) {
    const cur = this.save.eq[slotOf(item.t)];
    if (!cur) return true;
    if (item.t === 'charm') return false;
    return itemPower(item) > itemPower(cur);
  }

  equip(id) {
    const f = this.find(id);
    if (!f || f.slot) return false;
    const s = this.save;
    const slot = slotOf(f.item.t);
    const old = s.eq[slot];
    s.eq[slot] = f.item;
    if (old) s.inv[f.index] = old;
    else s.inv.splice(f.index, 1);
    this.game.audio.equip();
    this.game.onEquipChanged();
    this.changed();
    return true;
  }

  unequip(slot) {
    const s = this.save;
    const it = s.eq[slot];
    const ui = this.game.ui;
    if (!it) return false;
    if (slot === 'weapon') {
      ui.toast('무기는 다른 무기로 바꿔 낄 수만 있어요.');
      return false;
    }
    if (this.free() <= 0) {
      ui.toast('가방이 가득 차서 벗을 수 없습니다.');
      return false;
    }
    s.eq[slot] = null;
    s.inv.push(it);
    this.game.audio.equip();
    this.game.onEquipChanged();
    this.changed();
    return true;
  }

  // 가방 안의 아이템을 상인에게 판다
  sell(id) {
    const f = this.find(id);
    if (!f || f.slot) return 0;
    const v = itemValue(f.item);
    this.save.inv.splice(f.index, 1);
    this.save.gold += v;
    this.game.audio.coin();
    this.changed();
    return v;
  }

  // 일반 등급(강화하지 않은 것)을 한꺼번에 판다
  junk() {
    return this.save.inv.filter((it) => it.r === 0 && !it.e);
  }

  sellJunk() {
    const list = this.junk();
    let total = 0;
    for (const it of list) total += itemValue(it);
    if (!list.length) return 0;
    this.save.inv = this.save.inv.filter((it) => !list.includes(it));
    this.save.gold += total;
    this.game.audio.coin();
    this.changed();
    return total;
  }

  discard(id) {
    const f = this.find(id);
    if (!f || f.slot) return false;
    this.save.inv.splice(f.index, 1);
    this.changed();
    return true;
  }

  // 대장간에서 새 장비를 산다 (바로 착용하고, 쓰던 것은 가방으로)
  buy(type, level, price) {
    const s = this.save;
    const ui = this.game.ui;
    if (s.gold < price) return false;
    const slot = slotOf(type);
    if (s.eq[slot] && this.free() <= 0) {
      ui.toast('가방이 가득 찼습니다. 먼저 물건을 팔거나 버리세요.');
      return false;
    }
    s.gold -= price;
    const it = makeItem(type, 0, level);
    if (s.eq[slot]) s.inv.push(s.eq[slot]);
    s.eq[slot] = it;
    this.game.audio.coin();
    this.game.onEquipChanged();
    this.changed();
    ui.toast(`${itemName(it)}${josa(itemName(it), '을', '를')} 착용했습니다.${WEAPONS[type] ? ' ' + WEAPONS[type].desc : ''}`, true);
    return true;
  }

  // 강화를 시도한다. 결과: { ok, item } 또는 재료가 모자라면 { lack: '별가루' }
  enhance(id) {
    const f = this.find(id);
    if (!f || !canEnhance(f.item)) return null;
    const s = this.save;
    const it = f.item;
    const cost = enhanceCost(it);
    if (s.mats.dust < cost.dust) return { lack: '별가루' };
    if (s.mats.core < cost.core) return { lack: '별의 핵' };
    if (s.gold < cost.gold) return { lack: '골드' };
    s.mats.dust -= cost.dust;
    s.mats.core -= cost.core;
    s.gold -= cost.gold;
    const ok = Math.random() < enhanceChance(it);
    if (ok) {
      it.e = (it.e || 0) + 1;
      delete it.f;
    } else it.f = (it.f || 0) + 1;
    if (f.slot && ok) this.game.onEquipChanged();
    this.changed();
    return { ok, item: it, equipped: !!f.slot };
  }

  // 교환 성사: 준 것은 빼고 받은 것은 넣는다
  applyTrade(give, get) {
    const s = this.save;
    const ids = new Set(give.items.map((q) => q.id));
    s.inv = s.inv.filter((q) => !ids.has(q.id));
    s.gold = Math.max(0, s.gold - give.gold) + get.gold;
    for (const it of get.items) {
      s.inv.push({ ...it, id: makeItem(it.t, it.r, it.l).id });
      this.note(it);
    }
    this.changed();
  }

  slotLabel(slot) {
    return SLOT_NAME[slot];
  }
}

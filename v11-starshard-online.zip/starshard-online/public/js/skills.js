// 직업 기술: 발동, 판정, 연출. 무엇이 얼마나 센지는 shared/jobs.js 에 적혀 있고, 피해는 서버가 셈한다.
//  do_이름(a)  내가 기술을 쓸 때 (대상을 고르고, 동작을 시작하고, 타격을 예약한다)
//  re_이름(o, m, col)  다른 모험가가 쓴 기술을 보여 줄 때 (연출만)
import * as THREE from '/vendor/three/three.module.js';
import { ANIM, HP_SHOW } from '/shared/defs.js';
import { JOBS } from '/shared/jobs.js';
import { ZONE_FLOOR, WALL_H, zoneSolid, zoneClearLine } from '/shared/zones.js';
import { Geo, M } from './geo.js';

const TAU = Math.PI * 2;
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
function angDiff(a, b) {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}
const _d = new THREE.Vector3();
const rnd = (a) => (Math.random() - 0.5) * a;

export class Skills {
  constructor(game) {
    this.game = game;
    this.cd = [0, 0, 0, 0]; // 다시 쓸 수 있을 때까지 남은 시간(초)
    this.cdMax = [1, 1, 1, 1];
    this.timers = []; // 예약된 일
    this.shots = []; // 날아가는 것들 (화살 · 별똥 화살 · 별똥탄)
    this.clouds = []; // 한동안 이어지는 연출 (연막 · 화살비 · 떨어지는 별똥)
    this.denyT = 0;
    // 날아가는 것들의 모델
    const og = new Geo();
    og.ico(0.32, 1, null, 0x9ad0ff, 0xffffff, 0.12, 3);
    this.orbGeo = og.build(false);
    const sg = new Geo();
    sg.cone(0.2, 1.5, 5, M(0, 0, 0.55, Math.PI / 2, 0, 0), 0xfff2a8, 0xffffff);
    sg.ico(0.28, 0, M(0, 0, -0.15), 0xffd35a, 0xfff6c0, 0.2, 5);
    this.starGeo = sg.build(false);
    const mg = new Geo();
    mg.ico(0.75, 0, null, 0x7ac0ff, 0xffffff, 0.35, 9);
    this.meteorGeo = mg.build(false);
  }

  // 직업이 바뀌면 재사용 시간을 처음으로 돌린다
  reset() {
    this.cd.fill(0);
    this.game.ui.dirty = true;
  }

  // t 초 뒤에 한다. alive: 내가 쓰러졌으면 하지 않는다
  after(t, fn, alive = true) {
    this.timers.push({ t, fn, alive });
  }

  deny(text) {
    if (this.denyT > 0) return;
    this.denyT = 0.9;
    this.game.ui.toast(text);
    this.game.audio.deny();
  }

  // ---------- 발동 ----------
  // k: 기술 번호(0~3), (dirX, dirZ): 누르고 있는 방향
  cast(k, dirX, dirZ, hasInput) {
    const g = this.game;
    const pl = g.player;
    const j = g.jobs.job();
    const J = j.t ? JOBS[j.c] : null;
    if (!J) {
      this.deny(g.save.level >= 10 ? '기술은 전직한 뒤에 쓸 수 있습니다. 마을의 스승 가람을 찾아가세요.' : '기술은 Lv.10 에 전직한 뒤부터 쓸 수 있습니다.');
      return false;
    }
    const sk = J.skills[k];
    if (!sk) return false;
    if (k >= j.t) {
      this.deny(`「${sk.name}」 — ${k + 1}차 전직을 하면 열립니다.`);
      return false;
    }
    if (pl.state === 'dead' || pl.taming) return false;
    if (this.cd[k] > 0) {
      this.deny(`「${sk.name}」 — ${Math.ceil(this.cd[k])}초 뒤에 다시 쓸 수 있습니다.`);
      return false;
    }
    if ((pl.state !== 'ground' && pl.state !== 'air') || (pl.action && pl.action.type === 'roll')) {
      this.deny('지금은 기술을 쓸 수 없습니다.');
      return false;
    }
    if (sk.stat === 'bow' && !g.save.eq.bow) {
      this.deny('활이 없습니다. 가방에서 활을 착용하세요.');
      return false;
    }
    if (pl.mounted) pl.setMounted(false);
    const a = { k, sk, col: J.color, dirX, dirZ, hasInput };
    if (this['do_' + sk.key](a) === false) return false;
    this.cd[k] = this.cdMax[k] = sk.cd * pl.cdK;
    pl.queued = false;
    pl.comboT = 0;
    g.ui.dirty = true;
    return true;
  }

  // 서버에 알린다: 재사용 시간이 돌기 시작하고, 주변 사람들에게 연출이 보인다. (x, z): 겨눈 자리
  begin(a, x, y, z, yaw, pts) {
    const n1 = (v) => +v.toFixed(1);
    const m = { t: 'sk', k: a.k, c: 1, x: n1(x), y: n1(y), z: n1(z), yaw: +yaw.toFixed(2) };
    if (pts) m.pts = pts.map((q) => [n1(q[0]), n1(q[1])]);
    this.game.net.send(m);
  }

  // 타격을 서버에 보내고, 맞은 자리에 바로 반응을 보여 준다. o: { second 여파, kb, shake, fx, fz 밀려나는 방향의 기준 }
  hit(a, ids, pids, o = {}) {
    const g = this.game;
    const pl = g.player;
    if (pl.state === 'dead') return 0;
    pids = pids || [];
    if (!ids.length && !pids.length) return 0;
    const m = { t: 'sk', k: a.k, ids };
    if (pids.length) m.pids = pids;
    if (o.second) m.s = 1;
    g.net.send(m);
    g.jobs.noteHit(ids, a.sk.stat === 'bow' ? 'b' : 'm', true);
    const fx = o.fx === undefined ? pl.pos.x : o.fx;
    const fz = o.fz === undefined ? pl.pos.z : o.fz;
    const h = { kb: o.kb === undefined ? a.sk.kb : o.kb, shake: o.shake === undefined ? 0.2 : o.shake };
    for (const id of ids) g.ents.localHit(id, fx, fz, h, a.col);
    for (const id of pids) g.ents.localHitPlayer(id, a.col);
    pl.shake = Math.max(pl.shake, h.shake);
    pl.kick = Math.max(pl.kick, h.shake * 0.8);
    g.audio.hit(0.9, h.shake >= 0.4);
    if (navigator.vibrate && g.input.isTouch) navigator.vibrate(h.shake >= 0.4 ? 26 : 10);
    return ids.length + pids.length;
  }

  // ---------- 대상 고르기 ----------
  // 가까운 적 (정면 yaw 에서 half 안쪽). 실내에서는 벽에 가려진 것은 고르지 않는다
  nearest(range, yaw, half) {
    const g = this.game;
    const pos = g.player.pos;
    const zs = g.zone;
    let best = null;
    let bs = Infinity;
    for (const e of g.ents.monsters.values()) {
      if (e.dying || !e.shown) continue;
      const dx = e.x - pos.x;
      const dz = e.z - pos.z;
      const d = Math.hypot(dx, dz) - e.info.radius;
      if (d > range) continue;
      const an = Math.abs(angDiff(yaw, Math.atan2(dx, dz)));
      if (an > half && d > 1.2) continue;
      if (zs && !zoneClearLine(zs.def, pos.x, pos.z, e.x, e.z, zs.open)) continue;
      const score = d + an * 2;
      if (score < bs) {
        bs = score;
        best = e;
      }
    }
    return best;
  }

  // 가까이에서 쓰는 기술: 주목한 대상 > 누르는(바라보는) 쪽의 가까운 적. 그쪽으로 돌아선다. { x, z, dist, e } 또는 null
  faceNear(a, range) {
    const g = this.game;
    const pl = g.player;
    const base = a.hasInput ? Math.atan2(a.dirX, a.dirZ) : pl.yaw;
    let tgt = null;
    const lk = pl.lock;
    if (lk) {
      const d = Math.hypot(lk.x - pl.pos.x, lk.z - pl.pos.z) - lk.info.radius;
      if (d < range) tgt = { x: lk.x, z: lk.z, dist: Math.max(0, d), e: lk };
    }
    if (!tgt) {
      const e = this.nearest(range, base, a.hasInput ? 1.9 : 2.6);
      if (e) tgt = { x: e.x, z: e.z, dist: Math.max(0, Math.hypot(e.x - pl.pos.x, e.z - pl.pos.z) - e.info.radius), e };
    }
    if (!tgt) tgt = g.ents.nearestRival(pl.pos.x, pl.pos.z, range, base, a.hasInput ? 1.9 : 2.6); // 결투 상대
    pl.yaw = tgt ? Math.atan2(tgt.x - pl.pos.x, tgt.z - pl.pos.z) : base;
    return tgt;
  }

  // 조준 보정의 너그러움 (터치로는 시점을 정밀하게 돌리기 어렵다)
  cone() {
    const inp = this.game.input;
    return inp.isTouch ? 0.75 : inp.locked ? 0.3 : 0.55;
  }

  // 멀리 쏘는 기술의 방향: 주목한 대상 > 시점 쪽의 적 > (마우스로 겨누는 중이 아니면) 가까운 적 > 시점이 향한 곳. { dir, yaw, tgt }
  aimDir(range) {
    const g = this.game;
    const pl = g.player;
    const cy = pl.camYaw;
    const lk = pl.lock;
    const mid = (e) => ({ x: e.x, y: e.y + e.info.def.height * (e.info.elite ? 1.45 : 1) * 0.55, z: e.z, e });
    let tgt = lk ? mid(lk) : g.ents.aimTarget(pl.pos, cy, this.cone(), range);
    if (!tgt && !g.input.locked) {
      // 터치나 키보드만으로는 시점을 재빨리 돌리기 어렵다: 시점 밖이라도 가까운 적을 겨눠 준다
      const e = this.nearest(range * 0.7, cy, Math.PI);
      if (e) tgt = mid(e);
    }
    const dir = new THREE.Vector3();
    const ox = pl.pos.x;
    const oy = pl.pos.y + 1.3;
    const oz = pl.pos.z;
    if (tgt) dir.set(tgt.x - ox, tgt.y - oy, tgt.z - oz).normalize();
    else {
      const p = clamp(0.1 - pl.camPitch * 0.5, -0.5, 0.4);
      dir.set(Math.sin(cy) * Math.cos(p), Math.sin(p), Math.cos(cy) * Math.cos(p));
    }
    return { dir, yaw: Math.atan2(dir.x, dir.z), tgt };
  }

  // 자리에 쓰는 기술의 겨눈 자리: 주목한 대상 > 시점 쪽의 적 > 가까운 적 > 시점 앞 def 미터. 실내에서는 보이는 데까지만
  aimPoint(maxDist, def) {
    const g = this.game;
    const pl = g.player;
    const pos = pl.pos;
    let t = null;
    const lk = pl.lock;
    if (lk && Math.hypot(lk.x - pos.x, lk.z - pos.z) <= maxDist + 5) t = lk;
    if (!t) {
      const q = g.ents.aimTarget(pos, pl.camYaw, this.cone() + 0.25, maxDist + 3);
      if (q) t = q.e || q.rival;
    }
    if (!t) t = this.nearest(maxDist * 0.8, pl.camYaw, Math.PI);
    let tx = t ? t.x : pos.x + Math.sin(pl.camYaw) * def;
    let tz = t ? t.z : pos.z + Math.cos(pl.camYaw) * def;
    const dx = tx - pos.x;
    const dz = tz - pos.z;
    const d = Math.hypot(dx, dz);
    if (d > maxDist) {
      tx = pos.x + (dx / d) * maxDist;
      tz = pos.z + (dz / d) * maxDist;
    }
    const zs = g.zone;
    if (zs) {
      const n = Math.max(1, Math.ceil(Math.min(d, maxDist) / 0.5));
      let lx = pos.x;
      let lz = pos.z;
      for (let i = 1; i <= n; i++) {
        const x = pos.x + ((tx - pos.x) * i) / n;
        const z = pos.z + ((tz - pos.z) * i) / n;
        if (zoneSolid(zs.def, x, z, zs.open)) break;
        lx = x;
        lz = z;
      }
      tx = lx;
      tz = lz;
    }
    return { x: tx, y: Math.max(g.world.heightAt(tx, tz), 0), z: tz };
  }

  // 그 자리에 설 수 있는지 (순간 이동하는 기술). refY: 견줄 땅의 높이
  standable(x, z, refY) {
    const g = this.game;
    const zs = g.zone;
    if (zs) return !zoneSolid(zs.def, x, z, zs.open);
    const h = g.world.heightAt(x, z);
    return h > -1.0 && Math.abs(h - refY) < 3.5;
  }

  blink(x, z) {
    const g = this.game;
    const pl = g.player;
    const h = g.world.heightAt(x, z);
    pl.pos.set(x, Math.max(h, -0.95), z);
    pl.vel.set(0, 0, 0);
    pl.state = 'ground';
    pl.groundH = h;
  }

  act(o) {
    this.game.player.action = { type: 'skill', t: 0, move: 0.3, ...o };
  }

  // 기술이 미치는 자리를 바닥에 은은하게 그린다 (옅은 바탕 + 또렷한 테두리)
  mark(x, z, r, dur, col) {
    const fx = this.game.fx;
    fx.telegraph({ kind: 'circle', x, z, r }, dur * 1000, 0, col, 0.16);
    fx.telegraph({ kind: 'ring', x, z, r0: r - 0.22, r1: r }, dur * 1000, 0, 0xffffff, 0.5);
  }

  // ============================================================
  // 검사
  // ============================================================
  // 회전 베기: 몸을 돌려 둘레를 모두 벤다
  do_whirl(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    this.faceNear(a, sk.r + 1);
    this.act({ dur: 0.5, anim: ANIM.ATK1, move: 0.55, spin: 1, swing: 0.3 });
    this.begin(a, pl.pos.x, pl.pos.y, pl.pos.z, pl.yaw);
    g.audio.swing(2, true);
    this.after(0.14, () => {
      const p = pl.pos;
      this.v_whirl(p, pl.yaw, a.col, sk.r);
      const n = this.hit(a, g.ents.monstersInCircle(p.x, p.y, p.z, sk.r), g.ents.playersInCircle(p.x, p.y, p.z, sk.r), { shake: 0.32 });
      if (n) g.hitStop = Math.max(g.hitStop || 0, 0.06);
    });
  }

  v_whirl(p, yaw, col, r) {
    const fx = this.game.fx;
    fx.slash(p.x, p.y + 1.0, p.z, yaw, 0, col, r / 3.1, 2.4);
    fx.slash(p.x, p.y + 1.15, p.z, yaw + Math.PI, 1, 0xffffff, r / 3.1, 2.4);
    fx.ring(p.x, p.y + 0.25, p.z, col, r, 0.32);
    for (let i = 0; i < 18; i++) {
      const an = (i / 18) * TAU;
      fx.spawn(p.x + Math.sin(an) * r * 0.7, p.y + 0.9 + rnd(0.5), p.z + Math.cos(an) * r * 0.7, Math.cos(an) * 9, 0.6, -Math.sin(an) * 9, i % 3 ? col : 0xffffff, 0.24, 0.26, 0, 1, 2.6);
    }
    fx.dust(p.x, p.y, p.z, 8);
  }

  re_whirl(o, m, col) {
    this.after(0.14, () => this.v_whirl(o, m.yaw, col, JOBS[1].skills[0].r), false);
  }

  // 돌진 베기: 앞으로 내달리며 길 위의 적을 벤다
  do_charge(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    const tgt = this.faceNear(a, sk.len + 2);
    const yaw = pl.yaw;
    const sx = Math.sin(yaw);
    const sz = Math.cos(yaw);
    const x0 = pl.pos.x;
    const z0 = pl.pos.z;
    const dash = tgt ? clamp(tgt.dist + 3, 4.5, sk.dash) : sk.dash; // 상대를 살짝 지나칠 만큼
    const T = 0.24;
    this.act({ dur: 0.44, anim: ANIM.THRUST, move: 0, dx: sx, dz: sz, dashT: T, dashSp: dash / T, swing: 0.16 });
    pl.skillInv = T + 0.12;
    if (pl.state === 'air') {
      pl.vel.x = sx * (dash / T) * 0.7;
      pl.vel.z = sz * (dash / T) * 0.7;
    }
    this.begin(a, x0, pl.pos.y, z0, yaw);
    g.audio.swing(1, true);
    g.audio.gust(0.5);
    this.v_charge({ x: x0, y: pl.pos.y, z: z0 }, yaw, a.col, dash);
    this.after(T + 0.02, () => {
      const p = pl.pos;
      g.fx.slash(p.x, p.y + 1.0, p.z, yaw, 0, a.col, 1.5, 2.0);
      const n = this.hit(a, g.ents.monstersInLine(x0, z0, yaw, sk.len, sk.half), g.ents.playersInLine(x0, z0, yaw, sk.len, sk.half), { fx: x0, fz: z0, shake: 0.4 });
      if (n) g.hitStop = Math.max(g.hitStop || 0, 0.07);
    });
  }

  v_charge(o, yaw, col, dash) {
    const fx = this.game.fx;
    const sx = Math.sin(yaw);
    const sz = Math.cos(yaw);
    // 지나간 자리에 빛줄기가 남는다
    for (let d = 0; d < dash + 1.5; d += 0.45) {
      const t = d / (dash + 1.5);
      this.after(t * 0.24, () => {
        const x = o.x + sx * d;
        const z = o.z + sz * d;
        const y = Math.max(this.game.world.heightAt(x, z), 0);
        for (let i = 0; i < 2; i++) fx.spawn(x + rnd(0.7), y + 0.5 + Math.random() * 1.1, z + rnd(0.7), -sx * 2, 0.4, -sz * 2, i ? col : 0xffffff, 0.26, 0.3, 0, 1, 2.6);
        if (d % 1.8 < 0.45) fx.dust(x, y, z, 2);
      }, false);
    }
    fx.slash(o.x, o.y + 1.0, o.z, yaw, 3, col, (dash + 2) / 3.1);
  }

  re_charge(o, m, col) {
    this.v_charge(o, m.yaw, col, JOBS[1].skills[1].dash);
  }

  // 수호의 함성: 나와 곁의 친구들이 받는 피해가 줄고 체력을 되찾는다
  do_ward(a) {
    const g = this.game;
    const pl = g.player;
    this.act({ dur: 0.7, anim: ANIM.CHEER, move: 0.3 });
    this.begin(a, pl.pos.x, pl.pos.y, pl.pos.z, pl.yaw);
    this.v_ward(pl.pos, a.col, a.sk.r);
    g.audio.roar();
    this.effect(a.sk, a.col);
  }

  v_ward(p, col, r) {
    const fx = this.game.fx;
    fx.ring(p.x, p.y + 0.3, p.z, col, r, 0.7);
    fx.ring(p.x, p.y + 0.3, p.z, 0xffffff, r * 0.6, 0.5);
    fx.burst(p.x, p.y + 1.6, p.z, col, 30, 6, { size: 0.34, life: 0.8, grav: 2, glow: 2.4, up: 0.4 });
    for (let i = 0; i < 20; i++) {
      const an = (i / 20) * TAU;
      fx.spawn(p.x + Math.sin(an) * 1.2, p.y + 0.2, p.z + Math.cos(an) * 1.2, Math.sin(an) * 7, 1.5, Math.cos(an) * 7, i % 2 ? col : 0xfff2c0, 0.3, 0.6, 0, 1, 2.6);
    }
  }

  re_ward(o, m, col) {
    this.v_ward(o, col, JOBS[1].skills[2].r);
  }

  // 여명 가르기: 힘을 모아 빛의 칼날을 내리친다
  do_dawn(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    this.faceNear(a, sk.len);
    const W = sk.wind;
    this.act({ dur: W + 0.5, anim: ANIM.ATK3, move: 0.05, prog: (t) => (t < W ? 0 : Math.min(1, (t - W) / 0.12)) });
    this.begin(a, pl.pos.x, pl.pos.y, pl.pos.z, pl.yaw);
    this.v_gather(() => ({ x: pl.pos.x, y: pl.pos.y + 2.5, z: pl.pos.z }), 0xffe27a, W);
    g.audio.portal();
    this.after(W, () => {
      const p = pl.pos;
      const yaw = pl.yaw;
      this.v_dawn(p, yaw, sk.len);
      pl.shake = Math.max(pl.shake, 0.7);
      const n = this.hit(a, g.ents.monstersInLine(p.x, p.z, yaw, sk.len, sk.half), g.ents.playersInLine(p.x, p.z, yaw, sk.len, sk.half), { shake: 0.7 });
      if (n) g.hitStop = Math.max(g.hitStop || 0, 0.1);
    });
  }

  // 빛이 한 점으로 모여든다 (힘을 모으는 동안). at(): 모이는 자리
  v_gather(at, col, dur) {
    const fx = this.game.fx;
    for (let t = 0; t < dur; t += 0.04) {
      this.after(t, () => {
        const c = at();
        for (let i = 0; i < 3; i++) {
          const an = Math.random() * TAU;
          const r = 1.6 + Math.random() * 1.4;
          const h = rnd(2.4);
          fx.spawn(c.x + Math.sin(an) * r, c.y + h, c.z + Math.cos(an) * r, -Math.sin(an) * r * 4.5, -h * 4.5, -Math.cos(an) * r * 4.5, i ? col : 0xffffff, 0.2, 0.22, 0, 1, 3);
        }
      }, false);
    }
  }

  v_dawn(p, yaw, len) {
    const g = this.game;
    const fx = g.fx;
    const sx = Math.sin(yaw);
    const sz = Math.cos(yaw);
    fx.lightWave(p.x, p.y + 1.1, p.z, yaw, len, 0xffe27a);
    fx.slash(p.x, p.y + 1.2, p.z, yaw, 2, 0xffffff, 2.0, 2.0);
    for (let d = 3; d < len; d += 4.5) {
      const x = p.x + sx * d;
      const z = p.z + sz * d;
      fx.quake(x, Math.max(g.world.heightAt(x, z), 0), z, 2.6, 0xffe27a);
    }
    g.audio.wave();
    g.audio.thud();
  }

  re_dawn(o, m, col) {
    const W = JOBS[1].skills[3].wind;
    this.v_gather(() => ({ x: o.x, y: o.y + 2.5, z: o.z }), 0xffe27a, W);
    this.after(W, () => this.v_dawn(o, m.yaw, JOBS[1].skills[3].len), false);
  }

  // ============================================================
  // 궁수
  // ============================================================
  // 세 갈래 화살
  do_triple(a) {
    const g = this.game;
    const pl = g.player;
    const { dir, yaw, tgt } = this.aimDir(70);
    pl.yaw = yaw;
    // 화살은 날아가며 떨어지므로 먼 적일수록 살짝 들어 쏜다
    const lift = tgt ? (4.5 * Math.hypot(tgt.x - pl.pos.x, tgt.z - pl.pos.z)) / (58 * 58) : 0.02;
    this.act({ dur: 0.42, anim: ANIM.BOW, move: 0.4 });
    this.begin(a, pl.pos.x, pl.pos.y, pl.pos.z, yaw);
    this.after(0.15, () => {
      const ox = pl.pos.x + dir.x * 0.6;
      const oy = pl.pos.y + 1.3;
      const oz = pl.pos.z + dir.z * 0.6;
      for (let i = -1; i <= 1; i++) {
        const an = i * 0.13;
        const dx = dir.x * Math.cos(an) + dir.z * Math.sin(an);
        const dz = dir.z * Math.cos(an) - dir.x * Math.sin(an);
        this.arrow(a, ox, oy, oz, dx, dir.y + lift, dz, a.col);
        g.net.send({ t: 'shot', x: ox, y: oy, z: oz, dx, dy: dir.y + lift, dz });
      }
      g.audio.bow();
      g.audio.swing(2);
    });
  }

  // 내 화살 한 발 (맞으면 기술의 타격이 된다)
  arrow(a, x, y, z, dx, dy, dz, col) {
    const g = this.game;
    const m = new THREE.Mesh(g.ents.arrowGeo, g.gfx.matChar);
    m.position.set(x, y, z);
    g.gfx.scene.add(m);
    const sp = 58;
    this.shots.push({
      m, kind: 'arrow', vx: dx * sp, vy: dy * sp, vz: dz * sp, g: 9, life: 2.6, trailT: 0,
      trail: (p) => g.fx.spawn(p.x, p.y, p.z, 0, 0, 0, col, 0.14, 0.22, 0, 0.9, 2.2),
      onMon: (e, px, py, pz) => {
        g.fx.burst(px, py, pz, col, 7, 3.5, { size: 0.24, life: 0.28 });
        e.flash = 0.12;
        this.hit(a, [e.id], [], { shake: 0.12, fx: x, fz: z });
      },
      onRival: (e) => this.hit(a, [], [e.id], { shake: 0.12 }),
    });
  }

  re_triple() {
    /* 화살은 'shot' 으로 따로 보인다 */
  }

  // 꿰뚫는 화살: 곧게 뻗어 길 위의 적을 모두 꿰뚫는다
  do_pierce(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    const { yaw } = this.aimDir(sk.len);
    pl.yaw = yaw;
    this.act({ dur: 0.5, anim: ANIM.BOW, move: 0.2 });
    this.begin(a, pl.pos.x, pl.pos.y, pl.pos.z, yaw);
    this.after(0.2, () => {
      const p = pl.pos;
      this.v_pierce(p, yaw, a.col, sk.len);
      pl.shake = Math.max(pl.shake, 0.3);
      this.hit(a, g.ents.monstersInLine(p.x, p.z, yaw, sk.len, sk.half), g.ents.playersInLine(p.x, p.z, yaw, sk.len, sk.half), { shake: 0.35 });
    });
  }

  v_pierce(p, yaw, col, len) {
    const g = this.game;
    const fx = g.fx;
    const sx = Math.sin(yaw);
    const sz = Math.cos(yaw);
    const zs = g.zone;
    fx.slash(p.x, p.y + 1.25, p.z, yaw, 3, 0xffffff, 3);
    fx.ring(p.x + sx * 1.2, p.y + 0.3, p.z + sz * 1.2, col, 2.2, 0.3);
    for (let d = 0.8; d < len; d += 0.55) {
      const x = p.x + sx * d;
      const z = p.z + sz * d;
      if (zs && zoneSolid(zs.def, x, z, zs.open)) break; // 벽에서 멈춘다
      const y = Math.max(g.world.heightAt(x, z), 0) + 1.2;
      fx.spawn(x, y, z, sx * 10, 0, sz * 10, 0xffffff, 0.34, 0.24 + d * 0.008, 0, 1, 3);
      fx.spawn(x + rnd(0.35), y + rnd(0.35), z + rnd(0.35), sx * 6, rnd(1), sz * 6, col, 0.26, 0.34 + d * 0.008, 0, 0.9, 2.6);
      if (d % 1.65 < 0.55) fx.spawn(x + rnd(0.6), y + rnd(0.6), z + rnd(0.6), rnd(2.5), 1.5 + Math.random() * 1.5, rnd(2.5), col, 0.18, 0.6, 2, 1, 2.2);
    }
    g.audio.bow();
    g.audio.wave();
  }

  re_pierce(o, m, col) {
    this.after(0.2, () => this.v_pierce(o, m.yaw, col, JOBS[2].skills[1].len), false);
  }

  // 화살비: 겨눈 자리에 화살이 다섯 번 쏟아진다
  do_rain(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    const pt = this.aimPoint(sk.cast, 9);
    if (Math.hypot(pt.x - pl.pos.x, pt.z - pl.pos.z) > 0.5) pl.yaw = Math.atan2(pt.x - pl.pos.x, pt.z - pl.pos.z);
    this.act({ dur: 0.5, anim: ANIM.BOW, move: 0.3 });
    this.begin(a, pt.x, pt.y, pt.z, pl.yaw);
    g.audio.bow();
    this.v_rain(pt, a.col, sk);
    for (let i = 0; i < sk.ticks; i++) {
      this.after(0.4 + i * sk.every, () => this.hit(a, g.ents.monstersInCircle(pt.x, pt.y, pt.z, sk.r), g.ents.playersInCircle(pt.x, pt.y, pt.z, sk.r), { fx: pt.x, fz: pt.z, shake: 0.12 }));
    }
  }

  v_rain(pt, col, sk) {
    const g = this.game;
    const dur = 0.4 + sk.ticks * sk.every;
    this.mark(pt.x, pt.z, sk.r, dur, col);
    this.clouds.push({ kind: 'rain', x: pt.x, y: pt.y, z: pt.z, r: sk.r, t: -0.3, dur: dur - 0.15, col, acc: 0 });
  }

  re_rain(o, m, col) {
    this.v_rain({ x: m.x, y: m.y, z: m.z }, col, JOBS[2].skills[2]);
  }

  // 별똥 화살: 별빛을 모아 쏜다. 처음 닿은 적에게 큰 피해, 둘레에는 여파
  do_star(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    const aim = this.aimDir(sk.len);
    pl.yaw = aim.yaw;
    const W = sk.wind;
    this.act({ dur: W + 0.35, anim: ANIM.BOW, move: 0.05 });
    this.begin(a, pl.pos.x, pl.pos.y, pl.pos.z, aim.yaw);
    this.v_gather(() => ({ x: pl.pos.x + Math.sin(pl.yaw) * 0.7, y: pl.pos.y + 1.4, z: pl.pos.z + Math.cos(pl.yaw) * 0.7 }), 0xfff2a8, W);
    g.audio.portal();
    this.after(W, () => {
      // 쏘는 순간 다시 겨눈다 (모으는 동안 적이 움직였을 수 있다)
      const now = this.aimDir(sk.len);
      const dir = Math.abs(angDiff(aim.yaw, now.yaw)) < 0.9 ? now.dir : aim.dir;
      pl.yaw = Math.atan2(dir.x, dir.z);
      pl.shake = Math.max(pl.shake, 0.35);
      this.starShot(pl.pos.x + dir.x * 0.7, pl.pos.y + 1.35, pl.pos.z + dir.z * 0.7, dir.x, dir.y, dir.z, sk, (main, x, y, z) => {
        // 처음 닿은 적 -> 큰 피해, 그 둘레 -> 여파
        if (main) this.hit(a, [main.id], [], { shake: 0.6, fx: x - dir.x, fz: z - dir.z });
        const ids = g.ents.monstersInCircle(x, y, z, sk.r).filter((id) => !main || id !== main.id);
        this.hit(a, ids, g.ents.playersInCircle(x, y, z, sk.r), { second: true, fx: x, fz: z, shake: 0.4 });
        g.hitStop = Math.max(g.hitStop || 0, 0.08);
      });
    });
  }

  // 별똥 화살 한 발. done(main, x, y, z): 터진 자리 (main: 처음 닿은 적). done 이 없으면 연출만
  starShot(x, y, z, dx, dy, dz, sk, done) {
    const g = this.game;
    const m = new THREE.Mesh(this.starGeo, g.gfx.matGlow);
    m.position.set(x, y, z);
    m.scale.setScalar(1.5);
    g.gfx.scene.add(m);
    const sp = 72;
    const boom = (main, px, py, pz) => {
      this.v_starBoom(px, py, pz, sk.r);
      if (done) done(main, px, py, pz);
    };
    this.shots.push({
      m, kind: 'star', vx: dx * sp, vy: dy * sp, vz: dz * sp, g: 0, life: sk.len / sp, fake: !done,
      trail: (p) => {
        for (let i = 0; i < 2; i++) g.fx.spawn(p.x + rnd(0.3), p.y + rnd(0.3), p.z + rnd(0.3), rnd(1.5), rnd(1.5), rnd(1.5), i ? 0xffd35a : 0xffffff, 0.3, 0.4, 0, 1, 3);
      },
      onMon: (e, px, py, pz) => boom(e, px, py, pz),
      onRival: (e, px, py, pz) => boom(null, px, py, pz),
      onEnd: (px, py, pz) => boom(null, px, py, pz),
    });
    g.audio.bow();
    g.audio.wave();
  }

  v_starBoom(x, y, z, r) {
    const g = this.game;
    const fx = g.fx;
    const gy = Math.max(g.world.heightAt(x, z), 0);
    fx.impact(x, y, z, 0xfff6c0, 3);
    fx.burst(x, y, z, 0xffd35a, 46, 11, { size: 0.42, life: 0.7, grav: 6, glow: 2.8 });
    fx.burst(x, y, z, 0xffffff, 18, 6, { size: 0.3, life: 0.5, grav: 2, glow: 3 });
    fx.ring(x, gy + 0.25, z, 0xffd35a, r, 0.45);
    fx.ring(x, gy + 0.2, z, 0xffffff, r * 0.6, 0.3);
    const pl = g.player;
    const d = Math.hypot(pl.pos.x - x, pl.pos.z - z);
    if (d < 45) pl.shake = Math.max(pl.shake, 0.6 * (1 - d / 45));
    g.audio.thud();
    g.audio.thunder();
  }

  re_star(o, m, col) {
    const sk = JOBS[2].skills[3];
    this.v_gather(() => ({ x: o.x + Math.sin(m.yaw) * 0.7, y: o.y + 1.4, z: o.z + Math.cos(m.yaw) * 0.7 }), 0xfff2a8, sk.wind);
    this.after(sk.wind, () => this.starShot(o.x + Math.sin(m.yaw) * 0.7, o.y + 1.35, o.z + Math.cos(m.yaw) * 0.7, Math.sin(m.yaw), 0, Math.cos(m.yaw), sk, null), false);
  }

  // ============================================================
  // 도적
  // ============================================================
  // 연속 찌르기: 눈앞을 다섯 번 잇달아 찌른다
  do_flurry(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    const tgt = this.faceNear(a, sk.reach + 3);
    const T0 = 0.07;
    this.act({ dur: T0 + sk.ticks * sk.every + 0.12, anim: ANIM.THRUST, move: 0.15, prog: (t) => clamp((((t - 0.01) % sk.every) + sk.every) % sk.every / (sk.every * 0.7), 0, 1) });
    if (pl.state === 'ground') {
      const step = tgt && tgt.dist < sk.reach * 0.6 ? 1.2 : 6;
      pl.vel.x = Math.sin(pl.yaw) * step;
      pl.vel.z = Math.cos(pl.yaw) * step;
    }
    this.begin(a, pl.pos.x, pl.pos.y, pl.pos.z, pl.yaw);
    for (let i = 0; i < sk.ticks; i++) {
      this.after(T0 + i * sk.every, () => {
        const p = pl.pos;
        // 찌르는 동안에도 상대를 따라 돌아선다
        const e = tgt && tgt.e;
        if (e && !e.dying && Math.hypot(e.x - p.x, e.z - p.z) < sk.reach + 4) pl.yaw = Math.atan2(e.x - p.x, e.z - p.z);
        const last = i === sk.ticks - 1;
        this.v_stab(p, pl.yaw, a.col, sk.reach, i);
        this.hit(a, g.ents.monstersInArc(p.x, p.y, p.z, pl.yaw, sk.reach, sk.half).slice(0, sk.max), g.ents.playersInArc(p.x, p.y, p.z, pl.yaw, sk.reach, sk.half), { kb: last ? 7 : 1.5, shake: last ? 0.3 : 0.1 });
      });
    }
  }

  v_stab(p, yaw, col, reach, i) {
    const g = this.game;
    g.fx.slash(p.x + rnd(0.5), p.y + 0.9 + rnd(0.6), p.z + rnd(0.5), yaw + rnd(0.3), 3, i % 2 ? col : 0xffffff, reach / 3.1);
    g.audio.swing(i % 3);
  }

  re_flurry(o, m, col) {
    const sk = JOBS[3].skills[0];
    for (let i = 0; i < sk.ticks; i++) this.after(0.07 + i * sk.every, () => this.v_stab(o, m.yaw, col, sk.reach, i), false);
  }

  // 그림자 걸음: 적의 등 뒤로 옮겨 가 급소를 찌른다. 적이 없으면 앞으로 미끄러진다
  do_step(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    const pos = pl.pos;
    const base = a.hasInput ? Math.atan2(a.dirX, a.dirZ) : pl.yaw;
    const from = { x: pos.x, y: pos.y, z: pos.z };
    const lk = pl.lock;
    let e = lk && Math.hypot(lk.x - pos.x, lk.z - pos.z) - lk.info.radius < sk.cast ? lk : this.nearest(sk.cast, base, 1.5);
    let rival = null;
    if (!e) {
      const q = g.ents.nearestRival(pos.x, pos.z, sk.cast, base, 1.5);
      rival = q ? q.e : null;
    }
    const zs = g.zone;
    if (e && zs && !zoneClearLine(zs.def, pos.x, pos.z, e.x, e.z, zs.open)) e = null; // 벽 너머로는 가지 못한다
    const tg = e || rival;
    let dest = null;
    if (tg) {
      // 등 뒤 자리 -> 설 수 없으면 옆자리 -> 내 쪽 자리
      const r = (e ? e.info.radius : 0.5) + 1.0;
      const back = tg.yaw + Math.PI;
      const mine = Math.atan2(pos.x - tg.x, pos.z - tg.z);
      const gy = Math.max(g.world.heightAt(tg.x, tg.z), 0);
      for (const an of [back, back + 0.9, back - 0.9, mine]) {
        const x = tg.x + Math.sin(an) * r;
        const z = tg.z + Math.cos(an) * r;
        if (!this.standable(x, z, gy)) continue;
        if (zs && !zoneClearLine(zs.def, tg.x, tg.z, x, z, zs.open)) continue;
        dest = { x, z };
        break;
      }
    }
    if (tg && dest) {
      this.blink(dest.x, dest.z);
      pl.yaw = Math.atan2(tg.x - dest.x, tg.z - dest.z);
    } else {
      // 앞으로 미끄러진다 (벽이나 벼랑, 깊은 물 앞에서 멈춘다)
      let bx = pos.x;
      let bz = pos.z;
      let gy = Math.max(g.world.heightAt(bx, bz), -1);
      for (let d = 0.5; d <= sk.blink; d += 0.5) {
        const x = pos.x + Math.sin(base) * d;
        const z = pos.z + Math.cos(base) * d;
        if (!this.standable(x, z, gy)) break;
        if (!zs && Math.abs(g.world.heightAt(x, z) - gy) > 1.6) break;
        gy = g.world.heightAt(x, z);
        bx = x;
        bz = z;
      }
      this.blink(bx, bz);
      pl.yaw = base;
    }
    pl.skillInv = 0.45;
    this.act({ dur: 0.36, anim: ANIM.THRUST, move: 0, swing: 0.18 });
    this.begin(a, pl.pos.x, pl.pos.y, pl.pos.z, pl.yaw, [[from.x, from.z]]);
    this.v_step(from, pl.pos, a.col);
    if (tg && dest) {
      this.after(0.1, () => {
        const p = pl.pos;
        g.fx.slash(p.x, p.y + 1.0, p.z, pl.yaw, 3, 0xffffff, 1.3);
        g.fx.slash(p.x, p.y + 1.0, p.z, pl.yaw, 2, a.col, 1.1, 1.2);
        const n = this.hit(a, e && !e.dying ? [e.id] : [], rival ? [rival.id] : [], { shake: 0.45 });
        if (n) g.hitStop = Math.max(g.hitStop || 0, 0.07);
      });
    }
  }

  // 사라진 자리와 나타난 자리에 그림자 연기가 인다
  v_step(from, to, col) {
    const g = this.game;
    const fx = g.fx;
    for (const p of [from, to]) {
      fx.burst(p.x, p.y + 1.0, p.z, 0x2a2238, 14, 2.6, { size: 0.6, life: 0.5, grav: -1, glow: 1, alpha: 0.7 });
      fx.burst(p.x, p.y + 1.0, p.z, col, 8, 3.4, { size: 0.24, life: 0.4, grav: 0, glow: 2.4 });
    }
    const d = Math.hypot(to.x - from.x, to.z - from.z);
    const n = Math.min(24, Math.ceil(d / 0.6));
    for (let i = 1; i < n; i++) {
      const t = i / n;
      fx.spawn(from.x + (to.x - from.x) * t, from.y + (to.y - from.y) * t + 1.0, from.z + (to.z - from.z) * t, 0, 0.3, 0, i % 2 ? col : 0x4a3a66, 0.3, 0.3 + t * 0.2, 0, 0.8, 2);
    }
    g.audio.glide();
    g.audio.swing(1);
  }

  re_step(o, m, col) {
    const from = m.pts && m.pts[0] ? { x: m.pts[0][0], y: m.y, z: m.pts[0][1] } : o;
    this.v_step(from, { x: m.x, y: m.y, z: m.z }, col);
  }

  // 연막: 독 연막 속의 적은 독에 시달리고, 나는 잠깐 몬스터의 눈에서 사라진다
  do_smoke(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    const c = { x: pl.pos.x, y: Math.max(g.world.heightAt(pl.pos.x, pl.pos.z), 0), z: pl.pos.z };
    this.act({ dur: 0.34, anim: ANIM.ATK3, move: 0.7, swing: 0.2 });
    pl.buffs.hide = sk.dur;
    this.begin(a, c.x, c.y, c.z, pl.yaw);
    this.v_smoke(c, a.col, sk);
    for (let i = 0; i < sk.ticks; i++) {
      this.after(0.3 + i * sk.every, () => this.hit(a, g.ents.monstersInCircle(c.x, c.y, c.z, sk.r), g.ents.playersInCircle(c.x, c.y, c.z, sk.r), { fx: c.x, fz: c.z, shake: 0.06, kb: 0 }));
    }
  }

  v_smoke(c, col, sk) {
    const g = this.game;
    const dur = 0.3 + sk.ticks * sk.every;
    g.fx.burst(c.x, c.y + 0.6, c.z, 0x2c2638, 26, 5, { size: 0.9, life: 0.9, grav: -0.5, glow: 0.8, alpha: 0.6 });
    g.fx.ring(c.x, c.y + 0.2, c.z, col, sk.r, 0.5);
    this.mark(c.x, c.z, sk.r, dur, 0x6a4a9a);
    this.clouds.push({ kind: 'smoke', x: c.x, y: c.y, z: c.z, r: sk.r, t: 0, dur, col });
    g.audio.flame();
    g.audio.pop(false);
  }

  re_smoke(o, m, col) {
    this.v_smoke({ x: m.x, y: m.y, z: m.z }, col, JOBS[3].skills[2]);
  }

  // 달그림자 난무: 둘레의 적들 사이를 옮겨 다니며 여섯 번 벤다. 끝나면 제자리로 돌아온다
  do_dance(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    const pos = pl.pos;
    const zs = g.zone;
    const list = [];
    for (const e of g.ents.monsters.values()) {
      if (e.dying || !e.shown) continue;
      const d = Math.hypot(e.x - pos.x, e.z - pos.z) - e.info.radius;
      if (d > sk.cast) continue;
      if (zs && !zoneClearLine(zs.def, pos.x, pos.z, e.x, e.z, zs.open)) continue;
      list.push({ e, d });
    }
    list.sort((p, q) => p.d - q.d);
    list.length = Math.min(list.length, 6);
    const rivals = g.ents.playersInCircle(pos.x, pos.y, pos.z, sk.cast);
    if (!list.length && !rivals.length) {
      this.deny('가까이에 벨 적이 없습니다.');
      return false;
    }
    const home = { x: pos.x, y: pos.y, z: pos.z, yaw: pl.yaw };
    const T0 = 0.06;
    const total = T0 + sk.ticks * sk.every;
    pl.skillInv = total + 0.4;
    // 옮겨 다니는 동안 시점은 제자리에 머문다 (화면이 이리저리 튀지 않게)
    pl.camAnchor = { x: pos.x, y: pos.y, z: pos.z };
    pl.camAnchorT = total + 0.2;
    this.act({ dur: total + 0.22, anim: ANIM.ATK1, move: 0, prog: (t) => clamp((((t - T0) % sk.every) + sk.every) % sk.every / (sk.every * 0.8), 0, 1) });
    this.begin(a, pos.x, pos.y, pos.z, pl.yaw, list.map((q) => [q.e.x, q.e.z]));
    g.audio.glide();
    for (let i = 0; i < sk.ticks; i++) {
      this.after(T0 + i * sk.every, () => {
        // 살아 있는 적을 돌아가며 벤다
        let e = null;
        for (let n = 0; n < list.length && !e; n++) {
          const q = list[(i + n) % list.length].e;
          if (!q.dying && g.ents.monsters.get(q.id) === q) e = q;
        }
        const rid = e ? null : rivals[i % (rivals.length || 1)];
        const rv = rid !== null && rid !== undefined ? g.ents.players.get(rid) : null;
        const tg = e || rv;
        if (!tg) return;
        const was = { x: pl.pos.x, y: pl.pos.y, z: pl.pos.z };
        const r = (e ? e.info.radius : 0.5) + 1.0;
        const gy = Math.max(g.world.heightAt(tg.x, tg.z), 0);
        for (let n = 0; n < 5; n++) {
          const an = i * 2.4 + n * 1.3;
          const x = tg.x + Math.sin(an) * r;
          const z = tg.z + Math.cos(an) * r;
          if (!this.standable(x, z, gy) || (zs && !zoneClearLine(zs.def, tg.x, tg.z, x, z, zs.open))) continue;
          this.blink(x, z);
          break;
        }
        const p = pl.pos;
        pl.yaw = Math.atan2(tg.x - p.x, tg.z - p.z);
        if (pl.action && pl.action.type === 'skill') pl.action.anim = i % 2 ? ANIM.ATK2 : ANIM.ATK1;
        this.v_dance(was, p, pl.yaw, a.col, i);
        this.hit(a, e ? [e.id] : [], rv ? [rv.id] : [], { shake: 0.26 });
      });
    }
    this.after(total + 0.1, () => {
      // 제자리로 돌아온다
      const was = { x: pl.pos.x, y: pl.pos.y, z: pl.pos.z };
      this.blink(home.x, home.z);
      pl.yaw = home.yaw;
      this.v_step(was, pl.pos, a.col);
    });
  }

  v_dance(from, p, yaw, col, i) {
    const g = this.game;
    const fx = g.fx;
    fx.burst(from.x, from.y + 1.0, from.z, 0x2a2238, 6, 2.2, { size: 0.5, life: 0.35, grav: -1, glow: 1, alpha: 0.6 });
    fx.slash(p.x, p.y + 1.0, p.z, yaw, i % 2, i % 3 ? col : 0xffffff, 1.5, 2.0);
    fx.spawn(p.x, p.y + 1.1, p.z, 0, 0, 0, col, 0.9, 0.14, 0, 0.7, 2.6);
    g.audio.swing(i % 3, i === 5);
  }

  re_dance(o, m, col) {
    const sk = JOBS[3].skills[3];
    const pts = m.pts && m.pts.length ? m.pts : [[o.x, o.z]];
    let prev = { x: o.x, y: o.y, z: o.z };
    for (let i = 0; i < sk.ticks; i++) {
      const q = pts[i % pts.length];
      const p = { x: q[0] + Math.sin(i * 2.4) * 1.5, y: m.y, z: q[1] + Math.cos(i * 2.4) * 1.5 };
      const from = prev;
      this.after(0.06 + i * sk.every, () => this.v_dance(from, p, Math.atan2(q[0] - p.x, q[1] - p.z), col, i), false);
      prev = p;
    }
  }

  // ============================================================
  // 별술사
  // ============================================================
  // 별똥탄: 겨눈 적을 쫓아가는 별빛 덩어리
  do_bolt(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    const lk = pl.lock;
    let e = lk && Math.hypot(lk.x - pl.pos.x, lk.z - pl.pos.z) < sk.cast + 4 ? lk : null;
    let rival = null;
    if (!e) {
      const q = g.ents.aimTarget(pl.pos, pl.camYaw, this.cone() + 0.2, sk.cast);
      if (q) {
        e = q.e || null;
        rival = q.rival || null;
      }
    }
    if (!e && !rival) e = this.nearest(sk.cast * 0.75, pl.camYaw, Math.PI);
    const tg = e || rival;
    const yaw = tg ? Math.atan2(tg.x - pl.pos.x, tg.z - pl.pos.z) : pl.camYaw;
    pl.yaw = yaw;
    this.act({ dur: 0.32, anim: ANIM.THRUST, move: 0.6, swing: 0.14 });
    this.begin(a, tg ? tg.x : pl.pos.x + Math.sin(yaw) * sk.cast, pl.pos.y, tg ? tg.z : pl.pos.z + Math.cos(yaw) * sk.cast, yaw);
    this.after(0.1, () => {
      const p = pl.pos;
      this.orb(p.x + Math.sin(pl.yaw) * 0.7, p.y + 1.3, p.z + Math.cos(pl.yaw) * 0.7, Math.sin(yaw), 0.02, Math.cos(yaw), a.col, sk.cast, e, rival, (m, r, x, z) => this.hit(a, m ? [m.id] : [], r ? [r.id] : [], { shake: 0.22, fx: x, fz: z }));
    });
  }

  // 별빛 덩어리 한 발. e / rival: 쫓아갈 대상, done(m, r, x, z): 닿았을 때 (없으면 연출만)
  orb(x, y, z, dx, dy, dz, col, range, e, rival, done) {
    const g = this.game;
    const m = new THREE.Mesh(this.orbGeo, g.gfx.matGlow);
    m.position.set(x, y, z);
    g.gfx.scene.add(m);
    const sp = 30;
    const pop = (px, py, pz) => {
      g.fx.impact(px, py, pz, col, 1.6);
      g.fx.burst(px, py, pz, col, 16, 6, { size: 0.28, life: 0.4, grav: 3, glow: 2.8 });
      g.fx.burst(px, py, pz, 0xffffff, 6, 3, { size: 0.2, life: 0.3, grav: 0, glow: 3 });
    };
    this.shots.push({
      m, kind: 'orb', vx: dx * sp, vy: dy * sp, vz: dz * sp, g: 0, sp, life: range / sp + 0.5, fake: !done, home: e || rival || null, homeMon: !!e,
      trail: (p) => g.fx.spawn(p.x + rnd(0.2), p.y + rnd(0.2), p.z + rnd(0.2), rnd(0.8), rnd(0.8), rnd(0.8), Math.random() < 0.4 ? 0xffffff : col, 0.26, 0.32, 0, 1, 2.8),
      onMon: (q, px, py, pz) => {
        pop(px, py, pz);
        if (done) done(q, null, x, z);
      },
      onRival: (q, px, py, pz) => {
        pop(px, py, pz);
        if (done) done(null, q, x, z);
      },
      onEnd: pop,
    });
    g.audio.wave();
  }

  re_bolt(o, m, col) {
    const sk = JOBS[4].skills[0];
    // 겨눈 자리 가까이의 적을 쫓아가는 것처럼 보여 준다
    let e = null;
    let bd = 5;
    for (const q of this.game.ents.monsters.values()) {
      if (q.dying || !q.shown) continue;
      const d = Math.hypot(q.x - m.x, q.z - m.z);
      if (d < bd) {
        bd = d;
        e = q;
      }
    }
    this.after(0.1, () => this.orb(o.x + Math.sin(m.yaw) * 0.7, o.y + 1.3, o.z + Math.cos(m.yaw) * 0.7, Math.sin(m.yaw), 0.02, Math.cos(m.yaw), col, sk.cast, e, null, null), false);
  }

  // 별빛 고리: 고리가 퍼져 나가며 둘레의 적을 밀쳐 낸다
  do_nova(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    this.act({ dur: 0.5, anim: ANIM.CHEER, move: 0.4 });
    this.begin(a, pl.pos.x, pl.pos.y, pl.pos.z, pl.yaw);
    this.after(0.14, () => {
      const p = pl.pos;
      this.v_nova(p, a.col, sk.r);
      const n = this.hit(a, g.ents.monstersInCircle(p.x, p.y, p.z, sk.r), g.ents.playersInCircle(p.x, p.y, p.z, sk.r), { shake: 0.4 });
      if (n) g.hitStop = Math.max(g.hitStop || 0, 0.06);
    });
  }

  v_nova(p, col, r) {
    const g = this.game;
    const fx = g.fx;
    fx.ring(p.x, p.y + 0.3, p.z, col, r, 0.4);
    fx.ring(p.x, p.y + 0.9, p.z, 0xffffff, r * 0.8, 0.32);
    fx.ring(p.x, p.y + 1.5, p.z, col, r * 0.55, 0.26);
    for (let i = 0; i < 36; i++) {
      const an = (i / 36) * TAU;
      fx.spawn(p.x + Math.sin(an), p.y + 0.4 + Math.random() * 1.2, p.z + Math.cos(an), Math.sin(an) * r * 2.6, 0.5, Math.cos(an) * r * 2.6, i % 3 ? col : 0xffffff, 0.3, 0.36, 0, 1, 2.8);
    }
    g.audio.wave();
    g.audio.thud();
  }

  re_nova(o, m, col) {
    this.after(0.14, () => this.v_nova(o, col, JOBS[4].skills[1].r), false);
  }

  // 치유의 별빛: 나와 곁의 친구들의 체력을 되찾아 준다
  do_heal(a) {
    const g = this.game;
    const pl = g.player;
    this.act({ dur: 0.6, anim: ANIM.CHEER, move: 0.3 });
    this.begin(a, pl.pos.x, pl.pos.y, pl.pos.z, pl.yaw);
    this.v_heal(pl.pos, a.sk.r);
    this.effect(a.sk, a.col);
  }

  v_heal(p, r) {
    const g = this.game;
    const fx = g.fx;
    fx.ring(p.x, p.y + 0.3, p.z, 0x8dffb0, r, 0.8);
    fx.ring(p.x, p.y + 0.3, p.z, 0xffffff, r * 0.5, 0.5);
    for (let i = 0; i < 40; i++) {
      const an = Math.random() * TAU;
      const d = Math.sqrt(Math.random()) * Math.min(r, 6);
      fx.spawn(p.x + Math.sin(an) * d, p.y + 0.2 + Math.random() * 0.5, p.z + Math.cos(an) * d, 0, 2 + Math.random() * 3, 0, i % 3 ? 0x8dffb0 : 0xfff6c0, 0.24, 0.8 + Math.random() * 0.5, -1, 1, 2.6, 0.5, 0.1);
    }
    g.audio.heal();
    g.audio.seal();
  }

  re_heal(o, m) {
    this.v_heal(o, JOBS[4].skills[2].r);
  }

  // 별무리 낙하: 겨눈 자리에 별똥이 여섯 번 쏟아진다
  do_meteor(a) {
    const g = this.game;
    const pl = g.player;
    const sk = a.sk;
    const pt = this.aimPoint(sk.cast, 10);
    if (Math.hypot(pt.x - pl.pos.x, pt.z - pl.pos.z) > 0.5) pl.yaw = Math.atan2(pt.x - pl.pos.x, pt.z - pl.pos.z);
    this.act({ dur: 0.6, anim: ANIM.CHEER, move: 0.2 });
    this.begin(a, pt.x, pt.y, pt.z, pl.yaw);
    g.audio.portal();
    this.v_meteor(pt, a.col, sk, (i) => {
      const n = this.hit(a, g.ents.monstersInCircle(pt.x, pt.y, pt.z, sk.r), g.ents.playersInCircle(pt.x, pt.y, pt.z, sk.r), { fx: pt.x, fz: pt.z, shake: 0.3 });
      if (n && i === sk.ticks - 1) g.hitStop = Math.max(g.hitStop || 0, 0.07);
    });
  }

  // 별똥이 하나씩 떨어진다. onHit(i): 땅에 닿는 순간 (연출만이면 null)
  v_meteor(pt, col, sk, onHit) {
    const g = this.game;
    const T0 = 0.5;
    this.mark(pt.x, pt.z, sk.r, T0 + sk.ticks * sk.every, col);
    for (let i = 0; i < sk.ticks; i++) {
      const an = i * 2.3 + 0.7;
      const d = i === sk.ticks - 1 ? 0 : sk.r * 0.55;
      const x = pt.x + Math.sin(an) * d;
      const z = pt.z + Math.cos(an) * d;
      const at = T0 + i * sk.every;
      const fall = 0.36;
      this.after(at - fall, () => {
        const m = new THREE.Mesh(this.meteorGeo, g.gfx.matGlow);
        m.scale.setScalar(i === sk.ticks - 1 ? 1.6 : 1);
        g.gfx.scene.add(m);
        this.clouds.push({ kind: 'fall', m, x, y: pt.y, z, x0: x - 5, y0: pt.y + 22, z0: z - 3, t: 0, dur: fall, col });
      }, false);
      this.after(at, () => {
        const big = i === sk.ticks - 1;
        g.fx.quake(x, pt.y, z, big ? sk.r * 0.8 : 3.2, col);
        g.fx.burst(x, pt.y + 0.5, z, col, big ? 40 : 18, big ? 10 : 7, { size: 0.36, life: 0.6, grav: 8, glow: 2.8 });
        g.fx.impact(x, pt.y + 0.8, z, 0xffffff, big ? 3 : 1.8);
        const pl = g.player;
        const dd = Math.hypot(pl.pos.x - x, pl.pos.z - z);
        if (dd < 40) pl.shake = Math.max(pl.shake, (big ? 0.6 : 0.3) * (1 - dd / 40));
        g.audio.thud();
        if (onHit) onHit(i);
      }, !!onHit);
    }
  }

  re_meteor(o, m, col) {
    this.v_meteor({ x: m.x, y: m.y, z: m.z }, col, JOBS[4].skills[3], null);
  }

  // ============================================================
  // 곁의 사람들도 함께 받는 효과 (수호의 함성 · 치유의 별빛)
  effect(sk, col, from) {
    const g = this.game;
    const pl = g.player;
    if (pl.state === 'dead') return;
    const p = pl.pos;
    if (sk.effect === 'guard') pl.buffs.ward = Math.max(pl.buffs.ward || 0, sk.dur);
    if (sk.heal) {
      const n = Math.max(1, Math.round(pl.maxHp * sk.heal));
      const was = pl.hp;
      pl.heal(n);
      if (pl.hp > was) g.fx.text(p.x, p.y + 2.3, p.z, `+${(pl.hp - was) * HP_SHOW}`, 'heal');
    }
    g.fx.burst(p.x, p.y + 1.2, p.z, sk.effect === 'heal' ? 0x8dffb0 : col, 16, 3, { size: 0.3, life: 0.7, grav: -1.5, glow: 2.2 });
    if (from) {
      g.ui.toast(sk.effect === 'heal' ? `${from} 님의 「${sk.name}」 — 체력을 되찾았습니다` : `${from} 님의 「${sk.name}」 — ${sk.dur}초 동안 받는 피해가 줄어듭니다`, true);
      g.audio.heal();
    }
    g.ui.dirty = true;
  }

  // 서버가 알려 준 것: 곁의 모험가가 나에게도 닿는 기술을 썼다
  onBuff(m) {
    const J = JOBS[m.c];
    const sk = J && J.skills[m.k];
    if (!sk || !sk.effect || sk.effect === 'hide') return;
    const e = this.game.ents.players.get(m.by);
    this.effect(sk, J.color, e ? e.prof.name : '누군가');
  }

  // 다른 모험가의 기술 연출
  onRemote(m) {
    const g = this.game;
    const J = JOBS[m.c];
    const sk = J && J.skills[m.k];
    const e = g.ents.players.get(m.by);
    if (!sk || !e || !e.seen || e.zone !== (g.zone ? g.zone.id : 0)) return;
    const fn = this['re_' + sk.key];
    if (fn) fn.call(this, { x: e.x, y: e.y, z: e.z }, m, J.color);
  }

  // ---------- 매 프레임 ----------
  // dt: 게임 속 시간, real: 실제로 흐른 시간 (예약과 재사용 시간은 실제 시간을 따른다 — 서버의 시계와 맞아야 한다)
  update(dt, real) {
    const g = this.game;
    const pl = g.player;
    for (let k = 0; k < 4; k++) if (this.cd[k] > 0) this.cd[k] = Math.max(0, this.cd[k] - real);
    this.denyT -= real;
    if (this.timers.length) {
      const dead = pl.state === 'dead';
      const run = [];
      for (let i = 0; i < this.timers.length;) {
        const tm = this.timers[i];
        tm.t -= real;
        if (tm.t <= 0) {
          this.timers.splice(i, 1);
          if (!(tm.alive && dead)) run.push(tm);
        } else i++;
      }
      for (const tm of run) tm.fn();
    }
    if (this.shots.length) this.updateShots(dt);
    if (this.clouds.length) this.updateClouds(dt, real);
    // 연막 속에 숨은 동안: 몸 둘레에 그림자가 감돈다
    if (pl.buffs.hide > 0 && Math.random() < dt * 30) {
      const p = pl.pos;
      g.fx.spawn(p.x + rnd(1), p.y + Math.random() * 1.8, p.z + rnd(1), 0, 0.5, 0, Math.random() < 0.7 ? 0x2a2238 : 0xc08aff, 0.4, 0.5, 0, 0.6, 1.2);
    }
    // 4차 전직의 기운: 발치에서 그 길의 빛이 이따금 피어오른다
    const j = g.jobs.job();
    if (j.t >= 4 && pl.state !== 'dead' && pl.rig.root.visible && Math.random() < dt * 5) this.aura(pl.pos, JOBS[j.c].color);
    if (pl.buffs.ward > 0 && Math.random() < dt * 14) {
      const an = Math.random() * TAU;
      const p = pl.pos;
      g.fx.spawn(p.x + Math.sin(an) * 0.8, p.y + 0.2, p.z + Math.cos(an) * 0.8, 0, 2.2, 0, 0xffb872, 0.18, 0.7, 0, 0.9, 2.4);
    }
  }

  aura(p, col) {
    const an = Math.random() * TAU;
    this.game.fx.spawn(p.x + Math.sin(an) * 0.55, p.y + 0.1 + Math.random() * 0.4, p.z + Math.cos(an) * 0.55, 0, 1.1 + Math.random() * 0.8, 0, Math.random() < 0.3 ? 0xffffff : col, 0.13, 0.8, -0.2, 0.85, 2.4, 0.25, 0.15);
  }

  updateShots(dt) {
    const g = this.game;
    const ents = g.ents;
    const zs = g.zone;
    const world = g.world;
    for (let i = this.shots.length - 1; i >= 0; i--) {
      const s = this.shots[i];
      const m = s.m;
      s.life -= dt;
      const ox = m.position.x;
      const oy = m.position.y;
      const oz = m.position.z;
      if (s.home) {
        const e = s.home;
        // 쫓던 대상이 사라졌으면 곧게 날아간다
        if (s.homeMon ? e.dying || ents.monsters.get(e.id) !== e : ents.players.get(e.id) !== e) s.home = null;
        else {
          const ty = e.y + (s.homeMon ? e.info.def.height * (e.info.elite ? 1.45 : 1) * 0.55 : 1.0);
          _d.set(e.x - ox, ty - oy, e.z - oz);
          const l = _d.length() || 1;
          s.vx = (_d.x / l) * s.sp;
          s.vy = (_d.y / l) * s.sp;
          s.vz = (_d.z / l) * s.sp;
        }
      }
      s.vy -= s.g * dt;
      m.position.x += s.vx * dt;
      m.position.y += s.vy * dt;
      m.position.z += s.vz * dt;
      if (s.kind === 'orb') {
        m.rotation.x += dt * 9;
        m.rotation.y += dt * 7;
      } else m.lookAt(m.position.x + s.vx, m.position.y + s.vy, m.position.z + s.vz);
      if (s.trail) s.trail(m.position);
      let done = false;
      let ended = s.life <= 0;
      // 선분-구 충돌 (빠르게 날아도 적을 지나치지 않도록)
      const sx = m.position.x - ox;
      const sy = m.position.y - oy;
      const sz = m.position.z - oz;
      const sl2 = sx * sx + sy * sy + sz * sz || 1;
      for (const e of ents.monsters.values()) {
        if (e.dying || !e.shown) continue;
        const hgt = e.info.def.height * (e.info.elite ? 1.45 : 1);
        const cx = e.x;
        const cy = e.y + hgt * 0.5;
        const cz = e.z;
        let t = ((cx - ox) * sx + (cy - oy) * sy + (cz - oz) * sz) / sl2;
        t = t < 0 ? 0 : t > 1 ? 1 : t;
        const qx = ox + sx * t - cx;
        const qy = (oy + sy * t - cy) * (e.info.radius / Math.max(hgt * 0.55, e.info.radius));
        const qz = oz + sz * t - cz;
        const rr = e.info.radius + (s.kind === 'arrow' ? 0.35 : 0.55);
        if (qx * qx + qy * qy + qz * qz < rr * rr) {
          s.onMon(e, ox + sx * t, oy + sy * t, oz + sz * t);
          done = true;
          break;
        }
      }
      if (!done && !s.fake && s.onRival) {
        for (const e of ents.rivals()) {
          const cx = e.x;
          const cy = e.y + 1.0;
          const cz = e.z;
          let t = ((cx - ox) * sx + (cy - oy) * sy + (cz - oz) * sz) / sl2;
          t = t < 0 ? 0 : t > 1 ? 1 : t;
          const qx = ox + sx * t - cx;
          const qy = (oy + sy * t - cy) * 0.6;
          const qz = oz + sz * t - cz;
          if (qx * qx + qy * qy + qz * qz < 0.8 * 0.8) {
            s.onRival(e, ox + sx * t, oy + sy * t, oz + sz * t);
            done = true;
            break;
          }
        }
      }
      // 벽(실내)과 땅에 막힌다
      if (!done && !ended && zs && m.position.y < ZONE_FLOOR + WALL_H && zoneSolid(zs.def, m.position.x, m.position.z, zs.open)) {
        m.position.set(ox, oy, oz);
        ended = true;
      }
      if (!done && !ended && m.position.y < Math.max(world.heightAt(m.position.x, m.position.z), 0) + 0.05) ended = true;
      if (!done && ended) {
        if (s.onEnd) s.onEnd(m.position.x, m.position.y, m.position.z);
        else g.fx.burst(m.position.x, m.position.y + 0.1, m.position.z, 0xd8cfb8, 5, 2.5, { size: 0.24, life: 0.25 });
        done = true;
      }
      if (done) {
        g.gfx.scene.remove(m);
        this.shots.splice(i, 1);
      }
    }
  }

  updateClouds(dt, real) {
    const g = this.game;
    const fx = g.fx;
    for (let i = this.clouds.length - 1; i >= 0; i--) {
      const c = this.clouds[i];
      c.t += real;
      if (c.kind === 'fall') {
        // 하늘에서 비스듬히 떨어지는 별똥
        const k = Math.min(1, c.t / c.dur);
        const x = c.x0 + (c.x - c.x0) * k;
        const y = c.y0 + (c.y - c.y0) * k;
        const z = c.z0 + (c.z - c.z0) * k;
        c.m.position.set(x, y, z);
        c.m.rotation.x += dt * 8;
        c.m.rotation.z += dt * 6;
        for (let n = 0; n < 3; n++) fx.spawn(x + rnd(0.6), y + rnd(0.6), z + rnd(0.6), rnd(1), 2 + Math.random() * 2, rnd(1), n ? c.col : 0xffffff, 0.4, 0.4, 0, 1, 2.8);
        if (k >= 1) {
          g.gfx.scene.remove(c.m);
          this.clouds.splice(i, 1);
        }
        continue;
      }
      if (c.t >= c.dur) {
        this.clouds.splice(i, 1);
        continue;
      }
      if (c.t < 0) continue;
      if (c.kind === 'rain') {
        // 쏟아지는 화살: 하늘에서 화살이 비스듬히 내리꽂히고, 빛줄기가 뒤따른다 (1초에 스무 발쯤)
        c.acc += real * 20;
        let n = Math.min(6, Math.floor(c.acc));
        c.acc -= n;
        while (n-- > 0) {
          const an = Math.random() * TAU;
          const d = Math.sqrt(Math.random()) * c.r;
          const x = c.x + Math.sin(an) * d;
          const z = c.z + Math.cos(an) * d;
          g.ents.spawnArrow(x + 2.2, c.y + 12, z + 1.1, -0.18, -0.98, -0.09, false);
          for (let q = 0; q < 3; q++) fx.spawn(x + 2.2 - q * 0.5, c.y + 12 - q * 2.8, z + 1.1 - q * 0.25, -9, -50, -4.5, q ? c.col : 0xffffff, 0.2, 0.22, 0, 1, 2.6);
          fx.spawn(x, c.y + 0.2, z, rnd(2.5), 2 + Math.random() * 2, rnd(2.5), 0xffffff, 0.16, 0.3, 9, 0.9, 2);
        }
      } else if (c.kind === 'smoke') {
        // 독 연막: 느리게 피어오르는 짙은 연기
        const n = Math.min(5, Math.ceil(dt * 46));
        for (let q = 0; q < n; q++) {
          const an = Math.random() * TAU;
          const d = Math.sqrt(Math.random()) * c.r;
          // 짙은 보랏빛 · 풀빛 연기 사이로 독 기운이 이따금 반짝인다
          if (Math.random() < 0.12) fx.spawn(c.x + Math.sin(an) * d, c.y + 0.3 + Math.random() * 1.4, c.z + Math.cos(an) * d, 0, 0.8, 0, c.col, 0.2, 0.7, 0, 0.9, 2.2, 0.5, 0.15);
          else fx.spawn(c.x + Math.sin(an) * d, c.y + 0.2 + Math.random() * 1.6, c.z + Math.cos(an) * d, rnd(0.8), 0.3 + Math.random() * 0.5, rnd(0.8), q % 2 ? 0x2c2638 : 0x34503c, 1.0 + Math.random() * 0.8, 1.2, 0, 0.5, 0.8, 0.6, 0.3);
        }
      }
    }
  }
}

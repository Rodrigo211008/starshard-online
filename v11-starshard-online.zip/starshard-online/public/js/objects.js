// 월드에 고정된 물체: 마을, 별조각 제단, 귀환석, 야영지, 보물상자, 열매 덤불, NPC
import * as THREE from '/vendor/three/three.module.js';
import { VILLAGE_LAYOUT, SHARD_COUNT } from '/shared/defs.js';
import { VILLAGE, VOLCANO } from '/shared/world.js';
import { Geo, M } from './geo.js';
import { makeHumanoid, animateHumanoid, npcLook, POSE } from './models.js';

const BUSH_RESPAWN_MS = 4 * 60 * 1000;

// 고정된 물체의 메시를 구역(가로세로 240m)별로 나누어 담는다.
// 세계 전체를 한 덩어리로 합치면 보이지 않는 먼 곳까지 매번 그리게 되므로, 가까운 구역만 그린다.
class Buckets {
  constructor(size) {
    this.size = size;
    this.map = new Map();
    this.cur = null;
  }

  // 이제부터 넣는 도형은 (x, z) 가 속한 구역에 담긴다
  at(x, z) {
    const key = `${Math.floor(x / this.size)},${Math.floor(z / this.size)}`;
    let g = this.map.get(key);
    if (!g) this.map.set(key, (g = new Geo()));
    this.cur = g;
    return this;
  }
}
for (const name of ['box', 'taperBox', 'cyl', 'cone', 'ico', 'roof', 'quad', 'tri', 'merge']) {
  Buckets.prototype[name] = function (...args) {
    this.cur[name](...args);
    return this;
  };
}

function hash1(n) {
  let h = Math.imul(n | 0, 374761393);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

export function chestLoot(chest) {
  const r = hash1(chest.id * 7919 + 13);
  const big = chest.kind !== 'wild';
  return {
    gold: Math.round((14 + r * 22) * chest.tier * (big ? 1.7 : 1)),
    berries: (chest.tier >= 2 || r > 0.45 ? 1 : 0) + (big ? 1 : 0),
    arrows: 4 + chest.tier * 2,
  };
}

// 이름표 스프라이트
export function makeLabel(text, color = '#ffffff', sub = '') {
  const cv = document.createElement('canvas');
  cv.width = 384;
  cv.height = 96;
  const ctx = cv.getContext('2d');
  ctx.font = '700 40px "Pretendard", "Apple SD Gothic Neo", "Noto Sans KR", "Malgun Gothic", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineJoin = 'round';
  ctx.lineWidth = 9;
  ctx.strokeStyle = 'rgba(15,20,35,0.85)';
  const full = sub ? `${text}  ${sub}` : text;
  // 긴 이름표(이름 + 레벨 + 칭호)는 글자를 줄여서 한 줄에 담는다
  const wide = ctx.measureText(full).width;
  if (wide > 366) ctx.font = `700 ${Math.max(22, Math.floor((40 * 366) / wide))}px "Pretendard", "Apple SD Gothic Neo", "Noto Sans KR", "Malgun Gothic", sans-serif`;
  ctx.strokeText(full, 192, 48);
  ctx.fillStyle = color;
  ctx.fillText(full, 192, 48);
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false }));
  sp.scale.set(3.2, 0.8, 1);
  sp.renderOrder = 10;
  return sp;
}

export class WorldObjects {
  constructor(game) {
    this.game = game;
    const { gfx, world, pois } = game;
    this.group = new THREE.Group();
    gfx.scene.add(this.group);
    this.colliders = [];
    this.interactables = [];
    this.rests = [{ x: VILLAGE.x, z: VILLAGE.z, r: 36 }];
    this.flames = [];
    this.spinners = [];
    this.lightSrc = []; // 주변을 밝히는 불빛 (모닥불, 가로등, 별조각)
    this.lightSlots = gfx.pointLights.map((light) => ({ light, src: null, k: 0 }));
    this._want = [];
    this.glowMatBeam = new THREE.MeshBasicMaterial({ color: 0x9fe8ff, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
    this.glowMatBeamSealed = this.glowMatBeam.clone();
    this.glowMatBeamSealed.color.setHex(0xff5a9a);
    this.sealMat = new THREE.MeshBasicMaterial({ color: 0xb04aff, transparent: true, opacity: 0.32, depthWrite: false, fog: false });

    const H = (x, z) => world.heightAt(x, z);
    const stat = new Buckets(240); // 정적 메시 (구역별로 합침)
    const glow = new Geo(); // 발광 정적 메시
    const win = new Geo(); // 창문 (밤에 불이 켜진다)

    stat.at(VILLAGE.x, VILLAGE.z);
    this._buildVillage(stat, glow, win, H);
    this._buildShrines(stat, H);
    this._buildStones(stat, H);
    this._buildCamps(stat, H);
    this._buildArena(stat, glow, H);
    this._buildBushes(stat, H);

    this.statics = [];
    for (const geo of stat.map.values()) {
      if (!geo.vertCount) continue;
      const sm = new THREE.Mesh(geo.build(false), gfx.matChar);
      sm.castShadow = true;
      sm.receiveShadow = true;
      sm.matrixAutoUpdate = false;
      this.group.add(sm);
      const bs = sm.geometry.boundingSphere;
      this.statics.push({ m: sm, x: bs.center.x, z: bs.center.z, r: bs.radius });
    }
    const gm = new THREE.Mesh(glow.build(false), gfx.matGlow);
    gm.frustumCulled = false;
    this.group.add(gm);
    const wm = new THREE.Mesh(win.build(false), gfx.matWindow);
    wm.frustumCulled = false;
    this.group.add(wm);

    this._buildChests(H);
    this._buildNpcs(H);
  }

  // ---------------- 마을 ----------------
  _buildVillage(g, glow, win, H) {
    const vx = VILLAGE.x;
    const vz = VILLAGE.z;
    const L = VILLAGE_LAYOUT;
    // 창틀 + 유리 + 창살 (alongX: 벽이 x 방향으로 뻗어 있는지)
    const windowAt = (wx, wy, wz, alongX) => {
      const d = (a, b, c) => (alongX ? [a, b, c] : [c, b, a]);
      g.box(...d(1.12, 1.12, 0.1), M(wx, wy, wz), 0x6a4a2c);
      win.box(...d(0.9, 0.9, 0.16), M(wx, wy, wz), 0xffffff);
      g.box(...d(0.07, 0.9, 0.2), M(wx, wy, wz), 0x6a4a2c);
      g.box(...d(0.9, 0.07, 0.2), M(wx, wy, wz), 0x6a4a2c);
      g.box(...d(1.2, 0.08, 0.3), M(wx, wy - 0.56, wz), 0x7a5a3a);
    };
    for (const h of L.houses) {
      const x = vx + h.x;
      const z = vz + h.z;
      const y = H(x, z) - 0.15;
      const front = h.z < 0 ? 1 : -1;
      g.box(h.w, 3.2, h.d, M(x, y + 1.6, z), 0xe2d5b4, 0xf7efdc);
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) g.box(0.28, 3.3, 0.28, M(x + (sx * h.w) / 2, y + 1.65, z + (sz * h.d) / 2), 0x6a4a2c);
      g.box(h.w + 0.3, 0.22, h.d + 0.3, M(x, y + 3.2, z), 0x6a4a2c);
      g.box(h.w + 0.1, 0.2, h.d + 0.1, M(x, y + 1.5, z), 0x7a5a3a);
      g.roof(h.w + 1.2, 2.4, h.d + 1.2, M(x, y + 3.3, z), (h.roof & 0xfefefe) >> 1, h.roof);
      g.box(1.15, 2.1, 0.14, M(x + h.w * 0.15, y + 1.05, z + (front * h.d) / 2), 0x5a3d25, 0x7a5535);
      g.box(0.1, 0.1, 0.06, M(x + h.w * 0.15 + 0.38, y + 1.05, z + front * (h.d / 2 + 0.08)), 0xe6c14a);
      windowAt(x - h.w * 0.25, y + 1.85, z + (front * h.d) / 2, true);
      windowAt(x + h.w / 2, y + 1.85, z, false);
      windowAt(x - h.w / 2, y + 1.85, z, false);
      g.box(0.7, 1.6, 0.7, M(x - h.w * 0.25, y + 5.1, z - h.d * 0.15), 0x8a8078, 0xa59a90);
      this.colliders.push({ x, z, hw: h.w / 2 + 0.1, hd: h.d / 2 + 0.1 });
    }
    // 가판대
    for (const s of L.stalls) {
      const x = vx + s.x;
      const z = vz + s.z;
      const y = H(x, z) - 0.05;
      const c1 = s.kind === 'merchant' ? 0x4f9a5a : 0x9a3a34;
      g.box(3.4, 1.0, 1.2, M(x, y + 0.5, z), 0x7a5a3a, 0xa07a4c);
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) g.box(0.16, 2.7, 0.16, M(x + sx * 1.7, y + 1.35, z + sz * 0.75), 0x6a4a2c);
      g.roof(4.2, 0.8, 2.6, M(x, y + 2.7, z), c1, 0xf2ead8);
      if (s.kind === 'merchant') {
        g.ico(0.16, 0, M(x - 0.9, y + 1.12, z), 0xe0304a);
        g.ico(0.16, 0, M(x - 0.6, y + 1.12, z + 0.15), 0xe0304a);
        g.ico(0.16, 0, M(x - 0.75, y + 1.28, z + 0.05), 0xe0304a);
        g.box(0.5, 0.3, 0.4, M(x + 0.2, y + 1.15, z), 0xc9a05a);
        g.cyl(0.2, 0.2, 0.5, 6, M(x + 1.0, y + 1.25, z), 0x9c7449);
      } else {
        g.box(0.9, 0.35, 0.45, M(x - 0.7, y + 1.18, z), 0x3a3a42, 0x55555f);
        g.box(0.5, 0.3, 0.35, M(x - 0.7, y + 1.0, z), 0x2a2a30);
        g.box(0.08, 0.9, 0.03, M(x + 0.5, y + 1.3, z, 0, 0, 1.2), 0xdfe7ee);
        g.box(0.08, 0.9, 0.03, M(x + 0.9, y + 1.25, z + 0.2, 0, 0.4, 1.2), 0xbfe9ff);
      }
      this.colliders.push({ x, z, hw: 1.8, hd: 0.7 });
    }
    // 우물
    {
      const x = vx + L.well.x;
      const z = vz + L.well.z;
      const y = H(x, z);
      g.cyl(1.25, 1.35, 0.9, 10, M(x, y + 0.45, z), 0x8a8f98, 0xb0b5bd);
      g.cyl(1.0, 1.0, 0.1, 10, M(x, y + 0.86, z), 0x2f6fa8);
      g.box(0.16, 2.2, 0.16, M(x - 1.15, y + 1.1, z), 0x6a4a2c);
      g.box(0.16, 2.2, 0.16, M(x + 1.15, y + 1.1, z), 0x6a4a2c);
      g.roof(3.0, 0.8, 1.6, M(x, y + 2.2, z), 0x8a3a2c, 0xb5523a);
      this.colliders.push({ x, z, r: L.well.r });
    }
    // 의뢰 게시판 (현상금): 마을 남쪽, 꼬마 옆
    {
      const x = vx + 9.5;
      const z = vz + 11;
      const y = H(x, z);
      g.box(0.2, 2.7, 0.2, M(x - 1.3, y + 1.35, z), 0x6a4a2c);
      g.box(0.2, 2.7, 0.2, M(x + 1.3, y + 1.35, z), 0x6a4a2c);
      g.box(2.9, 1.8, 0.14, M(x, y + 1.8, z), 0x9c7449, 0xc9a05a);
      g.roof(3.3, 0.5, 0.9, M(x, y + 2.8, z), 0x8a3a2c, 0xb5523a);
      // 붙어 있는 종이들
      for (const [px, py, c] of [[-0.85, 2.15, 0xfff3d0], [0.05, 2.2, 0xf4ecda], [0.9, 2.05, 0xfff3d0], [-0.4, 1.5, 0xf4ecda], [0.55, 1.45, 0xffe9a8]]) {
        g.box(0.62, 0.52, 0.03, M(x + px, y + py, z + 0.09, 0, 0, px * 0.12), c);
        g.box(0.4, 0.05, 0.035, M(x + px, y + py + 0.08, z + 0.1, 0, 0, px * 0.12), 0x6a5a48);
        g.box(0.3, 0.05, 0.035, M(x + px - 0.04, y + py - 0.06, z + 0.1, 0, 0, px * 0.12), 0x8a7a66);
      }
      this.colliders.push({ x, z, hw: 1.55, hd: 0.3 });
      this.board = { x, y, z };
      this.interactables.push({ kind: 'board', ref: null, x, z: z + 0.9, r: 3.1, active: () => true, label: () => '의뢰 게시판 보기 (현상금)' });
    }
    // 수련터 (마을 북동쪽, 스승 가람의 자리): 깃발, 허수아비 둘, 무기 걸이
    {
      // 네 갈래 길의 빛깔을 단 깃발
      const fx = vx + 14.6;
      const fz = vz - 23.2;
      const fy = H(fx, fz);
      g.cyl(0.07, 0.09, 4.6, 6, M(fx, fy + 2.3, fz), 0x6a4a2c);
      g.ico(0.14, 0, M(fx, fy + 4.7, fz), 0xe6c14a);
      g.box(0.05, 2.1, 1.25, M(fx, fy + 3.35, fz + 0.7), 0x26354f, 0x2f4a7a);
      [0xffa24a, 0x8fe06a, 0xc08aff, 0x7ac0ff].forEach((c, i) => g.box(0.07, 0.3, 0.3, M(fx, fy + 4.05 - i * 0.46, fz + 0.7, 0.785, 0, 0), c));
      this.colliders.push({ x: fx, z: fz, r: 0.25 });
      // 허수아비
      for (const [dx, dz, ry] of [[15.3, -26.3, 0.6], [17.6, -24.6, -0.5]]) {
        const x = vx + dx;
        const z = vz + dz;
        const y = H(x, z);
        g.cyl(0.09, 0.11, 2.0, 6, M(x, y + 1.0, z), 0x6a4a2c);
        g.box(1.5, 0.12, 0.12, M(x, y + 1.5, z, 0, ry, 0), 0x6a4a2c);
        g.cyl(0.36, 0.3, 0.95, 8, M(x, y + 1.15, z), 0xd9b96a, 0xf0d890);
        g.ico(0.27, 0, M(x, y + 2.0, z), 0xd9b96a, 0xf0d890, 0.15, 4);
        g.cyl(0.38, 0.38, 0.1, 8, M(x, y + 1.42, z), 0xc8452f);
        this.colliders.push({ x, z, r: 0.5 });
      }
      // 무기 걸이: 검, 창, 망치
      const rx = vx + 10.9;
      const rz = vz - 27;
      const ry = H(rx, rz);
      for (const sx of [-1, 1]) g.box(0.14, 1.6, 0.14, M(rx + sx * 1.0, ry + 0.8, rz), 0x6a4a2c);
      g.box(2.2, 0.1, 0.16, M(rx, ry + 1.5, rz), 0x7a5a3a);
      g.box(2.2, 0.1, 0.16, M(rx, ry + 0.45, rz), 0x7a5a3a);
      g.box(0.09, 1.25, 0.03, M(rx - 0.6, ry + 1.05, rz + 0.12), 0xdfe7ee, 0xb4c0cf);
      g.box(0.34, 0.07, 0.07, M(rx - 0.6, ry + 0.42, rz + 0.12), 0xe6c14a);
      g.cyl(0.03, 0.03, 2.0, 5, M(rx, ry + 1.05, rz + 0.12), 0x9c7449);
      g.cone(0.08, 0.28, 4, M(rx, ry + 2.18, rz + 0.12), 0xdfe7ee);
      g.cyl(0.035, 0.035, 1.3, 5, M(rx + 0.6, ry + 0.85, rz + 0.12), 0x9c7449);
      g.box(0.42, 0.26, 0.24, M(rx + 0.6, ry + 1.55, rz + 0.12), 0x7f848c, 0xb0b5bd);
      this.colliders.push({ x: rx, z: rz, hw: 1.15, hd: 0.25 });
    }
    // 별의 제단
    {
      const x = vx + L.altar.x;
      const z = vz + L.altar.z;
      const y = H(x, z);
      this.altar = { x, y, z };
      g.cyl(3.5, 3.9, 0.5, 12, M(x, y + 0.2, z), 0x9a968c, 0xc4c0b6);
      g.cyl(1.7, 1.9, 0.5, 8, M(x, y + 0.65, z), 0xa8a49a, 0xd0ccc2);
      g.taperBox(1.0, 4.4, 1.0, 0.4, M(x, y + 3.0, z, 0, 0.785, 0), 0xb8b4aa, 0xe8e4da);
      for (let k = 0; k < SHARD_COUNT; k++) {
        const a = (k / SHARD_COUNT) * Math.PI * 2;
        g.cyl(0.2, 0.26, 0.7, 6, M(x + Math.sin(a) * 2.75, y + 0.8, z + Math.cos(a) * 2.75), 0xa8a49a, 0xd0ccc2);
      }
      this.colliders.push({ x, z, r: 1.9 });
      // 꼭대기 별
      const sg = new Geo();
      sg.cone(0.38, 0.6, 4, M(0, 0.3, 0), 0xfff2a8);
      sg.cone(0.38, 0.6, 4, M(0, -0.3, 0, Math.PI, 0, 0), 0xffd65a);
      const star = new THREE.Mesh(sg.build(false), this.game.gfx.matGlow);
      star.position.set(x, y + 6.0, z);
      this.group.add(star);
      this.spinners.push(star);
      // 받침대 위의 별조각 (모은 만큼 켜진다)
      this.altarShards = [];
      for (let k = 0; k < SHARD_COUNT; k++) {
        const a = (k / SHARD_COUNT) * Math.PI * 2;
        const cg = new Geo();
        cg.cone(0.16, 0.26, 4, M(0, 0.13, 0), 0xfff2a8);
        cg.cone(0.16, 0.26, 4, M(0, -0.13, 0, Math.PI, 0, 0), 0xffd65a);
        const m = new THREE.Mesh(cg.build(false), this.game.gfx.matGlow);
        m.position.set(x + Math.sin(a) * 2.75, y + 1.5, z + Math.cos(a) * 2.75);
        m.visible = false;
        this.group.add(m);
        this.altarShards.push(m);
        this.spinners.push(m);
      }
    }
    // 모닥불
    this._campfire(g, vx + L.campfire.x, vz + L.campfire.z, H);
    // 울타리 (동서남북에 출입구)
    {
      const R = 42;
      const N = 84;
      let prev = null;
      for (let k = 0; k <= N; k++) {
        const a = (k / N) * Math.PI * 2;
        const quad = ((a + Math.PI / 4) % (Math.PI / 2)) - Math.PI / 4;
        if (Math.abs(quad) < 0.11) {
          prev = null;
          continue;
        }
        const x = vx + Math.sin(a) * R;
        const z = vz + Math.cos(a) * R;
        const y = H(x, z);
        g.box(0.2, 1.2, 0.2, M(x, y + 0.55, z, 0, a, 0), 0x7a5a3a, 0x9c7449);
        if (prev) {
          const mx = (x + prev.x) / 2;
          const mz = (z + prev.z) / 2;
          const len = Math.hypot(x - prev.x, z - prev.z);
          const ya = Math.atan2(x - prev.x, z - prev.z);
          const pitch = -Math.atan2(y - prev.y, len);
          g.box(0.1, 0.12, len, M(mx, (y + prev.y) / 2 + 0.9, mz, pitch, ya, 0), 0x8a623c);
          g.box(0.1, 0.12, len, M(mx, (y + prev.y) / 2 + 0.5, mz, pitch, ya, 0), 0x8a623c);
        }
        prev = { x, y, z };
      }
    }
    // 가로등
    for (let k = 0; k < 6; k++) {
      const a = (k / 6) * Math.PI * 2 + 0.52;
      const x = vx + Math.sin(a) * 17.5;
      const z = vz + Math.cos(a) * 17.5;
      const y = H(x, z);
      g.box(0.14, 2.8, 0.14, M(x, y + 1.4, z), 0x4a4038);
      g.box(0.5, 0.08, 0.5, M(x, y + 2.85, z), 0x4a4038);
      glow.box(0.34, 0.4, 0.34, M(x, y + 2.6, z), 0xffe9a0, 0xffc45a);
      this.lightSrc.push({ x, y: y + 2.5, z, color: 0xffcf8a, power: 26, nightOnly: true });
      this.colliders.push({ x, z, r: 0.15 });
    }
    // 상자와 통
    for (const [dx, dz, s] of [[19, 3.5, 1], [19.8, 4.6, 0.8], [-20, 2.6, 1], [11, -18, 0.9], [-13, 17, 1]]) {
      const x = vx + dx;
      const z = vz + dz;
      const y = H(x, z);
      g.box(0.9 * s, 0.9 * s, 0.9 * s, M(x, y + 0.45 * s, z, 0, dx, 0), 0x8a623c, 0xb08450);
      this.colliders.push({ x, z, r: 0.55 * s });
    }
  }

  _campfire(g, x, z, H) {
    const y = H(x, z);
    for (let k = 0; k < 8; k++) {
      const a = (k / 8) * Math.PI * 2;
      g.ico(0.24, 0, M(x + Math.cos(a) * 0.8, y + 0.1, z + Math.sin(a) * 0.8, 0, k, 0), 0x7f848c, 0xa9aeb6, 0.4, k);
    }
    g.cyl(0.1, 0.12, 1.2, 5, M(x, y + 0.2, z, Math.PI / 2, 0.4, 0), 0x5a3d25);
    g.cyl(0.1, 0.12, 1.2, 5, M(x, y + 0.24, z, Math.PI / 2, 1.9, 0), 0x4a3020);
    g.cyl(0.1, 0.12, 1.2, 5, M(x, y + 0.28, z, Math.PI / 2, 3.2, 0), 0x5a3d25);
    const fg = new Geo();
    fg.cone(0.34, 1.0, 5, M(0, 0.5, 0), 0xff7a1a, 0xffc040);
    fg.cone(0.2, 0.7, 5, M(0.1, 0.4, 0.05, 0, 1, 0), 0xffd35a, 0xfff3b0);
    const flame = new THREE.Mesh(fg.build(false), this.game.gfx.matGlow);
    flame.position.set(x, y + 0.25, z);
    this.group.add(flame);
    this.flames.push(flame);
    this.lightSrc.push({ x, y: y + 1.3, z, color: 0xff9440, power: 52, fire: true });
    this.rests.push({ x, z, r: 8.5 });
    this.colliders.push({ x, z, r: 0.7 });
  }

  // ---------------- 별조각 제단 ----------------
  _buildShrines(g, H) {
    const { pois, gfx } = this.game;
    this.shards = [];
    const beamGeo = new THREE.CylinderGeometry(0.9, 0.35, 140, 8, 1, true);
    beamGeo.translate(0, 70, 0);
    const sealGeo = new THREE.IcosahedronGeometry(1.25, 1);
    for (const s of pois.shards) {
      const x = s.x;
      const z = s.z;
      const y = H(x, z);
      g.at(x, z);
      g.cyl(2.7, 3.1, 0.5, 10, M(x, y + 0.15, z), 0x8f948c, 0xb8bcb2);
      g.cyl(0.5, 0.68, 1.0, 8, M(x, y + 0.9, z), 0x9a9f96, 0xc8ccc2);
      for (let k = 0; k < 4; k++) {
        const a = (k / 4) * Math.PI * 2 + 0.6;
        const hh = 1.5 + ((k * 7 + s.id * 3) % 4) * 0.45;
        const px = x + Math.cos(a) * 2.15;
        const pz = z + Math.sin(a) * 2.15;
        g.cyl(0.26, 0.32, hh, 6, M(px, y + 0.4 + hh / 2, pz), 0x8f948c, 0xb8bcb2);
        this.colliders.push({ x: px, z: pz, r: 0.34 });
      }
      this.colliders.push({ x, z, r: 0.75 });
      const cg = new Geo();
      cg.cone(0.42, 0.75, 5, M(0, 0.37, 0), 0xfff2a8);
      cg.cone(0.42, 0.75, 5, M(0, -0.37, 0, Math.PI, 0, 0), 0xffd65a);
      const crystal = new THREE.Mesh(cg.build(false), gfx.matGlow);
      crystal.position.set(x, y + 2.5, z);
      this.group.add(crystal);
      const beam = new THREE.Mesh(beamGeo, this.glowMatBeam);
      beam.position.set(x, y + 2.5, z);
      beam.renderOrder = 6;
      this.group.add(beam);
      const seal = new THREE.Mesh(sealGeo, this.sealMat);
      seal.position.copy(crystal.position);
      seal.visible = false;
      seal.renderOrder = 7;
      this.group.add(seal);
      const o = { def: s, x, y, z, crystal, beam, seal, collected: false, sealed: false };
      this.shards.push(o);
      this.lightSrc.push({ x, y: y + 2.6, z, color: 0xffe9a0, power: 20, shard: o });
      this.interactables.push({
        kind: 'shard', ref: o, x, z, r: 4.4,
        active: () => !o.collected,
        label: () => (o.sealed ? '봉인됨 — 수호자를 쓰러뜨리세요' : '별조각 얻기'),
      });
    }
  }

  // ch: 지금 장. 다른 장의 제단은 별조각 없이 잠들어 있다
  setShards(collected, sealed, ch = 0) {
    for (const o of this.shards) {
      o.dormant = o.def.ch !== ch;
      o.collected = o.dormant || collected.has(o.def.id);
      o.sealed = !o.collected && sealed.has(o.def.id);
      o.crystal.visible = !o.collected;
      o.beam.visible = !o.collected;
      o.beam.material = o.sealed ? this.glowMatBeamSealed : this.glowMatBeam;
      o.seal.visible = o.sealed;
    }
    let n = 0;
    for (let k = 0; k < this.altarShards.length; k++) {
      const has = collected.has(ch * SHARD_COUNT + k);
      this.altarShards[k].visible = has;
      if (has) n++;
    }
    return n;
  }

  // ---------------- 귀환석 ----------------
  _buildStones(g, H) {
    const { pois, gfx } = this.game;
    this.stones = [];
    for (const s of pois.stones) {
      const x = s.x;
      const z = s.z;
      const y = H(x, z);
      g.at(x, z);
      g.cyl(1.3, 1.55, 0.35, 8, M(x, y + 0.1, z), 0x5a5f6c, 0x7a8090);
      g.taperBox(1.0, 3.5, 0.62, 0.68, M(x, y + 2.0, z), 0x454a58, 0x6a7082);
      const mk = (c1, c2) => {
        const gg = new Geo();
        for (const side of [1, -1]) {
          gg.box(0.5, 0.07, 0.04, M(0, 2.9, 0.26 * side), c1);
          gg.box(0.07, 0.6, 0.04, M(0, 2.5, 0.28 * side), c1);
          gg.box(0.34, 0.07, 0.04, M(0, 2.05, 0.3 * side), c1);
          gg.box(0.07, 0.07, 0.04, M(-0.2, 1.7, 0.31 * side), c2);
          gg.box(0.07, 0.07, 0.04, M(0.2, 1.7, 0.31 * side), c2);
        }
        gg.cone(0.22, 0.36, 4, M(0, 4.4, 0), c2);
        gg.cone(0.22, 0.36, 4, M(0, 4.04, 0, Math.PI, 0, 0), c1);
        const m = new THREE.Mesh(gg.build(false), gfx.matGlow);
        m.position.set(x, y, z);
        this.group.add(m);
        return m;
      };
      const off = mk(0xff9a3a, 0xffc070);
      const on = mk(0x5fe0ff, 0xc8f6ff);
      on.visible = false;
      const o = { def: s, x, y, z, on, off, active: false };
      this.stones.push(o);
      this.colliders.push({ x, z, r: 0.7 });
      this.interactables.push({
        kind: 'stone', ref: o, x, z, r: 3.4,
        active: () => true,
        label: () => (o.active ? '귀환석 — 지도에서 빠른 이동' : `귀환석 깨우기: ${s.name}`),
      });
    }
  }

  setStones(activeIds) {
    for (const o of this.stones) {
      o.active = activeIds.includes(o.def.id);
      o.on.visible = o.active;
      o.off.visible = !o.active;
    }
  }

  // ---------------- 야영지 ----------------
  _buildCamps(g, H) {
    const { pois } = this.game;
    for (const c of pois.camps) {
      g.at(c.x, c.z);
      this._campfire(g, c.x, c.z, H);
      // 천막
      const tx = c.x - 3.6;
      const tz = c.z + 2.6;
      const ty = H(tx, tz);
      const tr = 0.6 + c.id;
      g.roof(3.0, 2.1, 3.4, M(tx, ty - 0.05, tz, 0, tr, 0), 0x8a6a40, 0xd4b884);
      // 천막 입구와 기둥
      g.roof(1.3, 1.5, 0.08, M(tx + Math.sin(tr) * 1.72, ty - 0.05, tz + Math.cos(tr) * 1.72, 0, tr, 0), 0x2a2018, 0x3a2c20);
      g.box(0.1, 2.5, 0.1, M(tx + Math.sin(tr) * 1.75, ty + 1.2, tz + Math.cos(tr) * 1.75), 0x5a3d25);
      g.box(0.5, 0.3, 0.04, M(tx + Math.sin(tr) * 1.75, ty + 2.5, tz + Math.cos(tr) * 1.75, 0, tr, 0), 0xb5321f);
      this.colliders.push({ x: tx, z: tz, r: 1.5 });
      // 깃발
      const fx = c.x + 3.4;
      const fz = c.z + 3.0;
      const fy = H(fx, fz);
      g.box(0.1, 3.2, 0.1, M(fx, fy + 1.6, fz), 0x5a3d25);
      g.box(0.9, 0.55, 0.04, M(fx + 0.48, fy + 2.85, fz), 0xb5321f, 0xd9483b);
      // 뾰족 울타리
      for (let k = 0; k < 5; k++) {
        const a = c.id + k * 1.26;
        const bx = c.x + Math.cos(a) * 8.6;
        const bz = c.z + Math.sin(a) * 8.6;
        const by = H(bx, bz);
        g.cone(0.14, 1.5, 4, M(bx, by + 0.6, bz, 0.5 * Math.sin(a), 0, -0.5 * Math.cos(a)), 0x5a3d25, 0x8a623c);
        g.cone(0.14, 1.5, 4, M(bx + 0.5, by + 0.6, bz + 0.3, 0.4 * Math.sin(a), 0, -0.6 * Math.cos(a)), 0x5a3d25, 0x8a623c);
      }
    }
  }

  // ---------------- 보스 경기장 ----------------
  // 2장 · 3장의 싸움터: 들판 한가운데 둥글게 선 돌기둥과 바닥의 빛나는 무늬
  _buildFieldArena(g, glow, H, A, style) {
    g.at(A.x, A.z);
    const C = style === 1
      ? { a: 0x8a4a2a, b: 0xd89a5a, top: 0xffb04a, g1: 0xc8502a, g2: 0xffb04a } // 노을 평원: 붉은 사암 기둥과 주홍빛 무늬
      : { a: 0x4a50a0, b: 0xc8d4ff, top: 0x9af0ff, g1: 0x5a6ae0, g2: 0xbff4ff }; // 세상의 끝: 흰 수정 기둥과 별빛 무늬
    for (let k = 0; k < 14; k++) {
      const a = (k / 14) * Math.PI * 2 + 0.22;
      const x = A.x + Math.cos(a) * (A.r + 4);
      const z = A.z + Math.sin(a) * (A.r + 4);
      const y = H(x, z);
      const hh = 6 + (k % 3) * 2.2;
      if (style === 1) {
        g.taperBox(1.5, hh, 1.2, 0.62, M(x, y + hh / 2 - 0.3, z, 0.12 * Math.sin(a), -a, -0.12 * Math.cos(a)), C.a, C.b);
        g.ico(0.75, 0, M(x, y + hh + 0.1, z, 0, k, 0, 1.2, 0.5, 1.1), C.a, C.b, 0.25, 301 + k);
      } else {
        g.cone(1.15, hh + 2, 6, M(x, y + hh / 2 + 0.6, z, 0.16 * Math.sin(a), k, -0.16 * Math.cos(a)), C.a, C.b);
        g.cone(0.6, hh * 0.5, 6, M(x + Math.cos(a + 1.4) * 1.3, y + hh * 0.22, z + Math.sin(a + 1.4) * 1.3, 0.3, k, 0.25), C.a, C.b);
      }
      glow.ico(0.22, 0, M(x, y + hh + (style === 1 ? 0.9 : 1.9), z), C.top);
      this.colliders.push({ x, z, r: 1.0 });
    }
    for (let k = 0; k < 24; k++) {
      const a = (k / 24) * Math.PI * 2;
      glow.box(1.6, 0.06, 0.3, M(A.x + Math.cos(a) * 13, A.h + 0.09, A.z + Math.sin(a) * 13, 0, -a + Math.PI / 2, 0), C.g1, C.g2);
      if (k % 2 === 0) glow.box(0.3, 0.06, 2.2, M(A.x + Math.cos(a) * 21, A.h + 0.09, A.z + Math.sin(a) * 21, 0, -a + Math.PI / 2, 0), C.g1, C.g2);
    }
  }

  _buildArena(g, glow, H) {
    const arenas = this.game.pois.arenas || [];
    for (let k = 1; k < arenas.length; k++) this._buildFieldArena(g, glow, H, arenas[k], k);
    const A = this.game.pois.arena;
    g.at(A.x, A.z);
    for (let k = 0; k < 16; k++) {
      const a = (k / 16) * Math.PI * 2 + 0.2;
      // 협곡 입구 쪽은 비워 둔다
      const dot = Math.cos(a) * VOLCANO.notchX + Math.sin(a) * VOLCANO.notchZ;
      if (dot > 0.9) continue;
      const x = A.x + Math.cos(a) * (A.r + 3.5);
      const z = A.z + Math.sin(a) * (A.r + 3.5);
      const y = H(x, z);
      g.cone(1.3, 6 + (k % 3) * 2, 5, M(x, y + 2.5, z, 0.25 * Math.sin(a), k, -0.25 * Math.cos(a)), 0x2a2224, 0x5a4648);
    }
    for (let k = 0; k < 24; k++) {
      const a = (k / 24) * Math.PI * 2;
      glow.box(1.6, 0.06, 0.3, M(A.x + Math.cos(a) * 13, VOLCANO.floor + 0.08, A.z + Math.sin(a) * 13, 0, -a + Math.PI / 2, 0), 0x7a2a8a, 0xb04aff);
    }
  }

  // ---------------- 열매 덤불 ----------------
  _buildBushes(g, H) {
    const { pois, gfx, save } = this.game;
    this.bushes = [];
    const bg = new Geo();
    for (let k = 0; k < 6; k++) {
      const a = k * 1.1;
      bg.ico(0.12, 0, M(Math.cos(a) * 0.55, 0.55 + (k % 3) * 0.22, Math.sin(a) * 0.55), 0xe0304a, 0xff6a7a);
    }
    const berryGeo = bg.build(false);
    for (const b of pois.bushes) {
      const y = H(b.x, b.z);
      g.at(b.x, b.z);
      g.ico(0.78, 0, M(b.x, y + 0.5, b.z, 0, b.id, 0, 1.15, 0.85, 1.1), 0x2f7a34, 0x58a848, 0.3, b.id);
      g.ico(0.5, 0, M(b.x + 0.5, y + 0.35, b.z + 0.25, 0, b.id * 2, 0), 0x2f7a34, 0x4f9a42, 0.3, b.id + 5);
      const berries = new THREE.Mesh(berryGeo, gfx.matChar);
      berries.position.set(b.x, y, b.z);
      berries.rotation.y = b.id;
      this.group.add(berries);
      const until = save.bushes[b.id] || 0;
      this.bushes.push({ def: b, x: b.x, y, z: b.z, berries, until });
    }
  }

  // ---------------- 보물상자 ----------------
  _buildChests(H) {
    const { pois, gfx, save } = this.game;
    this.chests = [];
    const TIER = [[0x8a623c, 0xd9a93a], [0x8a623c, 0xd9a93a], [0x3f6fa8, 0xdfe7ee], [0x6a4a9a, 0xffd65a], [0x6a4a9a, 0xffd65a]];
    const geos = TIER.map(([c1, c2]) => {
      const base = new Geo();
      base.box(1.0, 0.55, 0.7, M(0, 0.275, 0), (c1 & 0xfefefe) >> 1, c1);
      base.box(1.04, 0.08, 0.74, M(0, 0.5, 0), c2);
      base.box(0.1, 0.56, 0.74, M(-0.38, 0.28, 0), c2);
      base.box(0.1, 0.56, 0.74, M(0.38, 0.28, 0), c2);
      const lid = new Geo();
      lid.box(1.0, 0.26, 0.7, M(0, 0.13, 0.35), c1, c1 + 0x101010);
      lid.box(0.1, 0.28, 0.74, M(-0.38, 0.13, 0.35), c2);
      lid.box(0.1, 0.28, 0.74, M(0.38, 0.13, 0.35), c2);
      lid.box(0.16, 0.2, 0.06, M(0, 0.02, 0.72), c2);
      return { base: base.build(false), lid: lid.build(false) };
    });
    const opened = new Set(save.chests);
    for (const c of pois.chests) {
      const y = H(c.x, c.z);
      const grp = new THREE.Group();
      grp.position.set(c.x, y, c.z);
      grp.rotation.y = hash1(c.id + 77) * 6.283;
      const gset = geos[c.tier] || geos[1];
      const base = new THREE.Mesh(gset.base, gfx.matChar);
      base.castShadow = true;
      const lid = new THREE.Mesh(gset.lid, gfx.matChar);
      lid.position.set(0, 0.55, -0.35);
      grp.add(base, lid);
      this.group.add(grp);
      const o = { def: c, x: c.x, y, z: c.z, grp, lid, open: opened.has(c.id), t: 0 };
      if (o.open) lid.rotation.x = -1.9;
      this.chests.push(o);
      this.colliders.push({ x: c.x, z: c.z, r: 0.6 });
      this.interactables.push({ kind: 'chest', ref: o, x: c.x, z: c.z, r: 2.7, active: () => !o.open, label: () => '보물상자 열기' });
    }
  }

  resetChests() {
    for (const o of this.chests) {
      o.open = false;
      o.lid.rotation.x = 0;
    }
  }

  // ---------------- NPC ----------------
  _buildNpcs(H) {
    const { pois, gfx } = this.game;
    this.npcs = [];
    for (const n of pois.npcs) {
      const rig = makeHumanoid(npcLook(n.kind));
      const y = H(n.x, n.z);
      rig.root.position.set(n.x, y, n.z);
      let fx = VILLAGE.x;
      let fz = VILLAGE.z;
      if (n.kind === 'guide') {
        const st = pois.stones[n.stone];
        fx = st.x - 6;
        fz = st.z + 4;
      }
      const yaw = Math.atan2(fx - n.x, fz - n.z);
      rig.root.rotation.y = yaw;
      gfx.scene.add(rig.root);
      const label = makeLabel(n.name, '#ffe9a8');
      label.position.set(n.x, y + rig.height + 0.55, n.z);
      this.group.add(label);
      let mark = null;
      if (n.kind === 'elder') {
        mark = makeLabel('!', '#ffd84a');
        mark.scale.set(4.2, 1.05, 1);
        mark.position.set(n.x, y + rig.height + 1.3, n.z);
        this.group.add(mark);
      }
      // 의뢰 표시: '!' 맡길 일이 있다, '?' 보고를 기다린다
      const qNew = makeLabel('!', '#ffd84a');
      const qDone = makeLabel('?', '#8dff9a');
      for (const q of [qNew, qDone]) {
        q.scale.set(4.2, 1.05, 1);
        q.position.set(n.x, y + rig.height + 1.3, n.z);
        q.visible = false;
        this.group.add(q);
      }
      const o = { def: n, key: n.kind === 'guide' ? 'guide' + n.stone : n.kind, x: n.x, y, z: n.z, rig, yaw, baseYaw: yaw, label, mark, qNew, qDone, qm: '', talkT: 0 };
      this.npcs.push(o);
      this.colliders.push({ x: n.x, z: n.z, r: 0.5 });
      this.interactables.push({ kind: 'npc', ref: o, x: n.x, z: n.z, r: 3.3, active: () => true, label: () => `대화: ${n.name}` });
    }
  }

  // 가장 가까운 상호작용 대상
  nearest(px, pz) {
    let best = null;
    let bd = Infinity;
    for (const it of this.interactables) {
      const dx = it.x - px;
      const dz = it.z - pz;
      const d2 = dx * dx + dz * dz;
      if (d2 > it.r * it.r || d2 >= bd) continue;
      if (!it.active()) continue;
      bd = d2;
      best = it;
    }
    return best;
  }

  nearRest(x, z) {
    for (const r of this.rests) {
      const dx = r.x - x;
      const dz = r.z - z;
      if (dx * dx + dz * dz < r.r * r.r) return true;
    }
    return false;
  }

  // 가까운 불빛 몇 개에만 실제 조명을 붙인다 (바뀔 때는 서서히 꺼지고 켜진다)
  _updateLights(dt, time, px, pz) {
    const gfx = this.game.gfx;
    const n = Math.min(gfx.quality.lights, this.lightSlots.length);
    if (!n) return;
    const night = gfx.night;
    const want = this._want;
    want.length = 0;
    for (const s of this.lightSrc) {
      if (s.shard && s.shard.collected) continue;
      // 돌등은 밝힌 뒤에만, 던전 문은 드러난 뒤에만, 제단은 인장을 받기 전에만 빛난다
      if ((s.lamp && !s.lamp.lit) || (s.zoneGate && !(s.zoneGate.trial || s.zoneGate.found)) || (s.altar && s.altar.cleared) || (s.wild && !s.wild.rig.root.visible) || !s.power) continue;
      const dx = s.x - px;
      const dz = s.z - pz;
      const d2 = dx * dx + dz * dz;
      if (d2 > 60 * 60) continue;
      s.amt = (s.always ? 1 : s.nightOnly ? night : s.shard ? 0.15 + 0.85 * night : 0.3 + 0.7 * night) * (1 - Math.max(0, (Math.sqrt(d2) - 40) / 20));
      if (s.amt < 0.03) continue;
      s.d2 = d2;
      let i = want.length;
      while (i > 0 && want[i - 1].d2 > d2) i--;
      if (i < n) {
        want.splice(i, 0, s);
        if (want.length > n) want.length = n;
      }
    }
    for (let i = 0; i < n; i++) {
      const slot = this.lightSlots[i];
      if (slot.src && want.includes(slot.src)) slot.k = Math.min(1, slot.k + dt * 3);
      else {
        slot.k -= dt * 4;
        if (slot.k <= 0) {
          slot.k = 0;
          slot.src = null;
          for (const s of want) {
            if (!this.lightSlots.some((o) => o.src === s)) {
              slot.src = s;
              break;
            }
          }
        }
      }
      const s = slot.src;
      const L = slot.light;
      if (!s || slot.k <= 0) {
        L.intensity = 0;
        continue;
      }
      let flick = 1;
      if (s.fire) flick = 1 + Math.sin(time * 11 + s.x) * 0.1 + Math.sin(time * 23 + s.z) * 0.06;
      L.color.setHex(s.color);
      L.position.set(s.x, s.y, s.z);
      L.intensity = s.power * s.amt * slot.k * flick;
    }
  }

  update(dt, time, px, pz) {
    const now = Date.now();
    this._updateLights(dt, time, px, pz);
    // 안개 너머의 구역은 그리지 않는다
    const far = this.game.gfx.quality.fogFar + 40;
    for (const s of this.statics) {
      const dx = s.x - px;
      const dz = s.z - pz;
      const lim = far + s.r;
      s.m.visible = dx * dx + dz * dz < lim * lim;
    }
    for (const s of this.spinners) s.rotation.y += dt * 1.2;
    for (const o of this.shards) {
      if (o.collected) continue;
      o.crystal.rotation.y += dt * 1.5;
      o.crystal.position.y = o.y + 2.5 + Math.sin(time * 2 + o.x) * 0.18;
      if (o.sealed) {
        o.seal.rotation.y -= dt * 0.8;
        o.seal.rotation.x += dt * 0.5;
      }
    }
    for (let i = 0; i < this.flames.length; i++) {
      const f = this.flames[i];
      const dx = f.position.x - px;
      const dz = f.position.z - pz;
      f.visible = dx * dx + dz * dz < 160 * 160;
      if (!f.visible) continue;
      const k = 1 + Math.sin(time * 11 + i) * 0.14 + Math.sin(time * 17 + i * 2) * 0.08;
      f.scale.set(1 + (k - 1) * 0.5, k, 1 + (k - 1) * 0.5);
      f.rotation.y = time * 2 + i;
      // 불티
      if (dx * dx + dz * dz < 45 * 45 && Math.random() < dt * 5) {
        this.game.fx.spawn(f.position.x + (Math.random() - 0.5) * 0.5, f.position.y + 0.8, f.position.z + (Math.random() - 0.5) * 0.5, (Math.random() - 0.5) * 0.6, 1.4 + Math.random(), (Math.random() - 0.5) * 0.6, 0xffb040, 0.16, 1.1, -0.6, 0.9, 3.2, 0.5);
      }
    }
    for (const c of this.chests) {
      const dx = c.x - px;
      const dz = c.z - pz;
      const d2 = dx * dx + dz * dz;
      c.grp.visible = d2 < 200 * 200;
      if (c.open && c.lid.rotation.x > -1.9) c.lid.rotation.x = Math.max(-1.9, c.lid.rotation.x - dt * 5);
      // 아직 열지 않은 상자는 반짝인다
      if (!c.open && d2 < 40 * 40 && Math.random() < dt * 2.5) {
        this.game.fx.spawn(c.x + (Math.random() - 0.5) * 0.9, c.y + 0.7 + Math.random() * 0.5, c.z + (Math.random() - 0.5) * 0.7, 0, 0.7, 0, 0xffe27a, 0.2, 0.9, -0.2, 1, 2.6);
      }
    }
    for (const b of this.bushes) {
      const dx = b.x - px;
      const dz = b.z - pz;
      const d2 = dx * dx + dz * dz;
      const ripe = now >= b.until;
      b.berries.visible = ripe && d2 < 110 * 110;
      if (ripe && d2 < 1.9 * 1.9) this.game.onBushPicked(b);
    }
    for (const n of this.npcs) {
      const dx = n.x - px;
      const dz = n.z - pz;
      const d2 = dx * dx + dz * dz;
      const near = d2 < 90 * 90;
      n.rig.root.visible = near;
      n.label.visible = d2 < 45 * 45;
      if (n.mark) {
        n.mark.visible = near && !this.game.save.talkedElder;
        n.mark.position.y = n.y + n.rig.height + 1.3 + Math.sin(time * 4) * 0.12;
      }
      // 의뢰 표시 (촌장과 처음 이야기한 뒤부터)
      const qm = this.game.save.talkedElder ? n.qm : '';
      n.qNew.visible = near && qm === '!';
      n.qDone.visible = near && qm === '?';
      if (qm) (qm === '!' ? n.qNew : n.qDone).position.y = n.y + n.rig.height + 1.3 + Math.sin(time * 4 + n.x) * 0.12;
      if (!near) continue;
      // 가까이 오면 플레이어를 바라본다
      let want = n.baseYaw;
      if (d2 < 36) want = Math.atan2(px - n.x, pz - n.z);
      let d = (want - n.yaw) % (Math.PI * 2);
      if (d > Math.PI) d -= Math.PI * 2;
      if (d < -Math.PI) d += Math.PI * 2;
      n.yaw += d * Math.min(1, dt * 5);
      n.rig.root.rotation.y = n.yaw;
      n.talkT -= dt;
      animateHumanoid(n.rig, n.talkT > 0 ? POSE.WAVE : POSE.IDLE, dt, 0, 0);
    }
  }

  pickBush(b) {
    b.until = Date.now() + BUSH_RESPAWN_MS;
    b.berries.visible = false;
    this.game.save.bushes[b.def.id] = b.until;
  }
}

// 캐릭터·몬스터 모델과 절차적 애니메이션
import * as THREE from '/vendor/three/three.module.js';
import { ANIM, TUNIC_COLORS, HAIR_COLORS, RARITY, WEAPONS, MOUNT_COLORS, UNIQUES, bandOf, enhGlow } from '/shared/defs.js';
import { JOBS } from '/shared/jobs.js';
import { Geo, M } from './geo.js';

export const POSE = {
  ...ANIM,
  RAISE: 40, SMASH: 41, THROWBACK: 42, THROW: 43, SWEEPBACK: 44, SWEEP: 45, ROAR: 46, CROUCH: 47, LUNGE: 48, STAGGER: 49, WALK: 50,
};

let MAT = null;
let GLOW = null;
let JELLY = null;
export function initModels(gfx) {
  MAT = gfx.matChar;
  GLOW = gfx.matGlow;
  JELLY = gfx.matJelly;
}

function mesh(geo, glow) {
  const m = new THREE.Mesh(geo.build(false), glow ? GLOW : MAT);
  m.castShadow = !glow;
  return m;
}

const shade = (hex, k) => {
  const r = Math.min(255, Math.round(((hex >> 16) & 255) * k));
  const g = Math.min(255, Math.round(((hex >> 8) & 255) * k));
  const b = Math.min(255, Math.round((hex & 255) * k));
  return (r << 16) | (g << 8) | b;
};

// ============================================================
// 사람형 리그 (플레이어, NPC, 도깨비, 설인, 수호자, 보스)
// ============================================================
export function makeHumanoid(o) {
  const S = o.scale || 1;
  const bulk = o.bulk || 1;
  const armLen = o.armLen || 1;
  const legLen = o.legLen || 1;
  const headS = o.headSize || 1;
  const skin = o.skin ?? 0xf2c9a0;
  const tunic = o.tunic ?? 0xd9483b;
  const pants = o.pants ?? 0x4a4a5a;
  const boots = o.boots ?? 0x5a3d25;
  const hair = o.hair ?? 0x3a2a1e;

  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  const hipY = 0.63 * legLen;
  const torso = new THREE.Group();
  torso.position.y = hipY;
  body.add(torso);

  // --- 몸통 ---
  {
    const g = new Geo();
    const w = 0.46 * bulk;
    if (o.kind === 'golem') {
      g.ico(0.62, 0, M(0, 0.42, 0, 0.3, 0.4, 0, 1.25, 1.0, 0.95), o.rock, o.rock2, 0.4, 5);
      g.ico(0.3, 0, M(0.3, 0.75, -0.15, 0, 1, 0), o.rock, o.rock2, 0.4, 9);
      if (o.accent) g.ico(0.2, 0, M(-0.25, 0.8, 0.1, 0, 2, 0, 1.2, 0.6, 1), o.accent, null, 0.3, 4);
    } else {
      g.taperBox(w, 0.56, 0.28 * bulk, 1.12, M(0, 0.3, 0), shade(tunic, 0.82), tunic);
      if (o.skirt !== false) g.taperBox(w * 1.22, 0.2, 0.34 * bulk, 0.82, M(0, -0.04, 0), shade(tunic, 0.7), shade(tunic, 0.85));
      if (o.belt !== false) {
        g.box(w * 1.08, 0.07, 0.31 * bulk, M(0, 0.06, 0), o.beltColor ?? 0x5a3d25);
        g.box(0.08, 0.08, 0.03, M(0, 0.06, 0.16 * bulk), 0xe6c14a);
      }
      if (o.scarf != null) {
        g.box(0.4 * bulk, 0.1, 0.34, M(0, 0.6, 0), o.scarf);
        g.box(0.12, 0.32, 0.05, M(0.12, 0.42, -0.19, 0.25, 0, 0), shade(o.scarf, 0.85));
      }
      if (o.backpack) {
        g.box(0.32, 0.34, 0.16, M(0, 0.33, -0.23), 0x8a623c, 0x9c7449);
        g.cyl(0.08, 0.08, 0.38, 6, M(0, 0.56, -0.23, 0, 0, Math.PI / 2), 0xd9c9a0);
      }
      if (o.apron != null) g.box(w * 0.8, 0.5, 0.03, M(0, 0.2, 0.15 * bulk), o.apron);
      if (o.robe != null) g.taperBox(w * 1.5, 0.62, 0.42, 0.72, M(0, -0.3, 0), shade(o.robe, 0.75), o.robe);
      if (o.cape != null) g.taperBox(w * 1.5, 1.05, 0.06, 0.62, M(0, 0.02, -0.2 * bulk, 0.12, 0, 0), shade(o.cape, 0.7), o.cape);
      if (o.tail != null) g.cone(0.06, 0.6, 4, M(0, 0.0, -0.3, -1.9, 0, 0), o.tail);
      if (o.pauldrons != null) {
        g.ico(0.2, 0, M(0.34 * bulk, 0.56, 0, 0, 0, 0, 1.2, 0.8, 1.2), o.pauldrons);
        g.ico(0.2, 0, M(-0.34 * bulk, 0.56, 0, 0, 0, 0, 1.2, 0.8, 1.2), o.pauldrons);
      }
    }
    torso.add(mesh(g));
    if (o.core != null) {
      const gg = new Geo();
      gg.ico(0.11, 0, M(0, 0.36, 0.17 * bulk + (o.kind === 'golem' ? 0.42 : 0)), o.core);
      torso.add(mesh(gg, true));
    }
  }

  // --- 머리 ---
  const neckY = o.kind === 'golem' ? 0.9 : 0.6;
  const head = new THREE.Group();
  head.position.set(0, neckY, o.kind === 'golem' ? 0.12 : 0);
  torso.add(head);
  {
    const g = new Geo();
    const hs = headS;
    if (o.kind === 'golem') {
      g.ico(0.3, 0, M(0, 0.2, 0, 0, 0.6, 0, 1.1, 0.9, 1), o.rock, o.rock2, 0.35, 13);
    } else {
      g.ico(0.26 * hs, 1, M(0, 0.26 * hs, 0, 0, 0, 0, 1, 1, 0.95), shade(skin, 0.92), skin);
      const hy = 0.33 * hs;
      if (o.hairStyle !== 'bald') {
        g.ico(0.265 * hs, 1, M(0, hy, -0.06 * hs, 0, 0, 0, 1.03, 0.8, 1.03), shade(hair, 0.8), hair);
        g.box(0.3 * hs, 0.07 * hs, 0.08 * hs, M(0, 0.435 * hs, 0.18 * hs, 0.35, 0, 0), hair);
      }
      if (o.hairStyle === 'bun' && !o.helm) g.ico(0.11 * hs, 0, M(0, 0.52 * hs, -0.2 * hs), hair);
      if (o.hairStyle === 'long') g.box(0.34 * hs, 0.34 * hs, 0.1 * hs, M(0, 0.1 * hs, -0.2 * hs), shade(hair, 0.85));
      if (o.eyes !== false) {
        const ec = o.eyeColor ?? 0x1f1a1a;
        g.box(0.055 * hs, 0.085 * hs, 0.03, M(0.1 * hs, 0.25 * hs, 0.235 * hs), ec);
        g.box(0.055 * hs, 0.085 * hs, 0.03, M(-0.1 * hs, 0.25 * hs, 0.235 * hs), ec);
      }
      if (o.band != null && !o.helm) g.box(0.55 * hs, 0.065 * hs, 0.53 * hs, M(0, 0.4 * hs, -0.01), o.band);
      if (o.helm) {
        // 투구: 가죽 모자 -> 강철 투구 -> 볏 달린 투구
        const hb = o.helm.band;
        const hc = hb <= 1 ? 0x7a5a3a : hb === 2 ? 0xaab4c2 : hb === 3 ? 0xe2dcc0 : hb === 4 ? 0xcfc8f0 : hb === 5 ? 0xf2c66a : hb === 6 ? 0xf0a070 : hb === 7 ? 0x9ab8f4 : 0xfff0d0;
        const trim = o.helm.r >= 1 ? RARITY[o.helm.r].color : hb <= 1 ? 0x5a3d25 : 0x7f8a9a;
        g.ico(0.288 * hs, 1, M(0, 0.345 * hs, -0.03 * hs, 0, 0, 0, 1.05, 0.82, 1.07), shade(hc, 0.78), hc);
        g.box(0.6 * hs, 0.06 * hs, 0.6 * hs, M(0, 0.33 * hs, -0.02 * hs), trim);
        if (hb >= 2) {
          g.box(0.05 * hs, 0.2 * hs, 0.04, M(0, 0.25 * hs, 0.27 * hs), hc);
          g.box(0.07 * hs, 0.26 * hs, 0.2 * hs, M(0.27 * hs, 0.2 * hs, 0.04), shade(hc, 0.85));
          g.box(0.07 * hs, 0.26 * hs, 0.2 * hs, M(-0.27 * hs, 0.2 * hs, 0.04), shade(hc, 0.85));
        }
        if (hb >= 3) g.box(0.06 * hs, 0.2 * hs, 0.5 * hs, M(0, 0.62 * hs, -0.06 * hs, -0.12, 0, 0), shade(trim, 0.8), trim);
        else g.ico(0.05 * hs, 0, M(0, 0.59 * hs, -0.03 * hs), trim);
      }
      if (o.hat === 'straw') g.cone(0.44 * hs, 0.22 * hs, 8, M(0, 0.55 * hs, 0), 0xc9ad5a, 0xe6d08a);
      if (o.hat === 'hood') g.ico(0.3 * hs, 0, M(0, 0.32 * hs, -0.07 * hs, 0, 0, 0, 1.05, 0.95, 1.05), shade(o.hatColor ?? 0x6a5a45, 0.8), o.hatColor ?? 0x6a5a45, 0.1, 3);
      if (o.beard != null) g.ico(0.16 * hs, 0, M(0, 0.09 * hs, 0.17 * hs, 0, 0, 0, 1.1, 1.3, 0.7), o.beard, null, 0.2, 2);
      if (o.horns === 1) g.cone(0.07 * hs, 0.26 * hs, 5, M(0, 0.6 * hs, 0.06 * hs, 0.25, 0, 0), 0xcfc4a0, 0xf5efd8);
      if (o.horns === 2) {
        g.cone(0.06 * hs, 0.24 * hs, 5, M(0.13 * hs, 0.56 * hs, 0.04, 0.2, 0, -0.35), 0xcfc4a0, 0xf5efd8);
        g.cone(0.06 * hs, 0.24 * hs, 5, M(-0.13 * hs, 0.56 * hs, 0.04, 0.2, 0, 0.35), 0xcfc4a0, 0xf5efd8);
      }
      if (o.horns === 3) {
        // 보스의 큰 뿔
        for (const sx of [1, -1]) {
          g.cone(0.09, 0.4, 5, M(0.24 * sx * hs, 0.5 * hs, 0, 0, 0, -1.1 * sx), 0x2a2030, 0x8a6fd0);
          g.cone(0.07, 0.36, 5, M(0.46 * sx * hs, 0.72 * hs, 0, 0, 0, -0.25 * sx), 0x5a4a80, 0xd9c8ff);
        }
      }
      if (o.tusks) {
        g.cone(0.03 * hs, 0.1 * hs, 4, M(0.09 * hs, 0.13 * hs, 0.22 * hs), 0xffffff);
        g.cone(0.03 * hs, 0.1 * hs, 4, M(-0.09 * hs, 0.13 * hs, 0.22 * hs), 0xffffff);
      }
      if (o.ears) {
        g.cone(0.06 * hs, 0.22 * hs, 4, M(0.27 * hs, 0.28 * hs, 0, 0, 0, -1.25), skin);
        g.cone(0.06 * hs, 0.22 * hs, 4, M(-0.27 * hs, 0.28 * hs, 0, 0, 0, 1.25), skin);
      }
      if (o.crown) {
        for (let k = 0; k < 5; k++) {
          const a = (k / 5) * Math.PI * 2;
          g.cone(0.05, 0.14, 4, M(Math.cos(a) * 0.14, 0.58 * hs, Math.sin(a) * 0.14), 0xe6b83a, 0xfff0a0);
        }
      }
    }
    head.add(mesh(g));
    if (o.glowEyes != null) {
      const gg = new Geo();
      const ez = o.kind === 'golem' ? 0.27 : 0.24 * hs;
      const ey = o.kind === 'golem' ? 0.22 : 0.25 * hs;
      gg.box(0.07 * hs, 0.06 * hs, 0.03, M(0.1 * hs, ey, ez), o.glowEyes);
      gg.box(0.07 * hs, 0.06 * hs, 0.03, M(-0.1 * hs, ey, ez), o.glowEyes);
      head.add(mesh(gg, true));
    }
  }

  // --- 팔 ---
  const shoulderX = (o.kind === 'golem' ? 0.72 : 0.31) * bulk;
  const shoulderY = o.kind === 'golem' ? 0.72 : 0.5;
  const mkArm = (side) => {
    const arm = new THREE.Group();
    arm.position.set(shoulderX * side, shoulderY, 0);
    arm.rotation.order = 'YXZ';
    const g = new Geo();
    const L = armLen;
    if (o.kind === 'golem') {
      g.ico(0.3, 0, M(0, -0.1, 0, 0, side, 0, 1, 1.1, 1), o.rock, o.rock2, 0.4, 17 + side);
      g.ico(0.36, 0, M(0, -0.62 * L, 0.02, 0.4, side * 2, 0, 1, 1.25, 1), o.rock, o.rock2, 0.45, 23 + side);
    } else {
      const sleeve = o.sleeve ?? tunic;
      const aw = 0.14 * (o.armBulk || 1);
      g.box(aw, 0.3 * L, aw * 1.07, M(0, -0.13 * L, 0), shade(sleeve, 0.9), sleeve);
      g.box(aw * 0.86, 0.24 * L, aw * 0.93, M(0, -0.38 * L, 0), o.bareArms ? skin : (o.glove ?? skin));
      g.box(aw * 0.93, 0.1, aw, M(0, -0.54 * L, 0), skin);
    }
    arm.add(mesh(g));
    torso.add(arm);
    return arm;
  };
  const armL = mkArm(1);
  const armR = mkArm(-1);
  const handY = -0.56 * armLen;

  // --- 다리 ---
  const mkLeg = (side) => {
    const leg = new THREE.Group();
    leg.position.set((o.kind === 'golem' ? 0.3 : 0.12 * bulk) * side, hipY, 0);
    const g = new Geo();
    const L = legLen;
    if (o.kind === 'golem') {
      g.ico(0.28, 0, M(0, -0.3 * L, 0, 0, side, 0, 1, 1.3, 1), o.rock, o.rock2, 0.4, 31 + side);
    } else {
      const lw = 0.19 * (o.legBulk || 1);
      g.box(lw, 0.38 * L, lw * 1.05, M(0, -0.2 * L, 0), shade(pants, 0.85), pants);
      g.box(lw * 1.06, 0.26 * L, lw * 1.28, M(0, -0.5 * L, 0.02), shade(boots, 0.85), boots);
    }
    leg.add(mesh(g));
    body.add(leg);
    return leg;
  };
  const legL = mkLeg(1);
  const legR = mkLeg(-1);

  // --- 무기 ---
  const weapon = new THREE.Group();
  weapon.position.set(0, handY, 0.03);
  armR.add(weapon);
  // 왼손 무기 (쌍단검)
  const weaponL = new THREE.Group();
  weaponL.position.set(0, handY, 0.03);
  armL.add(weaponL);
  const rig = {
    kind: 'humanoid', root, body, torso, head, armL, armR, legL, legR, weapon, weaponL, opts: o,
    glider: null, bow: null, weaponMesh: null, weaponParts: [], wkind: 'none', wglow: 0,
    p: null, phase: 0, t: Math.random() * 10, atkT: -1, lastAnim: -1, height: (hipY + neckY + 0.55 * headS) * S,
  };
  setWeapon(rig, o.weapon || 'none', o.weaponLook ?? 0);

  // --- 활공 천 ---
  if (o.glider) {
    const g = new Geo();
    const c = o.gliderColor ?? o.scarf ?? 0xe8b730;
    g.box(1.35, 0.04, 1.0, M(0.66, 1.52, 0, 0, 0, 0.14), shade(c, 0.85), c);
    g.box(1.35, 0.04, 1.0, M(-0.66, 1.52, 0, 0, 0, -0.14), shade(c, 0.85), c);
    g.box(0.16, 0.045, 1.02, M(0, 1.44, 0), 0xffffff);
    g.box(1.0, 0.04, 0.04, M(0, 1.02, 0.02), 0x7a5a3a);
    g.box(0.02, 0.5, 0.02, M(0.45, 1.27, 0.02, 0, 0, -0.5), 0x7a5a3a);
    g.box(0.02, 0.5, 0.02, M(-0.45, 1.27, 0.02, 0, 0, 0.5), 0x7a5a3a);
    rig.glider = mesh(g);
    rig.glider.visible = false;
    torso.add(rig.glider);
  }
  // --- 활 ---
  if (o.bow) {
    const g = new Geo();
    g.box(0.04, 0.34, 0.04, M(0, 0, 0.06), 0x8a623c);
    g.box(0.035, 0.36, 0.035, M(0, 0.31, -0.02, 0.5, 0, 0), 0x9c7449);
    g.box(0.035, 0.36, 0.035, M(0, -0.31, -0.02, -0.5, 0, 0), 0x9c7449);
    g.box(0.012, 0.92, 0.012, M(0, 0, -0.1), 0xeeeeee);
    rig.bow = mesh(g);
    rig.bow.position.set(0, handY, 0.08);
    rig.bow.rotation.x = -1.4;
    rig.bow.visible = false;
    armL.add(rig.bow);
  }

  root.scale.setScalar(S);
  rig.p = newPose();
  return rig;
}

// ---------- 무기 ----------
// 플레이어 무기는 종류(검·대검·창·쌍단검·망치), 레벨 구간(날 색), 등급(장식 색), 강화 단계(빛·크기·장식)에 따라 모양이 달라진다.
const BLADE = [0xb9c2cc, 0xdfe7ee, 0xbfe9ff, 0xfff2a8, 0xd9d2ff, 0xffbe6a, 0xff9a78, 0x8fd0ff, 0xfff4d8];
const mixHex = (a, b, t) => {
  const f = (sh) => Math.round(((a >> sh) & 255) + (((b >> sh) & 255) - ((a >> sh) & 255)) * t);
  return (f(16) << 16) | (f(8) << 8) | f(0);
};
const RX = Math.PI / 2;

function buildPlayerWeapon(kind, look) {
  const band = bandOf(look.l || 1);
  const e = look.e || 0;
  const r = look.r || 0;
  const uq = look.u ? UNIQUES[look.u] : null; // 히든 무기: 날 전체가 고유한 빛깔로 빛난다
  const glowC = uq ? uq.color : enhGlow(e);
  const blade = mixHex(BLADE[band], 0xffffff, Math.min(0.5, e * 0.05));
  const bladeD = shade(blade, 0.76);
  const metal = uq ? 0x2c2638 : r >= 3 ? 0xf2d27a : r >= 1 ? 0xd9a93a : 0x9a8f7a;
  const gem = uq ? uq.color : r >= 1 ? RARITY[r].color : metal;
  const wood = uq ? 0x2a2230 : 0x6a4a2c;
  const g = new Geo();
  const gl = new Geo();
  // 날: +10 과 히든 무기는 날 전체가 스스로 빛난다
  const lit = e >= 10 || !!uq;
  const B = lit ? gl : g;
  const bc = uq ? mixHex(uq.color, 0xffffff, 0.3) : e >= 10 ? mixHex(blade, glowC, 0.35) : blade;
  const bd = uq ? uq.color : e >= 10 ? bc : bladeD;
  let glow = lit;
  const G = (fn) => {
    if (!glowC) return;
    glow = true;
    fn();
  };
  if (kind === 'sword') {
    B.box(0.065, 0.028, 0.78, M(0, 0, 0.5), bd, bc);
    B.taperBox(0.065, 0.14, 0.028, 0.05, M(0, 0, 0.96, RX, 0, 0), bc);
    g.box(0.24, 0.05, 0.055, M(0, 0, 0.1), metal);
    g.box(0.045, 0.045, 0.17, M(0, 0, 0), 0x5a3d25);
    g.ico(0.04, 0, M(0, 0, -0.1), gem);
    if (e >= 3) G(() => gl.box(e >= 5 ? 0.03 : 0.02, 0.034, 0.62, M(0, 0, 0.5), glowC));
    if (e >= 5) G(() => gl.ico(0.045, 0, M(0, 0, 0.1), glowC));
    if (e >= 7) {
      for (const sx of [1, -1]) g.taperBox(0.05, 0.2, 0.04, 0.1, M(0.14 * sx, 0, 0.17, RX, 0, -0.75 * sx), metal);
      G(() => gl.box(0.012, 0.05, 0.1, M(0, 0, 0.24), glowC));
    }
    if (e >= 10) gl.ico(0.07, 0, M(0, 0, 1.06), 0xffffff);
  } else if (kind === 'great') {
    B.box(0.15, 0.04, 1.2, M(0, 0, 0.82), bd, bc);
    B.taperBox(0.15, 0.26, 0.04, 0.05, M(0, 0, 1.55, RX, 0, 0), bc);
    if (e < 10) g.box(0.04, 0.046, 0.9, M(0, 0, 0.8), shade(blade, 0.6));
    g.box(0.42, 0.07, 0.08, M(0, 0, 0.16), metal);
    g.box(0.05, 0.05, 0.34, M(0, 0, -0.03), 0x5a3d25);
    g.ico(0.055, 0, M(0, 0, -0.22), gem);
    if (e >= 3) G(() => gl.box(e >= 5 ? 0.05 : 0.03, 0.05, 0.95, M(0, 0, 0.8), glowC));
    if (e >= 5) G(() => gl.ico(0.06, 0, M(0, 0, 0.16), glowC));
    if (e >= 7) for (const sx of [1, -1]) g.taperBox(0.07, 0.3, 0.05, 0.1, M(0.24 * sx, 0, 0.26, RX, 0, -0.6 * sx), metal);
    if (e >= 10) gl.ico(0.09, 0, M(0, 0, 1.72), 0xffffff);
  } else if (kind === 'spear') {
    g.cyl(0.028, 0.028, 2.1, 6, M(0, 0, 0.55, RX, 0, 0), wood, 0x9c7449);
    B.taperBox(0.13, 0.44, 0.035, 0.06, M(0, 0, 1.82, RX, 0, 0), bd, bc);
    g.cyl(0.046, 0.046, 0.09, 6, M(0, 0, 1.6, RX, 0, 0), metal);
    g.cone(0.05, 0.22, 5, M(0, -0.1, 1.52, Math.PI, 0, 0), gem);
    g.ico(0.04, 0, M(0, 0, -0.5), metal);
    if (e >= 3) G(() => gl.box(0.03, 0.045, e >= 5 ? 0.34 : 0.24, M(0, 0, 1.8), glowC));
    if (e >= 5) G(() => gl.cyl(0.05, 0.05, 0.04, 6, M(0, 0, 1.6, RX, 0, 0), glowC));
    if (e >= 7) for (const sx of [1, -1]) B.taperBox(0.05, 0.22, 0.03, 0.1, M(0.085 * sx, 0, 1.68, RX, 0, -0.5 * sx), bc);
    if (e >= 10) gl.ico(0.06, 0, M(0, 0, 2.06), 0xffffff);
  } else if (kind === 'dagger') {
    B.box(0.055, 0.024, 0.36, M(0, 0, 0.3), bd, bc);
    B.taperBox(0.055, 0.12, 0.024, 0.05, M(0, 0, 0.54, RX, 0, 0), bc);
    g.box(0.14, 0.04, 0.045, M(0, 0, 0.1), metal);
    g.box(0.04, 0.04, 0.14, M(0, 0, 0.01), 0x3a2a22);
    g.ico(0.03, 0, M(0, 0, -0.08), gem);
    if (e >= 3) G(() => gl.box(e >= 5 ? 0.026 : 0.018, 0.03, 0.3, M(0, 0, 0.3), glowC));
    if (e >= 7) g.taperBox(0.05, 0.14, 0.03, 0.1, M(0, 0.05, 0.14, 0.9, 0, 0), metal);
    if (e >= 10) gl.ico(0.045, 0, M(0, 0, 0.62), 0xffffff);
  } else {
    // hammer
    g.cyl(0.035, 0.035, 1.3, 6, M(0, 0, 0.5, RX, 0, 0), wood, 0x9c7449);
    B.box(0.5, 0.26, 0.26, M(0, 0, 1.12), bd, bc);
    for (const sx of [1, -1]) g.box(0.07, 0.29, 0.29, M(0.2 * sx, 0, 1.12), metal);
    g.ico(0.045, 0, M(0, 0, -0.16), gem);
    if (e >= 3) G(() => gl.box(e >= 5 ? 0.16 : 0.08, 0.27, 0.27, M(0, 0, 1.12), glowC));
    if (e >= 5) G(() => gl.cyl(0.045, 0.045, 0.05, 6, M(0, 0, 0.95, RX, 0, 0), glowC));
    if (e >= 7) g.cone(0.08, 0.24, 4, M(0, 0, 1.36, RX, 0, 0), metal);
    if (e >= 10) for (const sx of [1, -1]) gl.ico(0.07, 0, M(0.3 * sx, 0, 1.12), 0xffffff);
  }
  return { g, gl: glow ? gl : null, scale: 1 + (e >= 10 ? 0.15 : e >= 7 ? 0.1 : e >= 5 ? 0.05 : 0) + (uq ? 0.08 : 0), glowC };
}

// look: 플레이어 무기는 { r, l, e } (등급·레벨·강화). 몬스터·NPC 무기는 쓰지 않는다.
export function setWeapon(rig, kind, look = 0) {
  for (const m of rig.weaponParts) {
    m.parent.remove(m);
    m.geometry.dispose();
  }
  rig.weaponParts = [];
  rig.weaponMesh = null;
  rig.wkind = kind;
  rig.wglow = 0;
  rig.weapon.scale.setScalar(1);
  rig.weaponL.scale.setScalar(1);
  const add = (group, geo, glow) => {
    const m = mesh(geo, glow);
    group.add(m);
    rig.weaponParts.push(m);
    return m;
  };
  if (WEAPONS[kind]) {
    const w = buildPlayerWeapon(kind, typeof look === 'object' && look ? look : { r: 0, l: 1, e: 0 });
    rig.weaponMesh = add(rig.weapon, w.g, false);
    if (w.gl) add(rig.weapon, w.gl, true);
    rig.weapon.scale.setScalar(w.scale);
    rig.wglow = w.glowC;
    if (kind === 'dagger') {
      // 왼손에도 같은 단검
      const w2 = buildPlayerWeapon(kind, typeof look === 'object' && look ? look : { r: 0, l: 1, e: 0 });
      add(rig.weaponL, w2.g, false);
      if (w2.gl) add(rig.weaponL, w2.gl, true);
      rig.weaponL.scale.setScalar(w.scale);
    }
    return;
  }
  const g = new Geo();
  if (kind === 'club') {
    g.cyl(0.12, 0.05, 0.95, 6, M(0, 0, 0.42, Math.PI / 2, 0, 0), 0x5a3d25, 0x7a5a3a);
    g.ico(0.05, 0, M(0.1, 0, 0.75), 0xbfbfbf);
    g.ico(0.05, 0, M(-0.1, 0, 0.7), 0xbfbfbf);
    g.ico(0.05, 0, M(0, 0.1, 0.8), 0xbfbfbf);
  } else if (kind === 'rock') {
    g.ico(0.13, 0, M(0, 0, 0.05), 0x8a8f98, 0xb0b5bd, 0.4, 3);
  } else if (kind === 'staff') {
    g.cyl(0.03, 0.04, 1.7, 5, M(0, 0.35, 0.05), 0x7a5a3a);
    g.ico(0.09, 0, M(0, 1.25, 0.05), 0xffe27a);
  } else if (kind === 'bigsword') {
    g.box(0.2, 0.05, 1.5, M(0, 0, 0.9), 0x241c30, 0x6a50a8);
    g.taperBox(0.2, 0.3, 0.05, 0.05, M(0, 0, 1.8, Math.PI / 2, 0, 0), 0x8a6fd0);
    g.box(0.5, 0.08, 0.08, M(0, 0, 0.12), 0x8a6fd0);
    g.box(0.07, 0.07, 0.3, M(0, 0, -0.05), 0x1a1420);
  } else return;
  rig.weaponMesh = add(rig.weapon, g, false);
}

// 공격 동작의 진행도(0..1). 무거운 무기는 천천히 들어 올렸다가 빠르게 내리친다.
export function attackProgress(kind, anim, t) {
  const w = WEAPONS[kind] || WEAPONS.sword;
  const idx = anim === ANIM.THRUST ? 3 : anim - ANIM.ATK1;
  let h = w.hits[0];
  for (const q of w.hits) {
    if (q.anim === idx) {
      h = q;
      break;
    }
  }
  if (h.dur >= 0.6) {
    const q = Math.min(1, t / (h.at * 1.25));
    return q * q * q;
  }
  return Math.min(1, t / (h.dur * 0.75));
}

function newPose() {
  return { tRx: 0, tRy: 0, tRz: 0, hRx: 0, hRy: 0, aLf: 0, aLs: 0.1, aLy: 0, aRf: 0, aRs: 0.1, aRy: 0, lLf: 0, lRf: 0, lSp: 0, bodyY: 0, bodyZ: 0, bodyRx: 0, wRx: 0.4 };
}
const TGT = newPose();
const ease = (p) => 1 - (1 - p) * (1 - p) * (1 - p);
const lerp = (a, b, t) => a + (b - a) * t;

// anim: POSE 값, speed: 이동 속도(달리기 주기), atkP: 공격 진행도(0..1), dt
export function animateHumanoid(rig, anim, dt, speed = 0, atkP = 0) {
  rig.t += dt;
  const t = rig.t;
  const T = TGT;
  T.tRx = T.tRy = T.tRz = T.hRx = T.hRy = T.aLf = T.aLy = T.aRf = T.aRy = T.lLf = T.lRf = T.lSp = T.bodyY = T.bodyZ = T.bodyRx = 0;
  T.aLs = 0.1;
  T.aRs = 0.12;
  T.wRx = 0.4;
  let snap = 14;
  let direct = false;
  let glider = false;
  let bow = false;
  let stow = false; // 무기를 넣어 두는 동작
  const hunch = rig.opts.hunch || 0;
  const wk = rig.wkind;
  const two = wk === 'great' || wk === 'hammer' || wk === 'spear'; // 두 손으로 쥐는 무기

  if (anim === POSE.RUN || anim === POSE.SPRINT || anim === POSE.WALK) {
    rig.phase += Math.max(1.5, speed) * dt * (anim === POSE.WALK ? 2.6 : 1.85);
    const s = Math.sin(rig.phase);
    const c = Math.cos(rig.phase);
    const amp = anim === POSE.SPRINT ? 1.1 : anim === POSE.WALK ? 0.5 : 0.85;
    T.lLf = s * amp;
    T.lRf = -s * amp;
    T.aLf = -s * amp * 0.75;
    T.aRf = s * amp * 0.6 + 0.15;
    T.tRx = anim === POSE.SPRINT ? 0.3 : 0.12;
    T.tRy = s * 0.1;
    T.bodyY = Math.abs(c) * 0.05 * amp;
    snap = 22;
  } else if (anim === POSE.ROLL) {
    // 앞구르기: 몸을 웅크리고 허리 높이를 축으로 한 바퀴 돈다
    const a = Math.min(1, atkP) * Math.PI * 2;
    const tuck = Math.sin(Math.min(1, atkP) * Math.PI);
    T.bodyRx = a;
    T.bodyY = 0.5 * (1 - Math.cos(a)) - 0.42 * tuck;
    T.bodyZ = -0.5 * Math.sin(a);
    T.tRx = 0.9 * tuck; T.hRx = 0.6 * tuck;
    T.lLf = 1.9 * tuck; T.lRf = 1.7 * tuck; T.aLf = 1.5 * tuck; T.aRf = 1.4 * tuck; T.aLs = 0.3; T.aRs = 0.3;
    direct = true;
    stow = true;
  } else if (anim === POSE.JUMP) {
    T.lLf = 0.55; T.lRf = -0.25; T.aLs = 0.7; T.aRs = 0.7; T.aLf = 0.3; T.aRf = 0.3;
  } else if (anim === POSE.FALL) {
    T.aLs = 1.3 + Math.sin(t * 9) * 0.12; T.aRs = 1.3 - Math.sin(t * 9) * 0.12; T.lLf = 0.25; T.lRf = -0.2;
  } else if (anim === POSE.GLIDE) {
    T.aLf = 3.0; T.aRf = 3.0; T.aLs = 0.22; T.aRs = 0.22; T.lLf = -0.25 + Math.sin(t * 2) * 0.06; T.lRf = -0.38; T.bodyRx = 0.28; T.wRx = 1.4;
    glider = true;
    stow = true;
  } else if (anim === POSE.SWIM) {
    stow = true;
    rig.phase += dt * 6.5;
    T.bodyRx = 1.15; T.bodyY = 0.72;
    T.aLf = Math.PI + Math.sin(rig.phase) * 1.3; T.aRf = Math.PI - Math.sin(rig.phase) * 1.3;
    T.aLs = 0.3; T.aRs = 0.3;
    T.lLf = Math.sin(rig.phase * 2) * 0.4; T.lRf = -Math.sin(rig.phase * 2) * 0.4; T.hRx = -0.9;
    snap = 18;
  } else if (anim === POSE.SWIMIDLE) {
    stow = true;
    T.bodyRx = 0.15; T.bodyY = -0.12;
    T.aLs = 1.2 + Math.sin(t * 3) * 0.25; T.aRs = 1.2 + Math.sin(t * 3 + 1) * 0.25; T.aLf = 0.4; T.aRf = 0.4;
    T.lLf = Math.sin(t * 4) * 0.3; T.lRf = -Math.sin(t * 4) * 0.3;
  } else if (anim === POSE.CLIMB || anim === POSE.CLIMBIDLE) {
    stow = true;
    if (anim === POSE.CLIMB) rig.phase += dt * 7;
    const s = Math.sin(rig.phase);
    T.bodyRx = 0.5; T.aLf = 2.5 + s * 0.5; T.aRf = 2.5 - s * 0.5; T.lLf = 0.7 - s * 0.5; T.lRf = 0.7 + s * 0.5; T.hRx = -0.4;
  } else if (anim === POSE.ATK1 || anim === POSE.SWEEP || anim === POSE.SWEEPBACK) {
    const e = anim === POSE.SWEEPBACK ? 0 : ease(atkP);
    T.aRf = 1.45; T.aRy = lerp(-1.5, 1.3, e); T.wRx = 1.35; T.tRy = lerp(-0.55, 0.5, e); T.tRx = 0.15; T.aLs = 0.45; T.lLf = 0.4; T.lRf = -0.3;
    if (two) { T.aLf = 1.3; T.aLy = T.aRy * 0.55 - 0.45; T.aLs = 0.1; T.tRy = lerp(-0.8, 0.7, e); }
    direct = anim !== POSE.SWEEPBACK;
  } else if (anim === POSE.ATK2) {
    const e = ease(atkP);
    if (wk === 'dagger') {
      // 쌍단검: 왼손으로 반대쪽에서 벤다
      T.aLf = 1.45; T.aLy = lerp(1.5, -1.3, e); T.aRf = 0.9; T.aRy = 0.9; T.wRx = 1.35; T.tRy = lerp(0.55, -0.5, e); T.tRx = 0.15; T.lLf = -0.3; T.lRf = 0.4;
    } else {
      T.aRf = 1.45; T.aRy = lerp(1.3, -1.5, e); T.wRx = 1.35; T.tRy = lerp(0.5, -0.55, e); T.tRx = 0.15; T.aLs = 0.45; T.lLf = -0.3; T.lRf = 0.4;
      if (two) { T.aLf = 1.3; T.aLy = T.aRy * 0.55 - 0.45; T.aLs = 0.1; T.tRy = lerp(0.7, -0.8, e); }
    }
    direct = true;
  } else if (anim === POSE.THRUST) {
    // 찌르기: 허리께에서 앞으로 쭉 내지른다
    const e = ease(atkP);
    T.aRf = lerp(0.35, 1.5, e); T.aRs = lerp(0.35, 0.02, e); T.wRx = lerp(0.3, 1.47, e);
    T.aLf = lerp(0.9, 1.25, e); T.aLy = -0.5; T.aLs = 0.05;
    T.tRy = lerp(-0.6, 0.22, e); T.tRx = lerp(0.05, 0.3, e); T.bodyZ = lerp(-0.12, 0.26, e);
    T.lLf = lerp(0.1, 0.7, e); T.lRf = lerp(0, -0.55, e);
    direct = true;
  } else if (anim === POSE.RIDE || anim === POSE.RIDEIDLE || anim === POSE.RIDEATK || anim === POSE.RIDEBOW) {
    // 탈것 위: 다리를 벌리고 앉아 고삐를 쥔다
    stow = true;
    const run = anim !== POSE.RIDEIDLE && speed > 1;
    if (run) rig.phase += dt * 11;
    const b = run ? Math.sin(rig.phase) : 0;
    T.lLf = 1.05 + b * 0.06; T.lRf = 1.05 + b * 0.06; T.lSp = 0.5;
    T.aLf = 0.95 + b * 0.1; T.aRf = 0.95 + b * 0.1; T.aLy = -0.25; T.aRy = 0.25; T.aLs = 0.05; T.aRs = 0.05;
    T.tRx = run ? 0.28 + b * 0.05 : 0.06; T.hRx = run ? -0.2 : 0; T.bodyY = run ? Math.abs(b) * 0.06 : Math.sin(t * 2) * 0.01;
    snap = 16;
    if (anim === POSE.RIDEATK) {
      // 기마전: 한 손은 고삐를 쥔 채, 무기를 머리 위에서 비스듬히 내리긋는다
      const e = ease(atkP);
      stow = false;
      T.aRf = lerp(2.7, 0.55, e); T.aRy = lerp(-0.7, 0.85, e); T.aRs = lerp(0.5, 0.15, e); T.wRx = 1.3;
      T.tRy = lerp(-0.5, 0.5, e); T.tRx = lerp(0.0, 0.34, e);
      if (two) { T.aLf = lerp(2.4, 0.6, e); T.aLy = T.aRy * 0.5 - 0.3; T.aLs = 0.05; }
      direct = true;
    } else if (anim === POSE.RIDEBOW) {
      T.aLf = 1.5; T.aLs = -0.1; T.aLy = 0; T.aRf = 1.35; T.aRs = 0.55; T.aRy = 0; T.tRx = 0.02; T.wRx = 0.2;
      bow = true; snap = 30;
    }
  } else if (anim === POSE.ATK3 || anim === POSE.SMASH) {
    const e = ease(atkP);
    T.aRf = lerp(3.2, 0.45, e); T.aLf = lerp(2.9, 0.4, e); T.aLs = -0.15; T.aRs = -0.1; T.wRx = 1.2; T.tRx = lerp(-0.25, 0.5, e); T.lLf = 0.45; T.lRf = -0.35;
    T.bodyY = Math.sin(Math.min(1, atkP * 1.6) * Math.PI) * 0.16;
    direct = true;
  } else if (anim === POSE.RAISE) {
    T.aRf = 3.1; T.aLf = 2.8; T.aLs = -0.1; T.aRs = -0.1; T.wRx = 1.2; T.tRx = -0.28; T.bodyY = 0.04 + Math.sin(t * 30) * 0.008;
    snap = 9;
  } else if (anim === POSE.THROWBACK) {
    T.aRf = -1.2; T.aRs = 0.5; T.tRy = -0.5; T.aLf = 1.2; T.tRx = -0.1; snap = 10;
  } else if (anim === POSE.THROW) {
    T.aRf = 1.9; T.tRy = 0.45; T.tRx = 0.3; snap = 30;
  } else if (anim === POSE.ROAR) {
    T.aLs = 1.5; T.aRs = 1.5; T.aLf = 0.6; T.aRf = 0.6; T.tRx = -0.35; T.hRx = -0.5; T.bodyY = Math.sin(t * 40) * 0.01;
  } else if (anim === POSE.LUNGE) {
    T.tRx = 0.6; T.aRf = 1.5; T.wRx = 1.4; T.lLf = 0.8; T.lRf = -0.7; snap = 30;
  } else if (anim === POSE.CROUCH) {
    T.bodyY = -0.14; T.tRx = 0.35; T.aRf = -0.6; T.lLf = 0.5; T.lRf = 0.5; T.wRx = 1.2; snap = 9;
  } else if (anim === POSE.BOW) {
    T.aLf = 1.5; T.aLs = -0.1; T.aRf = 1.35; T.aRs = 0.55; T.tRx = -0.03; T.wRx = 0.2;
    bow = true; snap = 30;
  } else if (anim === POSE.HURT || anim === POSE.STAGGER) {
    T.tRx = -0.4; T.aLs = 0.9; T.aRs = 0.9; T.hRx = -0.3; snap = 25;
  } else if (anim === POSE.DEAD) {
    T.bodyRx = -1.52; T.bodyY = 0.16; T.aLs = 0.9; T.aRs = 0.9; snap = 6;
  } else if (anim === POSE.SIT) {
    T.bodyY = -0.5; T.lLf = 1.5; T.lRf = 1.45; T.aLs = 0.25; T.aRs = 0.25; T.aLf = 0.5; T.aRf = 0.5; T.tRx = -0.08;
  } else if (anim === POSE.WAVE) {
    T.aRs = 2.5 + Math.sin(t * 9) * 0.35; T.aRf = 0.1; T.hRy = 0.15; T.wRx = 1.4;
  } else if (anim === POSE.CHEER) {
    T.aLs = 2.6; T.aRs = 2.6; T.bodyY = Math.abs(Math.sin(t * 8)) * 0.16; T.wRx = 1.4;
  } else {
    // IDLE
    T.bodyY = Math.sin(t * 2) * 0.012;
    T.aRf = 0.15 + Math.sin(t * 2) * 0.02;
    T.hRy = Math.sin(t * 0.6) * 0.18;
  }
  T.tRx += hunch;
  T.hRx -= hunch * 0.6;

  const p = rig.p;
  // 구르기가 끝난 뒤 몸이 거꾸로 한 바퀴 되감기지 않도록
  if (anim !== POSE.ROLL && p.bodyRx > Math.PI) p.bodyRx -= Math.PI * 2;
  const k = direct ? 1 : Math.min(1, snap * dt);
  for (const key in T) p[key] += (T[key] - p[key]) * k;

  rig.torso.rotation.set(p.tRx, p.tRy, p.tRz);
  rig.head.rotation.set(p.hRx, p.hRy, 0);
  rig.armL.rotation.set(-p.aLf, p.aLy, p.aLs);
  rig.armR.rotation.set(-p.aRf, p.aRy, -p.aRs);
  rig.legL.rotation.x = -p.lLf;
  rig.legR.rotation.x = -p.lRf;
  rig.legL.rotation.z = p.lSp;
  rig.legR.rotation.z = -p.lSp;
  rig.body.position.y = p.bodyY;
  rig.body.position.z = p.bodyZ;
  rig.body.rotation.x = p.bodyRx;
  rig.weapon.rotation.x = p.wRx;
  rig.weaponL.rotation.x = p.wRx;
  if (rig.glider) rig.glider.visible = glider;
  if (rig.bow) {
    rig.bow.visible = bow;
    rig.weapon.visible = !bow && !stow;
    rig.weaponL.visible = !bow && !stow;
  }
}

// ---------- 플레이어/NPC 외형 ----------
export function playerLook(profile) {
  const tunic = TUNIC_COLORS[profile.tunic % TUNIC_COLORS.length];
  const hair = HAIR_COLORS[profile.hair % HAIR_COLORS.length];
  const eq = profile.eq || {};
  // 갑옷 외형: 없음 -> 가죽 -> 강철 -> 빛나는 판금 (아이템 레벨 구간에 따라)
  const ab = eq.armor ? bandOf(eq.armor.l) : -1;
  const armor = ab < 0 ? 0 : ab <= 1 ? 1 : ab === 2 ? 2 : 3;
  const ar = eq.armor ? eq.armor.r : 0;
  const plate = armor === 3 ? (ab >= 8 ? 0xfff0d0 : ab === 7 ? 0x9ab8f4 : ab === 6 ? 0xf0a070 : ab === 5 ? 0xf2c66a : ab === 4 ? 0xcfc8f0 : 0xe2dcc0) : 0xaab4c2;
  const w = eq.weapon;
  // 전직한 모험가의 목도리는 그 길의 빛깔이다 (내 저장: job { c, t } / 다른 사람의 프로필: jc, jt)
  const jc = profile.job ? profile.job.c : profile.jc;
  const jt = profile.job ? profile.job.t : profile.jt;
  const jobColor = jt > 0 && JOBS[jc] ? JOBS[jc].color : null;
  return {
    scale: 1, skin: 0xf2c9a0, tunic, hair, hairStyle: profile.hair % 2 ? 'bun' : 'short',
    pants: armor >= 2 ? 0x6a7482 : 0x4a4a5a, boots: armor ? 0x4a3524 : 0x6a4a2c,
    scarf: jobColor ?? 0xf4ede0, band: shade(tunic, 0.7), backpack: true, glider: true, bow: true,
    gliderColor: tunic, weapon: w && WEAPONS[w.t] ? w.t : 'none', weaponLook: w ? { r: w.r, l: w.l, e: w.e || 0, u: w.u } : null,
    pauldrons: armor >= 2 ? (ar >= 2 ? RARITY[ar].color : plate) : armor === 1 ? 0x7a5a3a : null,
    sleeve: armor >= 2 ? shade(plate, 0.82) : tunic,
    apron: armor === 3 ? plate : null,
    beltColor: armor === 3 ? 0xe6c14a : undefined,
    helm: eq.helm ? { band: bandOf(eq.helm.l), r: eq.helm.r } : null,
  };
}

// ---------- 탈것 (말) ----------
// 히든 탈것의 빛깔. body 몸, mane 빛나는 갈기와 꼬리, eye 눈, hoof 발굽
const MOUNT_LOOK = {
  ember: { body: 0xb02a18, mane: 0xff8a2a, tip: 0xffe27a, eye: 0xffd35a, hoof: 0x3a1410 },
  frost: { body: 0xe6f2ff, mane: 0x8fdcff, tip: 0xffffff, eye: 0x5fd0ff, hoof: 0x9fc4dc },
  shade: { body: 0x2c2544, mane: 0xb06aff, tip: 0xe9c8ff, eye: 0xd08aff, hoof: 0x0c0a12 },
};

// kind: 'horse' 또는 히든 탈것. wild: 들판에 서 있는 길들이기 전의 모습 (안장이 없다)
export function makeHorse(colorIdx = 0, saddle = 0xd9483b, kind = 'horse', wild = false) {
  const L = MOUNT_LOOK[kind];
  const c = L ? L.body : MOUNT_COLORS[colorIdx % MOUNT_COLORS.length];
  const dark = shade(c, 0.66);
  const hairC = L ? shade(L.mane, 0.55) : colorIdx === 1 ? 0xcfc4b0 : colorIdx === 3 ? 0xf4ecda : colorIdx === 4 ? 0x3a3a44 : shade(c, 0.36);
  const root = new THREE.Group();
  const body = new THREE.Group();
  body.position.y = 1.04;
  root.add(body);
  const g = new Geo();
  g.box(0.56, 0.6, 1.3, M(0, 0.1, 0), dark, c);
  g.ico(0.36, 0, M(0, 0.12, 0.64, 0, 0, 0, 0.82, 0.9, 0.9), dark, c, 0.08, 3);
  g.ico(0.38, 0, M(0, 0.14, -0.62, 0, 0, 0, 0.8, 0.88, 0.9), dark, c, 0.08, 5);
  // 안장과 깔개
  if (!wild) {
    g.box(0.66, 0.05, 0.86, M(0, 0.42, -0.04), L ? shade(L.mane, 0.5) : 0xf4ede0);
    g.box(0.5, 0.1, 0.58, M(0, 0.48, -0.06), shade(saddle, 0.7), saddle);
    g.box(0.5, 0.12, 0.1, M(0, 0.53, -0.36), shade(saddle, 0.7), saddle);
    for (const sx of [1, -1]) g.box(0.03, 0.42, 0.06, M(0.3 * sx, 0.2, 0.0), 0x5a3d25);
  }
  body.add(mesh(g));
  // 목과 머리 (끄덕이도록 따로)
  const neck = new THREE.Group();
  neck.position.set(0, 0.3, 0.62);
  const ng = new Geo();
  ng.box(0.26, 0.8, 0.36, M(0, 0.34, 0.12, 0.55, 0, 0), dark, c);
  ng.box(0.24, 0.3, 0.56, M(0, 0.72, 0.44, 0.35, 0, 0), dark, c);
  ng.box(0.2, 0.2, 0.2, M(0, 0.61, 0.72, 0.35, 0, 0), shade(c, 0.5));
  ng.cone(0.05, 0.15, 4, M(0.08, 0.92, 0.3), dark);
  ng.cone(0.05, 0.15, 4, M(-0.08, 0.92, 0.3), dark);
  ng.box(0.04, 0.05, 0.03, M(0.125, 0.78, 0.5), 0x1f1a1a);
  ng.box(0.04, 0.05, 0.03, M(-0.125, 0.78, 0.5), 0x1f1a1a);
  ng.box(0.07, 0.78, 0.14, M(0, 0.42, -0.04, 0.55, 0, 0), hairC);
  if (!wild) ng.box(0.27, 0.05, 0.3, M(0, 0.66, 0.6, 0.35, 0, 0), 0x5a3d25);
  neck.add(mesh(ng));
  if (L) {
    // 빛나는 갈기와 눈
    const mg = new Geo();
    for (let i = 0; i < 5; i++) mg.cone(0.09, 0.36 - i * 0.03, 4, M(0, 0.78 - i * 0.17, 0.12 - i * 0.11, -0.9, 0, 0), L.mane, L.tip);
    mg.cone(0.07, 0.26, 4, M(0, 1.0, 0.36, 0.3, 0, 0), L.mane, L.tip);
    mg.box(0.05, 0.06, 0.035, M(0.128, 0.78, 0.5), L.eye);
    mg.box(0.05, 0.06, 0.035, M(-0.128, 0.78, 0.5), L.eye);
    neck.add(mesh(mg, true));
  }
  body.add(neck);
  const tail = new THREE.Group();
  tail.position.set(0, 0.34, -0.9);
  const tg = new Geo();
  tg.cone(0.12, 0.9, 5, M(0, -0.42, -0.15, 3.49, 0, 0), shade(hairC, 0.8), hairC);
  tail.add(mesh(tg));
  if (L) {
    const tl = new Geo();
    tl.cone(0.15, 1.05, 5, M(0, -0.48, -0.17, 3.49, 0, 0), L.tip, L.mane);
    tail.add(mesh(tl, true));
  }
  body.add(tail);
  const legs = [];
  for (const [x, z] of [[0.18, 0.5], [-0.18, 0.5], [0.18, -0.52], [-0.18, -0.52]]) {
    const leg = new THREE.Group();
    leg.position.set(x, -0.12, z);
    const lg = new Geo();
    lg.box(0.17, 0.5, 0.2, M(0, -0.22, 0), dark, c);
    lg.box(0.12, 0.42, 0.14, M(0, -0.64, 0), dark, c);
    lg.box(0.15, 0.1, 0.17, M(0, -0.87, 0.01), L ? L.hoof : 0x2a2420);
    leg.add(mesh(lg));
    if (L) {
      const hg = new Geo();
      hg.box(0.17, 0.04, 0.19, M(0, -0.8, 0.01), L.mane);
      leg.add(mesh(hg, true));
    }
    body.add(leg);
    legs.push(leg);
  }
  root.scale.setScalar(L ? 1.2 : 1.12);
  return { kind: 'horse', mount: kind, look: L || null, root, body, neck, tail, legs, t: Math.random() * 10, phase: 0, seat: L ? 1.22 : 1.14, scale: L ? 1.2 : 1.12 };
}

// 탈것이 선 자리의 기울기 (앞이 높으면 +). 비탈과 절벽에서 몸을 땅에 맞춰 기울일 때 쓴다
export function slopePitch(world, x, z, yaw) {
  const sx = Math.sin(yaw) * 1.1;
  const sz = Math.cos(yaw) * 1.1;
  const a = Math.max(world.heightAt(x + sx, z + sz), -0.12);
  const b = Math.max(world.heightAt(x - sx, z - sz), -0.12);
  return Math.max(-1.2, Math.min(1.2, Math.atan2(a - b, 2.2)));
}

// 탈것을 놓고 그 위에 사람을 앉힌다. pitch: 땅의 기울기
export function seatRider(horse, rig, x, y, z, yaw, pitch) {
  const hr = horse.root;
  hr.rotation.order = 'YXZ';
  hr.position.set(x, y, z);
  hr.rotation.set(-pitch, yaw, 0);
  const seat = (horse.body.position.y - 1.04) * horse.scale + horse.seat;
  const back = Math.sin(pitch) * seat;
  rig.root.rotation.order = 'YXZ';
  rig.root.rotation.x = -pitch;
  rig.root.position.set(x - Math.sin(yaw) * back, y + Math.cos(pitch) * seat, z - Math.cos(yaw) * back);
}

export function animateHorse(rig, dt, speed) {
  rig.t += dt;
  const k = Math.min(1, dt * 16);
  let amp = 0;
  let bob = 0;
  let pitch = 0;
  let nod = 0.08 + Math.sin(rig.t * 1.3) * 0.04;
  let off = Math.PI; // 앞다리와 뒷다리의 엇박
  if (speed > 9) {
    // 달리기
    rig.phase += dt * (9 + speed * 0.42);
    amp = 0.95;
    off = 1.1;
    bob = Math.abs(Math.sin(rig.phase)) * 0.14;
    pitch = Math.sin(rig.phase) * 0.07;
    nod = -0.18 + Math.sin(rig.phase) * 0.12;
  } else if (speed > 0.6) {
    rig.phase += dt * (3 + speed * 0.75);
    amp = 0.5;
    bob = Math.abs(Math.sin(rig.phase)) * 0.05;
    nod = Math.sin(rig.phase * 2) * 0.07;
  }
  const s = Math.sin(rig.phase);
  const s2 = Math.sin(rig.phase + off);
  const tg = speed > 9 ? [s, Math.sin(rig.phase + 0.35), s2, Math.sin(rig.phase + off + 0.35)] : [s, -s, -s, s];
  for (let i = 0; i < 4; i++) rig.legs[i].rotation.x += (-tg[i] * amp - rig.legs[i].rotation.x) * k;
  rig.body.position.y += (1.04 + bob - rig.body.position.y) * k;
  rig.body.rotation.x += (pitch - rig.body.rotation.x) * k;
  rig.neck.rotation.x += (nod - rig.neck.rotation.x) * Math.min(1, dt * 8);
  rig.tail.rotation.x = speed > 9 ? 0.9 : 0.1 + Math.sin(rig.t * 2.2) * 0.08;
  rig.tail.rotation.y = Math.sin(rig.t * 3) * 0.25;
}

export function npcLook(kind) {
  switch (kind) {
    case 'elder':
      return { scale: 1.02, skin: 0xe8bf98, tunic: 0x6a4f9a, robe: 0x6a4f9a, hair: 0xe9e9ee, hairStyle: 'long', beard: 0xf2f2f5, weapon: 'staff', pants: 0x4a3a6a, belt: false, skirt: false };
    case 'merchant':
      return { scale: 1, skin: 0xf0c49a, tunic: 0x4f8a5a, apron: 0xe8dcc0, hair: 0x3a2a1e, hat: 'straw', backpack: true };
    case 'smith':
      return { scale: 1.08, skin: 0xd9a57a, tunic: 0x5a4a44, apron: 0x3a3030, hairStyle: 'bald', beard: 0x3a2a1e, bulk: 1.25, armBulk: 1.4, bareArms: true };
    case 'kid':
      return { scale: 0.68, skin: 0xf6d2ae, tunic: 0xf2c53a, hair: 0x5a3a22, hairStyle: 'bun', headSize: 1.18, pants: 0x4f6fa8 };
    case 'master':
      // 스승 가람: 흰 수염에 남빛 도복, 붉은 띠
      return { scale: 1.06, skin: 0xe2b48c, tunic: 0x2f4a7a, robe: 0x2f4a7a, hair: 0xdfe3ea, hairStyle: 'bun', beard: 0xeef0f4, scarf: 0xc8452f, pants: 0x26354f, band: 0xc8452f, beltColor: 0xc8452f, weapon: 'staff', skirt: false };
    default:
      return { scale: 1, skin: 0xe9bd92, tunic: 0x7a6a50, hair: 0x3a2a1e, hat: 'hood', hatColor: 0x6a5a45, backpack: true, scarf: 0xb5523a, pants: 0x4a4038 };
  }
}

// ---------- 몬스터 외형 ----------
// 지역별 색: 초원, 숲, 설산, 사막, 늪, 화산, 단풍, 벚꽃, 버섯, 수정, 그림자, 바람 협곡, 얼음 호수, 거인의 계단, 산호 군도, 하늘 기둥, 별똥 분지, 노을 평원, 거울 소금밭, 천둥 산맥, 은하수 들판
const SLIME_COL = [0x6fd06a, 0x3fae8f, 0xbfe9ff, 0xe9c040, 0x9a7fd0, 0xf0703a, 0xf0a040, 0xff9ac8, 0x4fe0c0, 0xb9a8ff, 0x6a52a8, 0xe08a4a, 0x9fdcff, 0xa8d84a, 0xff7f8a, 0x7fc8a0, 0x6f8cff, 0xf0b040, 0xffc8d4, 0x5a7ae0, 0x9af0ff];
const GOBLIN_COL = [0x5fae8a, 0x4a8f6a, 0x8fb4c9, 0xc9a05a, 0x6a8f5a, 0x8a5a5a, 0x9a8a4a, 0x9cc08a, 0x4f9a8a, 0x9a94c9, 0x5a4a6a, 0xc07a4e, 0x8fc0dc, 0x86b04a, 0x4fb8a8, 0x7a9a80, 0x5a64a8, 0xc8904a, 0xd8a8a0, 0x4a5878, 0x7ab8d8];
const WOLF_COL = [0x7a7f88, 0x6a6f78, 0xe8edf5, 0xb59a6a, 0x5a6058, 0x4a4044, 0x9a6a45, 0xf0d8e0, 0x4a6a66, 0xcfd0f5, 0x2a2434, 0xb5754a, 0xd8ecfa, 0x8a6a48, 0xd8c8a0, 0x6a7a70, 0x343a6a, 0xc89a52, 0xf0dcd8, 0x2c3448, 0xbfe4f4];
const GOLEM_COL = [
  [0x7f848c, 0xa9aeb6, 0x6fbe4c], [0x6f7a70, 0x98a498, 0x4f9a48], [0x9fb4d0, 0xe4eefc, 0xbfe9ff], [0xc98f5f, 0xe9c890, 0xe9cf8c],
  [0x5a6050, 0x7f8a70, 0x6f8a4e], [0x3a3233, 0x5a4a48, 0xff6a2a], [0x8f8478, 0xb5a898, 0xe07a2a],
  [0xb8a0a8, 0xe8d0d8, 0xff9ac8], [0x4a6a60, 0x6f9a8a, 0x4fe0c0], [0x8a84c8, 0xcfc8f8, 0xb9a8ff], [0x2a2434, 0x4a4060, 0x8a5ad0],
  [0xb0583a, 0xdc9a68, 0xf0c070], [0x86bfe2, 0xe8f6ff, 0xbfe9ff], [0x9a9070, 0xc4ba94, 0x6fb84a],
  [0xd98a7a, 0xf4c8b8, 0x3fd6c8], [0x6f7a70, 0x9eaa9c, 0x5a9a5a], [0x2b2e52, 0x4c5290, 0x7a9aff],
  [0xa9764a, 0xd8a870, 0xf0c050], [0xd8b0a8, 0xfff0ec, 0xff9ab0], [0x262c3a, 0x48546c, 0x6fb0ff], [0x5a5fa8, 0xa8b0f0, 0x9af0ff],
];
const GOLEM_EYE = [0x8fffd0, 0x8fffd0, 0x9ad6ff, 0xffe27a, 0xc8ff7a, 0xff8a3a, 0xffb05a, 0xffb0d8, 0x7fffe0, 0xd0c0ff, 0xc07aff, 0xffc45a, 0x9ae8ff, 0xb8ff7a, 0x7ffff0, 0xd8ffb0, 0x9ab8ff, 0xffc45a, 0xffa0c0, 0x8fd0ff, 0xd0f8ff];
// 불도깨비·설인·전갈은 지역에 따라 빛깔이 달라진다
const IMP_COL = { 8: 0x3fb0a0, 9: 0x8a7ae0, 10: 0x4a2a6a, 12: 0x5fb4ea, 15: 0x6fb88a, 16: 0x4a64f0, 18: 0xf08aa0, 19: 0x3a5ac8, 20: 0x6ad8f0 };
const YETI_COL = { 9: [0x8a84c8, 0xdcd8ff, 0xcfc8f8], 10: [0x2a2434, 0x4a4060, 0x3a3050], 12: [0x6fa8d0, 0xe6f6ff, 0xc8e6f8], 15: [0x66806a, 0xcfdcc4, 0xb4c6ac], 16: [0x343a78, 0xa4b0ff, 0x6a76cc], 19: [0x2c3448, 0x8a9ac0, 0x566684], 20: [0x5a6ab8, 0xe0f4ff, 0xa8c8f0] };
const SCORPION_COL = { 8: [0x3f9a8a, 0x24584e], 11: [0xc8502e, 0x6a2a1c], 14: [0xf0606a, 0x8a2a3a], 17: [0xd8a23a, 0x7a4a1c], 18: [0xf4b8c0, 0xa8506a] };

export function makeMonster(type, biome, elite, minion) {
  const b = Math.min(biome, SLIME_COL.length - 1);
  let rig;
  if (type === 'slime') rig = makeSlime(minion ? 0x5a4a8a : SLIME_COL[b], elite);
  else if (type === 'wolf') rig = makeWolf(WOLF_COL[b], elite);
  else if (type === 'scorpion') rig = makeScorpion(elite, SCORPION_COL[b]);
  else if (type === 'goblin') {
    rig = makeHumanoid({ scale: elite ? 1.5 : 1.02, skin: GOBLIN_COL[b], tunic: 0x7a5a3a, pants: 0x5a4030, boots: GOBLIN_COL[b], hairStyle: 'bald', horns: elite ? 2 : 1, tusks: true, ears: true, weapon: 'club', hunch: 0.22, bareArms: true, sleeve: GOBLIN_COL[b], belt: false, headSize: 1.12, armLen: 1.12, eyeColor: 0xffe27a, pauldrons: elite ? 0x5a5a66 : null });
  } else if (type === 'thrower') {
    rig = makeHumanoid({ scale: 0.95, skin: GOBLIN_COL[b], tunic: 0x8a4a3a, pants: 0x5a4030, boots: GOBLIN_COL[b], hairStyle: 'bald', horns: 1, ears: true, weapon: 'rock', hunch: 0.15, bareArms: true, sleeve: GOBLIN_COL[b], band: 0xd9483b, headSize: 1.1, eyeColor: 0xffe27a });
  } else if (type === 'imp') {
    const ic = minion ? 0x6a4a9a : IMP_COL[b] || 0xd9502f;
    rig = makeHumanoid({ scale: elite ? 1.3 : 0.86, skin: ic, tunic: 0x4a2a2a, pants: 0x3a2224, boots: 0x3a2224, hairStyle: 'bald', horns: 2, ears: true, weapon: 'none', hunch: 0.12, bareArms: true, sleeve: ic, belt: false, headSize: 1.2, tail: shade(ic, 0.8), glowEyes: 0xffe27a, eyes: false });
  } else if (type === 'yeti') {
    const yc = YETI_COL[b] || [0x8fa0b5, 0xf0f4fa, 0xe4eaf2];
    rig = makeHumanoid({ scale: elite ? 2.1 : 1.65, skin: yc[0], tunic: yc[1], pants: yc[2], boots: shade(yc[2], 0.9), hair: yc[1], hairStyle: 'short', bulk: 1.55, armLen: 1.3, armBulk: 1.7, legBulk: 1.5, legLen: 0.8, weapon: 'none', hunch: 0.25, sleeve: yc[1], glove: yc[2], belt: false, skirt: false, headSize: 0.95, horns: elite ? 2 : 0, eyeColor: 0x2a3a5a, glowEyes: b === 10 ? 0xc07aff : null, eyes: b !== 10 });
  } else if (type === 'golem') {
    const c = GOLEM_COL[b];
    rig = makeHumanoid({ kind: 'golem', scale: 2.4, rock: c[0], rock2: c[1], accent: c[2], glowEyes: GOLEM_EYE[b], core: GOLEM_EYE[b], bulk: 1, armLen: 1.25, legLen: 0.75, weapon: 'none', hunch: 0.1 });
  } else if (type === 'lord') {
    rig = makeHumanoid({ scale: 3.3, skin: 0x2a2438, tunic: 0x241c30, pants: 0x1a1424, boots: 0x120e1a, hairStyle: 'bald', horns: 3, weapon: 'bigsword', bulk: 1.35, armBulk: 1.5, legBulk: 1.3, sleeve: 0x2a2438, glove: 0x1a1424, cape: 0x4a2a6a, pauldrons: 0x5a4a80, glowEyes: 0xff5ad0, eyes: false, core: 0xff5ad0, beltColor: 0x8a6fd0, headSize: 0.9 });
  } else if (type === 'kingslime') {
    // 던전 보스: 왕관을 쓴 거대한 말랑이
    rig = makeSlime(0x3a62d8, true);
    rig.root.scale.setScalar(3.1);
    rig.height = 4.0;
  } else if (type === 'tyrant') {
    // 던전 보스: 뿔 달린 거대한 설인
    rig = makeHumanoid({ scale: 3.0, skin: 0x5a6a9a, tunic: 0xcfe0ff, pants: 0xaac0e8, boots: 0x8fa8d8, hair: 0xe8f2ff, hairStyle: 'short', bulk: 1.7, armLen: 1.35, armBulk: 1.9, legBulk: 1.6, legLen: 0.8, weapon: 'club', hunch: 0.28, sleeve: 0xcfe0ff, glove: 0xaac0e8, belt: false, skirt: false, headSize: 0.95, horns: 3, glowEyes: 0x9ad6ff, eyes: false, core: 0x9ad6ff, pauldrons: 0x8fb4e8 });
  } else if (type === 'knight') {
    // 던전 보스: 텅 빈 갑옷의 기사
    rig = makeHumanoid({ scale: 2.3, skin: 0x1a1a24, tunic: 0x30323e, pants: 0x22242e, boots: 0x16171e, hairStyle: 'bald', weapon: 'bigsword', bulk: 1.25, armBulk: 1.35, legBulk: 1.25, sleeve: 0x3a3c4a, glove: 0x22242e, cape: 0x1f3a6a, pauldrons: 0x5a6a8a, glowEyes: 0x6fe0ff, eyes: false, core: 0x6fe0ff, beltColor: 0x6fe0ff, headSize: 0.92, helm: { band: 4, r: 2 }, apron: 0x4a4e5e });
  } else if (type === 'empress') {
    // 바람굴의 주인: 금빛 등딱지에 가시 왕관을 두른 거대한 전갈
    rig = makeScorpion(false, [0xe2a83a, 0x5a2a7a]);
    const cg = new Geo();
    for (let k = 0; k < 5; k++) {
      const a = (k - 2) * 0.42;
      cg.cone(0.07, 0.34, 4, M(Math.sin(a) * 0.36, 0.32, 0.32 + Math.cos(a) * 0.2, 0.35, 0, -a * 0.5), 0xffe27a, 0xfff6c8);
    }
    cg.ico(0.1, 0, M(0, 0.3, 0.2), 0xff7ad0);
    rig.body.add(mesh(cg, true));
    rig.root.scale.setScalar(3.3);
    rig.height = 3.6;
  } else if (type === 'tidelord') {
    // 가라앉은 신전의 주인: 물빛 옷자락을 끌고 지팡이를 든 키 큰 술사
    rig = makeHumanoid({ scale: 2.6, skin: 0x3f8fa8, tunic: 0x1f5a7a, robe: 0x1f5a7a, pants: 0x174a66, boots: 0x123a52, hair: 0xbff4ff, hairStyle: 'long', beard: 0xbff4ff, weapon: 'staff', belt: false, skirt: false, horns: 2, bulk: 1.15, sleeve: 0x2a7f9a, glove: 0x174a66, cape: 0x2a7f9a, pauldrons: 0xff7f8a, glowEyes: 0x7ffff0, eyes: false, core: 0x7ffff0, headSize: 0.95 });
  } else if (type === 'starborn') {
    // 별똥 구덩이의 주인: 밤하늘빛 갑옷에 별빛 눈을 한 검사
    rig = makeHumanoid({ scale: 2.7, skin: 0x1c2048, tunic: 0x2b2e62, pants: 0x1c2048, boots: 0x14173a, hairStyle: 'bald', horns: 2, weapon: 'bigsword', bulk: 1.3, armBulk: 1.4, legBulk: 1.25, sleeve: 0x2b2e62, glove: 0x14173a, cape: 0x3a4ad0, pauldrons: 0x7a9aff, glowEyes: 0xfff2a8, eyes: false, core: 0xfff2a8, beltColor: 0xfff2a8, headSize: 0.9, helm: { band: 4, r: 3 }, apron: 0x3a418a });
  } else if (type === 'devourer') {
    // 레이드 보스: 밤하늘빛 바위로 된 거인. 가슴에 삼킨 별이 타오르고, 어깨와 등에 별 조각이 박혀 있다
    rig = makeHumanoid({ kind: 'golem', scale: 4.7, rock: 0x3a3f8c, rock2: 0x7078d8, accent: 0x9ab8ff, glowEyes: 0xffe27a, core: 0xffe27a, bulk: 1.1, armLen: 1.3, legLen: 0.75, weapon: 'none', hunch: 0.12 });
    const sg = new Geo();
    for (let k = 0; k < 7; k++) {
      const a = (k / 7) * Math.PI * 2;
      const up = k % 2 ? 0.34 : 0.5;
      sg.cone(0.09, up, 4, M(Math.sin(a) * 0.62, 0.98, Math.cos(a) * 0.3 - 0.12, Math.cos(a) * 0.5, 0, -Math.sin(a) * 0.7), 0xffe27a, 0xfff6d8);
    }
    for (const sx of [1, -1]) sg.ico(0.12, 0, M(sx * 0.8, 0.8, 0.05), 0x9ab8ff);
    rig.torso.add(mesh(sg, true));
  } else if (type === 'dragon') rig = makeDragon();
  else if (type === 'blacksun') rig = makeBlackSun();
  else if (type === 'pylon') rig = makePylon();
  else rig = makeSlime(0xffffff, false);
  rig.type = type;
  return rig;
}

// ---- 황혼의 용 (2장의 마지막 상대): 노을빛 비늘에 보랏빛 날개막, 금빛 뿔 ----
// 네 발로 걷고, 긴 목과 꼬리를 흔든다. 몸통 길이 약 7m
function makeDragon() {
  const S = 1.25;
  const root = new THREE.Group();
  root.scale.setScalar(S);
  root.userData.baseScale = S;
  const body = new THREE.Group();
  body.position.y = 1.9;
  root.add(body);
  const c1 = 0xb8432a; // 등 비늘
  const c2 = 0xf08a3c; // 밝은 비늘
  const belly = 0x4a2a5a;
  const horn = 0xf2d27a;
  const g = new Geo();
  g.ico(1.0, 1, M(0, 0, 0, 0, 0, 0, 1.15, 1.0, 2.1), belly, c1, 0.06, 5);
  g.ico(0.85, 1, M(0, 0.25, 0.9, 0, 0, 0, 1.2, 1.0, 1.2), c1, c2, 0.06, 7);
  // 등줄기의 가시
  for (let k = 0; k < 6; k++) g.cone(0.13, 0.55 - Math.abs(k - 2.2) * 0.06, 4, M(0, 0.98 - Math.abs(k - 2) * 0.05, 1.3 - k * 0.62, -0.25, 0, 0), horn, 0xfff2c0);
  body.add(mesh(g));

  // 목: 세 마디가 앞으로 솟아오른다
  const neck = [];
  let parent = body;
  for (let k = 0; k < 3; k++) {
    const seg = new THREE.Group();
    seg.position.set(0, k === 0 ? 0.45 : 0.72, k === 0 ? 1.55 : 0.18);
    const ng = new Geo();
    ng.ico(0.5 - k * 0.07, 0, M(0, 0.36, 0.08, 0, 0, 0, 1, 1.5, 1), belly, c1, 0.08, 11 + k);
    ng.cone(0.09, 0.34, 4, M(0, 0.5, -0.36 + k * 0.03, -0.5, 0, 0), horn, 0xfff2c0);
    seg.add(mesh(ng));
    parent.add(seg);
    parent = seg;
    neck.push(seg);
  }
  // 머리
  const head = new THREE.Group();
  head.position.set(0, 0.78, 0.12);
  const hg = new Geo();
  hg.ico(0.5, 0, M(0, 0.1, 0.1, 0, 0, 0, 1.0, 0.85, 1.25), c1, c2, 0.08, 21);
  hg.taperBox(0.56, 0.9, 0.36, 0.6, M(0, 0.02, 0.85, Math.PI / 2, 0, 0), c1, c2);
  for (const sx of [1, -1]) {
    hg.cone(0.11, 0.85, 5, M(0.27 * sx, 0.6, -0.3, -0.9, 0, -0.25 * sx), horn, 0xfff6d8);
    hg.cone(0.07, 0.4, 4, M(0.42 * sx, 0.3, -0.25, -1.2, 0, -0.7 * sx), horn, 0xfff6d8);
    hg.cone(0.06, 0.2, 4, M(0.16 * sx, -0.16, 1.2, Math.PI, 0, 0), 0xfff6d8); // 송곳니
  }
  head.add(mesh(hg));
  const eg = new Geo();
  for (const sx of [1, -1]) eg.box(0.1, 0.1, 0.16, M(0.3 * sx, 0.24, 0.42, 0, 0.3 * sx, 0), 0xffe27a);
  head.add(mesh(eg, true));
  const jaw = new THREE.Group();
  jaw.position.set(0, -0.12, 0.42);
  const jg = new Geo();
  jg.taperBox(0.48, 0.8, 0.16, 0.6, M(0, -0.04, 0.4, Math.PI / 2, 0, 0), belly, c1);
  jaw.add(mesh(jg));
  // 벌린 입 속의 불빛
  const fg = new Geo();
  fg.ico(0.2, 0, M(0, 0.05, 0.3, 0, 0, 0, 1, 0.5, 1.6), 0xffb04a);
  const fire = mesh(fg, true);
  jaw.add(fire);
  head.add(jaw);
  neck[2].add(head);

  // 꼬리: 다섯 마디
  const tail = [];
  parent = body;
  for (let k = 0; k < 5; k++) {
    const seg = new THREE.Group();
    seg.position.set(0, k === 0 ? 0.05 : 0, k === 0 ? -1.85 : -0.72);
    const tg = new Geo();
    const r = 0.5 - k * 0.085;
    tg.ico(r, 0, M(0, 0, -0.36, 0, 0, 0, 1, 0.9, 1.9), belly, c1, 0.08, 31 + k);
    if (k < 4) tg.cone(0.08, 0.3, 4, M(0, r * 0.8, -0.3, -0.3, 0, 0), horn, 0xfff2c0);
    else {
      tg.cone(0.2, 0.7, 4, M(0, 0, -0.9, -Math.PI / 2, 0, 0), horn, 0xfff6d8);
      for (const sx of [1, -1]) tg.cone(0.12, 0.45, 4, M(0.2 * sx, 0, -0.6, -Math.PI / 2, 0, -0.9 * sx), horn, 0xfff6d8);
    }
    seg.add(mesh(tg));
    parent.add(seg);
    parent = seg;
    tail.push(seg);
  }

  // 다리 넷
  const legs = [];
  for (const [x, z, front] of [[0.85, 1.05, 1], [-0.85, 1.05, 1], [0.85, -1.0, 0], [-0.85, -1.0, 0]]) {
    const leg = new THREE.Group();
    leg.position.set(x, -0.1, z);
    const lg = new Geo();
    lg.ico(0.44, 0, M(0, -0.2, 0, 0, 0, 0, 0.9, 1.5, 1.1), c1, c2, 0.08, 41);
    lg.box(0.3, 1.0, 0.34, M(0, -1.1, front ? 0.1 : -0.06, front ? 0.15 : -0.2, 0, 0), belly, c1);
    lg.box(0.42, 0.22, 0.66, M(0, -1.68, 0.2), belly, c1);
    for (const cx of [-0.14, 0, 0.14]) lg.cone(0.06, 0.24, 4, M(cx, -1.72, 0.6, Math.PI / 2, 0, 0), 0xfff6d8);
    leg.add(mesh(lg));
    body.add(leg);
    legs.push(leg);
  }

  // 날개: 어깨에서 뻗은 뼈 셋 사이에 막이 걸려 있다
  const wings = [];
  for (const sx of [1, -1]) {
    const wing = new THREE.Group();
    wing.position.set(0.7 * sx, 0.75, 0.75);
    const wg = new Geo();
    const A = [0, 0, 0];
    const B = [2.3 * sx, 1.5, 0.3];
    const tips = [[4.9 * sx, 2.2, 0.9], [4.6 * sx, 0.9, -1.3], [3.1 * sx, 0.1, -2.6], [0.8 * sx, -0.2, -2.2]];
    const bone = (p, q, r) => {
      const dx = q[0] - p[0];
      const dy = q[1] - p[1];
      const dz = q[2] - p[2];
      const len = Math.hypot(dx, dy, dz);
      // 기둥(+y 방향)을 뼈의 방향으로 눕힌다
      wg.cyl(r * 0.6, r, len, 4, M((p[0] + q[0]) / 2, (p[1] + q[1]) / 2, (p[2] + q[2]) / 2, Math.atan2(dz, dy), 0, -Math.asin(dx / len)), c1, c2);
    };
    bone(A, B, 0.14);
    for (const t of tips.slice(0, 3)) bone(B, t, 0.09);
    const m1 = 0x7a2a6a;
    const m2 = 0xf07a4a;
    for (let k = 0; k < tips.length - 1; k++) {
      wg.tri(B, tips[k], tips[k + 1], k % 2 ? m1 : mixHex(m1, m2, 0.45));
      wg.tri(B, tips[k + 1], tips[k], k % 2 ? m1 : mixHex(m1, m2, 0.45));
    }
    wg.tri(A, B, tips[3], m1);
    wg.tri(A, tips[3], B, m1);
    wing.add(mesh(wg));
    body.add(wing);
    wings.push(wing);
  }
  return { kind: 'dragon', root, body, neck, head, jaw, fire, tail, legs, wings, t: Math.random() * 10, phase: 0, height: 5.9, pose: { rear: 0, spread: 0, mouth: 0, sweep: 0, crouch: 0 } };
}

// ---- 검은 태양 (3장의 마지막 상대): 땅 위에 뜬 검은 별. 불꽃 테와 도는 고리 ----
function makeBlackSun() {
  const root = new THREE.Group();
  const body = new THREE.Group();
  body.position.y = 5.2;
  root.add(body);
  // 검은 알맹이
  const cg = new Geo();
  cg.ico(1.9, 2, M(0, 0, 0), 0x07060c, 0x1c1430);
  body.add(mesh(cg));
  // 불꽃 테: 사방으로 뻗는 빛의 가시 (크기가 숨 쉬듯 변한다)
  const corona = new THREE.Group();
  const kg = new Geo();
  const N = 26;
  for (let k = 0; k < N; k++) {
    // 구 위에 고르게 흩은 방향 (황금각 나선)
    const y = 1 - (2 * (k + 0.5)) / N;
    const r = Math.sqrt(1 - y * y);
    const a = k * 2.399963;
    const dx = Math.cos(a) * r;
    const dz = Math.sin(a) * r;
    const len = 1.5 + ((k * 7) % 5) * 0.32;
    // 가시를 바깥쪽으로 눕힌다: +y 축을 (dx, y, dz) 로 돌린다
    const rz = -Math.asin(dx);
    const rx = Math.atan2(dz, y);
    kg.cone(0.42, len, 4, M(dx * (1.75 + len / 2), y * (1.75 + len / 2), dz * (1.75 + len / 2), rx, 0, rz), 0xff7a2a, 0xfff2c0);
  }
  corona.add(mesh(kg, true));
  body.add(corona);
  // 테두리 빛 (알맹이 바로 바깥의 얇은 껍질)
  const rimG = new Geo();
  rimG.ico(2.02, 2, M(0, 0, 0), 0xffb04a, 0xff5a2a);
  const rim = new THREE.Mesh(rimG.build(false), new THREE.MeshBasicMaterial({ color: 0xff8a3a, transparent: true, opacity: 0.28, side: THREE.BackSide, depthWrite: false, fog: false }));
  rim.scale.setScalar(1.08);
  body.add(rim);
  // 도는 고리 둘
  const rings = [];
  for (const [rad, tilt, col] of [[3.6, 0.5, 0xffd35a], [4.5, -0.9, 0xb98aff]]) {
    const ring = new THREE.Group();
    ring.rotation.x = tilt;
    const rg = new Geo();
    for (let k = 0; k < 28; k++) {
      const a = (k / 28) * Math.PI * 2;
      if (k % 7 === 6) continue;
      rg.box(0.62, 0.1, 0.2, M(Math.sin(a) * rad, 0, Math.cos(a) * rad, 0, a + Math.PI / 2, 0), col);
    }
    for (let k = 0; k < 4; k++) {
      const a = (k / 4) * Math.PI * 2 + 0.3;
      rg.ico(0.26, 0, M(Math.sin(a) * rad, 0, Math.cos(a) * rad), 0xfff6d8);
    }
    const inner = mesh(rg, true);
    ring.add(inner);
    body.add(ring);
    rings.push({ g: ring, inner, tilt });
  }
  // 하나뿐인 눈: 앞쪽의 빛나는 틈
  const eye = new THREE.Group();
  eye.position.set(0, 0, 1.86);
  const eg = new Geo();
  eg.ico(0.5, 1, M(0, 0, 0, 0, 0, 0, 1.5, 0.42, 0.3), 0xfff6d8);
  eg.ico(0.2, 0, M(0, 0, 0.12, 0, 0, 0, 0.7, 1.6, 0.3), 0x07060c);
  eye.add(mesh(eg, true));
  body.add(eye);
  return { kind: 'sun', root, body, corona, rim, rings, eye, t: Math.random() * 10, phase: 0, height: 7.6, pose: { lift: 0, flare: 0, spin: 0, tilt: 0 } };
}

// ---- 별의 사슬 기둥 (레이드): 돌 받침 위에 떠서 도는 수정 ----
function makePylon() {
  const root = new THREE.Group();
  const base = new Geo();
  base.cyl(1.25, 1.45, 0.5, 8, M(0, 0.25, 0), 0x2a2e58, 0x4c5290);
  base.cyl(0.8, 1.05, 0.5, 8, M(0, 0.75, 0), 0x343a78, 0x5a64a8);
  for (let k = 0; k < 4; k++) {
    const a = (k / 4) * Math.PI * 2 + 0.4;
    base.taperBox(0.26, 1.5, 0.26, 0.5, M(Math.sin(a) * 1.0, 1.4, Math.cos(a) * 1.0, Math.cos(a) * 0.25, 0, -Math.sin(a) * 0.25), 0x2a2e58, 0x6a76cc);
  }
  root.add(mesh(base));
  const body = new THREE.Group();
  body.position.y = 2.9;
  const cg = new Geo();
  cg.cone(0.62, 1.5, 6, M(0, 0.75, 0), 0xffe27a, 0xfff6d8);
  cg.cone(0.62, 1.1, 6, M(0, -0.55, 0, Math.PI, 0, 0), 0xffb02a, 0xffe27a);
  body.add(mesh(cg, true));
  const rg = new Geo();
  for (let k = 0; k < 6; k++) {
    const a = (k / 6) * Math.PI * 2;
    rg.box(0.34, 0.1, 0.16, M(Math.sin(a) * 1.05, 0.1, Math.cos(a) * 1.05, 0, a, 0), 0x9ab8ff);
  }
  const ring = mesh(rg, true);
  body.add(ring);
  root.add(body);
  return { kind: 'pylon', root, body, ring, t: Math.random() * 10, phase: 0, height: 4.6 };
}

// ---- 말랑이 ----
function makeSlime(color, elite) {
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  // 몸통: 매끈하고 속이 비치는 젤리
  const bg = new Geo();
  bg.ico(0.8, 2, M(0, 0.6, 0, 0, 0, 0, 1, 0.78, 1), shade(color, 0.7), shade(color, 1.18));
  const bgeo = bg.build(false);
  bgeo.computeVertexNormals();
  const jelly = new THREE.Mesh(bgeo, JELLY);
  jelly.castShadow = true;
  body.add(jelly);
  // 속에 비치는 핵과 눈
  const g = new Geo();
  g.ico(0.34, 1, M(0.05, 0.48, -0.08, 0, 0, 0, 1, 0.8, 1), shade(color, 0.42), shade(color, 0.78));
  g.ico(0.12, 1, M(0.26, 0.72, 0.68), 0x1f1a1a);
  g.ico(0.12, 1, M(-0.26, 0.72, 0.68), 0x1f1a1a);
  g.ico(0.045, 0, M(0.29, 0.78, 0.77), 0xffffff);
  g.ico(0.045, 0, M(-0.23, 0.78, 0.77), 0xffffff);
  if (elite) {
    for (let k = 0; k < 5; k++) {
      const a = (k / 5) * Math.PI * 2;
      g.cone(0.1, 0.3, 4, M(Math.cos(a) * 0.28, 1.28, Math.sin(a) * 0.28), 0xe6b83a, 0xfff0a0);
    }
    g.cyl(0.32, 0.32, 0.1, 8, M(0, 1.14, 0), 0xe6b83a);
  }
  body.add(mesh(g));
  if (elite) root.scale.setScalar(1.45);
  return { kind: 'slime', root, body, t: Math.random() * 10, phase: 0, sy: 1, height: elite ? 1.9 : 1.2 };
}

// ---- 늑대 ----
function makeWolf(color, elite) {
  const root = new THREE.Group();
  const body = new THREE.Group();
  body.position.y = 0.62;
  root.add(body);
  const dark = shade(color, 0.7);
  const g = new Geo();
  g.taperBox(0.46, 0.46, 1.15, 0.85, M(0, 0.12, 0), dark, color);
  g.box(0.36, 0.38, 0.4, M(0, 0.28, 0.72), dark, color);
  g.taperBox(0.2, 0.18, 0.34, 0.7, M(0, 0.2, 1.02, Math.PI / 2, 0, 0), color);
  g.box(0.08, 0.06, 0.06, M(0, 0.23, 1.2), 0x1f1a1a);
  g.cone(0.07, 0.2, 4, M(0.12, 0.56, 0.66), dark);
  g.cone(0.07, 0.2, 4, M(-0.12, 0.56, 0.66), dark);
  g.box(0.05, 0.05, 0.03, M(0.11, 0.36, 0.925), 0xffe27a);
  g.box(0.05, 0.05, 0.03, M(-0.11, 0.36, 0.925), 0xffe27a);
  body.add(mesh(g));
  const tail = new THREE.Group();
  tail.position.set(0, 0.22, -0.55);
  const tg = new Geo();
  tg.cone(0.11, 0.6, 5, M(0, 0, -0.28, -Math.PI / 2, 0, 0), dark, color);
  tail.add(mesh(tg));
  body.add(tail);
  const legs = [];
  for (const [x, z] of [[0.16, 0.42], [-0.16, 0.42], [0.16, -0.42], [-0.16, -0.42]]) {
    const leg = new THREE.Group();
    leg.position.set(x, -0.02, z);
    const lg = new Geo();
    lg.box(0.13, 0.6, 0.15, M(0, -0.3, 0), dark, color);
    leg.add(mesh(lg));
    body.add(leg);
    legs.push(leg);
  }
  if (elite) root.scale.setScalar(1.45);
  return { kind: 'wolf', root, body, tail, legs, t: Math.random() * 10, phase: 0, height: elite ? 1.7 : 1.2 };
}

// ---- 전갈 ----
function makeScorpion(elite, cols) {
  const root = new THREE.Group();
  const body = new THREE.Group();
  body.position.y = 0.35;
  root.add(body);
  const c1 = elite ? 0x7a3a8a : cols ? cols[0] : 0xb5653a;
  const c2 = elite ? 0x4a2458 : cols ? cols[1] : 0x6a3a26;
  const g = new Geo();
  g.ico(0.5, 0, M(0, 0.05, 0.25, 0, 0, 0, 1.1, 0.5, 1.2), c2, c1, 0.2, 3);
  g.ico(0.42, 0, M(0, 0.05, -0.4, 0, 0, 0, 1, 0.5, 1.1), c2, c1, 0.2, 5);
  g.box(0.06, 0.06, 0.04, M(0.12, 0.2, 0.8), 0xffe27a);
  g.box(0.06, 0.06, 0.04, M(-0.12, 0.2, 0.8), 0xffe27a);
  for (let k = 0; k < 3; k++) {
    for (const s of [1, -1]) g.box(0.6, 0.06, 0.07, M(0.6 * s, -0.08, 0.3 - k * 0.32, 0, s * (0.3 - k * 0.3), s * -0.5), c2);
  }
  body.add(mesh(g));
  const claws = [];
  for (const s of [1, -1]) {
    const claw = new THREE.Group();
    claw.position.set(0.4 * s, 0.05, 0.6);
    const cg = new Geo();
    cg.box(0.14, 0.12, 0.5, M(0.08 * s, 0, 0.25, 0, 0.3 * s, 0), c1);
    cg.ico(0.2, 0, M(0.2 * s, 0, 0.6, 0, 0, 0, 1, 0.7, 1.4), c2, c1, 0.2, 7);
    claw.add(mesh(cg));
    body.add(claw);
    claws.push(claw);
  }
  // 꼬리: 3마디 사슬
  const tail = [];
  let parent = body;
  for (let k = 0; k < 3; k++) {
    const seg = new THREE.Group();
    seg.position.set(0, k === 0 ? 0.15 : 0.42, k === 0 ? -0.75 : 0);
    const sg = new Geo();
    sg.ico(0.17 - k * 0.02, 0, M(0, 0.2, 0, 0, 0, 0, 1, 1.5, 1), c2, c1, 0.2, 11 + k);
    if (k === 2) sg.cone(0.08, 0.36, 4, M(0, 0.5, 0.08, 0.9, 0, 0), 0x2a1a1a, 0xffe27a);
    seg.add(mesh(sg));
    parent.add(seg);
    parent = seg;
    tail.push(seg);
  }
  if (elite) root.scale.setScalar(1.45);
  return { kind: 'scorpion', root, body, claws, tail, t: Math.random() * 10, phase: 0, height: elite ? 1.7 : 1.2 };
}

// 몬스터 애니메이션. state: 'idle'|'walk'|'run'|'windup'|'strike'|'stagger', pattern: 공격 종류
export function animateMonster(rig, state, pattern, dt, speed, p) {
  rig.t += dt;
  const t = rig.t;
  if (rig.kind === 'pylon') {
    // 천천히 돌며 오르내린다. 맞으면(stagger 는 없지만 깜빡임은 entities 가 맡는다) 그대로 버틴다
    rig.body.rotation.y = t * 0.9;
    rig.body.position.y = 2.9 + Math.sin(t * 2.2) * 0.18;
    rig.ring.rotation.y = -t * 2.4;
    return;
  }
  // 새 공격의 몸짓: 고리 충격파·별 삼키기·별똥 나누기는 포효하듯, 십자 가르기는 내려찍듯
  if (pattern === 'nova' || pattern === 'wipe' || pattern === 'split') pattern = 'roar';
  else if (pattern === 'cross') pattern = 'slam';
  if (rig.kind === 'dragon') return animateDragon(rig, state, pattern, dt, p);
  if (rig.kind === 'sun') return animateSun(rig, state, pattern, dt, p);
  if (rig.kind === 'humanoid') {
    let pose = POSE.IDLE;
    if (state === 'walk') pose = POSE.WALK;
    else if (state === 'run') pose = POSE.RUN;
    else if (state === 'stagger') pose = POSE.STAGGER;
    else if (state === 'windup') {
      pose = pattern === 'throw' ? POSE.THROWBACK : pattern === 'arc' && (rig.type === 'lord' || rig.type === 'knight') ? POSE.SWEEPBACK : pattern === 'roar' || pattern === 'meteor' ? POSE.ROAR : pattern === 'lunge' ? POSE.CROUCH : POSE.RAISE;
    } else if (state === 'strike') {
      pose = pattern === 'throw' ? POSE.THROW : pattern === 'arc' && (rig.type === 'lord' || rig.type === 'knight') ? POSE.SWEEP : pattern === 'roar' || pattern === 'meteor' ? POSE.ROAR : pattern === 'lunge' ? POSE.LUNGE : POSE.SMASH;
    }
    animateHumanoid(rig, pose, dt, speed, p);
    return;
  }
  if (rig.kind === 'slime') {
    let sy = 1 + Math.sin(t * 4) * 0.06;
    let y = 0;
    if (state === 'walk' || state === 'run') {
      rig.phase += dt * (state === 'run' ? 9 : 6);
      const h = Math.abs(Math.sin(rig.phase));
      y = h * (state === 'run' ? 0.45 : 0.25);
      sy = 0.85 + h * 0.3;
    } else if (state === 'windup') sy = 0.62 + Math.sin(t * 40) * 0.02;
    else if (state === 'strike') { sy = 1.3; y = Math.sin(Math.min(1, p) * Math.PI) * 0.9; }
    else if (state === 'stagger') sy = 0.75;
    rig.sy += (sy - rig.sy) * Math.min(1, dt * 18);
    const sxz = 1 / Math.sqrt(rig.sy);
    rig.body.scale.set(sxz, rig.sy, sxz);
    rig.body.position.y += (y - rig.body.position.y) * Math.min(1, dt * 20);
    return;
  }
  if (rig.kind === 'wolf') {
    let amp = 0;
    let by = 0.62;
    let rx = 0;
    if (state === 'walk') { rig.phase += dt * 7; amp = 0.4; }
    else if (state === 'run') { rig.phase += dt * 15; amp = 0.9; by = 0.62 + Math.abs(Math.sin(rig.phase)) * 0.08; }
    else if (state === 'windup') { by = 0.48; rx = -0.2; }
    else if (state === 'strike') { by = 0.8; rx = 0.25; amp = 1.2; }
    else if (state === 'stagger') { rx = -0.3; }
    const s = Math.sin(rig.phase);
    const k = Math.min(1, dt * 20);
    const tg = state === 'strike' ? [1.2, 1.2, -1.2, -1.2] : [s * amp, -s * amp, -s * amp, s * amp];
    for (let i = 0; i < 4; i++) rig.legs[i].rotation.x += (-tg[i] - rig.legs[i].rotation.x) * k;
    rig.body.position.y += (by - rig.body.position.y) * k;
    rig.body.rotation.x += (rx - rig.body.rotation.x) * k;
    rig.tail.rotation.y = Math.sin(t * 6) * 0.3;
    rig.tail.rotation.x = state === 'run' ? 0.3 : -0.4;
    return;
  }
  if (rig.kind === 'scorpion') {
    if (state === 'walk' || state === 'run') rig.phase += dt * (state === 'run' ? 16 : 9);
    rig.body.position.y = 0.35 + Math.sin(rig.phase) * 0.03;
    rig.body.rotation.z = Math.sin(rig.phase) * 0.05;
    let curl = 0.75 + Math.sin(t * 2) * 0.05;
    let base = 0.55;
    if (state === 'windup') { curl = 0.35; base = -0.1; }
    else if (state === 'strike') { curl = 0.95; base = 1.25; }
    const k = Math.min(1, dt * (state === 'strike' ? 30 : 10));
    rig.tail[0].rotation.x += (base - rig.tail[0].rotation.x) * k;
    rig.tail[1].rotation.x += (curl - rig.tail[1].rotation.x) * k;
    rig.tail[2].rotation.x += (curl - rig.tail[2].rotation.x) * k;
    const open = state === 'windup' ? 0.6 : 0.15 + Math.sin(t * 3) * 0.1;
    rig.claws[0].rotation.y = open;
    rig.claws[1].rotation.y = -open;
  }
}

// ---- 황혼의 용 ----
// 몸짓: 휩쓸기(arc) = 몸을 틀어 꼬리를 휘두른다 / 내려찍기(slam) = 앞발을 들고 일어섰다가 찍는다 / 던지기(throw) = 고개를 젖혔다가 불을 뿜는다
//       돌진(lunge) = 웅크렸다가 날개를 펴고 덮친다 / 포효(roar·meteor·nova) = 날개를 활짝 펴고 하늘을 본다
function animateDragon(rig, state, pattern, dt, p) {
  const t = rig.t;
  const P = rig.pose;
  let rear = 0; // 앞몸을 들어 올린다
  let spread = 0.12 + Math.sin(t * 1.6) * 0.05; // 날개를 편 정도
  let mouth = 0.08;
  let sweep = 0; // 몸을 트는 정도 (꼬리 휩쓸기)
  let crouch = 0;
  let neckUp = 0;
  let stride = 0;
  if (state === 'walk') { rig.phase += dt * 5; stride = 0.35; }
  else if (state === 'run') { rig.phase += dt * 9; stride = 0.6; spread = 0.3; }
  else if (state === 'stagger') { crouch = 0.5; mouth = 0.6; neckUp = -0.4; }
  else if (state === 'windup') {
    if (pattern === 'arc') { sweep = -0.9; crouch = 0.2; }
    else if (pattern === 'slam') { rear = 0.75; spread = 0.7; mouth = 0.5; }
    else if (pattern === 'throw') { neckUp = 0.7; mouth = 0.9; rear = 0.2; }
    else if (pattern === 'lunge') { crouch = 0.9; spread = 0.5; }
    else { spread = 1; neckUp = 0.6; mouth = 1; rear = 0.3; } // 포효
  } else if (state === 'strike') {
    const k = Math.sin(Math.min(1, p) * Math.PI);
    if (pattern === 'arc') { sweep = 1.4 * (1 - p) + 0.2; }
    else if (pattern === 'slam') { rear = -0.25 * k; crouch = 0.5 * k; spread = 0.4; }
    else if (pattern === 'throw') { neckUp = -0.25; mouth = 1; }
    else if (pattern === 'lunge') { spread = 1; rear = 0.15; mouth = 0.6; }
    else { spread = 1; neckUp = 0.6; mouth = 1; }
  }
  const k = Math.min(1, dt * (state === 'strike' ? 16 : 7));
  P.rear += (rear - P.rear) * k;
  P.spread += (spread - P.spread) * k;
  P.mouth += (mouth - P.mouth) * k;
  P.sweep += (sweep - P.sweep) * k;
  P.crouch += (crouch - P.crouch) * k;
  P.neck = (P.neck || 0) + (neckUp - (P.neck || 0)) * k;
  const s = Math.sin(rig.phase);
  rig.body.position.y = 1.9 - P.crouch * 0.55 + Math.abs(s) * stride * 0.12 + Math.sin(t * 1.6) * 0.04;
  rig.body.rotation.x = -P.rear * 0.5 + P.crouch * 0.12;
  rig.body.rotation.y = P.sweep * 0.9;
  for (let i = 0; i < 3; i++) rig.neck[i].rotation.x = -0.34 + i * 0.3 - P.neck * 0.3 + P.rear * 0.16 + Math.sin(t * 1.4 + i) * 0.03 + P.crouch * 0.18;
  rig.head.rotation.x = 0.5 + P.neck * 0.25 - P.rear * 0.2;
  rig.jaw.rotation.x = P.mouth * 0.7;
  rig.fire.scale.setScalar(0.4 + P.mouth * 1.5 + Math.sin(t * 30) * 0.1 * P.mouth);
  for (let i = 0; i < 5; i++) {
    rig.tail[i].rotation.y = Math.sin(t * 1.8 - i * 0.7) * 0.16 - P.sweep * 0.5;
    rig.tail[i].rotation.x = (i === 0 ? 0.18 : 0.06) - P.rear * 0.1;
  }
  const lf = [s, -s, -s, s];
  for (let i = 0; i < 4; i++) rig.legs[i].rotation.x = lf[i] * stride + (i < 2 ? -P.rear * 0.9 + P.crouch * 0.3 : P.rear * 0.35 - P.crouch * 0.3);
  const flap = Math.sin(t * (state === 'run' ? 7 : 2.2)) * (0.1 + P.spread * 0.16);
  for (let i = 0; i < 2; i++) {
    const sx = i ? -1 : 1;
    // 접었을 때는 등 뒤로 모으고, 펴면 옆으로 활짝
    rig.wings[i].rotation.y = sx * (1.05 - P.spread * 1.0);
    rig.wings[i].rotation.z = sx * (0.5 - P.spread * 0.75 + flap);
    rig.wings[i].rotation.x = -0.2 + P.spread * 0.15;
  }
}

// ---- 검은 태양 ----
// 몸짓: 내려찍기(slam·cross) = 솟구쳤다가 떨어진다 / 고리 불길·포효(nova·roar·meteor) = 불꽃 테가 크게 부푼다 / 돌진(lunge) = 앞으로 기울어 덮친다 / 던지기(throw) = 고리가 빠르게 돈다
function animateSun(rig, state, pattern, dt, p) {
  const t = rig.t;
  const P = rig.pose;
  let lift = 0;
  let flare = 0;
  let spin = 1;
  let tilt = 0;
  if (state === 'run') { tilt = 0.25; spin = 1.6; }
  else if (state === 'walk') tilt = 0.12;
  else if (state === 'stagger') { flare = -0.4; tilt = -0.3; spin = 0.2; }
  else if (state === 'windup') {
    if (pattern === 'slam') { lift = 2.6; spin = 2.5; }
    else if (pattern === 'lunge') { tilt = -0.5; flare = 0.3; spin = 3; }
    else if (pattern === 'throw') { spin = 5; flare = 0.25; }
    else if (pattern === 'arc') { spin = 4; tilt = -0.2; }
    else { flare = 0.8; spin = 3.2; lift = 0.8; } // 고리 불길 · 포효 · 불씨
  } else if (state === 'strike') {
    const k = Math.sin(Math.min(1, p) * Math.PI);
    if (pattern === 'slam') { lift = -2.9 * (1 - Math.min(1, p)); flare = 0.5 * k; }
    else if (pattern === 'lunge') { tilt = 0.6; flare = 0.4; spin = 3; }
    else if (pattern === 'throw') { flare = 0.5 * k; spin = 5; }
    else if (pattern === 'arc') { spin = 9; flare = 0.3; }
    else { flare = 1.1 * k + 0.2; spin = 4; }
  }
  const k = Math.min(1, dt * (state === 'strike' ? 14 : 5));
  P.lift += (lift - P.lift) * k;
  P.flare += (flare - P.flare) * k;
  P.spin += (spin - P.spin) * Math.min(1, dt * 4);
  P.tilt += (tilt - P.tilt) * k;
  rig.phase += dt * P.spin;
  rig.body.position.y = 5.2 + P.lift + Math.sin(t * 1.3) * 0.25;
  rig.body.rotation.x = P.tilt;
  const fs = 1 + P.flare * 0.5 + Math.sin(t * 5.3) * 0.04;
  rig.corona.scale.setScalar(fs);
  rig.corona.rotation.y = t * 0.25;
  rig.corona.rotation.z = Math.sin(t * 0.4) * 0.2;
  rig.rim.scale.setScalar(1.08 + P.flare * 0.12 + Math.sin(t * 5.3) * 0.015);
  rig.rings[0].inner.rotation.y = rig.phase * 0.9;
  rig.rings[1].inner.rotation.y = -rig.phase * 0.6;
  rig.rings[0].g.rotation.x = rig.rings[0].tilt + Math.sin(t * 0.7) * 0.25;
  rig.rings[1].g.rotation.x = rig.rings[1].tilt + Math.cos(t * 0.5) * 0.3;
  rig.rings[1].g.rotation.z = Math.sin(t * 0.33) * 0.4;
  rig.eye.scale.set(1 + P.flare * 0.3, 1 - Math.max(0, Math.sin(t * 0.9) - 0.96) * 20, 1);
}

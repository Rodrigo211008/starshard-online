// 지형 메시, 지형 데이터 텍스처, 장식물(나무·바위), 풀
import * as THREE from '/vendor/three/three.module.js';
import { W, NB, BIOME, PROP, VOLCANO, VILLAGE, LANDS } from '/shared/world.js';
import { VILLAGE_LAYOUT } from '/shared/defs.js';
import { rand2 } from '/shared/noise.js';
import { Geo, M, MergeBuffer, lin } from './geo.js';
import { env } from './shade.js';

// 지역별 지면 색과 절벽 암석 색
// (초원, 숲, 설산, 사막, 늪, 화산, 단풍, 벚꽃, 버섯, 수정, 그림자, 바람 협곡, 얼음 호수, 거인의 계단, 산호 군도, 하늘 기둥, 별똥 분지,
//  노을 평원, 거울 소금밭, 천둥 산맥, 은하수 들판)
const BASE = [
  0x76b04e, 0x4c9146, 0xf4f8ff, 0xe9cf8c, 0x6f8a4e, 0x5a4e4c, 0xcfa64a, 0x93c46c, 0x3f7a68, 0xbcb8ea, 0x3b3049,
  0xcc7f4e, 0xf0f6ff, 0x62b246, 0xf4e6bd, 0x4a8556, 0x3d426c,
  0xdcae4e, 0xf5d6d0, 0x3c4654, 0x8fd0cc,
].map(lin);
const ROCK = [
  0x8a8f98, 0x7d8580, 0x8f98ab, 0xc98f5f, 0x57574d, 0x40393a, 0x8f8478, 0x9d9299, 0x4d5a58, 0x7c78b4, 0x241d2e,
  0xb5552f, 0x86bfe2, 0xb3a57f, 0xe08f7c, 0x858d7c, 0x2b2e52,
  0xa9764a, 0xc9785a, 0x262c3a, 0x5a5fa8,
].map(lin);
// 새 땅의 지면에 섞는 색
const CANYON_CAP = lin(0xe6b47c); // 협곡 고원의 윗단
const OASIS = lin(0x7fb052); // 협곡 바닥의 풀밭
const ICE = lin(0x8ccbec); // 꽁꽁 언 호수
const PADDY = lin(0xc4c44c); // 계단 한 층 걸러 누렇게 익은 층
const ISLET = lin(0x84c658); // 산호 군도의 작은 섬 위
const PILLAR_TOP = lin(0x78b656); // 돌기둥 꼭대기
const STAR_RING = lin(0x6f80d8); // 별똥 분지 바닥의 물결
const STAR_CORE = lin(0xd4dcff); // 별똥 분지 한가운데 봉우리
const KOPJE = lin(0xb07a4e); // 노을 평원의 바위 언덕
const SALT_ISLE = lin(0xcf8a5c); // 소금밭의 붉은 바위섬
const STORM_PASS = lin(0x56705c); // 천둥 산맥의 골짜기 길
const STAR_MOUND = lin(0xa894e8); // 은하수 들판의 수정 언덕
const SAND = lin(0xead9a0);
const DEEP = lin(0x2c5f6e);
const MESA = lin(0xd98e5a);
const DIRT = lin(0xc2a878);
const BASALT = lin(0x332a2b);
const SNOWCAP = lin(0xf4f8ff);
const STONE = lin(0x9a9d94);
// 풀이 자라는 정도 (바이옴별)
const GRASS_DENS = [0.95, 0.8, 0, 0.1, 0.55, 0, 0.9, 0.95, 0.5, 0, 0, 0.04, 0, 0.95, 0.75, 0.8, 0, 0.9, 0, 0, 0.85];

function smooth(e0, e1, x) {
  let t = (x - e0) / (e1 - e0);
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return t * t * (3 - 2 * t);
}
const toSRGB = (c) => (c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055);

// 정점별 지형 정보를 계산한다:
//  col  지면 색(선형)        rock 절벽 암석 색        tmat 재질 가중치(풀, 모래, 눈, 용암)
//  dens 풀 밀도              swamp 늪 가중치          map  지도용 색(sRGB 바이트)
// tmat 의 눈(z)과 용암(w)은 새 땅에서 다른 뜻으로도 쓴다:
//   얼음 호수 = 눈 1 + 용암 양수 (얼음에 간 금),  별똥 분지 = 눈 0.45 + 용암 음수 (별빛 금)
export function computeTerrainColors(world, pois) {
  const crater = LANDS.find((q) => q.b === BIOME.CRATER);
  const N = W.VERTS;
  const H = world.heights;
  const col = new Float32Array(N * N * 3);
  const rock = new Float32Array(N * N * 3);
  const tmat = new Float32Array(N * N * 4);
  const dens = new Float32Array(N * N);
  const swamp = new Float32Array(N * N);
  const map = new Uint8ClampedArray(N * N * 4);
  const spots = [];
  for (const c of pois.camps) spots.push([c.x, c.z, 8, 0]);
  for (const s of pois.stones) spots.push([s.x, s.z, 4.5, 0]);
  for (const s of pois.shards) spots.push([s.x, s.z, 6, 1]);
  const dirt = new Float32Array(N * N);
  const stone = new Float32Array(N * N);
  for (const [dx0, dz0, r, isStone] of spots) {
    const mask = isStone ? stone : dirt;
    const i0 = Math.max(0, Math.floor((dx0 - r - 6 + W.HALF) / W.CELL));
    const i1 = Math.min(W.GRID, Math.ceil((dx0 + r + 6 + W.HALF) / W.CELL));
    const j0 = Math.max(0, Math.floor((dz0 - r - 6 + W.HALF) / W.CELL));
    const j1 = Math.min(W.GRID, Math.ceil((dz0 + r + 6 + W.HALF) / W.CELL));
    for (let j = j0; j <= j1; j++) {
      for (let i = i0; i <= i1; i++) {
        const x = -W.HALF + i * W.CELL;
        const z = -W.HALF + j * W.CELL;
        const d = Math.hypot(x - dx0, z - dz0);
        const t = 1 - smooth(r * 0.6, r + 5, d);
        if (t > mask[j * N + i]) mask[j * N + i] = t;
      }
    }
  }

  for (let j = 0; j < N; j++) {
    for (let i = 0; i < N; i++) {
      const idx = j * N + i;
      const h = H[idx];
      const x = -W.HALF + i * W.CELL;
      const z = -W.HALF + j * W.CELL;
      const hl = H[idx - (i > 0 ? 1 : 0)];
      const hr = H[idx + (i < W.GRID ? 1 : 0)];
      const hu = H[idx - (j > 0 ? N : 0)];
      const hd = H[idx + (j < W.GRID ? N : 0)];
      const gx = (hr - hl) / (2 * W.CELL);
      const gz = (hd - hu) / (2 * W.CELL);
      const slope = Math.sqrt(gx * gx + gz * gz);

      let r = 0, g = 0, b = 0, rr = 0, rg = 0, rb = 0, sum = 0, gd = 0;
      const o = idx * NB;
      for (let k = 0; k < NB; k++) {
        const w = world.bw[o + k];
        if (!w) continue;
        sum += w;
        r += BASE[k][0] * w; g += BASE[k][1] * w; b += BASE[k][2] * w;
        rr += ROCK[k][0] * w; rg += ROCK[k][1] * w; rb += ROCK[k][2] * w;
        gd += GRASS_DENS[k] * w;
      }
      r /= sum; g /= sum; b /= sum; rr /= sum; rg /= sum; rb /= sum; gd /= sum;
      const wDesert = world.bw[o + BIOME.DESERT] / sum;
      const wSwamp = world.bw[o + BIOME.SWAMP] / sum;
      const wVolc = world.bw[o + BIOME.VOLCANO] / sum;
      const wSnow = world.bw[o + BIOME.SNOW] / sum;
      const wCrystal = world.bw[o + BIOME.CRYSTAL] / sum;
      const wShadow = world.bw[o + BIOME.SHADOW] / sum;
      const wCanyon = world.bw[o + BIOME.CANYON] / sum;
      const wGlacier = world.bw[o + BIOME.GLACIER] / sum;
      const wTerrace = world.bw[o + BIOME.TERRACE] / sum;
      const wReef = world.bw[o + BIOME.REEF] / sum;
      const wPillars = world.bw[o + BIOME.PILLARS] / sum;
      const wCrater = world.bw[o + BIOME.CRATER] / sum;
      const wSavanna = world.bw[o + BIOME.SAVANNA] / sum;
      const wSalt = world.bw[o + BIOME.SALT] / sum;
      const wStorm = world.bw[o + BIOME.STORM] / sum;
      const wGalaxy = world.bw[o + BIOME.GALAXY] / sum;

      // ---- 새 땅마다 다른 지면 ----
      // 바람 협곡: 붉은 고원(윗단은 밝다) + 협곡 바닥의 풀밭
      const oasis = wCanyon * smooth(9, 4.5, h);
      if (wCanyon > 0) {
        const capT = wCanyon * smooth(31, 36, h) * 0.75;
        r += (CANYON_CAP[0] - r) * capT; g += (CANYON_CAP[1] - g) * capT; b += (CANYON_CAP[2] - b) * capT;
        r += (OASIS[0] - r) * oasis; g += (OASIS[1] - g) * oasis; b += (OASIS[2] - b) * oasis;
        gd += 0.85 * oasis;
      }
      // 얼음 호수: 판판한 얼음판
      const lake = wGlacier * smooth(1.7, 0.95, h) * (h > 0.2 ? 1 : 0);
      if (lake > 0) {
        const t = lake * 0.9;
        r += (ICE[0] - r) * t; g += (ICE[1] - g) * t; b += (ICE[2] - b) * t;
      }
      // 거인의 계단: 한 층 걸러 누렇게 익은 다랑이
      if (wTerrace > 0) {
        const lv = (h - 3) / 13;
        const li = Math.round(lv);
        const t = wTerrace * (li % 2 === 1 ? 0.72 : 0) * (1 - smooth(0.05, 0.16, Math.abs(lv - li)));
        r += (PADDY[0] - r) * t; g += (PADDY[1] - g) * t; b += (PADDY[2] - b) * t;
      }
      // 산호 군도: 흰 모래 위로 솟은 작은 섬은 푸르다
      const islet = wReef * smooth(2.3, 3.5, h);
      if (islet > 0) {
        r += (ISLET[0] - r) * islet; g += (ISLET[1] - g) * islet; b += (ISLET[2] - b) * islet;
      }
      gd *= 1 - wReef * (1 - smooth(2.3, 3.5, h));
      // 하늘 기둥: 꼭대기는 볕이 들어 밝다
      if (wPillars > 0) {
        const t = wPillars * smooth(18, 26, h) * 0.85;
        r += (PILLAR_TOP[0] - r) * t; g += (PILLAR_TOP[1] - g) * t; b += (PILLAR_TOP[2] - b) * t;
      }
      // 별똥 분지: 바닥의 동심원 물결과 한가운데의 빛나는 봉우리
      let core = 0;
      if (wCrater > 0) {
        const tt = Math.hypot(x - crater.x, z - crater.z) / crater.r;
        const inside = smooth(0.6, 0.42, tt);
        const u = tt * 13;
        const fr = u - Math.floor(u);
        const crest = smooth(0.55, 1.0, (fr < 0.5 ? fr : 1 - fr) * 2) * inside * wCrater * 0.55;
        r += (STAR_RING[0] - r) * crest; g += (STAR_RING[1] - g) * crest; b += (STAR_RING[2] - b) * crest;
        const c = tt / 0.085;
        core = wCrater / ((1 + c * c) * (1 + c * c));
        const ct = Math.min(1, core * 1.5);
        r += (STAR_CORE[0] - r) * ct; g += (STAR_CORE[1] - g) * ct; b += (STAR_CORE[2] - b) * ct;
      }
      // ---- 대륙 끝의 네 지역 ----
      // 노을 평원: 바위 언덕은 붉은 흙빛
      if (wSavanna > 0) {
        const t = wSavanna * smooth(15, 22, h) * 0.75;
        r += (KOPJE[0] - r) * t; g += (KOPJE[1] - g) * t; b += (KOPJE[2] - b) * t;
        gd *= 1 - t;
      }
      // 거울 소금밭: 흰 벌판 위로 솟은 바위섬은 붉다
      const saltIsle = wSalt * smooth(5, 10, h);
      if (saltIsle > 0) {
        r += (SALT_ISLE[0] - r) * saltIsle; g += (SALT_ISLE[1] - g) * saltIsle; b += (SALT_ISLE[2] - b) * saltIsle;
        gd += 0.08 * saltIsle;
      }
      // 천둥 산맥: 골짜기 길에는 이끼가 끼어 있다
      const pass = wStorm * smooth(24, 13, h);
      if (pass > 0) {
        const t = pass * 0.8;
        r += (STORM_PASS[0] - r) * t; g += (STORM_PASS[1] - g) * t; b += (STORM_PASS[2] - b) * t;
        gd += 0.45 * pass;
      }
      // 은하수 들판: 수정 언덕은 보랏빛
      const mound = wGalaxy * smooth(11, 18, h);
      if (mound > 0) {
        const t = mound * 0.75;
        r += (STAR_MOUND[0] - r) * t; g += (STAR_MOUND[1] - g) * t; b += (STAR_MOUND[2] - b) * t;
        gd *= 1 - mound * 0.8;
      }
      const wGrass = 1 - wDesert - wVolc - wSnow - wCrystal - wShadow - (wCanyon - oasis) - wGlacier - wCrater - (wReef - islet) - wSalt - (wStorm - pass) - mound;

      // 사막 탁상지
      const mesa = wDesert * smooth(13, 21, h);
      r += (MESA[0] - r) * mesa; g += (MESA[1] - g) * mesa; b += (MESA[2] - b) * mesa;
      // 높은 곳의 눈 (화산 제외)
      const cap = smooth(84, 100, h) * (1 - wVolc) * (1 - wSnow) * (1 - wShadow) * (1 - wTerrace) * (1 - wGlacier);
      r += (SNOWCAP[0] - r) * cap; g += (SNOWCAP[1] - g) * cap; b += (SNOWCAP[2] - b) * cap;
      // 분화구 바닥
      const dv = Math.hypot(x - VOLCANO.x, z - VOLCANO.z);
      // 화산은 붉은 용암 균열, 그림자 황무지는 보랏빛 균열 (음수로 적어 두면 셰이더가 보랏빛으로 그린다)
      // 얼음 호수의 금(양수)과 별똥 분지의 별빛(음수)도 같은 자리에 적는다
      let lava = wVolc * 0.16 - wShadow * 0.15 + lake * 0.3 - wCrater * (0.2 + 0.8 * Math.min(1, core * 1.6)) - mound * 0.22;
      if (dv < 80) {
        const t = 1 - smooth(40, 68, dv);
        r += (BASALT[0] - r) * t; g += (BASALT[1] - g) * t; b += (BASALT[2] - b) * t;
        lava = Math.max(lava, 1 - smooth(30, 78, dv));
      }
      // 마을 광장과 야영지의 흙바닥
      const dvil = Math.hypot(x - VILLAGE.x, z - VILLAGE.z);
      const dt = Math.max(dirt[idx], 1 - smooth(13, 24, dvil)) * 0.9;
      r += (DIRT[0] - r) * dt; g += (DIRT[1] - g) * dt; b += (DIRT[2] - b) * dt;
      // 별조각 제단 주변의 돌바닥
      const stt = stone[idx] * 0.85;
      r += (STONE[0] - r) * stt; g += (STONE[1] - g) * stt; b += (STONE[2] - b) * stt;
      // 물가의 모래 (소금 벌판은 낮아도 흰 소금 그대로다)
      const sd = smooth(2.3, 0.7, h) * (1 - wSwamp * 0.85) * (1 - wVolc * 0.7) * (1 - wShadow * 0.75) * (1 - wGlacier) * (1 - wCrater * 0.8) * (1 - wSalt) * (1 - wGalaxy * 0.5);
      r += (SAND[0] - r) * sd; g += (SAND[1] - g) * sd; b += (SAND[2] - b) * sd;
      // 지도 색 (절벽 암석 + 음영 + 물) - 물속 색을 섞기 전에 계산
      {
        const rk = smooth(0.7, 1.12, slope) * (1 - mesa * 0.6);
        let mr = r + (rr - r) * rk;
        let mg = g + (rg - g) * rk;
        let mb = b + (rb - b) * rk;
        const shade = Math.max(0.55, Math.min(1.35, 1 - (gx + gz) * 0.55));
        mr *= shade; mg *= shade; mb *= shade;
        if (h < 0) {
          const t = Math.min(1, 0.55 + -h / 14);
          // 산호 군도의 얕은 바다는 지도에서도 옥빛이다
          // (소금밭의 얕은 소금물과 은하수 들판의 별못도 지도에서 밝게 보인다)
          const sh = Math.min(1, wReef * smooth(-3.2, -1.2, h) + wSalt * 0.9 + wGalaxy * 0.6);
          mr += (0.03 + 0.1 * sh - mr) * t; mg += (0.2 + 0.4 * sh - mg) * t; mb += (0.45 + 0.17 * sh - mb) * t;
        }
        map[idx * 4] = toSRGB(Math.min(1, mr)) * 255;
        map[idx * 4 + 1] = toSRGB(Math.min(1, mg)) * 255;
        map[idx * 4 + 2] = toSRGB(Math.min(1, mb)) * 255;
        map[idx * 4 + 3] = 255;
      }
      // 물속
      if (h < 0) {
        const t = smooth(0, -8, h);
        r += (DEEP[0] - r) * t; g += (DEEP[1] - g) * t; b += (DEEP[2] - b) * t;
      }
      col[idx * 3] = r; col[idx * 3 + 1] = g; col[idx * 3 + 2] = b;
      rock[idx * 3] = rr; rock[idx * 3 + 1] = rg; rock[idx * 3 + 2] = rb;
      const bare = (1 - dt) * (1 - stt) * (1 - cap) * (1 - sd) * (1 - mesa);
      tmat[idx * 4] = Math.max(0, wGrass) * bare * (h > 0.2 ? 1 : 0);
      // (협곡·계단·기둥은 절벽 아래쪽이 흙빛으로 물들지 않도록 이 값을 함께 켜 둔다)
      tmat[idx * 4 + 1] = Math.min(1, wDesert * (1 - mesa) + sd + wCanyon + (wReef - islet) + wTerrace + wPillars + wSalt + wSavanna * smooth(15, 22, h));
      tmat[idx * 4 + 2] = Math.min(1, wSnow + cap + wCrystal * 0.75 + wGlacier + wCrater * 0.45 + (wSalt - saltIsle) * 0.55 + mound * 0.5);
      tmat[idx * 4 + 3] = lava;
      dens[idx] = gd * bare * (1 - smooth(0.6, 0.85, slope));
      swamp[idx] = wSwamp;
    }
  }
  return { col, rock, tmat, dens, swamp, map };
}

// ---------- 장식물 템플릿 ----------
function buildTemplates() {
  const T = {};
  const bark = 0x7a5a3a;
  const bark2 = 0x5f4630;

  T[PROP.OAK] = [0, 1, 2].map((v) => {
    const g = new Geo();
    g.cyl(0.2, 0.34, 2.4, 5, M(0, 1.2, 0), bark2, bark);
    g.ico(1.75, 0, M(0, 3.7, 0, 0, v, 0, 1, 0.85, 1), 0x3f8f38, 0x7cc653, 0.32, 11 + v, 1);
    g.ico(1.25, 0, M(0.95, 3.0, 0.4, 0, v * 2, 0), 0x3a8534, 0x6fbe4c, 0.3, 21 + v, 0.8);
    g.ico(1.15, 0, M(-0.85, 3.15, -0.5, 0, v * 3, 0), 0x3f8f38, 0x74c250, 0.3, 31 + v, 0.8);
    g.ico(1.0, 0, M(0.1, 3.2, -1.0, 0, v * 4, 0, 1, 0.9, 1), 0x377f32, 0x69b848, 0.3, 37 + v, 0.8);
    g.cyl(0.07, 0.11, 1.0, 4, M(0.45, 2.3, 0.2, 0, 0, -0.8), bark2, bark);
    return g.template();
  });

  const autumnCols = [[0xc9541f, 0xf2a63a], [0xa8321f, 0xe2603a], [0xcf9a22, 0xf7e05c]];
  T[PROP.AUTUMN] = autumnCols.map(([c1, c2], v) => {
    const g = new Geo();
    g.cyl(0.2, 0.34, 2.4, 5, M(0, 1.2, 0), bark2, bark);
    g.ico(1.75, 0, M(0, 3.7, 0, 0, v, 0, 1, 0.85, 1), c1, c2, 0.32, 41 + v, 1);
    g.ico(1.25, 0, M(0.95, 3.0, 0.4, 0, v * 2, 0), c1, c2, 0.3, 51 + v, 0.8);
    g.ico(1.15, 0, M(-0.85, 3.15, -0.5, 0, v * 3, 0), c1, c2, 0.3, 61 + v, 0.8);
    g.ico(1.0, 0, M(0.1, 3.2, -1.0, 0, v * 4, 0, 1, 0.9, 1), c1, c2, 0.3, 67 + v, 0.8);
    g.cyl(0.07, 0.11, 1.0, 4, M(0.45, 2.3, 0.2, 0, 0, -0.8), bark2, bark);
    return g.template();
  });

  const pine = (c1, c2, tip) => {
    const g = new Geo();
    g.cyl(0.15, 0.27, 1.7, 5, M(0, 0.85, 0), bark2, bark);
    g.cone(1.55, 2.1, 6, M(0, 2.3, 0), c1, tip || c2, 0.5);
    g.cone(1.2, 1.9, 6, M(0, 3.5, 0, 0, 0.5, 0), c1, tip || c2, 0.7);
    g.cone(0.82, 1.7, 6, M(0, 4.65, 0, 0, 1, 0), c1, tip || c2, 0.9);
    g.cone(0.5, 1.3, 6, M(0, 5.6, 0, 0, 1.5, 0), c1, tip || c2, 1.0);
    return g.template();
  };
  T[PROP.PINE] = [pine(0x24603a, 0x4f9a55), pine(0x2a6a45, 0x58a862)];
  T[PROP.SNOWPINE] = [pine(0x2f6a4c, 0, 0xf4f8ff), pine(0x35705a, 0, 0xe4eefc)];

  T[PROP.PALM] = [0, 1].map((v) => {
    const g = new Geo();
    const lean = v ? 0.22 : -0.16;
    g.cyl(0.19, 0.24, 1.5, 5, M(0, 0.75, 0, 0, 0, lean * 0.5), 0x8a6a45, 0x9a7a50);
    g.cyl(0.16, 0.19, 1.5, 5, M(-lean * 0.9, 2.15, 0, 0, 0, lean), 0x8a6a45, 0x9a7a50);
    g.cyl(0.13, 0.16, 1.5, 5, M(-lean * 2.4, 3.5, 0, 0, 0, lean * 1.5), 0x8a6a45, 0x9a7a50);
    const tx = -lean * 3.5;
    const ty = 4.25;
    for (let k = 0; k < 6; k++) {
      const a = (k / 6) * Math.PI * 2 + v;
      const ca = Math.cos(a);
      const sa = Math.sin(a);
      const px = -sa * 0.45;
      const pz = ca * 0.45;
      const A = [tx, ty, 0];
      const B = [tx + ca * 1.3 + px, ty + 0.25, sa * 1.3 + pz];
      const Cc = [tx + ca * 2.5, ty - 0.75, sa * 2.5];
      const D = [tx + ca * 1.3 - px, ty + 0.25, sa * 1.3 - pz];
      g.quad(A, B, Cc, D, 0x3f8f3a, 0x6fbe4c, 1.2);
      g.quad(A, D, Cc, B, 0x3f8f3a, 0x6fbe4c, 1.2);
    }
    return g.template();
  });

  T[PROP.DEAD] = [0, 1].map((v) => {
    const g = new Geo();
    g.cyl(0.1, 0.3, 3.2, 5, M(0, 1.6, 0, 0, 0, v ? 0.08 : -0.06), 0x4f443c, 0x6a5d52);
    g.cyl(0.04, 0.11, 1.5, 4, M(0.55, 2.3, 0, 0, 0, -0.95), 0x5c5048);
    g.cyl(0.04, 0.1, 1.3, 4, M(-0.45, 2.8, 0.1, 0.2, 0, 0.85), 0x5c5048);
    g.cyl(0.03, 0.08, 1.0, 4, M(0.1, 2.0, -0.4, -0.9, 0, 0), 0x5c5048);
    return g.template();
  });

  T[PROP.WILLOW] = [0, 1].map((v) => {
    const g = new Geo();
    g.cyl(0.24, 0.42, 2.8, 5, M(0, 1.4, 0), 0x4a4034, 0x5f5444);
    g.ico(2.0, 0, M(0, 3.6, 0, 0, v, 0, 1, 0.55, 1), 0x3f6f45, 0x7fa860, 0.3, 71 + v, 0.8);
    for (let k = 0; k < 7; k++) {
      const a = (k / 7) * Math.PI * 2 + v;
      g.cone(0.28, 1.9, 4, M(Math.cos(a) * 1.55, 2.5, Math.sin(a) * 1.55, Math.PI, 0, 0), 0x6f9a5a, 0x4f7f4a, 1.6);
    }
    return g.template();
  });

  T[PROP.CACTUS] = [0, 1].map((v) => {
    const g = new Geo();
    g.cyl(0.3, 0.36, 2.4, 6, M(0, 1.2, 0), 0x3f8a4f, 0x66b56a);
    g.ico(0.3, 0, M(0, 2.4, 0, 0, 0, 0, 1, 0.7, 1), 0x66b56a);
    g.cyl(0.17, 0.17, 0.8, 5, M(0.55, 1.3, 0, 0, 0, Math.PI / 2), 0x4a9558);
    g.cyl(0.15, 0.17, 0.9, 5, M(0.9, 1.75, 0), 0x4a9558, 0x66b56a);
    if (v) {
      g.cyl(0.15, 0.15, 0.7, 5, M(-0.5, 0.95, 0, 0, 0, Math.PI / 2), 0x4a9558);
      g.cyl(0.13, 0.15, 0.7, 5, M(-0.8, 1.3, 0), 0x4a9558, 0x66b56a);
    }
    g.ico(0.14, 0, M(0, 2.66, 0), 0xff7ab0);
    return g.template();
  });

  T[PROP.ROCK] = [0, 1, 2].map((v) => {
    const g = new Geo();
    g.ico(1, 0, M(0, 0.4, 0, 0.2 * v, v, 0, 1.25, 0.75 + v * 0.12, 1.0), 0x7f848c, 0xb0b5bd, 0.5, 81 + v * 7);
    if (v === 2) g.ico(0.55, 0, M(0.9, 0.2, 0.4, 0, 1, 0, 1.1, 0.7, 1), 0x7f848c, 0xa5aab2, 0.5, 97);
    return g.template();
  });

  T[PROP.BUSH] = [0, 1].map((v) => {
    const g = new Geo();
    g.ico(0.7, 0, M(0, 0.45, 0, 0, v, 0, 1.2, 0.8, 1.1), 0x3f8f38, 0x6fbe4c, 0.35, 101 + v, 0.4);
    g.ico(0.5, 0, M(0.55, 0.38, 0.2, 0, v * 2, 0), 0x3a8534, 0x66b548, 0.35, 111 + v, 0.4);
    return g.template();
  });

  T[PROP.DRYBUSH] = [0].map(() => {
    const g = new Geo();
    for (let k = 0; k < 5; k++) {
      const a = (k / 5) * Math.PI * 2;
      g.cone(0.07, 0.9, 3, M(Math.cos(a) * 0.15, 0.4, Math.sin(a) * 0.15, Math.sin(a) * 0.6, 0, -Math.cos(a) * 0.6), 0x8f7448, 0xc9ad74, 0.5);
    }
    return g.template();
  });

  const flowerCols = [0xff6f91, 0xffd34f, 0xffffff, 0x8fb4ff, 0xd58cff];
  T[PROP.FLOWER] = flowerCols.map((c, v) => {
    const g = new Geo();
    for (let k = 0; k < 3; k++) {
      const ox = Math.cos(k * 2.1 + v) * 0.3;
      const oz = Math.sin(k * 2.1 + v) * 0.3;
      const hh = 0.3 + k * 0.07;
      g.box(0.04, hh, 0.04, M(ox, hh / 2, oz), 0x4f9a3f, null, 0.5);
      g.ico(0.11, 0, M(ox, hh + 0.05, oz, 0, 0, 0, 1, 0.7, 1), c, null, 0, 1, 0.8);
    }
    return g.template();
  });

  const shroomCols = [0xd9483b, 0xe89a3c, 0x9b6fd1];
  T[PROP.MUSHROOM] = shroomCols.map((c, v) => {
    const g = new Geo();
    g.cyl(0.08, 0.11, 0.4, 5, M(0, 0.2, 0), 0xe8e0cc);
    g.cone(0.34, 0.26, 6, M(0, 0.5, 0), c, 0xfff0e0);
    g.cyl(0.05, 0.07, 0.24, 5, M(0.35, 0.12, 0.15 + v * 0.05), 0xe8e0cc);
    g.cone(0.2, 0.17, 6, M(0.35, 0.3, 0.15 + v * 0.05), c, 0xfff0e0);
    return g.template();
  });

  T[PROP.REED] = [0].map(() => {
    const g = new Geo();
    for (let k = 0; k < 5; k++) {
      const a = k * 1.9;
      g.cone(0.05, 1.5 + (k % 3) * 0.35, 3, M(Math.cos(a) * 0.22, 0.8 + (k % 3) * 0.17, Math.sin(a) * 0.22, Math.sin(a) * 0.08, 0, Math.cos(a) * 0.08), 0x5f8a45, 0xc9c070, 1.0);
    }
    return g.template();
  });

  T[PROP.ICE] = [0, 1].map((v) => {
    const g = new Geo();
    g.cone(0.42, 2.4, 5, M(0, 1.2, 0, 0.08, v, 0.05), 0x8fcfff, 0xeefaff);
    g.cone(0.3, 1.5, 5, M(0.5, 0.7, 0.2, 0.3, v, -0.35), 0x8fcfff, 0xeefaff);
    g.cone(0.25, 1.1, 5, M(-0.4, 0.5, -0.2, -0.3, v, 0.4), 0x9ad6ff, 0xeefaff);
    return g.template();
  });

  // ---- 바깥 네 지역의 장식물 ----
  const cherryCols = [[0xe886b4, 0xffd0e4], [0xf29ac4, 0xffe0ee], [0xd9709e, 0xffb8d6]];
  T[PROP.CHERRY] = cherryCols.map(([c1, c2], v) => {
    const g = new Geo();
    g.cyl(0.18, 0.32, 2.2, 5, M(0, 1.1, 0, 0, 0, v ? 0.07 : -0.05), 0x4a3430, 0x6a4a40);
    g.cyl(0.07, 0.11, 1.1, 4, M(0.5, 2.2, 0.1, 0, 0, -0.9), 0x4a3430, 0x6a4a40);
    g.cyl(0.07, 0.1, 1.0, 4, M(-0.45, 2.3, -0.2, 0.3, 0, 0.85), 0x4a3430, 0x6a4a40);
    g.ico(1.7, 0, M(0, 3.5, 0, 0, v, 0, 1.05, 0.8, 1.05), c1, c2, 0.34, 141 + v, 1);
    g.ico(1.2, 0, M(1.05, 3.0, 0.3, 0, v * 2, 0, 1, 0.85, 1), c1, c2, 0.3, 151 + v, 0.8);
    g.ico(1.15, 0, M(-0.95, 3.1, -0.4, 0, v * 3, 0, 1, 0.85, 1), c1, c2, 0.3, 161 + v, 0.8);
    g.ico(0.95, 0, M(0.1, 3.05, -1.05, 0, v * 4, 0, 1, 0.85, 1), c1, c2, 0.3, 167 + v, 0.8);
    return g.template();
  });

  const capCols = [[0xb8342c, 0xf06a5a], [0x2f9a8c, 0x6fe0c8], [0x7a52b8, 0xc09aff]];
  T[PROP.SHROOMTREE] = capCols.map(([c1, c2], v) => {
    const g = new Geo();
    g.cyl(0.26, 0.42, 3.0, 6, M(0, 1.5, 0, 0, 0, v === 1 ? 0.08 : -0.04), 0xcfc4a8, 0xf2ead8);
    g.cyl(0.6, 0.34, 0.3, 7, M(0, 2.95, 0), 0xe8dcc0, 0xfff6e4);
    g.ico(2.0, 1, M(0, 3.3, 0, 0, v, 0, 1, 0.42, 1), c1, c2, 0.06, 171 + v, 0.35);
    for (let k = 0; k < 5; k++) {
      const a = k * 1.26 + v;
      g.ico(0.2, 0, M(Math.cos(a) * 1.1, 3.82 - (k % 2) * 0.12, Math.sin(a) * 1.1, 0, 0, 0, 1, 0.5, 1), 0xfff6e4);
    }
    if (v !== 1) {
      g.cyl(0.12, 0.18, 1.3, 5, M(1.3, 0.65, 0.5), 0xcfc4a8, 0xf2ead8);
      g.ico(0.8, 0, M(1.3, 1.45, 0.5, 0, 1, 0, 1, 0.42, 1), c1, c2, 0.06, 181 + v, 0.3);
    }
    return g.template();
  });

  const crystalCols = [[0x7a5fd8, 0xe8dcff], [0x4fb8e8, 0xe6fbff], [0xb06fe0, 0xffd8ff]];
  T[PROP.CRYSTAL] = crystalCols.map(([c1, c2], v) => {
    const g = new Geo();
    g.cone(0.55, 3.6, 6, M(0, 1.7, 0, 0.06, v, 0.04), c1, c2);
    g.cone(0.4, 2.3, 6, M(0.6, 1.0, 0.25, 0.3, v, -0.4), c1, c2);
    g.cone(0.34, 1.8, 6, M(-0.5, 0.8, -0.3, -0.32, v, 0.42), c1, c2);
    if (v) g.cone(0.26, 1.2, 6, M(0.1, 0.5, 0.65, 0.5, v, 0.1), c1, c2);
    return g.template();
  });

  T[PROP.OBELISK] = [0, 1, 2].map((v) => {
    const g = new Geo();
    g.cone(0.6, 3.4 + v * 0.5, 5, M(0, 1.6 + v * 0.25, 0, 0.12, v, -0.1), 0x1d1826, 0x3f3458);
    g.cone(0.42, 1.9, 5, M(0.65, 0.85, 0.25, 0.3, v, -0.45), 0x1d1826, 0x3a3050);
    if (v !== 1) g.cone(0.32, 1.4, 5, M(-0.55, 0.6, -0.35, -0.4, v, 0.4), 0x1d1826, 0x3a3050);
    g.ico(0.13, 0, M(0.02, 3.3 + v * 0.5, 0.02), 0x9a6aff);
    return g.template();
  });

  T[PROP.SPIKE] = [0, 1].map((v) => {
    const g = new Geo();
    g.cone(0.55, 2.6, 5, M(0, 1.3, 0, 0.1, v, -0.08), 0x2f292a, 0x5a4a48);
    g.cone(0.4, 1.6, 5, M(0.6, 0.75, 0.25, 0.25, v, -0.4), 0x2f292a, 0x55464a);
    if (v) g.cone(0.3, 1.2, 5, M(-0.5, 0.55, -0.3, -0.35, v, 0.35), 0x2f292a, 0x55464a);
    return g.template();
  });

  // ---- 먼 여섯 땅의 장식물 ----
  // 바람 협곡의 버섯바위: 층층이 깎인 붉은 돌기둥 위에 넓적한 돌이 얹혀 있다
  T[PROP.HOODOO] = [0, 1, 2].map((v) => {
    const g = new Geo();
    const c1 = 0xa9532e;
    const c2 = 0xdc9258;
    const c3 = 0xeab880;
    g.cyl(0.62, 0.95, 1.5, 6, M(0, 0.7, 0, 0, v, 0), c1, c2);
    g.cyl(0.46, 0.6, 1.5 + v * 0.35, 6, M(0.05, 2.1 + v * 0.17, 0.03, 0, v + 0.5, 0.04), c2, c3);
    g.cyl(0.38, 0.47, 1.1, 6, M(0.1, 3.35 + v * 0.35, 0.04, 0, v + 1, -0.05), c1, c2);
    g.ico(0.86, 0, M(0.12, 4.2 + v * 0.35, 0.02, 0.12, v, 0.06, 1.2, 0.5, 1.05), 0x8f4a2c, 0xc87848, 0.28, 201 + v);
    if (v === 2) {
      g.cyl(0.3, 0.5, 1.7, 5, M(1.15, 0.8, 0.5, 0, 1, -0.08), c1, c2);
      g.ico(0.52, 0, M(1.22, 1.85, 0.5, 0, 2, 0, 1.15, 0.5, 1), 0x8f4a2c, 0xc87848, 0.28, 207);
    }
    return g.template();
  });

  // 거인의 계단의 대나무: 가늘고 긴 줄기 다발
  T[PROP.BAMBOO] = [0, 1].map((v) => {
    const g = new Geo();
    const n = 3 + v;
    for (let k = 0; k < n; k++) {
      const a = k * 2.4 + v * 0.7;
      const ca = Math.cos(a);
      const sa = Math.sin(a);
      const rad = 0.16 + (k % 3) * 0.17;
      const hh = 4.8 + ((k * 7 + v * 3) % 5) * 0.45;
      const lean = 0.04 + (k % 2) * 0.03;
      g.cyl(0.04, 0.07, hh, 3, M(ca * (rad + lean * hh * 0.5), hh / 2, sa * (rad + lean * hh * 0.5), sa * lean, 0, -ca * lean), 0x5a9638, 0xa2cf5c, 0.22, false);
      g.ico(0.68, 0, M(ca * (rad + lean * hh + 0.15), hh - 0.4, sa * (rad + lean * hh + 0.15), 0, a, 0, 1, 0.5, 1), 0x4f9a3a, 0x92d45c, 0.3, 231 + k + v * 9, 1.0);
      if (k === 0) g.ico(0.46, 0, M(ca * (rad + lean * hh * 0.7 - 0.12), hh - 1.6, sa * (rad + lean * hh * 0.7 - 0.12), 0, a + 1, 0, 1, 0.45, 1), 0x4a9038, 0x86c654, 0.3, 241 + k, 0.7);
    }
    return g.template();
  });

  // 산호 군도의 산호: 가지 산호, 둥근 뇌 산호, 굵은 관 산호
  const coralCols = [[0xe8557a, 0xffb4c6], [0xf07a3a, 0xffc890], [0x9a5ad8, 0xe2bcff], [0x2fbfb0, 0xaafff0], [0xe8c23a, 0xfff2a0], [0xf0506a, 0xffd0a0]];
  T[PROP.CORAL] = coralCols.map(([c1, c2], v) => {
    const g = new Geo();
    if (v % 3 === 0) {
      for (let k = 0; k < 5; k++) {
        const a = k * 1.2566 + v;
        const ca = Math.cos(a);
        const sa = Math.sin(a);
        const tilt = 0.3 + (k % 3) * 0.17;
        const len = 0.85 + (k % 4) * 0.2;
        const st = Math.sin(tilt);
        const ct = Math.cos(tilt);
        g.cyl(0.05, 0.12, len, 3, M(ca * (0.12 + st * len * 0.5), ct * len * 0.5, sa * (0.12 + st * len * 0.5), sa * tilt, 0, -ca * tilt), c1, c2, 0, false);
        if (k % 2 === 0) g.cyl(0.035, 0.07, len * 0.5, 3, M(ca * (0.12 + st * len * 0.8) + sa * 0.14, ct * len * 0.8, sa * (0.12 + st * len * 0.8) - ca * 0.14, sa * tilt - ca * 0.5, 0, -ca * tilt - sa * 0.5), c1, c2, 0, false);
      }
    } else if (v % 3 === 1) {
      g.ico(0.62, 1, M(0, 0.3, 0, 0, v, 0, 1.1, 0.6, 1), c1, c2, 0.16, 221 + v);
      g.ico(0.34, 0, M(0.62, 0.17, 0.22, 0, 1, 0, 1, 0.6, 1), c1, c2, 0.2, 229 + v);
    } else {
      for (let k = 0; k < 4; k++) {
        const a = k * 1.571 + v;
        const hh = 0.5 + (k % 3) * 0.3;
        g.cyl(0.18, 0.12, hh, 4, M(Math.cos(a) * 0.28, hh / 2, Math.sin(a) * 0.28, 0, a, 0), c1, c2);
      }
      g.cyl(0.22, 0.15, 1.05, 5, M(0, 0.52, 0), c1, c2);
    }
    return g.template();
  });

  // ---- 대륙 끝 네 지역의 장식물 ----
  // 노을 평원의 우산나무: 가는 줄기 위에 잎이 납작하게 펼쳐져 있다
  T[PROP.ACACIA] = [0, 1].map((v) => {
    const g = new Geo();
    const lean = v ? 0.16 : -0.1;
    const tx = -lean * 3.2;
    g.cyl(0.16, 0.3, 2.6, 5, M(-lean * 1.3, 1.3, 0, 0, 0, lean), 0x5a4030, 0x7a5a40);
    g.cyl(0.08, 0.14, 1.7, 4, M(tx + 0.6, 3.1, 0.1, 0, 0, -0.75), 0x5a4030, 0x7a5a40);
    g.cyl(0.08, 0.14, 1.6, 4, M(tx - 0.55, 3.1, -0.15, 0.2, 0, 0.7), 0x5a4030, 0x7a5a40);
    g.ico(2.5, 0, M(tx, 4.1, 0, 0, v, 0, 1.15, 0.26, 1.05), 0x6f8f34, 0xb5c85a, 0.2, 251 + v, 0.9);
    g.ico(1.5, 0, M(tx + 1.5, 3.75, 0.6, 0, v * 2, 0, 1.1, 0.26, 1), 0x688a30, 0xa8c052, 0.2, 257 + v, 0.8);
    g.ico(1.3, 0, M(tx - 1.4, 3.8, -0.5, 0, v * 3, 0, 1.1, 0.26, 1), 0x6f8f34, 0xb0c458, 0.2, 263 + v, 0.8);
    return g.template();
  });

  // 거울 소금밭의 소금 기둥: 연분홍빛이 도는 흰 결정
  T[PROP.SALT] = [0, 1, 2].map((v) => {
    const g = new Geo();
    g.cone(0.6, 1.9 + v * 0.5, 5, M(0, 0.9 + v * 0.25, 0, 0.05, v, 0.04), 0xf0c8c4, 0xffffff);
    g.cone(0.42, 1.2, 5, M(0.55, 0.55, 0.2, 0.22, v, -0.35), 0xf4bcb8, 0xffffff);
    if (v !== 1) g.cone(0.34, 0.9, 5, M(-0.5, 0.4, -0.25, -0.3, v, 0.36), 0xf0c8c4, 0xfff4f0);
    g.ico(0.5, 0, M(0.1, 0.12, -0.45, 0, v, 0, 1.3, 0.35, 1), 0xf2d0cc, 0xffffff, 0.2, 271 + v);
    return g.template();
  });

  // 은하수 들판의 별빛나무: 흰 줄기에 푸르스름한 잎, 꼭대기에 별 하나
  const starCols = [[0x5fb8e8, 0xd8f8ff], [0x8a8af0, 0xe6e0ff], [0x4fd8c8, 0xe0fff6]];
  T[PROP.STARTREE] = starCols.map(([c1, c2], v) => {
    const g = new Geo();
    g.cyl(0.16, 0.3, 2.8, 5, M(0, 1.4, 0, 0, 0, v ? 0.06 : -0.05), 0xd8dcec, 0xffffff);
    g.cyl(0.06, 0.1, 1.2, 4, M(0.5, 2.6, 0.1, 0, 0, -0.85), 0xd8dcec, 0xffffff);
    g.cyl(0.06, 0.1, 1.1, 4, M(-0.45, 2.8, -0.2, 0.3, 0, 0.8), 0xd8dcec, 0xffffff);
    g.ico(1.5, 0, M(0, 4.0, 0, 0, v, 0, 1, 1.15, 1), c1, c2, 0.3, 281 + v, 1);
    g.ico(1.05, 0, M(0.95, 3.3, 0.3, 0, v * 2, 0), c1, c2, 0.3, 287 + v, 0.8);
    g.ico(0.95, 0, M(-0.85, 3.4, -0.4, 0, v * 3, 0), c1, c2, 0.3, 293 + v, 0.8);
    g.ico(0.16, 0, M(0, 5.8, 0), 0xfff6c8);
    return g.template();
  });

  return T;
}

const ROCK_TINT = [
  [1, 1, 1], [0.88, 0.95, 0.88], [1.12, 1.16, 1.28], [1.4, 1.08, 0.74], [0.72, 0.78, 0.66], [0.46, 0.42, 0.43], [1.06, 0.98, 0.88],
  [1.08, 0.98, 1.02], [0.66, 0.8, 0.78], [0.98, 0.94, 1.4], [0.38, 0.32, 0.48],
  [1.42, 0.8, 0.56], [1.02, 1.3, 1.5], [1.12, 1.04, 0.86], [1.5, 0.92, 0.84], [0.84, 0.94, 0.82], [0.42, 0.44, 0.78],
  [1.32, 0.94, 0.68], [1.46, 0.96, 0.82], [0.46, 0.52, 0.68], [0.8, 0.84, 1.42],
];
// 산호 군도의 바위는 산호처럼 알록달록하다
const REEF_TINT = [[1.5, 0.92, 0.84], [1.55, 1.1, 0.7], [1.2, 0.86, 1.4], [0.8, 1.35, 1.3], [1.3, 1.25, 1.1]];

export class Terrain {
  constructor(gfx, world, pois) {
    this.gfx = gfx;
    this.world = world;
    this.pois = pois;
    this.group = new THREE.Group();
    gfx.scene.add(this.group);
    this.propMap = new Map(); // 청크 번호 -> 장식물 메시
    this.terrainChunks = [];
    this.templates = buildTemplates();
    const info = computeTerrainColors(world, pois);
    this.info = info;
    this.colors = info.col;
    this.mapPixels = info.map;
    this.grass = null;
    this._buildTextures();
  }

  // 셰이더가 읽는 지형 데이터 텍스처들
  _buildTextures() {
    const N = W.VERTS;
    const { col, dens, swamp, tmat } = this.info;
    const H = this.world.heights;
    // (1) 높이 / 늪 / 풀 밀도 / 용암 (반정밀도 실수)
    const data = new Uint16Array(N * N * 4);
    const hf = THREE.DataUtils.toHalfFloat;
    for (let i = 0; i < N * N; i++) {
      data[i * 4] = hf(H[i]);
      data[i * 4 + 1] = hf(swamp[i]);
      data[i * 4 + 2] = hf(dens[i]);
      data[i * 4 + 3] = hf(tmat[i * 4 + 3]);
    }
    const tData = new THREE.DataTexture(data, N, N, THREE.RGBAFormat, THREE.HalfFloatType);
    tData.magFilter = THREE.LinearFilter;
    tData.minFilter = THREE.LinearFilter;
    tData.wrapS = tData.wrapT = THREE.ClampToEdgeWrapping;
    tData.needsUpdate = true;
    env.uData.value = tData;
    // (2) 지면 색
    const gcol = new Uint8Array(N * N * 4);
    for (let i = 0; i < N * N; i++) {
      gcol[i * 4] = Math.round(toSRGB(Math.min(1, col[i * 3])) * 255);
      gcol[i * 4 + 1] = Math.round(toSRGB(Math.min(1, col[i * 3 + 1])) * 255);
      gcol[i * 4 + 2] = Math.round(toSRGB(Math.min(1, col[i * 3 + 2])) * 255);
      gcol[i * 4 + 3] = 255;
    }
    const tGround = new THREE.DataTexture(gcol, N, N, THREE.RGBAFormat, THREE.UnsignedByteType);
    tGround.colorSpace = THREE.SRGBColorSpace;
    tGround.magFilter = THREE.LinearFilter;
    tGround.minFilter = THREE.LinearFilter;
    tGround.needsUpdate = true;
    env.uGround.value = tGround;
    // (3) 나무·바위·집 아래의 그늘을 미리 구워 둔다 (세계가 넓으므로 가능하면 4096 칸)
    const S = this.gfx.renderer.capabilities.maxTextureSize >= 4096 && !((navigator.deviceMemory || 8) <= 2) ? 4096 : 2048;
    const k = S / W.SIZE;
    const shade = new Uint8Array(S * S);
    const stamp = (x, z, radius, strength) => {
      const cx = (x + W.HALF) * k;
      const cz = (z + W.HALF) * k;
      const r = radius * k;
      const x0 = Math.max(0, Math.floor(cx - r));
      const x1 = Math.min(S - 1, Math.ceil(cx + r));
      const z0 = Math.max(0, Math.floor(cz - r));
      const z1 = Math.min(S - 1, Math.ceil(cz + r));
      for (let pz = z0; pz <= z1; pz++) {
        for (let px = x0; px <= x1; px++) {
          const d2 = ((px - cx) * (px - cx) + (pz - cz) * (pz - cz)) / (r * r);
          if (d2 >= 1) continue;
          const a = strength * (1 - d2) * (1 - d2);
          const o = pz * S + px;
          shade[o] = Math.round(255 - (255 - shade[o]) * (1 - a));
        }
      }
    };
    const TREE = new Set([PROP.OAK, PROP.PINE, PROP.AUTUMN, PROP.SNOWPINE, PROP.PALM, PROP.WILLOW, PROP.DEAD, PROP.CHERRY, PROP.SHROOMTREE, PROP.BAMBOO]);
    for (let cz = 0; cz < W.CHUNKS; cz++) {
      for (let cx = 0; cx < W.CHUNKS; cx++) {
        for (const p of this.world.chunkProps(cx, cz)) {
          if (TREE.has(p.t)) stamp(p.x, p.z, (p.t === PROP.DEAD ? 1.3 : p.t === PROP.BAMBOO ? 1.7 : 2.6) * p.s, p.t === PROP.DEAD ? 0.4 : 0.8);
          else if (p.t === PROP.ROCK || p.t === PROP.SPIKE || p.t === PROP.ICE || p.t === PROP.CACTUS || p.t === PROP.CRYSTAL || p.t === PROP.OBELISK || p.t === PROP.HOODOO) stamp(p.x, p.z, 1.3 * p.s, 0.5);
          else if (p.t === PROP.BUSH) stamp(p.x, p.z, 1.0 * p.s, 0.45);
        }
      }
    }
    for (const h of VILLAGE_LAYOUT.houses) stamp(VILLAGE.x + h.x, VILLAGE.z + h.z, Math.max(h.w, h.d) * 0.78, 0.55);
    for (const s of VILLAGE_LAYOUT.stalls) stamp(VILLAGE.x + s.x, VILLAGE.z + s.z, 2.6, 0.45);
    for (const b of this.pois.bushes) stamp(b.x, b.z, 1.1, 0.45);
    const tShade = new THREE.DataTexture(shade, S, S, THREE.RedFormat, THREE.UnsignedByteType);
    tShade.magFilter = THREE.LinearFilter;
    tShade.minFilter = THREE.LinearMipmapLinearFilter;
    tShade.generateMipmaps = true;
    tShade.needsUpdate = true;
    env.uShade.value = tShade;
  }

  buildTerrain() {
    const n = W.CHUNK_CELLS + 1;
    const N = W.VERTS;
    const H = this.world.heights;
    const { col: C, rock: R, tmat: T } = this.info;
    const idx = new Uint16Array(W.CHUNK_CELLS * W.CHUNK_CELLS * 6);
    let o = 0;
    for (let j = 0; j < W.CHUNK_CELLS; j++) {
      for (let i = 0; i < W.CHUNK_CELLS; i++) {
        const a = j * n + i;
        const b = a + 1;
        const c = a + n;
        const d = c + 1;
        idx[o++] = a; idx[o++] = c; idx[o++] = b;
        idx[o++] = b; idx[o++] = c; idx[o++] = d;
      }
    }
    const indexAttr = new THREE.BufferAttribute(idx, 1);
    for (let cz = 0; cz < W.CHUNKS; cz++) {
      for (let cx = 0; cx < W.CHUNKS; cx++) {
        const pos = new Float32Array(n * n * 3);
        const nor = new Float32Array(n * n * 3);
        const col = new Float32Array(n * n * 3);
        const rock = new Float32Array(n * n * 3);
        const tmat = new Float32Array(n * n * 4);
        let maxH = -99;
        let k = 0;
        let m = 0;
        for (let j = 0; j < n; j++) {
          for (let i = 0; i < n; i++) {
            const gi = cx * W.CHUNK_CELLS + i;
            const gj = cz * W.CHUNK_CELLS + j;
            const g = gj * N + gi;
            const h = H[g];
            if (h > maxH) maxH = h;
            pos[k] = -W.HALF + gi * W.CELL;
            pos[k + 1] = h;
            pos[k + 2] = -W.HALF + gj * W.CELL;
            // 높이맵에서 부드러운 법선 계산
            const hl = H[g - (gi > 0 ? 1 : 0)];
            const hr = H[g + (gi < W.GRID ? 1 : 0)];
            const hu = H[g - (gj > 0 ? N : 0)];
            const hd = H[g + (gj < W.GRID ? N : 0)];
            const nx = -(hr - hl) / (2 * W.CELL);
            const nz = -(hd - hu) / (2 * W.CELL);
            const nl = 1 / Math.sqrt(nx * nx + 1 + nz * nz);
            nor[k] = nx * nl;
            nor[k + 1] = nl;
            nor[k + 2] = nz * nl;
            col[k] = C[g * 3]; col[k + 1] = C[g * 3 + 1]; col[k + 2] = C[g * 3 + 2];
            rock[k] = R[g * 3]; rock[k + 1] = R[g * 3 + 1]; rock[k + 2] = R[g * 3 + 2];
            tmat[m] = T[g * 4]; tmat[m + 1] = T[g * 4 + 1]; tmat[m + 2] = T[g * 4 + 2]; tmat[m + 3] = T[g * 4 + 3];
            k += 3;
            m += 4;
          }
        }
        if (maxH < -20) continue; // 깊은 바다는 그리지 않는다
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        geo.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
        geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
        geo.setAttribute('rock', new THREE.BufferAttribute(rock, 3));
        geo.setAttribute('tmat', new THREE.BufferAttribute(tmat, 4));
        geo.setIndex(indexAttr);
        geo.computeBoundingSphere();
        const mesh = new THREE.Mesh(geo, this.gfx.matTerrain);
        mesh.receiveShadow = true;
        mesh.matrixAutoUpdate = false;
        mesh.userData.cx = -W.HALF + (cx + 0.5) * W.CHUNK;
        mesh.userData.cz = -W.HALF + (cz + 0.5) * W.CHUNK;
        this.group.add(mesh);
        this.terrainChunks.push(mesh);
      }
    }
    // 정점별 계산 결과는 메시와 텍스처로 옮겼으니 놓아 준다 (세계가 넓어 꽤 크다)
    this.info = null;
    this.colors = null;
  }

  // 장식물 메시는 가까운 청크만 만들어 두고 멀어지면 놓아 준다.
  // (세계가 넓어서 전부 만들어 두면 메모리를 많이 쓴다. 청크 하나를 합치는 데는 1ms 도 걸리지 않는다)
  buildProps() {
    for (const m of this.propMap.values()) {
      if (!m) continue;
      this.group.remove(m);
      m.geometry.dispose();
    }
    this.propMap.clear(); // 청크 번호 -> 메시 (장식물이 없는 청크는 null). update() 가 채운다
  }

  get propChunks() {
    const list = [];
    for (const m of this.propMap.values()) if (m) list.push(m);
    return list;
  }

  _buildPropChunk(cx, cz) {
    const T = this.templates;
    const props = this.world.chunkProps(cx, cz);
    if (!props.length) return null;
    let nv = 0;
    let ni = 0;
    for (const p of props) {
      const vars = T[p.t];
      const t = vars[Math.floor(p.r * 997) % vars.length];
      nv += t.nv;
      ni += t.ni;
    }
    const mb = new MergeBuffer(nv, ni);
    for (const p of props) {
      const vars = T[p.t];
      const t = vars[Math.floor(p.r * 997) % vars.length];
      const tone = 0.88 + ((p.r * 131) % 1) * 0.24;
      if (p.t === PROP.ROCK) {
        const tint = p.b === BIOME.REEF ? REEF_TINT[Math.floor(p.r * 4999) % REEF_TINT.length] : ROCK_TINT[p.b];
        mb.add(t, p.x, p.y - 0.1 * p.s, p.z, p.s, p.r * 6.283, tint[0] * tone, tint[1] * tone, tint[2] * tone);
      } else {
        mb.add(t, p.x, p.y - 0.05, p.z, p.s, p.r * 6.283, tone, tone, tone);
      }
    }
    const mesh = new THREE.Mesh(mb.build(true), this.gfx.matProp);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.matrixAutoUpdate = false;
    this.group.add(mesh);
    return mesh;
  }

  // 풀: 플레이어 주변 격자에 심어 두고, 위치·높이·색은 셰이더가 지형 텍스처에서 읽는다
  setupGrass() {
    if (this.grass) {
      this.group.remove(this.grass);
      this.grass.geometry.dispose();
      this.grass = null;
    }
    const q = this.gfx.quality;
    const count = q.grass;
    if (!count) return;
    const R = q.grassR;
    this.gfx.uGrassR.value = R;
    // 풀 한 포기 = 휘어진 잎 5장
    const pos = [];
    const gcol = [];
    const sway = [];
    const index = [];
    for (let b = 0; b < 5; b++) {
      const a = b * 1.2566 + 0.4;
      const lx = Math.cos(a);
      const lz = Math.sin(a);
      const px = -lz;
      const pz = lx;
      const bx = lx * 0.09;
      const bz = lz * 0.09;
      const hh = 0.4 + (b % 3) * 0.09;
      const w0 = 0.034;
      const w1 = 0.024;
      const base = pos.length / 3;
      pos.push(bx - px * w0, 0, bz - pz * w0, bx + px * w0, 0, bz + pz * w0);
      pos.push(bx + lx * 0.07 - px * w1, hh * 0.55, bz + lz * 0.07 - pz * w1, bx + lx * 0.07 + px * w1, hh * 0.55, bz + lz * 0.07 + pz * w1);
      pos.push(bx + lx * 0.2, hh, bz + lz * 0.2);
      gcol.push(0, 0, 0.55, 0.55, 1);
      sway.push(0, 0, 0.32, 0.32, 1);
      index.push(base, base + 1, base + 3, base, base + 3, base + 2, base + 2, base + 3, base + 4);
    }
    const geo = new THREE.InstancedBufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pos), 3));
    geo.setAttribute('gcol', new THREE.BufferAttribute(new Float32Array(gcol), 1));
    geo.setAttribute('sway', new THREE.BufferAttribute(new Float32Array(sway), 1));
    geo.setIndex(index);
    const side = Math.ceil(Math.sqrt(count));
    const n = side * side;
    const cell = (2 * R) / side;
    const off = new Float32Array(n * 2);
    const rnd = new Float32Array(n * 4);
    for (let j = 0; j < side; j++) {
      for (let i = 0; i < side; i++) {
        const k = j * side + i;
        off[k * 2] = (i + rand2(i, j, 501)) * cell - R;
        off[k * 2 + 1] = (j + rand2(i, j, 502)) * cell - R;
        rnd[k * 4] = rand2(i, j, 503);
        rnd[k * 4 + 1] = rand2(i, j, 504);
        rnd[k * 4 + 2] = rand2(i, j, 505);
        rnd[k * 4 + 3] = rand2(i, j, 506);
      }
    }
    geo.setAttribute('aOff', new THREE.InstancedBufferAttribute(off, 2));
    geo.setAttribute('aRnd', new THREE.InstancedBufferAttribute(rnd, 4));
    geo.instanceCount = n;
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
    this.grass = new THREE.Mesh(geo, this.gfx.matGrass);
    this.grass.frustumCulled = false;
    this.grass.receiveShadow = true;
    this.grass.matrixAutoUpdate = false;
    this.group.add(this.grass);
  }

  // 멀리 있는 지형·장식물은 그리지 않는다
  update(px, pz) {
    const tr = this.gfx.quality.fogFar + W.CHUNK * 0.75;
    const tr2 = tr * tr;
    for (const m of this.terrainChunks) {
      const dx = m.userData.cx - px;
      const dz = m.userData.cz - pz;
      m.visible = dx * dx + dz * dz < tr2;
    }
    // 장식물: 범위 안의 청크는 만들고(가까운 것부터, 한 번에 조금씩), 한참 멀어진 청크는 지운다
    const r = this.gfx.quality.propRange + W.CHUNK * 0.72;
    const r2 = r * r;
    const far2 = (r + W.CHUNK * 1.3) * (r + W.CHUNK * 1.3);
    const map = this.propMap;
    for (const [key, m] of map) {
      const dx = -W.HALF + ((key % W.CHUNKS) + 0.5) * W.CHUNK - px;
      const dz = -W.HALF + (Math.floor(key / W.CHUNKS) + 0.5) * W.CHUNK - pz;
      const d2 = dx * dx + dz * dz;
      if (d2 > far2) {
        if (m) {
          this.group.remove(m);
          m.geometry.dispose();
        }
        map.delete(key);
      } else if (m) m.visible = d2 < r2;
    }
    const x0 = Math.max(0, Math.floor((px - r + W.HALF) / W.CHUNK));
    const x1 = Math.min(W.CHUNKS - 1, Math.floor((px + r + W.HALF) / W.CHUNK));
    const z0 = Math.max(0, Math.floor((pz - r + W.HALF) / W.CHUNK));
    const z1 = Math.min(W.CHUNKS - 1, Math.floor((pz + r + W.HALF) / W.CHUNK));
    let need = null;
    for (let cz = z0; cz <= z1; cz++) {
      for (let cx = x0; cx <= x1; cx++) {
        const key = cz * W.CHUNKS + cx;
        if (map.has(key)) continue;
        const dx = -W.HALF + (cx + 0.5) * W.CHUNK - px;
        const dz = -W.HALF + (cz + 0.5) * W.CHUNK - pz;
        const d2 = dx * dx + dz * dz;
        if (d2 < r2) (need || (need = [])).push([d2, cx, cz, key]);
      }
    }
    if (need) {
      need.sort((a, b) => a[0] - b[0]);
      // 바로 곁의 청크는 기다리지 않고 만든다 (순간 이동 직후에 나무가 비어 보이지 않도록). 먼 것은 한 프레임에 3ms 까지만
      const near2 = W.CHUNK * 1.3 * (W.CHUNK * 1.3);
      const t0 = performance.now();
      for (let i = 0; i < need.length; i++) {
        const [d2, cx, cz, key] = need[i];
        if (i > 0 && d2 > near2 && performance.now() - t0 > 3) break;
        map.set(key, this._buildPropChunk(cx, cz));
      }
    }
  }
}

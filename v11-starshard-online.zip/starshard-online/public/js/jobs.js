// 직업과 전직: 마을의 스승 가람에게서 길(검사 · 궁수 · 도적 · 별술사)을 고르고, 시험을 치러 1~4차 전직을 한다.
// 진행 상황은 각자의 저장(save.job)에 들어 있다: { c: 직업, t: 전직 차수, q: 치르는 중인 시험 { c, tier, n: [과제마다 센 수], told } }
import { JOBS, JOB_LEVELS, JOB_MAX, JOB_SWITCH_GOLD, cleanJob, jobTitle } from '/shared/jobs.js';
import { josa } from './dom.js';

export const MASTER_NAME = '스승 가람';
const FAR_BIOME = 11; // 이 번호부터가 먼 땅 (먼 여섯 땅과 대륙 끝의 네 지역)
const CREDIT_MS = 6000; // 내가 때린 뒤 이 시간 안에 쓰러지면 내 솜씨로 친다

// 시험의 과제
//  맡은 뒤부터 세는 것 — melee 근접 처치 / bow 활 처치 / skill 기술 처치 / dodge 구르기로 피하기 / strong 우두머리·수호자 / golem 수호자 / fargolem 먼 땅의 수호자
//  지금 상태를 보는 것 — seals 별의 인장 / stones 깨운 귀환석 / dclear 정복한 던전
const COUNTED = new Set(['melee', 'bow', 'skill', 'dodge', 'strong', 'golem', 'fargolem']);
const GOAL_TEXT = {
  melee: (n) => `근접 무기로 몬스터 ${n}마리 쓰러뜨리기`,
  bow: (n) => `활로 몬스터 ${n}마리 쓰러뜨리기`,
  skill: (n) => `기술로 몬스터 ${n}마리 쓰러뜨리기`,
  dodge: (n) => `구르기로 공격 ${n}번 피하기`,
  strong: (n) => `우두머리나 수호자 ${n}마리 쓰러뜨리기`,
  golem: (n) => `수호자 ${n}마리 쓰러뜨리기`,
  fargolem: (n) => `먼 땅(바람 협곡 너머)의 수호자 ${n}마리 쓰러뜨리기`,
  seals: (n) => `별의 인장 ${n}개 모으기`,
  stones: (n) => `귀환석 ${n}곳 깨우기`,
  dclear: (n) => `숨겨진 던전 ${n}곳 정복하기`,
};
const GOAL_SHORT = { melee: '근접 처치', bow: '활 처치', skill: '기술 처치', dodge: '구르기로 피하기', strong: '우두머리 · 수호자', golem: '수호자', fargolem: '먼 땅의 수호자', seals: '별의 인장', stones: '귀환석', dclear: '던전 정복' };

// 직업 c 의 tier 차 전직 시험
export function jobGoals(c, tier) {
  if (tier === 1) {
    return [
      c === 1 ? { kind: 'melee', n: 20 } : c === 2 ? { kind: 'bow', n: 12 } : c === 3 ? { kind: 'dodge', n: 8 } : { kind: 'seals', n: 2 },
      { kind: 'strong', n: 1 },
    ];
  }
  if (tier === 2) {
    return [
      { kind: 'skill', n: 25 },
      { kind: 'seals', n: 3 },
      c === 1 ? { kind: 'golem', n: 1 } : c === 2 ? { kind: 'bow', n: 30 } : c === 3 ? { kind: 'dodge', n: 20 } : { kind: 'stones', n: 7 },
    ];
  }
  if (tier === 3) return [{ kind: 'skill', n: 60 }, { kind: 'dclear', n: 1 }, { kind: 'seals', n: 6 }];
  return [{ kind: 'skill', n: 100 }, { kind: 'dclear', n: 3 }, { kind: 'seals', n: 10 }, { kind: 'fargolem', n: 2 }];
}
export const goalText = (g) => GOAL_TEXT[g.kind](g.n);

export class Jobs {
  constructor(game) {
    this.game = game;
    this.hits = new Map(); // 몬스터 번호 -> 내가 마지막으로 때린 방법 { kind: 'm' | 'b', at, skillAt }
    this.pollT = 0;
    const s = game.save;
    if (!s.job || typeof s.job !== 'object') s.job = { c: 0, t: 0, q: null };
  }

  // 지금의 직업과 차수 { c, t }
  job() {
    const s = this.game.save;
    return cleanJob(s.job, s.level);
  }

  def() {
    const j = this.job();
    return j.t ? JOBS[j.c] : null;
  }

  title() {
    return jobTitle(this.job());
  }

  // 열린 기술들
  skills() {
    const j = this.job();
    return j.t ? JOBS[j.c].skills.slice(0, j.t) : [];
  }

  quest() {
    return this.game.save.job.q || null;
  }

  // ---------- 시험의 진행 ----------
  stateValue(kind) {
    const s = this.game.save;
    if (kind === 'seals') return s.trials.length;
    if (kind === 'stones') return s.stones.length;
    if (kind === 'dclear') return s.dclear.length;
    return 0;
  }

  // 지금 치르는 시험의 과제들: [{ kind, text, short, n, need, done }]
  goals() {
    const q = this.quest();
    if (!q) return [];
    return jobGoals(q.c, q.tier).map((g, i) => {
      const n = Math.min(g.n, COUNTED.has(g.kind) ? q.n[i] | 0 : this.stateValue(g.kind));
      return { kind: g.kind, text: goalText(g), short: GOAL_SHORT[g.kind], n, need: g.n, done: n >= g.n };
    });
  }

  ready() {
    const gs = this.goals();
    return gs.length > 0 && gs.every((g) => g.done);
  }

  // 다음 전직 시험을 받을 수 있는지
  canStart() {
    const j = this.job();
    return !this.quest() && j.t < JOB_MAX && this.game.save.level >= JOB_LEVELS[j.t];
  }

  // 스승 머리 위의 표시: '?' 시험을 마쳤다 / '!' 새 시험을 받을 수 있다
  marker() {
    if (this.quest()) return this.ready() ? '?' : '';
    return this.canStart() ? '!' : '';
  }

  // 화면 왼쪽 위에 보여 줄 줄 (마쳤으면 한 줄, 아니면 남은 과제 둘까지)
  tracked() {
    const q = this.quest();
    if (!q) return [];
    const title = JOBS[q.c].titles[q.tier - 1];
    const gs = this.goals();
    if (gs.every((g) => g.done)) return [{ rdy: true, text: `${q.tier}차 전직 「${title}」 — ${MASTER_NAME}에게 보고` }];
    return gs.filter((g) => !g.done).slice(0, 2).map((g) => ({ rdy: false, text: `전직 시험: ${g.short} ${g.n}/${g.need}` }));
  }

  changed() {
    const g = this.game;
    if (g.quests) g.quests.dirty = true; // 화면의 목록과 머리 위 표시를 새로 그린다
    g.ui.dirty = true;
    g.saveSoon();
  }

  // 과제를 센다
  on(kind, n = 1) {
    const q = this.quest();
    if (!q) return;
    const list = jobGoals(q.c, q.tier);
    let hit = false;
    for (let i = 0; i < list.length; i++) {
      if (list[i].kind !== kind || (q.n[i] | 0) >= list[i].n) continue;
      q.n[i] = Math.min(list[i].n, (q.n[i] | 0) + n);
      hit = true;
    }
    if (hit) {
      this.changed();
      this.announce();
    }
  }

  // 내가 몬스터를 때렸다 (kind: 'm' 근접 / 'b' 활, skill: 기술로)
  noteHit(ids, kind, skill = false) {
    const at = performance.now();
    for (const id of ids) {
      const h = this.hits.get(id);
      this.hits.set(id, { kind, at, skillAt: skill ? at : h ? h.skillAt : 0 });
    }
    if (this.hits.size > 240) {
      for (const [id, h] of this.hits) if (at - h.at > CREDIT_MS) this.hits.delete(id);
    }
  }

  // 몬스터가 쓰러졌다 (내가 몫을 받는 것만 불린다)
  onKill(id, info) {
    const h = this.hits.get(id);
    this.hits.delete(id);
    if (!this.quest() || !info || (info.minion && !info.tower) || info.raid) return;
    const now = performance.now();
    if (h && now - h.at < CREDIT_MS) this.on(h.kind === 'b' ? 'bow' : 'melee');
    if (h && now - h.skillAt < CREDIT_MS) this.on('skill');
    if (info.elite || info.type === 'golem') this.on('strong');
    if (info.type === 'golem') {
      this.on('golem');
      if (info.biome >= FAR_BIOME && !info.zone) this.on('fargolem');
    }
  }

  // 방금 시험을 모두 마쳤으면 한 번 알려 준다
  announce() {
    const q = this.quest();
    if (!q || q.told || !this.ready()) return;
    q.told = true;
    const g = this.game;
    g.ui.toast(`전직 시험을 모두 마쳤습니다! 마을의 ${MASTER_NAME}에게 돌아가세요`, true);
    g.audio.puzzleOk();
    this.changed();
  }

  // 상태로 따지는 과제(인장 · 귀환석 · 던전)는 가끔 살펴본다
  update(dt) {
    this.pollT -= dt;
    if (this.pollT > 0) return;
    this.pollT = 1;
    this.announce();
  }

  // 레벨이 올라 전직할 수 있게 됐으면 알려 준다
  onLevel(from) {
    const g = this.game;
    const s = g.save;
    const j = this.job();
    if (j.t >= JOB_MAX || this.quest()) return;
    const need = JOB_LEVELS[j.t];
    if (from < need && s.level >= need) {
      g.ui.chatAdd('', j.t ? `Lv.${need} 이 되었습니다! 마을의 ${MASTER_NAME}에게 가면 ${j.t + 1}차 전직 시험을 받을 수 있어요.` : `Lv.${need} 이 되었습니다! 마을 북동쪽의 ${MASTER_NAME}에게 가서 직업을 골라 보세요 (검사 · 궁수 · 도적 · 별술사).`, 'sys');
      g.ui.toast(j.t ? `${j.t + 1}차 전직 시험을 받을 수 있습니다 — ${MASTER_NAME}` : `직업을 고를 수 있습니다 — 마을의 ${MASTER_NAME}`, true);
      this.changed();
    }
  }

  // ---------- 시험 받기 · 전직 ----------
  accept(c, tier) {
    const s = this.game.save;
    if (!JOBS[c] || s.job.q) return false;
    s.job.q = { c, tier, n: jobGoals(c, tier).map(() => 0), told: false };
    this.changed();
    return true;
  }

  abandon() {
    this.game.save.job.q = null;
    this.changed();
  }

  // 시험을 마치고 전직한다
  advance() {
    const g = this.game;
    const s = g.save;
    const q = this.quest();
    if (!q || !this.ready()) return false;
    const J = JOBS[q.c];
    const tier = q.tier;
    s.job = { c: q.c, t: tier, q: null };
    const pl = g.player;
    pl.refreshStats();
    pl.buildRig(); // 목도리가 그 길의 빛깔로 바뀐다
    pl.hp = pl.maxHp;
    pl.stamina = pl.maxStamina;
    pl.exhausted = false;
    g.net.send({ t: 'prof', prof: pl.profile() });
    const sk = J.skills[tier - 1];
    const pa = J.passives[tier - 1];
    const title = J.titles[tier - 1];
    g.ui.banner(`${tier}차 전직!`, `「${title}」 — 새 기술 「${sk.name}」`);
    const how = g.input.isTouch ? `「${sk.short}」 버튼` : `숫자 키 ${tier}`;
    g.ui.chatAdd('', `${tier}차 전직 「${title}」! 새 기술 「${sk.name}」(${how}): ${sk.desc}. 다시 쓰기까지 ${+(sk.cd * pl.cdK).toFixed(1)}초.`, 'sys');
    g.ui.chatAdd('', `숨은 힘 「${pa.name}」: ${pa.desc}`, 'sys');
    g.audio.seal();
    g.audio.levelUp();
    // 직업의 빛깔로 솟는 기둥과 퍼져 나가는 고리
    const p = pl.pos;
    const fx = g.fx;
    fx.ring(p.x, p.y + 0.3, p.z, J.color, 5, 0.8);
    fx.ring(p.x, p.y + 0.3, p.z, 0xffffff, 9, 1.1);
    fx.ring(p.x, p.y + 0.3, p.z, J.color, 13, 1.4);
    fx.burst(p.x, p.y + 1.2, p.z, J.color, 60, 7, { size: 0.42, life: 1.2, grav: -2, glow: 2.4 });
    for (let i = 0; i < 40; i++) fx.spawn(p.x + (Math.random() - 0.5) * 1.8, p.y + Math.random() * 0.8, p.z + (Math.random() - 0.5) * 1.8, 0, 5 + Math.random() * 9, 0, Math.random() < 0.4 ? 0xffffff : J.color, 0.22, 1 + Math.random() * 0.6, -1, 1, 3, 0.3);
    pl.shake = Math.max(pl.shake, 0.3);
    if (g.skills) g.skills.reset();
    this.changed();
    return true;
  }

  // 다른 길로 옮긴다 (차수는 그대로)
  switchCost() {
    return JOB_SWITCH_GOLD * this.job().t;
  }

  switchTo(c) {
    const g = this.game;
    const s = g.save;
    const j = this.job();
    const cost = this.switchCost();
    if (!j.t || !JOBS[c] || c === j.c || s.gold < cost) return false;
    s.gold -= cost;
    s.job = { c, t: j.t, q: null };
    g.player.refreshStats();
    g.player.buildRig();
    g.net.send({ t: 'prof', prof: g.player.profile() });
    if (g.skills) g.skills.reset();
    const J = JOBS[c];
    const p = g.player.pos;
    g.fx.ring(p.x, p.y + 0.3, p.z, J.color, 6, 0.8);
    g.fx.burst(p.x, p.y + 1.2, p.z, J.color, 36, 5, { size: 0.36, life: 1, grav: -1.5, glow: 2.2 });
    g.audio.seal();
    g.ui.banner(`「${jobTitle({ c, t: j.t })}」의 길`, `${J.name}의 기술 ${j.t}개를 익혔습니다`);
    this.changed();
    return true;
  }

  // ---------- 스승 가람과의 대화 ----------
  talk(npc) {
    const g = this.game;
    const s = g.save;
    const ui = g.ui;
    if (npc) npc.talkT = 1.6;
    const j = this.job();
    const q = this.quest();
    if (q) return this.ready() ? this.ceremonyTalk() : this.progressTalk();
    if (!j.t) {
      if (s.level < JOB_LEVELS[0]) {
        return ui.dialog(MASTER_NAME, [
          '나는 가람. 모험가들에게 저마다의 길을 일러 주는 사람이다.',
          '길은 넷이다. 검사, 궁수, 도적, 별술사. 길을 고르면 그 길의 기술을 익히고, 걸을수록 새 기술이 열리지.',
          `하지만 너는 아직 이르구나. Lv.${JOB_LEVELS[0]} 이 되면 다시 오너라. (지금 Lv.${s.level})`,
        ], [{ text: '네 갈래 길 이야기 듣기', primary: true, fn: () => this.pathsTalk(false) }]);
      }
      return ui.dialog(MASTER_NAME, [
        '왔구나. 이제 네 길을 고를 때가 되었다.',
        '검사, 궁수, 도적, 별술사 — 어느 길이든 끝까지 걸으면 강해진다. 고른 뒤에도 골드를 내면 다른 길로 옮길 수 있으니 너무 겁내지는 말거라.',
        '어느 길이 궁금하냐?',
      ], this.pathButtons(true));
    }
    if (j.t >= JOB_MAX) {
      return ui.dialog(MASTER_NAME, [`「${this.title()}」… 내가 더 가르칠 것은 없구나. 이제는 네가 다른 이들의 길잡이가 되어 주거라.`], this.menuButtons());
    }
    const need = JOB_LEVELS[j.t];
    if (s.level < need) {
      return ui.dialog(MASTER_NAME, [`「${this.title()}」의 길을 잘 걷고 있구나. 다음 전직은 Lv.${need} 이다. 그때까지 지금의 기술을 손에 익혀 두거라. (지금 Lv.${s.level})`], this.menuButtons());
    }
    return this.offerTalk(j.c, j.t + 1);
  }

  pathButtons(canPick) {
    return [1, 2, 3, 4].map((c) => ({ text: JOBS[c].name, fn: () => this.classTalk(c, canPick) }));
  }

  menuButtons() {
    return [
      { text: '기술 되짚기', primary: true, fn: () => this.skillsTalk() },
      { text: '다른 길로 옮기기', fn: () => this.switchTalk() },
    ];
  }

  pathsTalk(canPick) {
    this.game.ui.dialog(MASTER_NAME, ['어느 길이 궁금하냐?'], this.pathButtons(canPick));
  }

  // 한 길의 설명. canPick: 지금 이 길을 고를 수 있다
  classTalk(c, canPick) {
    const J = JOBS[c];
    const sk = J.skills[0];
    const pa = J.passives[0];
    const lines = [
      `「${J.name}」 — ${J.desc}`,
      `${J.titles[0]} → ${J.titles[1]} → ${J.titles[2]} → ${J.titles[3]}. 전직할 때마다 기술 하나와 숨은 힘 하나를 얻는다.`,
      `첫 기술은 「${sk.name}」 — ${sk.desc}. 숨은 힘으로는 「${pa.name}」(${pa.desc})${josa(pa.name, '을', '를')} 얻는다.`,
    ];
    const buttons = [];
    if (canPick) {
      lines.push(`이 길에 들어서려면 시험을 치러야 한다 — ${jobGoals(c, 1).map(goalText).join(', 그리고 ')}.`);
      buttons.push({
        text: `${J.name}의 길을 걷겠습니다`, primary: true,
        fn: () => {
          const g = this.game;
          g.ui.closeAll();
          if (!this.accept(c, 1)) return;
          g.audio.stone();
          g.ui.toast(`1차 전직 시험 「${J.titles[0]}」을 받았습니다`, true);
          this.announce();
        },
      });
    }
    buttons.push({ text: '다른 길 보기', fn: () => this.pathsTalk(canPick) });
    this.game.ui.dialog(MASTER_NAME, lines, buttons);
  }

  offerTalk(c, tier) {
    const g = this.game;
    const J = JOBS[c];
    const sk = J.skills[tier - 1];
    const pa = J.passives[tier - 1];
    g.ui.dialog(MASTER_NAME, [
      `Lv.${JOB_LEVELS[tier - 1]} 에 이르렀구나. ${tier}차 전직 「${J.titles[tier - 1]}」의 시험을 받을 때다.`,
      `시험은 이렇다 — ${jobGoals(c, tier).map(goalText).join(', ')}.`,
      `해내면 새 기술 「${sk.name}」${josa(sk.name, '을', '를')} 얻는다 — ${sk.desc}. 숨은 힘 「${pa.name}」(${pa.desc})도 함께다.`,
    ], [
      {
        text: '시험을 받겠습니다', primary: true,
        fn: () => {
          g.ui.closeAll();
          if (!this.accept(c, tier)) return;
          g.audio.stone();
          g.ui.toast(`${tier}차 전직 시험 「${J.titles[tier - 1]}」을 받았습니다`, true);
          this.announce();
        },
      },
      { text: '다른 이야기', fn: () => g.ui.dialog(MASTER_NAME, ['무엇이 궁금하냐?'], this.menuButtons()) },
    ]);
  }

  progressTalk() {
    const g = this.game;
    const q = this.quest();
    const J = JOBS[q.c];
    const buttons = [];
    if (q.tier === 1) {
      buttons.push({
        text: '다른 길을 고르겠습니다',
        fn: () => {
          this.abandon();
          this.pathsTalk(true);
        },
      });
    } else buttons.push({ text: '기술 되짚기', fn: () => this.skillsTalk() });
    g.ui.dialog(MASTER_NAME, [
      `${q.tier}차 전직 「${J.titles[q.tier - 1]}」의 시험이 아직 끝나지 않았구나.`,
      this.goals().map((x) => `${x.done ? '✔' : '·'} ${x.text} (${x.n}/${x.need})`).join('   '),
      '서두르지 말거라. 길은 달아나지 않는다.',
    ], buttons);
  }

  ceremonyTalk() {
    const g = this.game;
    const q = this.quest();
    const J = JOBS[q.c];
    const sk = J.skills[q.tier - 1];
    const pa = J.passives[q.tier - 1];
    g.ui.dialog(MASTER_NAME, [
      '시험을 모두 마쳤구나. 훌륭하다.',
      `이제부터 너는 「${J.titles[q.tier - 1]}」${josa(J.titles[q.tier - 1], '이다', '다')}. 새 기술 「${sk.name}」${josa(sk.name, '과', '와')} 숨은 힘 「${pa.name}」${josa(pa.name, '을', '를')} 받거라.`,
    ], [
      {
        text: '전직하기', primary: true,
        fn: () => {
          g.ui.closeAll();
          this.advance();
        },
      },
    ]);
  }

  skillsTalk() {
    const g = this.game;
    const list = this.skills();
    const cdK = g.player.cdK || 1;
    const lines = list.map((sk, i) => `${i + 1}. 「${sk.name}」 — ${sk.desc}. (다시 쓰기까지 ${+(sk.cd * cdK).toFixed(1)}초)`);
    lines.push(g.input.isTouch ? '기술은 화면의 기술 버튼으로 쓴다. 자세한 것은 메뉴의 「모험가」에 적혀 있다.' : '기술은 숫자 키 1 · 2 · 3 · 4 로 쓴다. 자세한 것은 모험가 화면(P)에 적혀 있다.');
    g.ui.dialog(MASTER_NAME, lines, [{ text: '다른 길로 옮기기', fn: () => this.switchTalk() }]);
  }

  switchTalk() {
    const g = this.game;
    const j = this.job();
    if (!j.t) return this.talk(null);
    const cost = this.switchCost();
    const buttons = [1, 2, 3, 4].filter((c) => c !== j.c).map((c) => ({
      text: JOBS[c].name,
      fn: () => {
        const J = JOBS[c];
        g.ui.dialog(MASTER_NAME, [`「${J.name}」 — ${J.desc}`, `골드 ${cost}을 내고 「${jobTitle({ c, t: j.t })}」의 길로 옮기겠느냐? ${J.name}의 기술 ${j.t}개를 곧바로 쓸 수 있다.`], [
          {
            text: `옮기겠습니다 (골드 ${cost})`, primary: true,
            fn: () => {
              g.ui.closeAll();
              if (g.save.gold < cost) {
                g.ui.toast(`골드가 부족합니다 (${cost} 필요).`);
                g.audio.deny();
                return;
              }
              this.switchTo(c);
            },
          },
          { text: '다시 고르기', fn: () => this.switchTalk() },
        ]);
      },
    }));
    const warn = this.quest() ? ' 치르는 중인 시험은 처음부터 다시 받아야 한다.' : '';
    g.ui.dialog(MASTER_NAME, [`길을 바꾸려면 골드 ${cost}이 든다. 전직 차수는 그대로 이어지니, 새 길의 기술을 그만큼 바로 쓸 수 있지.${warn} 어느 길로 옮기겠느냐? (가진 골드 ${g.save.gold})`], buttons);
  }
}

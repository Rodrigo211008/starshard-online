// 바람 정령 하늬: 마을 북쪽 풀밭에서 술래잡기로 친구가 된다.
// 친구가 되면 곁을 따라다니다가, 부르면 바람 기둥을 일으켜 높은 곳으로 밀어 올려 준다 (기둥은 잠깐 남아서 친구들도 함께 탈 수 있다).
import * as THREE from '/vendor/three/three.module.js';
import { GUST } from '/shared/defs.js';
import { Geo, M } from './geo.js';

const TAU = Math.PI * 2;
const C_WIND = 0xbff8ff;

// 작은 구름 뭉치 같은 몸에 바람결 꼬리가 달린 정령
function buildSprite(gfx) {
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  // 몸은 스스로 은은하게 빛난다 (멀리서도 반짝이는 점으로 보인다)
  const g = new Geo();
  g.ico(0.27, 1, M(0, 0, 0, 0, 0, 0, 1, 0.92, 1), 0x3f6a66, 0x8fa8a4);
  g.ico(0.15, 1, M(0.17, 0.05, -0.1), 0x4f7672, 0x8fa8a4);
  g.ico(0.15, 1, M(-0.17, 0.05, -0.1), 0x4f7672, 0x8fa8a4);
  // 바람에 말린 앞머리
  g.cone(0.07, 0.2, 5, M(0.02, 0.27, 0.02, 0.25, 0, -0.35), 0x6f9692, 0xa4b8b4);
  g.cone(0.05, 0.15, 5, M(0.09, 0.36, 0.04, 0.5, 0, -1.1), 0x8fa8a4, 0xb8c8c4);
  const bm = new THREE.Mesh(g.build(false), gfx.matGlow);
  body.add(bm);
  // 눈과 볼
  const fg = new Geo();
  fg.ico(0.04, 0, M(0.1, 0.03, 0.25), 0x1c262c);
  fg.ico(0.04, 0, M(-0.1, 0.03, 0.25), 0x1c262c);
  fg.ico(0.036, 0, M(0.175, -0.05, 0.2), 0xff8fa8);
  fg.ico(0.036, 0, M(-0.175, -0.05, 0.2), 0xff8fa8);
  body.add(new THREE.Mesh(fg.build(false), gfx.matChar));
  // 속에서 비치는 바람 구슬
  const cg = new Geo();
  cg.ico(0.1, 0, M(0, -0.02, 0.02), 0x8ff6ff);
  const core = new THREE.Mesh(cg.build(false), gfx.matGlow);
  body.add(core);
  // 바람결 꼬리 두 가닥
  const tails = [];
  for (const sx of [1, -1]) {
    const t = new THREE.Group();
    t.position.set(sx * 0.1, -0.08, -0.2);
    const tg = new Geo();
    tg.taperBox(0.1, 0.03, 0.34, 0.5, M(0, 0, -0.17), 0x2f7a6c, 0x5fa89c);
    tg.taperBox(0.06, 0.025, 0.26, 0.3, M(0, 0, -0.44), 0x4f94a0, 0x8fb4b8);
    t.add(new THREE.Mesh(tg.build(false), gfx.matGlow));
    body.add(t);
    tails.push(t);
  }
  root.scale.setScalar(1.15);
  return { root, body, core, tails };
}

export class WindSprite {
  constructor(game) {
    this.game = game;
    const { gfx, world, pois, objects, save } = game;
    this.place = pois.sprite || { x: -70, z: -112, spots: [] };
    this.rig = buildSprite(gfx);
    gfx.scene.add(this.rig.root);
    this.pos = new THREE.Vector3(this.place.x, world.heightAt(this.place.x, this.place.z) + 1.5, this.place.z);
    this.vel = new THREE.Vector3();
    this.mode = save.sprite ? 'friend' : 'wild'; // wild 풀밭에서 논다 / chase 술래잡기 중 / friend 함께 다닌다
    this.spot = -1; // 술래잡기에서 지금 가 있는 자리
    this.caught = 0;
    this.left = 0;
    this.dodge = 0;
    this.spin = 0;
    this.charges = GUST.charges;
    this.recharge = 0;
    this.castT = 0;
    this.gusts = [];
    this.remote = new Map(); // 친구들의 정령 (플레이어 번호 -> 모델)
    // 바람 기둥의 모양: 위로 갈수록 좁아지는 투명한 기둥에 비스듬한 바람결이 감겨 돈다 (돌리면 위로 솟는 것처럼 보인다)
    this.colGeo = new THREE.CylinderGeometry(GUST.radius * 0.7, GUST.radius, 1, 18, 1, true);
    this.colGeo.translate(0, 0.5, 0);
    const cv = document.createElement('canvas');
    cv.width = 128;
    cv.height = 256;
    const ctx = cv.getContext('2d');
    ctx.lineCap = 'round';
    for (let k = 0; k < 13; k++) {
      const x = (k * 37 + 11) % 128;
      ctx.lineWidth = 1.5 + ((k * 7) % 5);
      ctx.strokeStyle = `rgba(255,255,255,${0.25 + ((k * 13) % 10) * 0.055})`;
      const y0 = 256 - ((k * 53) % 90);
      const len = 90 + ((k * 29) % 150);
      for (const off of [-128, 0, 128]) {
        ctx.beginPath();
        ctx.moveTo(x + off, y0);
        ctx.lineTo(x + off + len * 0.42, y0 - len);
        ctx.stroke();
      }
    }
    // 위로 갈수록 사라지고, 발밑은 조금 옅다
    const fade = ctx.createLinearGradient(0, 0, 0, 256);
    fade.addColorStop(0, 'rgba(0,0,0,0)');
    fade.addColorStop(0.3, 'rgba(0,0,0,0.75)');
    fade.addColorStop(0.85, 'rgba(0,0,0,1)');
    fade.addColorStop(1, 'rgba(0,0,0,0.5)');
    ctx.globalCompositeOperation = 'destination-in';
    ctx.fillStyle = fade;
    ctx.fillRect(0, 0, 128, 256);
    const tex = new THREE.CanvasTexture(cv);
    tex.wrapS = THREE.RepeatWrapping;
    tex.repeat.set(2, 1);
    tex.colorSpace = THREE.SRGBColorSpace;
    this.colMat = new THREE.MeshBasicMaterial({ color: C_WIND, map: tex, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
    objects.interactables.push({
      kind: 'sprite', ref: this, x: this.place.x, z: this.place.z, r: 3.4,
      active: () => this.mode === 'wild' && !game.zone,
      label: () => '바람 정령에게 말 걸기',
    });
    objects.lightSrc.push({ x: this.place.x, y: this.pos.y, z: this.place.z, color: 0x8ff6ff, power: 0, sprite: this });
    this.light = objects.lightSrc[objects.lightSrc.length - 1];
    document.body.classList.toggle('has-gust', !!save.sprite);
  }

  home() {
    const w = this.game.world;
    return { x: this.place.x, y: w.heightAt(this.place.x, this.place.z) + 1.5, z: this.place.z };
  }

  // 풀밭의 정령에게 말을 걸었다: 술래잡기 시작
  talk() {
    const g = this.game;
    if (this.mode !== 'wild') return;
    if (g.player.mounted) {
      g.ui.toast('하늬: "말을 타고 오면 반칙이지! 내려서 다시 말 걸어 줘."');
      g.audio.deny();
      return;
    }
    this.mode = 'chase';
    this.caught = 0;
    this.spot = -1;
    this._flit(true);
    g.audio.plate(4);
    g.ui.banner('술래잡기!', `바람 정령 하늬를 ${GUST.catches}번 잡으면 친구가 됩니다`);
    g.ui.chatAdd('하늬', '나 잡아 봐라! 다섯 번 잡으면 친구가 돼 줄게. 느림보는 싫어!', '');
  }

  // 다른 자리로 날아간다
  _flit(first) {
    const g = this.game;
    const spots = this.place.spots;
    const p = g.player.pos;
    // 지금 자리와 다르고, 술래에게서 먼 쪽을 좋아한다 (뒤로 갈수록 더 멀리 달아난다)
    let best = 0;
    let bs = -1;
    for (let i = 0; i < spots.length; i++) {
      if (i === this.spot) continue;
      const d = Math.hypot(spots[i].x - p.x, spots[i].z - p.z);
      const s = d * (0.5 + this.caught * 0.15) + Math.random() * 14;
      if (s > bs) {
        bs = s;
        best = i;
      }
    }
    this.spot = best;
    this.left = Math.max(12, GUST.catchSec - this.caught * 2);
    this.dodge = this.caught >= 3 ? 1 : 0; // 마지막 두 번은 한 번씩 약을 올리며 피한다
    if (!first) g.fx.burst(this.pos.x, this.pos.y, this.pos.z, C_WIND, 14, 4, { size: 0.26, life: 0.5, grav: -1, glow: 2.2 });
  }

  _befriend() {
    const g = this.game;
    const { save, ui, audio, fx } = g;
    this.mode = 'friend';
    save.sprite = true;
    this.charges = GUST.charges;
    document.body.classList.add('has-gust');
    audio.seal();
    fx.ring(this.pos.x, this.pos.y - 1, this.pos.z, C_WIND, 6, 0.9);
    fx.burst(this.pos.x, this.pos.y, this.pos.z, C_WIND, 50, 7, { size: 0.36, life: 1.1, grav: -1.5, glow: 2.4 });
    ui.banner('바람 정령 하늬가 친구가 되었습니다!', g.input.isTouch ? '「솟구침」 버튼을 누르면 바람 기둥이 솟아 높이 떠오릅니다' : 'Z 키를 누르면 바람 기둥이 솟아 높이 떠오릅니다');
    ui.chatAdd('하늬', '헤헤, 졌다! 이제부터 같이 다니자. 높은 데 올라가고 싶으면 불러 — 내가 바람으로 밀어 올려 줄게!', '');
    g.net.send({ t: 'chat', text: '★ 바람 정령 하늬와 친구가 되었습니다!' });
    g.net.send({ t: 'prof', prof: g.player.profile() });
    g.tip('gust-how', '바람 기둥은 잠깐 남아 있어서 친구들도 뛰어들어 함께 오를 수 있어요. 바람 구슬은 세 개까지 모이고 시간이 지나면 다시 찹니다.');
    g.saveSoon();
  }

  // 바람 기둥 일으키기 (내가 불렀을 때)
  cast() {
    const g = this.game;
    const p = g.player;
    if (this.mode !== 'friend' || p.state === 'dead' || p.taming) return;
    if (g.zone) {
      g.ui.toast('하늬: "여긴 지붕이 막혀서 바람이 안 불어…"');
      g.audio.deny();
      return;
    }
    if (this.charges <= 0) {
      g.ui.toast(`바람 구슬이 아직 차지 않았습니다 (${Math.ceil(this.recharge)}초)`);
      g.audio.deny();
      return;
    }
    if (this.castT > 0) return;
    this.charges--;
    if (this.recharge <= 0) this.recharge = GUST.recharge;
    this.castT = 0.6;
    const y0 = p.state === 'swim' ? Math.max(p.pos.y, -1) : p.pos.y;
    this._addGust(p.pos.x, y0, p.pos.z, true);
    // 땅이나 벽, 물에 있었다면 바로 떠오른다
    if (p.mounted) p.setMounted(false);
    if (p.state !== 'air' && p.state !== 'glide') {
      p.state = 'air';
      p.airT = 0.2;
    }
    p.action = null;
    p.vel.y = Math.max(p.vel.y, 10);
    p.lifted = true;
    p.gustSafe = 9;
    g.net.send({ t: 'gust', x: +p.pos.x.toFixed(1), y: +y0.toFixed(1), z: +p.pos.z.toFixed(1) });
    g.quests.on('gust');
  }

  // 친구가 일으킨 바람 기둥
  onGust(msg) {
    if (this.game.zone) return;
    this._addGust(msg.x, msg.y, msg.z, false);
  }

  _addGust(x, y0, z, mine) {
    const g = this.game;
    const m = new THREE.Mesh(this.colGeo, this.colMat);
    m.position.set(x, y0, z);
    m.scale.set(1, GUST.height, 1);
    m.renderOrder = 5;
    g.gfx.scene.add(m);
    this.gusts.push({ x, z, y0, y1: y0 + GUST.height, t: 0, m, mine });
    g.fx.ring(x, y0 + 0.3, z, C_WIND, GUST.radius * 1.6, 0.6);
    g.fx.dust(x, y0, z, 10);
    const d = Math.hypot(x - g.player.pos.x, z - g.player.pos.z);
    if (d < 70) g.audio.gust(Math.max(0.2, 1 - d / 70));
    if (!mine && d < 25) g.tip('gust-friend', '친구의 바람 기둥입니다! 안으로 뛰어들면(점프) 함께 떠오를 수 있어요.');
  }

  // 그 자리가 바람 기둥 안이라면 밀어 올리는 빠르기를 돌려준다 (아니면 0)
  liftAt(pos) {
    for (const q of this.gusts) {
      const dx = pos.x - q.x;
      const dz = pos.z - q.z;
      if (dx * dx + dz * dz > GUST.radius * GUST.radius) continue;
      if (pos.y < q.y0 - 2 || pos.y > q.y1) continue;
      if (q.t > GUST.life) continue;
      // 꼭대기에 가까워지면 부드럽게 잦아든다
      return GUST.rise * Math.min(1, 0.35 + (q.y1 - pos.y) / 8);
    }
    return 0;
  }

  // 친구들의 정령을 그린다 (프로필에 표시가 있는 친구만)
  _updateRemote(dt, time) {
    const g = this.game;
    for (const e of g.ents.players.values()) {
      const has = !!e.prof.sp && e.rig.root.visible;
      let r = this.remote.get(e.id);
      if (!has) {
        if (r) r.root.visible = false;
        continue;
      }
      if (!r) {
        r = buildSprite(g.gfx);
        r.root.scale.setScalar(1.05);
        r.x = e.x;
        r.y = e.y + 2;
        r.z = e.z;
        g.gfx.scene.add(r.root);
        this.remote.set(e.id, r);
      }
      const tx = e.x - Math.cos(e.yaw) * 0.8 - Math.sin(e.yaw) * 0.4;
      const tz = e.z + Math.sin(e.yaw) * 0.8 - Math.cos(e.yaw) * 0.4;
      const ty = e.y + 2.05 + Math.sin(time * 2.4 + e.id) * 0.12;
      const k = Math.min(1, dt * 4);
      if (Math.hypot(tx - r.x, tz - r.z) > 30) {
        r.x = tx;
        r.y = ty;
        r.z = tz;
      }
      r.x += (tx - r.x) * k;
      r.y += (ty - r.y) * k;
      r.z += (tz - r.z) * k;
      r.root.visible = true;
      r.root.position.set(r.x, r.y, r.z);
      r.root.rotation.y = e.yaw;
      for (let i = 0; i < 2; i++) r.tails[i].rotation.x = Math.sin(time * 6 + i * 1.7 + e.id) * 0.35;
    }
    for (const [id, r] of this.remote) {
      if (g.ents.players.has(id)) continue;
      g.gfx.scene.remove(r.root);
      this.remote.delete(id);
    }
  }

  update(dt, time) {
    const g = this.game;
    const { fx, world, player } = g;
    const p = player.pos;
    const rig = this.rig;

    // ---- 바람 기둥 ----
    for (let i = this.gusts.length - 1; i >= 0; i--) {
      const q = this.gusts[i];
      q.t += dt;
      const k = q.t < 0.25 ? q.t / 0.25 : q.t > GUST.life - 1 ? Math.max(0, GUST.life - q.t) : 1;
      q.m.scale.set(0.6 + 0.4 * k, GUST.height, 0.6 + 0.4 * k);
      q.m.rotation.y = time * 3;
      q.m.visible = !g.zone;
      if (q.t >= GUST.life) {
        g.gfx.scene.remove(q.m);
        this.gusts.splice(i, 1);
        continue;
      }
      // 위로 감겨 오르는 바람결
      const dx = q.x - p.x;
      const dz = q.z - p.z;
      if (!g.zone && dx * dx + dz * dz < 120 * 120) {
        const n = Math.random() < dt * 40 * k ? 2 : 0;
        for (let j = 0; j < n; j++) {
          const a = Math.random() * TAU;
          const r = GUST.radius * (0.3 + Math.random() * 0.6);
          const y = q.y0 + Math.random() * GUST.height * 0.8;
          fx.spawn(q.x + Math.cos(a) * r, y, q.z + Math.sin(a) * r, -Math.sin(a) * 5, 9 + Math.random() * 6, Math.cos(a) * 5, Math.random() < 0.4 ? 0xffffff : C_WIND, 0.09 + Math.random() * 0.07, 0.7, 0, 0.8, 2.4);
        }
      }
    }
    this.colMat.opacity = 0.55 + Math.sin(time * 9) * 0.1;

    // ---- 바람 구슬이 다시 찬다 ----
    this.castT -= dt;
    if (this.mode === 'friend' && this.charges < GUST.charges) {
      this.recharge -= dt;
      if (this.recharge <= 0) {
        this.charges++;
        this.recharge = this.charges < GUST.charges ? GUST.recharge : 0;
        if (this.charges === GUST.charges) g.audio.plate(5);
      }
    }

    this._updateRemote(dt, time);

    // ---- 정령의 움직임 ----
    let tx;
    let ty;
    let tz;
    let stiff = 5;
    if (this.mode === 'friend') {
      // 오른쪽 어깨 뒤에서 따라다닌다
      const yaw = player.yaw;
      tx = p.x - Math.cos(yaw) * 0.75 - Math.sin(yaw) * 0.45;
      tz = p.z + Math.sin(yaw) * 0.75 - Math.cos(yaw) * 0.45;
      ty = p.y + (player.mounted ? 3.0 : 2.0) + Math.sin(time * 2.4) * 0.12;
      if (this.castT > 0) {
        // 바람을 일으키는 동안에는 발밑에서 빙글 돌며 솟는다
        const a = time * 14;
        tx = p.x + Math.cos(a) * 1.2;
        tz = p.z + Math.sin(a) * 1.2;
        ty = p.y + 0.6;
        stiff = 14;
        this.spin += dt * 20;
      }
      if (this.pos.distanceToSquared(p) > 60 * 60) this.pos.set(tx, ty, tz); // 멀리 순간 이동했으면 바로 따라온다
    } else {
      const far = Math.hypot(this.place.x - p.x, this.place.z - p.z);
      if (this.mode === 'chase') {
        const s = this.place.spots[this.spot] || this.place;
        tx = s.x;
        tz = s.z;
        ty = world.heightAt(s.x, s.z) + 1.25 + Math.sin(time * 5) * 0.2;
        stiff = 7;
        this.left -= dt;
        const d = Math.hypot(this.pos.x - p.x, this.pos.z - p.z);
        const there = Math.hypot(this.pos.x - tx, this.pos.z - tz) < 1.5;
        if (there && d < 4.2 && this.dodge > 0 && !player.mounted) {
          // 잡히기 직전에 한 번 달아난다
          this.dodge = 0;
          const keep = this.left;
          this._flit(false);
          this.dodge = 0;
          this.left = Math.max(8, keep);
          g.ui.toast('하늬: "아슬아슬! 여기야 여기~"');
          g.audio.plate(2);
        } else if (there && d < 2.3 && Math.abs(p.y - (this.pos.y - 1.2)) < 3) {
          if (player.mounted) {
            if (!this._told) g.ui.toast('하늬: "말을 타는 건 반칙이야! 내려서 잡아 봐."');
            this._told = true;
          } else {
            this.caught++;
            g.audio.plate(Math.min(5, this.caught));
            fx.text(this.pos.x, this.pos.y + 0.8, this.pos.z, `잡았다! ${this.caught}/${GUST.catches}`, 'heal');
            if (this.caught >= GUST.catches) this._befriend();
            else this._flit(false);
          }
        } else if (this.left <= 0 || far > 90 || player.state === 'dead' || g.zone) {
          this.mode = 'wild';
          this.spot = -1;
          if (far <= 90) {
            g.ui.toast('하늬: "하하, 느림보! 준비되면 다시 말 걸어."');
            g.audio.deny();
          }
        }
        this._told = this._told && player.mounted;
      }
      if (this.mode === 'wild') {
        // 풀밭 위를 느긋하게 맴돈다
        const h = this.home();
        const a = time * 0.7;
        tx = h.x + Math.cos(a) * 1.6;
        tz = h.z + Math.sin(a) * 1.6;
        ty = h.y + Math.sin(time * 1.9) * 0.3;
        stiff = 3;
        if (far < 26 && !g.zone) g.tip('sprite-meet', '풀밭 위에 무언가 반짝이며 맴돌고 있다… 바람 정령인 것 같다. 가까이 가서 말을 걸어 보자.');
      }
    }
    const k = Math.min(1, dt * stiff);
    this.pos.x += (tx - this.pos.x) * k;
    this.pos.y += (ty - this.pos.y) * k;
    this.pos.z += (tz - this.pos.z) * k;
    const mvx = tx - this.pos.x;
    const mvz = tz - this.pos.z;
    rig.root.visible = !g.zone || this.mode === 'friend';
    rig.root.position.copy(this.pos);
    // 가는 쪽을 바라본다 (거의 멈춰 있으면 술래 쪽을 본다)
    const face = Math.hypot(mvx, mvz) > 0.25 ? Math.atan2(mvx, mvz) : this.mode === 'friend' ? player.yaw : Math.atan2(p.x - this.pos.x, p.z - this.pos.z);
    let dy = face - rig.root.rotation.y;
    while (dy > Math.PI) dy -= TAU;
    while (dy < -Math.PI) dy += TAU;
    rig.root.rotation.y += dy * Math.min(1, dt * 8);
    this.spin = Math.max(0, this.spin - dt * 12);
    rig.body.rotation.y = this.spin;
    rig.body.rotation.z = Math.sin(time * 2.1) * 0.12;
    const low = this.mode === 'friend' && this.charges === 0;
    rig.core.scale.setScalar((low ? 0.5 : 1) * (1 + Math.sin(time * 6) * 0.15));
    for (let i = 0; i < 2; i++) rig.tails[i].rotation.x = Math.sin(time * 6 + i * 1.7) * 0.35 + Math.min(0.6, Math.hypot(mvx, mvz) * 0.12);
    this.light.x = this.pos.x;
    this.light.y = this.pos.y;
    this.light.z = this.pos.z;
    this.light.power = rig.root.visible ? (low ? 4 : 9) : 0;
    // 지나간 자리에 남는 바람결
    if (rig.root.visible && Math.random() < dt * (this.mode === 'chase' ? 26 : 7) && this.pos.distanceToSquared(p) < 80 * 80) {
      fx.spawn(this.pos.x + (Math.random() - 0.5) * 0.3, this.pos.y - 0.1, this.pos.z + (Math.random() - 0.5) * 0.3, 0, 0.3, 0, Math.random() < 0.5 ? 0xffffff : C_WIND, 0.07, 0.8, -0.1, 0.9, 2.2);
    }
  }
}

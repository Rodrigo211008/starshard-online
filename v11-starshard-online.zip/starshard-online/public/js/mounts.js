// 히든 탈것: 외진 곳에 사는 야생마.
// 겁이 많아서 달려오거나 말을 탄 사람이 다가오면 달아난다. 황금 사과를 들고 걸어서 다가가 등에 올라탄 뒤,
// 날뛰는 말 위에서 균형을 잃지 않고 버텨 내야(「길들이기 시험」) 내 말이 된다.
import { MOUNTS, TAME_STAMINA, TAME_FLEE_MS, tameState, tameStep } from '/shared/defs.js';
import { makeHorse, animateHorse } from './models.js';
import { josa } from './dom.js';

const ALARM_R = 17; // 이 안으로 달려오거나 말을 탄 채 들어오면 달아난다
const FLEE_SPEED = 17;
const FLEE_TIME = 2.4;

export class WildMounts {
  constructor(game) {
    this.game = game;
    this.trial = null; // 지금 치르는 길들이기 시험
    const { world, pois, objects, save } = game;
    this.list = (pois.mounts || []).map((m) => {
      const rig = makeHorse(0, 0, m.k, true);
      const y = world.heightAt(m.x, m.z);
      rig.root.position.set(m.x, y, m.z);
      rig.root.rotation.y = (m.x * 0.37) % 6.28;
      rig.root.visible = false;
      objects.group.add(rig.root);
      const w = {
        k: m.k, def: MOUNTS[m.k], x: m.x, y, z: m.z, rig, yaw: rig.root.rotation.y, t: Math.random() * 10, met: false,
        col: { x: m.x, z: m.z, r: 1.0, off: true },
        mode: 'idle', // idle 제자리 / flee 달아나는 중 / away 달아나고 없음
        fx: 0, fz: 0, ft: 0, px: m.x, pz: m.z, backAt: 0,
      };
      objects.interactables.push({
        kind: 'wmount', ref: w, x: m.x, z: m.z, r: 4.4,
        active: () => !game.zone && !this.trial && w.mode === 'idle' && this.shown(w),
        label: () => `${w.def.name}의 등에 오르기 — 황금 사과 ${w.def.need}개 (가진 것 ${save.apples}개)`,
      });
      objects.colliders.push(w.col);
      objects.lightSrc.push({ x: m.x, y: y + 2, z: m.z, color: rig.look.mane, power: 20, wild: w });
      return w;
    });
  }

  // 아직 길들이지 않았고, 모습을 드러내는 때인지 (그림자갈기는 밤에만)
  shown(w) {
    const g = this.game;
    if (g.save.mounts.includes(w.k)) return false;
    return w.k !== 'shade' || g.gfx.night > 0.5;
  }

  // 놀라서 (ax, az) 반대쪽으로 달아난다. 한동안 돌아오지 않는다
  flee(w, ax, az, ms = TAME_FLEE_MS) {
    let dx = w.x - ax;
    let dz = w.z - az;
    const d = Math.hypot(dx, dz) || 1;
    w.mode = 'flee';
    w.fx = dx / d;
    w.fz = dz / d;
    w.ft = 0;
    w.px = w.x;
    w.pz = w.z;
    w.backAt = Date.now() + ms;
    w.yaw = Math.atan2(w.fx, w.fz);
    w.col.off = true;
  }

  // 말에게 다가가 상호작용: 사과가 넉넉하면 등에 올라타 시험을 시작한다
  tame(w) {
    const g = this.game;
    const s = g.save;
    const pl = g.player;
    if (s.mounts.includes(w.k) || this.trial || w.mode !== 'idle') return;
    if (s.apples < w.def.need) {
      g.ui.toast(`${w.def.name}${josa(w.def.name, '이', '가')} 고개를 돌립니다. 황금 사과가 ${w.def.need - s.apples}개 더 필요해요. (의뢰 보상 · 수호자 · 던전에서 얻을 수 있습니다)`);
      g.audio.deny();
      return;
    }
    if (pl.state !== 'ground' || pl.mounted) {
      g.ui.toast('땅 위에 서 있을 때만 올라탈 수 있습니다.');
      return;
    }
    this.trial = { w, st: tameState(), c: w.def.tame, intro: 1.6, buck: 0, spin: 1, sign: 1, low: 0 };
    w.rig.root.visible = false;
    w.col.off = true;
    // 시험 동안은 이 말을 타고 있는 것으로 그린다
    pl.tameKind = w.k;
    pl.buildHorse();
    pl.pos.set(w.x, w.y, w.z);
    pl.vel.set(0, 0, 0);
    pl.yaw = w.yaw;
    pl.taming = { pitch: 0, hop: 0, roll: 0 };
    pl.setMounted(true);
    g.input.autoRun = false;
    g.net.send({ t: 'prof', prof: pl.profile() });
    g.audio.neigh();
    g.ui.tameShow(w.def.name);
    g.ui.banner('길들이기 시험!', `날뛰는 ${w.def.name}의 등에서 떨어지지 않게 버티세요`);
    g.tip('tame-how', g.input.isTouch ? '조이스틱을 좌우로 움직여 표시를 가운데 밝은 칸에 두세요. 말이 몸을 틀기 직전에 화살표가 뜹니다.' : 'A · D 키로 표시를 가운데 밝은 칸에 두세요. 말이 몸을 틀기 직전에 화살표가 뜹니다.');
  }

  // 시험이 끝났다. ok: 길들였는지, why: 실패한 까닭 ('fall' 떨어짐, 'tired' 기력이 다함, 'off' 다른 까닭으로 내림)
  endTrial(ok, why = '') {
    const g = this.game;
    const s = g.save;
    const pl = g.player;
    const T = this.trial;
    if (!T) return;
    const w = T.w;
    this.trial = null;
    pl.taming = null;
    pl.tameKind = null;
    g.ui.tameHide();
    if (ok) {
      s.apples = Math.max(0, s.apples - w.def.need);
      s.mounts.push(w.k);
      s.mountKind = w.k;
      pl.buildHorse(); // 그대로 타고 있다
      g.audio.tame();
      g.fx.ring(w.x, w.y + 0.3, w.z, w.rig.look.mane, 6, 0.9);
      g.fx.burst(w.x, w.y + 1.6, w.z, w.rig.look.tip, 40, 6, { size: 0.36, life: 1.1, grav: 2, glow: 2.4 });
      g.ui.banner(`${w.def.name}${josa(w.def.name, '을', '를')} 길들였습니다!`, g.input.isTouch ? '탈것 버튼으로 부를 수 있어요' : 'G 키로 부를 수 있어요 · 모험가 화면(P)에서 탈것을 바꿉니다');
      g.net.send({ t: 'chat', text: `★ 히든 탈것 「${w.def.name}」${josa(w.def.name, '을', '를')} 길들였습니다!` });
    } else {
      // 말은 사과 하나를 물고 달아난다
      s.apples = Math.max(0, s.apples - 1);
      const thrown = pl.mounted && pl.state !== 'dead';
      if (pl.mounted) pl.setMounted(false, true);
      pl.buildHorse(); // 원래 타던 말로
      if (thrown && why !== 'off') {
        // 내동댕이쳐진다: 균형을 잃은 쪽으로 날아가 구른다
        const side = T.st.bal >= 0 ? 1 : -1;
        const rx = Math.cos(pl.yaw) * side;
        const rz = -Math.sin(pl.yaw) * side;
        const dmg = Math.min(Math.max(1, Math.round(pl.maxHp * 0.15)), pl.hp - 1); // 떨어져서 쓰러지지는 않는다
        if (dmg > 0) pl.damage(dmg, pl.pos.x - rx, pl.pos.z - rz, { raw: true, force: true, noKnock: true });
        if (pl.state !== 'dead') {
          pl.vel.set(rx * 7, 7.5, rz * 7);
          pl.state = 'air';
          pl.airT = 0;
        }
      }
      w.rig.root.visible = true;
      w.rig.root.position.set(w.x, w.y, w.z);
      this.flee(w, pl.pos.x + 0.01, pl.pos.z + 0.01);
      g.audio.neigh();
      g.audio.deny();
      const left = s.apples >= w.def.need ? `남은 사과 ${s.apples}개 — 말이 돌아오면 다시 도전하세요.` : `남은 사과 ${s.apples}개 — 다시 도전하려면 ${w.def.need}개가 있어야 해요.`;
      g.ui.toast(why === 'tired' ? `기력이 다해 ${w.def.name}에게서 떨어졌습니다! 말이 황금 사과 하나를 물고 달아났어요. ${left}` : `${w.def.name}에게서 떨어졌습니다! 말이 황금 사과 하나를 물고 달아났어요. ${left}`);
    }
    g.net.send({ t: 'prof', prof: pl.profile() });
    g.ui.dirty = true;
    g.saveSoon();
  }

  _updateTrial(dt) {
    const g = this.game;
    const pl = g.player;
    const T = this.trial;
    const w = T.w;
    // 죽었거나, 맞아서 떨어졌거나, 다른 곳으로 가 버렸으면 그만둔다
    if (pl.state === 'dead' || !pl.mounted || g.zone || Math.hypot(pl.pos.x - w.x, pl.pos.z - w.z) > 5) return this.endTrial(false, 'off');
    const st = T.st;
    const tm = pl.taming;
    T.buck = Math.max(0, T.buck - dt * 2.6);
    if (T.intro > 0) {
      // 올라타자마자 앞발을 번쩍 든다. 잠깐 숨 고를 틈
      T.intro -= dt;
      const k = Math.sin(Math.min(1, (1.6 - T.intro) / 1.1) * Math.PI);
      tm.pitch = 0.5 * k;
      tm.hop = 0.25 * k;
      tm.roll = 0;
      g.ui.tameUpdate(0, T.c.zone, 0, 0, true);
      return;
    }
    const ax = Math.max(-1, Math.min(1, g.input.moveX));
    const kicked = tameStep(st, T.c, ax, dt);
    if (kicked) {
      T.buck = 1;
      T.sign = kicked;
      T.spin = kicked;
      pl.shake = Math.max(pl.shake, 0.3);
      g.audio.thud();
      g.fx.dust(pl.pos.x, pl.pos.y, pl.pos.z, 6);
    }
    pl.useStamina(TAME_STAMINA[st.inside ? 0 : 1] * dt);
    // 말의 몸짓: 쉬지 않고 뛰어오르며 빙글빙글 돈다. 몸을 틀 때는 크게 솟구친다
    tm.pitch = Math.sin(st.t * 8.5) * 0.13 + T.buck * 0.34 * Math.sin(st.t * 17);
    tm.hop = Math.abs(Math.sin(st.t * 6.5)) * 0.22 + T.buck * 0.4;
    tm.roll = st.bal * 0.42 + T.buck * T.sign * 0.14;
    pl.yaw += T.spin * (0.9 + T.buck * 2.4) * dt;
    if (Math.random() < dt * 9) {
      g.fx.spawn(pl.pos.x + (Math.random() - 0.5) * 1.6, pl.pos.y + 0.2 + Math.random() * 1.6, pl.pos.z + (Math.random() - 0.5) * 1.6, (Math.random() - 0.5) * 1.5, 0.8 + Math.random() * 1.4, (Math.random() - 0.5) * 1.5, Math.random() < 0.4 ? w.rig.look.tip : w.rig.look.mane, 0.16, 0.7, -0.4, 1, 3, 0.4);
    }
    g.ui.tameUpdate(st.bal, T.c.zone, st.trust, st.warn, st.inside);
    if (Math.abs(st.bal) >= 1) return this.endTrial(false, 'fall');
    if (pl.stamina <= 0 && !(pl.buffs.sta > 0)) return this.endTrial(false, 'tired');
    if (st.trust >= 1) return this.endTrial(true);
  }

  update(dt, time) {
    const g = this.game;
    const pl = g.player;
    const p = pl.pos;
    if (this.trial) this._updateTrial(dt);
    const now = Date.now();
    for (const w of this.list) {
      if (this.trial && this.trial.w === w) continue; // 지금 내가 타고 있다
      const dx = p.x - w.x;
      const dz = p.z - w.z;
      const d2 = dx * dx + dz * dz;
      const near = !g.zone && d2 < 240 * 240 && this.shown(w);
      if (w.mode === 'away') {
        w.rig.root.visible = false;
        w.col.off = true;
        // 사람이 멀찍이 떨어져 있으면 슬그머니, 곁에서 기다리고 있으면 조금 더 뜸을 들였다가 돌아온다
        if (now >= w.backAt && (d2 > 30 * 30 || !near || now >= w.backAt + 10000)) {
          w.mode = 'idle';
          w.rig.root.position.set(w.x, w.y, w.z);
          if (near && d2 < 60 * 60) {
            g.fx.dust(w.x, w.y, w.z, 10);
            g.audio.neigh();
          }
        }
        continue;
      }
      if (w.mode === 'flee') {
        w.ft += dt;
        const nx = w.px + w.fx * FLEE_SPEED * dt;
        const nz = w.pz + w.fz * FLEE_SPEED * dt;
        const nh = g.world.heightAt(nx, nz);
        // 물이나 절벽에 막히면 그 자리에서 사라진다
        if (w.ft > FLEE_TIME || !near || nh < 0.3 || Math.abs(nh - g.world.heightAt(w.px, w.pz)) > 2.2) {
          w.mode = 'away';
          g.fx.dust(w.px, g.world.heightAt(w.px, w.pz), w.pz, 10);
          w.rig.root.visible = false;
          continue;
        }
        w.px = nx;
        w.pz = nz;
        w.rig.root.visible = true;
        w.rig.root.position.set(nx, nh, nz);
        w.rig.root.rotation.y = w.yaw;
        animateHorse(w.rig, dt, FLEE_SPEED);
        if (Math.random() < dt * 14) g.fx.spawn(nx, nh + 0.2 + Math.random(), nz, (Math.random() - 0.5) * 0.6, 0.8 + Math.random(), (Math.random() - 0.5) * 0.6, w.rig.look.mane, 0.16, 0.6, -0.4, 1, 3, 0.4);
        continue;
      }
      w.rig.root.visible = near;
      w.col.off = !near;
      if (!near) continue;
      w.t += dt;
      // 겁이 많다: 달려오거나 말을 탄 사람이 가까이 오면 달아난다
      if (d2 < ALARM_R * ALARM_R && (pl.sprinting || pl.mounted) && pl.state !== 'dead') {
        this.flee(w, p.x, p.z);
        g.audio.neigh();
        g.ui.toast(`${w.def.name}${josa(w.def.name, '이', '가')} 놀라 달아났습니다! 달리지 말고, 탈것에서 내려 걸어서 다가가세요. (조금 뒤에 돌아옵니다)`);
        continue;
      }
      // 가까이 가면 이쪽을 바라본다
      if (d2 < 22 * 22) {
        const want = Math.atan2(dx, dz);
        let diff = (want - w.yaw) % 6.2832;
        if (diff > 3.1416) diff -= 6.2832;
        if (diff < -3.1416) diff += 6.2832;
        w.yaw += diff * Math.min(1, dt * 2);
        w.rig.root.rotation.y = w.yaw;
        if (!w.met && d2 < 14 * 14) {
          w.met = true;
          g.ui.region(w.def.name, w.def.desc);
          g.tip('wild-' + w.k, `야생의 ${w.def.name}입니다. 황금 사과 ${w.def.need}개를 들고 등에 올라타, 날뛰는 말 위에서 버텨 내면 길들일 수 있어요. 떨어지면 사과 하나를 잃습니다.`);
        }
      }
      animateHorse(w.rig, dt, 0);
      if (d2 < 70 * 70 && Math.random() < dt * 7) {
        g.fx.spawn(w.x + (Math.random() - 0.5) * 1.2, w.y + 1.2 + Math.random() * 1.2, w.z + (Math.random() - 0.5) * 1.2, (Math.random() - 0.5) * 0.4, 0.6 + Math.random() * 0.8, (Math.random() - 0.5) * 0.4, Math.random() < 0.4 ? w.rig.look.tip : w.rig.look.mane, 0.14, 0.9, -0.3, 1, 3, 0.4);
      }
    }
  }
}

// 실내 구역: 별의 시련장과 던전. 서버와 클라이언트가 함께 쓴다.
// 구역은 세계 북쪽 바깥(z < ZONE_Z)의 평평한 바닥 위에 따로 놓여 있고, 입구를 통해서만 드나든다.
// 지도는 글자 그림으로 그린다 (한 글자 = 한 칸, 한 칸 = TILE 미터):
//   #  벽            .  바닥           (빈칸) 아무것도 없음
//   S  들어오는 곳    E  나가는 문       R  시련의 제단(보상)    C  보물상자
//   1~9 관문 (같은 번호의 무리가 모두 쓰러지면 열린다. 퍼즐 관문은 퍼즐을 풀면 열린다)
//   o  화로(불빛)     p  발판(순서 퍼즐)  f F  불기둥 함정 (서로 엇박)
//   a~n 몬스터 (구역마다 sym 표에서 종류·무리·우두머리 여부를 정한다)   B  보스   P  사슬 기둥(레이드)
import { ZONE_Z, ZONE_FLOOR } from './world.js';

export const TILE = 3;
export const WALL_H = 4.4;
export { ZONE_FLOOR };

// ---------- 시련장 그림 ----------
const COMBAT = [
  '#############',
  '#.....S.....#',
  '#...........#',
  '#o.........o#',
  '######.######',
  '#...........#',
  '#..a.....a..#',
  '#.b...a...b.#',
  '#..a.....a..#',
  '#o.........o#',
  '######1######',
  '#...........#',
  '#..c.....c..#',
  '#.....d.....#',
  '#..c.....c..#',
  '#o.........o#',
  '######2######',
  '#...........#',
  '#.g.......g.#',
  '#.....e.....#',
  '#...........#',
  '#o.........o#',
  '######3######',
  '#..o.....o..#',
  '#.....R.....#',
  '#############',
];
const ORDER4 = [
  '###########',
  '#....S....#',
  '#.........#',
  '#.p..o..p.#',
  '#.........#',
  '#.p.....p.#',
  '#.........#',
  '#####1#####',
  '#.o.....o.#',
  '#....R....#',
  '###########',
];
const ORDER5 = [
  '###########',
  '#....S....#',
  '#.........#',
  '#.p.....p.#',
  '#....p....#',
  '#.p.....p.#',
  '#.........#',
  '#o.......o#',
  '#####1#####',
  '#.o.....o.#',
  '#....R....#',
  '###########',
];
const ORDER6 = [
  '#############',
  '#.....S.....#',
  '#...........#',
  '#.p...p...p.#',
  '#...........#',
  '#.p...p...p.#',
  '#...........#',
  '#o.........o#',
  '######1######',
  '#..o.....o..#',
  '#.....R.....#',
  '#############',
];
const TRAP1 = [
  '#########',
  '#...S...#',
  '#.......#',
  '#o.....o#',
  '#f.f.f.f#',
  '#.......#',
  '#.F.F.F.#',
  '#.......#',
  '#fffffff#',
  '#.......#',
  '#FFFFFFF#',
  '#.......#',
  '#f.F.f.F#',
  '#F.f.F.f#',
  '#.......#',
  '#fffffff#',
  '#FFFFFFF#',
  '#.......#',
  '#..a.a..#',
  '#.......#',
  '###111###',
  '#.o...o.#',
  '#...R...#',
  '#########',
];
const TRAP2 = [
  '#########',
  '#...S...#',
  '#.......#',
  '#o.....o#',
  '#fffffff#',
  '#.......#',
  '#FFFFFFF#',
  '#fffffff#',
  '#.......#',
  '#F.f.F.f#',
  '#f.F.f.F#',
  '#F.f.F.f#',
  '#.......#',
  '#..a.a..#',
  '#fffffff#',
  '#FFFFFFF#',
  '#.......#',
  '#fFfFfFf#',
  '#FfFfFfF#',
  '#.......#',
  '#.b...b.#',
  '#.......#',
  '###111###',
  '#.o...o.#',
  '#...R...#',
  '#########',
];
const TRAP3 = [
  '###########',
  '#....S....#',
  '#.........#',
  '#o.......o#',
  '#fFfFfFfFf#',
  '#FfFfFfFfF#',
  '#.........#',
  '#fffffffff#',
  '#FFFFFFFFF#',
  '#.........#',
  '#.a.....a.#',
  '#FFFFFFFFF#',
  '#fffffffff#',
  '#FFFFFFFFF#',
  '#.........#',
  '#f.F.f.F.f#',
  '#F.f.F.f.F#',
  '#f.F.f.F.f#',
  '#.........#',
  '#fffffffff#',
  '#FFFFFFFFF#',
  '#.........#',
  '#..c.b.c..#',
  '#.........#',
  '####111####',
  '#.o.....o.#',
  '#....R....#',
  '###########',
];

// ---------- 먼 여섯 땅의 시련장 (훨씬 험하다) ----------
// 불기둥 사이에서 싸우는 힘의 시련
const WINDFIRE = [
  '###############',
  '#......S......#',
  '#.............#',
  '#o...........o#',
  '#######.#######',
  '#.............#',
  '#..a...f...a..#',
  '#.b...a.a...b.#',
  '#..F.......F..#',
  '#..a...f...a..#',
  '#o...........o#',
  '#######1#######',
  '#.............#',
  '#.c..F...F..c.#',
  '#......d......#',
  '#.c..f...f..c.#',
  '#...e.....e...#',
  '#o...........o#',
  '#######2#######',
  '#.............#',
  '#.g....F....g.#',
  '#...f.....f...#',
  '#.g....h....g.#',
  '#...F.....F...#',
  '#......i......#',
  '#o...........o#',
  '#######3#######',
  '#...o.....o...#',
  '#......R......#',
  '###############',
];
// 발판 아홉 개의 지혜의 시련: 문 뒤에는 지키는 무리가 기다린다
const ORDER9 = [
  '#############',
  '#.....S.....#',
  '#...........#',
  '#..p..p..p..#',
  '#...........#',
  '#..p..p..p..#',
  '#...........#',
  '#..p..p..p..#',
  '#o.........o#',
  '######1######',
  '#...........#',
  '#..a.....a..#',
  '#.....b.....#',
  '#..a.....a..#',
  '#o.........o#',
  '######2######',
  '#..o.....o..#',
  '#.....R.....#',
  '#############',
];
// 발판 사이사이에 불기둥이 솟는 지혜의 시련
const ORDER9F = [
  '#############',
  '#.....S.....#',
  '#...........#',
  '#.p.f.p.F.p.#',
  '#.F...f...F.#',
  '#.p.F.p.f.p.#',
  '#.f...F...f.#',
  '#.p.f.p.F.p.#',
  '#o.........o#',
  '######1######',
  '#...........#',
  '#.a...F...a.#',
  '#.....b.....#',
  '#.a...f...a.#',
  '#..c.....c..#',
  '#o.........o#',
  '######2######',
  '#..o.....o..#',
  '#.....R.....#',
  '#############',
];
// 가장 긴 불길: 쉴 틈마다 적이 기다린다
const TRAP4 = [
  '###########',
  '#....S....#',
  '#.........#',
  '#o.......o#',
  '#fFfFfFfFf#',
  '#FfFfFfFfF#',
  '#fFfFfFfFf#',
  '#.........#',
  '#.a.....a.#',
  '#fffffffff#',
  '#FFFFFFFFF#',
  '#fffffffff#',
  '#FFFFFFFFF#',
  '#.........#',
  '#FfF.b.FfF#',
  '#fFf...fFf#',
  '#FfFfFfFfF#',
  '#fFfFfFfFf#',
  '#.........#',
  '#.c.....c.#',
  '#fffffffff#',
  '#FFFFFFFFF#',
  '#fFfFfFfFf#',
  '#FFFFFFFFF#',
  '#fffffffff#',
  '#.........#',
  '#..d.e.d..#',
  '#.........#',
  '####111####',
  '#.o.....o.#',
  '#....R....#',
  '###########',
];
// 기둥이 선 넓은 방의 힘의 시련
const ARENA3 = [
  '#################',
  '#.......S.......#',
  '#...............#',
  '#o.............o#',
  '########.########',
  '#...............#',
  '#..a..##.##..a..#',
  '#.b...#...#...b.#',
  '#.....a...a.....#',
  '#.b...#...#...b.#',
  '#..a..##.##..a..#',
  '#o.............o#',
  '########1########',
  '#...............#',
  '#.c...c...c...c.#',
  '#...##.....##...#',
  '#.e.....d.....e.#',
  '#...##.....##...#',
  '#.c...c...c...c.#',
  '#o.............o#',
  '########2########',
  '#...............#',
  '#.g.....F.....g.#',
  '#...f...h...f...#',
  '#.g.....F.....g.#',
  '#...i.......i...#',
  '#o.............o#',
  '########3########',
  '#....o.....o....#',
  '#.......R.......#',
  '#################',
];
// 마지막 시련: 불기둥과 기둥 사이에서 세 무리를 잇달아 상대한다
const STARFALL = [
  '#################',
  '#.......S.......#',
  '#...............#',
  '#o.............o#',
  '########.########',
  '#...............#',
  '#.a...f...f...a.#',
  '#...a...b...a...#',
  '#.F...........F.#',
  '#...a...b...a...#',
  '#.a...f...f...a.#',
  '#o.............o#',
  '########1########',
  '#...............#',
  '#.c..##...##..c.#',
  '#....#..d..#....#',
  '#.e...F...F...e.#',
  '#....#..d..#....#',
  '#.c..##...##..c.#',
  '#o.............o#',
  '########2########',
  '#...............#',
  '#.g..f.....f..g.#',
  '#......h.k......#',
  '#.F....F.F....F.#',
  '#...i...j...i...#',
  '#.g..f.....f..g.#',
  '#o.............o#',
  '########3########',
  '#....o.....o....#',
  '#.......R.......#',
  '#################',
];

// ---------- 던전 그림 ----------
const SEWER = [
  '###########################',
  '#.......#.........#.......#',
  '#...S...#.a.....a.#..c.c..#',
  '#.......#....b....#.......#',
  '#.......#.a.....a.1...e...#',
  '#.......#....b....#.......#',
  '#o.....o#.........#..c.c..#',
  '###...###o.......o####2####',
  '  #...#######.#####.......#',
  '  #...........#   #fFfFfFf#',
  '  #...........#   #.......#',
  '  #############   #FfFfFfF#',
  '                  #.......#',
  '                  #fffffff#',
  '                  #.......#',
  '          #########...o...#',
  '          #...............#',
  '          #.g...g.#########',
  '          #...h...#        ',
  '          #.g...g.#        ',
  '          #.......#        ',
  '        ######3######      ',
  '        #...........#      ',
  '        #.m.......m.#      ',
  '        #.....B.....#      ',
  '        #.m.......m.#      ',
  '        #.o.......o.#      ',
  '        ######4######      ',
  '          #...C...#        ',
  '          #.o.E.o.#        ',
  '          #########        ',
];
const VAULT = [
  '      #########                ',
  '      #.......#                ',
  '      #...S...#                ',
  '      #.......#                ',
  '      #.o...o.#                ',
  '      ###...###                ',
  '#########...###################',
  '#.............#...............#',
  '#..a...b...a..1..c....d....c..#',
  '#.............#...............#',
  '#..a...b...a..#..c....e....c..#',
  '#.....o.......#.......o.......#',
  '###############.......#########',
  '              ####2####        ',
  '              #fFfFfFf#        ',
  '              #FfFfFfF#        ',
  '              #.......#        ',
  '              #fffffff#        ',
  '              #FFFFFFF#        ',
  '              #fffffff#        ',
  '              #.......#        ',
  '    ###########...o...#        ',
  '    #.................#        ',
  '    #.g.......g.#######        ',
  '    #.....h.....#              ',
  '    #.g.......g.#              ',
  '    #.....i.....#              ',
  '    #.o.......o.#              ',
  '   #######3#######             ',
  '   #.............#             ',
  '   #.m....B....m.#             ',
  '   #.............#             ',
  '   #.m.........m.#             ',
  '   #.o.........o.#             ',
  '   #######4#######             ',
  '      #...C...#                ',
  '      #.o.E.o.#                ',
  '      #########                ',
];
const TOMB = [
  '            #########            ',
  '            #.......#            ',
  '            #...S...#            ',
  '            #.o...o.#            ',
  '            ###...###            ',
  '   ############...############   ',
  '   #.........................#   ',
  '   #..a...a.....b.....a...a..#   ',
  '   #.........................#   ',
  '   #.....b.......o.......b...#   ',
  '   ####1###############1######   ',
  '   #......#           #......#   ',
  '   #.c..c.#           #.d..d.#   ',
  '   #......#           #......#   ',
  '   #..e...#           #...e..#   ',
  '   #......#           #......#   ',
  '   ###2####           ####2###   ',
  '   #fFfFf#             #fFfFf#   ',
  '   #FfFfF#             #FfFfF#   ',
  '   #.....#             #.....#   ',
  '   #fffff#             #FFFFF#   ',
  '   #FFFFF#             #fffff#   ',
  '   #.....###############.....#   ',
  '   #.........................#   ',
  '   #..g....g....h....g....g..#   ',
  '   #.........................#   ',
  '   #.....i.......o.......i...#   ',
  '   ############3##############   ',
  '          #.............#        ',
  '          #.m.........m.#        ',
  '          #......B......#        ',
  '          #.m.........m.#        ',
  '          #.............#        ',
  '          #.o.........o.#        ',
  '          #######4#######        ',
  '             #...C...#           ',
  '             #.o.E.o.#           ',
  '             #########           ',
];

// ---------- 먼 땅의 던전과 레이드 (sim/mapgen 으로 깎아 낸 그림) ----------
const WINDCAVE = [
  '           #########           ',
  '           #.......#           ',
  '           #...S...#           ',
  '           #.o...o.#           ',
  '           ###...###           ',
  '  ############...############  ',
  '  #.........................#  ',
  '  #..a...a..b.....b..a...a..#  ',
  '  #o...........c...........o#  ',
  '  #..a...a.........a...a....#  ',
  '  #.........................#  ',
  '  ##111######################  ',
  '  #fFfFf#                      ',
  '  #FfFfF#                      ',
  '  #.....#                      ',
  '  #fffff#                      ',
  '  #FFFFF#                      ',
  '  #.....#####################  ',
  '  #.........................#  ',
  '  #....d.....d..o..d.....d..#  ',
  '  #.......e.........e.......#  ',
  '  #..F.........g.........F..#  ',
  '  #o...d.....d.....d.....d.o#  ',
  '  #.........................#  ',
  '  ######################222##  ',
  '                      #FFFFF#  ',
  '                      #fffff#  ',
  '                      #FFFFF#  ',
  '                      #.....#  ',
  '                      #fFfFf#  ',
  '  #####################FfFfF#  ',
  '  #.........................#  ',
  '  #..h.....h.....o.....h....#  ',
  '  #......f....i.i....f......#  ',
  '  #..j.........k.........j..#  ',
  '  #o.....F...h...h...F.....o#  ',
  '  #.........................#  ',
  '  ############333############  ',
  '      #.................#      ',
  '      #.o.............o.#      ',
  '      #..m...........m..#      ',
  '      #.................#      ',
  '      #........B........#      ',
  '      #.................#      ',
  '      #..m...........m..#      ',
  '      #.o.............o.#      ',
  '      #.................#      ',
  '      ########444########      ',
  '           #...C...#           ',
  '           #.o.E.o.#           ',
  '           #########           ',
];
const TEMPLE = [
  '              #########              ',
  '              #.......#              ',
  '              #...S...#              ',
  '              #.o...o.#              ',
  '              ###...###              ',
  '           ######...######           ',
  ' ###########.............########### ',
  ' #........##.o.........o.##.f.F.f.F# ',
  ' #.a...a..##.............##..d...d.# ',
  ' #...b.........#.....#...1......e..# ',
  ' #o....c.................1...g....o# ',
  ' #...b.........#.....#...1......e..# ',
  ' #.a...a..##.............##..d...d.# ',
  ' #........##.o.........o.##.F.f.F.f# ',
  ' ###########.............########### ',
  '           ######222######           ',
  '                #...#                ',
  '        #########...#########        ',
  '        #...................#        ',
  '        #.h...F.......F...h.#        ',
  '        #....##...i...##....#        ',
  '        #o.f.##..j.j..##.f.o#        ',
  '        #....##...i...##....#        ',
  '        #.h...F.......F...h.#        ',
  '        #...................#        ',
  '       ##########333##########       ',
  '       #.....................#       ',
  '       #.o.................o.#       ',
  '       #...m.............m...#       ',
  '       #.....................#       ',
  '       #.....................#       ',
  '       #..........B..........#       ',
  '       #.m.................m.#       ',
  '       #.....................#       ',
  '       #.....................#       ',
  '       #...m.............m...#       ',
  '       #.o.................o.#       ',
  '       #.....................#       ',
  '       ##########444##########       ',
  '              #...C...#              ',
  '              #.o.E.o.#              ',
  '              #########              ',
];
const STARPIT = [
  '               #########               ',
  '               #.......#               ',
  '               #...S...#               ',
  '               #.o...o.#               ',
  '               ###...###               ',
  '        ##########...###############   ',
  '        #....................#..o..#   ',
  '        #.a....a..o..a....a..1.....#   ',
  '        #....b...c.c...b.....1.....#   ',
  '        #.a....a.....a....a..1.....#   ',
  '        #....................#.....#   ',
  '        ######################.....#   ',
  '   ###########################.....#   ',
  '   #o.....##...............##......#   ',
  '   #.........o...........o.##.d..d.#   ',
  '   #...........m.......m...##......#   ',
  '   #.......................##f.e..F#   ',
  '   #fFfFfF##...............##......#   ',
  '   #FfFfFf##.......B.......##.d..d.#   ',
  '   #......##...............##..g...#   ',
  '   #FFFFFF##...............##.d..d.#   ',
  '   #ffffff##...m.......m...##......#   ',
  '   #......##.o...........o.##F..e.f#   ',
  '   #FfFfFf##...............##......#   ',
  '   #fFfFfF########444########.d..d.#   ',
  '   #......#    #...C...#    #......#   ',
  '   #.....##    #.o.E.o.#    ##222###   ',
  '   #.....####################......#   ',
  '   #.....#.........................#   ',
  '   #.....3.h...F...i...F...h.......#   ',
  '   #.....3...j....k.l....j.........#   ',
  '   #.....3.h...f...i...f...h.......#   ',
  '   #o....#........................o#   ',
  '   #################################   ',
];
const HEART = [
  '           ###########           ',
  '           #.o.....o.#           ',
  '           #....S....#           ',
  '           #.........#           ',
  '           #.o.....o.#           ',
  '           ####...####           ',
  '              #...#              ',
  '         ######...######         ',
  '     #####.............#####     ',
  '     ####...o.......o...####     ',
  '     ###.................###     ',
  '     ##.........m.........##     ',
  '    ##.....................##    ',
  '    #.....P...........P.....#    ',
  '    #...........n...........#    ',
  '    #.o...................o.#    ',
  '    #.......................#    ',
  '    #.......................#    ',
  '    #.......................#    ',
  '    #...m..n....B....n..m...#    ',
  '    #.......................#    ',
  '    #.......................#    ',
  '    #.......................#    ',
  '    #.o...................o.#    ',
  '    #...........n...........#    ',
  '    #.....P...........P.....#    ',
  '    ##.....................##    ',
  '     ##.........m.........##     ',
  '     ###.................###     ',
  '     ####...o.......o...####     ',
  '     #####.............#####     ',
  '         ######111######         ',
  '           #.........#           ',
  '           #....C....#           ',
  '           #.o..E..o.#           ',
  '           ###########           ',
];

// ---------- 별의 탑: 둥근 싸움터 하나 ----------
// 북쪽 끝이 들머리(S), 그 앞에 층을 여는 제단(R). 둘레에 화로가 서 있다
function roundRoom(w, h) {
  const cx = (w - 1) / 2;
  const cz = (h - 1) / 2;
  // (거듭제곱 연산자 대신 곱셈으로: 어느 기기에서나 똑같은 값이 나오도록)
  const inside = (c, r) => {
    const a = (c - cx) / (cx - 0.4);
    const b = (r - cz) / (cz - 0.4);
    return a * a + b * b <= 1;
  };
  const rows = [];
  for (let r = 0; r < h; r++) {
    let line = '';
    for (let c = 0; c < w; c++) {
      if (inside(c, r)) line += '.';
      else {
        // 바닥과 맞닿은 곳(모서리 포함)만 벽으로 두른다
        let near = false;
        for (let dr = -1; dr <= 1 && !near; dr++) for (let dc = -1; dc <= 1; dc++) if (inside(c + dc, r + dr)) { near = true; break; }
        line += near ? '#' : ' ';
      }
    }
    rows.push(line);
  }
  const put = (c, r, ch) => { rows[r] = rows[r].slice(0, c) + ch + rows[r].slice(c + 1); };
  put(Math.round(cx), 2, 'S');
  put(Math.round(cx), 6, 'R');
  for (const [dc, dr] of [[-7, -9], [7, -9], [-10, -3], [10, -3], [-10, 4], [10, 4], [-7, 10], [7, 10]]) put(Math.round(cx) + dc, Math.round(cz) + dr, 'o');
  return rows;
}
const SPIRE = roundRoom(25, 29);

// 몬스터 표: 글자 -> [종류, 무리(관문 번호), 우두머리(1) 또는 시련의 수호자(2: 우두머리이면서 레벨이 2 높다)]
// min: 1 이면 보스가 불러낼 때만 나타난다 (글자 m 은 늘 그렇다)
const M = (t, g, e = 0, min = 0) => ({ t, g, e, min });

// 구역 정의. theme: 몬스터 색과 벽 빛깔에 쓰는 지역 번호, level: 몬스터 레벨, anchor: 입구를 놓을 곳(월드 좌표 근처)
//  tough: [체력 배율, 공격력 배율] — 먼 땅의 구역은 방어구가 좋아진 모험가에게도 아프도록 몬스터가 더 세다 (보스는 따로 정한 값 그대로)
//  look: 벽 빛깔만 따로 정할 때 (레이드)
// ※ 번호(id)는 저장 기록에 남으므로, 새 구역은 반드시 맨 뒤에 덧붙인다
const DEFS = [
  // ---- 별의 시련장 12곳 ----
  { key: 't1', kind: 'trial', type: 'combat', name: '새벽의 시련장', sub: '힘의 시련', level: 2, theme: 0, anchor: [-150, 130], map: COMBAT, sym: { a: M('slime', 1), b: M('goblin', 1), c: M('goblin', 2), d: M('thrower', 2), e: M('slime', 3, 2), g: M('slime', 3) } },
  { key: 't2', kind: 'trial', type: 'order', name: '속삭임의 시련장', sub: '지혜의 시련', level: 3, theme: 1, anchor: [330, 250], map: ORDER4, puzzle: { gate: 1, len: 6, slot: 0.7 } },
  { key: 't3', kind: 'trial', type: 'trap', name: '단풍의 시련장', sub: '용기의 시련', level: 4, theme: 6, anchor: [-560, 40], map: TRAP1, sym: { a: M('wolf', 1) } },
  { key: 't4', kind: 'trial', type: 'combat', name: '모래의 시련장', sub: '힘의 시련', level: 7, theme: 3, anchor: [230, 420], map: COMBAT, sym: { a: M('scorpion', 1), b: M('thrower', 1), c: M('goblin', 2), d: M('scorpion', 2, 1), e: M('scorpion', 3, 2), g: M('thrower', 3) } },
  { key: 't5', kind: 'trial', type: 'order', name: '안개의 시련장', sub: '지혜의 시련', level: 7, theme: 4, anchor: [-250, 400], map: ORDER5, puzzle: { gate: 1, len: 7, slot: 0.62 } },
  { key: 't6', kind: 'trial', type: 'trap', name: '서리의 시련장', sub: '용기의 시련', level: 9, theme: 2, anchor: [-290, -330], map: TRAP2, sym: { a: M('thrower', 1), b: M('wolf', 1) } },
  { key: 't7', kind: 'trial', type: 'combat', name: '잿불의 시련장', sub: '힘의 시련', level: 12, theme: 5, anchor: [250, -180], map: COMBAT, sym: { a: M('imp', 1), b: M('goblin', 1), c: M('wolf', 2), d: M('imp', 2, 1), e: M('yeti', 3, 2), g: M('imp', 3) } },
  { key: 't8', kind: 'trial', type: 'order', name: '호숫가의 시련장', sub: '지혜의 시련', level: 5, theme: 0, anchor: [120, -150], map: ORDER5, puzzle: { gate: 1, len: 8, slot: 0.66 } },
  { key: 't9', kind: 'trial', type: 'combat', name: '꽃잎의 시련장', sub: '힘의 시련', level: 14, theme: 7, anchor: [905, 760], map: COMBAT, sym: { a: M('wolf', 1), b: M('thrower', 1), c: M('goblin', 2), d: M('wolf', 2, 1), e: M('goblin', 3, 2), g: M('thrower', 3) } },
  { key: 't10', kind: 'trial', type: 'order', name: '포자의 시련장', sub: '지혜의 시련', level: 16, theme: 8, anchor: [-760, 905], map: ORDER6, puzzle: { gate: 1, len: 10, slot: 0.56 } },
  { key: 't11', kind: 'trial', type: 'trap', name: '수정의 시련장', sub: '용기의 시련', level: 18, theme: 9, anchor: [-905, -760], map: TRAP3, sym: { a: M('imp', 1), b: M('thrower', 1, 1), c: M('yeti', 1) } },
  { key: 't12', kind: 'trial', type: 'combat', name: '그림자의 시련장', sub: '힘의 시련', level: 21, theme: 10, anchor: [760, -905], map: COMBAT, sym: { a: M('imp', 1), b: M('yeti', 1), c: M('wolf', 2), d: M('yeti', 2, 1), e: M('golem', 3), g: M('imp', 3) } },
  // ---- 숨겨진 던전 3곳 (lamps: 입구를 드러내려면 밝혀야 하는 돌등의 수) ----
  {
    key: 'd1', kind: 'dungeon', name: '잊힌 수로', sub: '숨겨진 던전', level: 14, theme: 4, anchor: [-616, 224], lamps: 3, night: false, map: SEWER,
    sym: { a: M('slime', 1), b: M('thrower', 1), c: M('goblin', 2), e: M('goblin', 2, 1), g: M('imp', 3), h: M('scorpion', 3, 1), m: M('slime', 4), B: M('kingslime', 4) },
  },
  {
    key: 'd2', kind: 'dungeon', name: '얼어붙은 금고', sub: '숨겨진 던전', level: 20, theme: 2, anchor: [80, -620], lamps: 4, night: false, map: VAULT,
    sym: { a: M('wolf', 1), b: M('thrower', 1, 1), c: M('yeti', 2), d: M('imp', 2), e: M('yeti', 2, 1), g: M('wolf', 3), h: M('yeti', 3, 1), i: M('imp', 3, 1), m: M('wolf', 4), B: M('tyrant', 4) },
  },
  {
    key: 'd3', kind: 'dungeon', name: '별무덤', sub: '숨겨진 던전', level: 26, theme: 10, anchor: [1010, -990], lamps: 5, night: true, map: TOMB,
    sym: { a: M('imp', 1), b: M('thrower', 1, 1), c: M('wolf', 2), d: M('yeti', 2), e: M('imp', 2, 1), g: M('yeti', 3), h: M('golem', 3), i: M('wolf', 3, 1), m: M('imp', 4), B: M('knight', 4) },
  },
  // ---- 먼 여섯 땅의 시련장 (16~21번) ----
  {
    key: 't13', kind: 'trial', type: 'combat', name: '돌개바람의 시련장', sub: '힘의 시련', level: 25, theme: 11, anchor: [1560, 90], map: WINDFIRE, tough: [1.3, 1.3],
    sym: { a: M('goblin', 1), b: M('thrower', 1), c: M('scorpion', 2), d: M('scorpion', 2, 1), e: M('thrower', 2), g: M('goblin', 3), h: M('yeti', 3, 2), i: M('golem', 3) },
  },
  {
    key: 't14', kind: 'trial', type: 'order', name: '살얼음의 시련장', sub: '지혜의 시련', level: 28, theme: 12, anchor: [-90, -1560], map: ORDER9, tough: [1.35, 1.4],
    puzzle: { gate: 1, len: 11, slot: 0.52 }, sym: { a: M('wolf', 2), b: M('yeti', 2, 2) },
  },
  {
    key: 't15', kind: 'trial', type: 'trap', name: '층층의 시련장', sub: '용기의 시련', level: 31, theme: 13, anchor: [-1560, -90], map: TRAP4, tough: [1.4, 1.45],
    sym: { a: M('thrower', 1), b: M('goblin', 1, 1), c: M('wolf', 1), d: M('goblin', 1), e: M('thrower', 1, 2) },
  },
  {
    key: 't16', kind: 'trial', type: 'combat', name: '물거품의 시련장', sub: '힘의 시련', level: 34, theme: 14, anchor: [90, 1580], map: ARENA3, tough: [1.45, 1.5],
    sym: { a: M('slime', 1), b: M('thrower', 1), c: M('scorpion', 2), d: M('scorpion', 2, 2), e: M('thrower', 2, 1), g: M('scorpion', 3), h: M('golem', 3, 2), i: M('thrower', 3, 1) },
  },
  {
    key: 't17', kind: 'trial', type: 'order', name: '구름기둥의 시련장', sub: '지혜의 시련', level: 38, theme: 15, anchor: [1650, -1650], map: ORDER9F, tough: [1.5, 1.6],
    puzzle: { gate: 1, len: 12, slot: 0.5 }, sym: { a: M('imp', 2), b: M('yeti', 2, 2), c: M('thrower', 2, 1) },
  },
  {
    key: 't18', kind: 'trial', type: 'combat', name: '별똥의 시련장', sub: '힘의 시련', level: 42, theme: 16, anchor: [-1650, 1650], map: STARFALL, tough: [1.6, 1.7],
    sym: { a: M('wolf', 1), b: M('imp', 1, 1), c: M('yeti', 2), d: M('imp', 2, 1), e: M('wolf', 2, 1), g: M('imp', 3), h: M('golem', 3, 2), k: M('golem', 3), i: M('imp', 3, 1), j: M('yeti', 3, 2) },
  },
  // ---- 먼 땅의 숨겨진 던전 (22~24번) ----
  {
    key: 'd4', kind: 'dungeon', name: '울부짖는 바람굴', sub: '숨겨진 던전', level: 30, theme: 11, anchor: [1790, -150], lamps: 5, night: false, map: WINDCAVE, tough: [1.4, 1.45],
    sym: { a: M('goblin', 1), b: M('thrower', 1, 1), c: M('scorpion', 1, 1), d: M('scorpion', 2), e: M('thrower', 2, 1), g: M('goblin', 2, 2), h: M('goblin', 3), i: M('thrower', 3, 1), j: M('scorpion', 3, 1), k: M('golem', 3), m: M('scorpion', 4), B: M('empress', 4) },
  },
  {
    key: 'd5', kind: 'dungeon', name: '가라앉은 신전', sub: '숨겨진 던전', level: 36, theme: 14, anchor: [-170, 1830], lamps: 5, night: false, map: TEMPLE, tough: [1.5, 1.55],
    sym: { a: M('slime', 1), b: M('scorpion', 1), c: M('slime', 1, 2), d: M('scorpion', 2), e: M('thrower', 2, 1), g: M('scorpion', 2, 2), h: M('thrower', 3, 1), i: M('slime', 3, 1), j: M('golem', 3), m: M('slime', 4), B: M('tidelord', 4) },
  },
  {
    key: 'd6', kind: 'dungeon', name: '별똥 구덩이', sub: '숨겨진 던전', level: 44, theme: 16, anchor: [-1800, 1820], lamps: 6, night: true, map: STARPIT, tough: [1.7, 1.75],
    sym: { a: M('wolf', 1), b: M('imp', 1, 1), c: M('yeti', 1), d: M('imp', 2), e: M('yeti', 2, 1), g: M('wolf', 2, 2), h: M('yeti', 3), i: M('imp', 3, 1), j: M('wolf', 3, 1), k: M('golem', 3, 2), l: M('golem', 3), m: M('imp', 4), B: M('starborn', 4) },
  },
  // ---- 레이드 (25번): 친구들과 함께 들어가는 큰 싸움. 레벨과 상관없이 누구나 함께할 수 있다 (피해는 체력의 비율로, 보스의 체력은 모인 사람들의 힘에 맞춰진다) ----
  {
    key: 'r1', kind: 'raid', name: '잠든 별의 심장', sub: '레이드', level: 20, theme: 0, look: 17, anchor: [100, 96], lamps: 0, map: HEART,
    sym: { m: M('wolf', 1), n: M('imp', 1, 0, 1), P: M('pylon', 1, 0, 1), B: M('devourer', 1) },
  },
  // ---- 별의 탑 (26번): 끝없이 이어지는 층. 층마다 무리가 강해지고, 다섯 층마다 우두머리가 기다린다 ----
  // pool: 층마다 불려 나오는 몬스터들 (종류별 마릿수), elites: 우두머리 꼴로 나오는 것, bosses: 다섯 층마다 돌아가며 나오는 주인들
  {
    key: 'tw', kind: 'tower', name: '별의 탑', sub: '끝없는 탑', level: 10, theme: 9, biome: 0, look: 18, anchor: [-122, 12], lamps: 0, map: SPIRE,
    pool: { slime: 8, goblin: 8, thrower: 6, wolf: 8, scorpion: 6, yeti: 5, imp: 7, golem: 2 },
    elites: ['slime', 'goblin', 'wolf', 'scorpion', 'yeti', 'imp', 'thrower'],
    bosses: ['kingslime', 'tyrant', 'knight', 'empress', 'tidelord', 'starborn'],
  },
];

// ---------- 별의 탑의 규칙 (서버와 화면이 함께 쓴다) ----------
export const TOWER = {
  every: 5, // 이 층수마다 우두머리가 나오고, 그다음 층이 다시 시작할 수 있는 층이 된다
  maxStart: 996,
  // 층마다 나오는 무리의 구성 (여섯 가지가 돌아가며 나온다)
  sets: [
    ['slime', 'goblin', 'thrower'], ['wolf', 'goblin', 'thrower'], ['scorpion', 'thrower', 'imp'],
    ['yeti', 'wolf', 'imp'], ['goblin', 'scorpion', 'yeti'], ['imp', 'yeti', 'wolf', 'golem'],
  ],
  failMs: 3000, // 탑 안에 서 있는 사람이 이만큼 없으면 그 층은 실패
};
// 그 층 몬스터의 레벨 (1층 = 10, 한 층에 2씩)
export const towerLevel = (f) => 8 + 2 * f;
// 다섯 층마다 우두머리
export const towerBossFloor = (f) => f % TOWER.every === 0;
// 그 층부터 다시 시작할 수 있는가 (1, 6, 11, …)
export const towerStartOk = (f) => Number.isInteger(f) && f >= 1 && f <= TOWER.maxStart && (f - 1) % TOWER.every === 0;
// 가장 높이 오른 층(best)으로부터, 다시 시작할 수 있는 가장 높은 층
export const towerCheckpoint = (best) => Math.floor(Math.max(0, best | 0) / TOWER.every) * TOWER.every + 1;
// 층에 따른 배율: 무리의 체력, 공격력 (높이 오를수록 가파르게 세진다)
export const towerHpK = (f) => 1 + 0.06 * f;
export const towerDmgK = (f) => 1 + 0.006 * Math.max(0, f - 10);
// 우두머리의 체력과 공격력은 종류와 상관없이 그 층의 레벨로 정한다 (L: 레벨, n: 탑 안의 사람 수)
export function towerBossHp(L, f, n) {
  const atk = (5.8 + 1.12 * L) * (0.97 + 0.03 * L) + L; // 그 레벨 모험가의 한 방 (어림)
  return Math.round(175 * atk * (1 + 0.6 * (Math.max(1, n) - 1)) * (1 + 0.02 * Math.max(0, f - 46)));
}
export function towerBossDmg(L, f) {
  return Math.round((6 + 0.42 * L + 0.005 * L * L) * (1 + 0.01 * Math.max(0, f - 46)));
}

const kindSeq = {};
function parse(def, index) {
  const rows = def.map;
  const tileH = rows.length;
  const tileW = rows[0].length;
  for (const r of rows) if (r.length !== tileW) throw new Error(`zone ${def.key}: 줄 길이가 다릅니다 (${r})`);
  // 시련장은 한 줄로, 던전은 그 뒤쪽 줄에, 레이드는 맨 뒤에 놓는다 (같은 종류 가운데 몇 번째인지로 자리를 정한다)
  const k = kindSeq[def.kind] || 0;
  kindSeq[def.kind] = k + 1;
  let cx;
  let cz;
  if (def.kind === 'trial') {
    cx = -1020 + k * 120;
    cz = ZONE_Z - 110;
  } else if (def.kind === 'dungeon') {
    cx = -1250 + k * 500;
    cz = ZONE_Z - 300;
  } else if (def.kind === 'tower') {
    cx = -900 + k * 400;
    cz = ZONE_Z - 820;
  } else {
    cx = k * 400;
    cz = ZONE_Z - 560;
  }
  const ox = cx - (tileW * TILE) / 2;
  const oz = cz - (tileH * TILE) / 2;
  const z = {
    id: index + 1, key: def.key, kind: def.kind, type: def.type || def.kind, name: def.name, sub: def.sub, level: def.level, theme: def.theme,
    look: def.look === undefined ? def.theme : def.look, tough: def.tough || null, center: null, bosses: def.bosses || null, biome: def.biome,
    anchor: def.anchor, lamps: def.lamps || 0, night: !!def.night, puzzle: def.puzzle || null,
    rows, tileW, tileH, ox, oz, x0: ox, z0: oz, x1: ox + tileW * TILE, z1: oz + tileH * TILE,
    start: null, exit: null, altar: null, chests: [], torches: [], plates: [], flames: [], gates: [], spawns: [], ngates: 0,
  };
  const gateMap = new Map();
  for (let r = 0; r < tileH; r++) {
    for (let c = 0; c < tileW; c++) {
      const ch = rows[r][c];
      if (ch === '#' || ch === '.' || ch === ' ') continue;
      const x = ox + (c + 0.5) * TILE;
      const zz = oz + (r + 0.5) * TILE;
      if (ch === 'S') z.start = { x, z: zz };
      else if (ch === 'E') z.exit = { x, z: zz };
      else if (ch === 'R') z.altar = { x, z: zz };
      else if (ch === 'C') z.chests.push({ x, z: zz });
      else if (ch === 'o') z.torches.push({ x, z: zz });
      else if (ch === 'p') z.plates.push({ x, z: zz, i: z.plates.length });
      else if (ch === 'f' || ch === 'F') z.flames.push({ x, z: zz, phase: ch === 'F' ? 0.5 : 0 });
      else if (ch >= '1' && ch <= '9') {
        // 같은 번호가 가로나 세로로 이어져 있으면 하나의 문으로 본다
        const n = +ch;
        let g = (rows[r][c - 1] === ch && gateMap.get(r + ',' + (c - 1))) || (r > 0 && rows[r - 1][c] === ch && gateMap.get(r - 1 + ',' + c)) || null;
        if (!g) {
          // horiz: 벽이 가로(x 방향)로 뻗어 있고 문을 남북으로 지나간다
          g = { n, tiles: [], horiz: rows[r][c - 1] === '#' || rows[r][c + 1] === '#' || rows[r][c + 1] === ch, x: 0, z: 0 };
          z.gates.push(g);
        }
        gateMap.set(r + ',' + c, g);
        g.tiles.push({ x, z: zz });
        if (n > z.ngates) z.ngates = n;
      } else {
        const s = def.sym && def.sym[ch];
        if (!s) throw new Error(`zone ${def.key}: 알 수 없는 글자 '${ch}'`);
        const boss = ch === 'B';
        z.spawns.push({ type: s.t, level: def.level + (boss ? 2 : s.e || 0), x, z: zz, group: s.g, elite: s.e ? 1 : 0, boss: boss ? 1 : 0, minion: ch === 'm' || s.min ? 1 : 0 });
      }
    }
  }
  for (const g of z.gates) {
    g.x = g.tiles.reduce((a, t) => a + t.x, 0) / g.tiles.length;
    g.z = g.tiles.reduce((a, t) => a + t.z, 0) / g.tiles.length;
  }
  if (!z.start) throw new Error(`zone ${def.key}: 시작 지점(S)이 없습니다`);
  if (def.kind === 'tower') {
    // 싸움터의 한가운데와, 층마다 불려 나올 몬스터들 (평소에는 잠들어 있다. 자리는 그때그때 정한다)
    z.center = { x: ox + (tileW * TILE) / 2, z: oz + (tileH * TILE) / 2 + TILE };
    const TINT = [9, 12, 16, 2, 20]; // 탑의 몬스터는 차가운 별빛 빛깔을 띤다
    let n = 0;
    const add = (type, elite, boss) => {
      const a = n * 2.399963;
      const r = 10 + (n % 5) * 3;
      z.spawns.push({ type, level: def.level, x: z.center.x + Math.sin(a) * r, z: z.center.z + Math.cos(a) * r, group: 1, elite: elite ? 1 : 0, boss: boss ? 1 : 0, minion: 1, biome: TINT[n % TINT.length] });
      n++;
    };
    for (const [type, count] of Object.entries(def.pool)) for (let i = 0; i < count; i++) add(type, false, false);
    for (const type of def.elites) add(type, true, false);
    for (const type of def.bosses) add(type, false, true);
  }
  return z;
}

export const ZONES = DEFS.map(parse);
export const TRIAL_COUNT = ZONES.filter((z) => z.kind === 'trial').length;
export const DUNGEON_COUNT = ZONES.filter((z) => z.kind === 'dungeon').length;
// 마을의 석판은 인장 열두 개에 열린다 (먼 여섯 땅의 인장은 그 뒤의 도전이다)
export const TABLET_SEALS = 12;
// 그 구역의 몬스터에게 더해지는 배율 [체력, 공격력]. 보스는 받지 않는다
const NO_TOUGH = [1, 1];
export function zoneTough(zoneId, boss) {
  const z = ZONES[zoneId - 1];
  return !z || !z.tough || boss ? NO_TOUGH : z.tough;
}

// 불기둥 함정: 주기 FLAME_PERIOD 초 가운데 FLAME_ON 초 동안 타오른다. 켜지기 FLAME_WARN 초 전부터 불씨가 인다.
export const FLAME_PERIOD = 2.4;
export const FLAME_ON = 1.1;
export const FLAME_WARN = 0.5;
// 지금 불기둥의 상태: 0 = 꺼짐, 0~1 사이 = 곧 켜짐(예고), 1 = 타오르는 중.  timeSec: 서버 시각(초)
export function flameState(flame, timeSec) {
  const t = (((timeSec / FLAME_PERIOD + flame.phase) % 1) + 1) % 1 * FLAME_PERIOD;
  if (t < FLAME_ON) return 1;
  if (t > FLAME_PERIOD - FLAME_WARN) return (t - (FLAME_PERIOD - FLAME_WARN)) / FLAME_WARN * 0.99;
  return 0;
}

// 좌표가 속한 구역 (없으면 null)
let last = null;
export function zoneAt(x, z) {
  if (z >= ZONE_Z) return null;
  if (last && x >= last.x0 - 4 && x <= last.x1 + 4 && z >= last.z0 - 4 && z <= last.z1 + 4) return last;
  for (const q of ZONES) {
    if (x >= q.x0 - 4 && x <= q.x1 + 4 && z >= q.z0 - 4 && z <= q.z1 + 4) {
      last = q;
      return q;
    }
  }
  return null;
}
export function zoneIdAt(x, z) {
  const q = zoneAt(x, z);
  return q ? q.id : 0;
}

// 그 칸이 막혀 있는지 (벽, 빈 곳, 닫힌 관문). open: 열린 관문의 비트 묶음
export function tileSolid(zone, c, r, open) {
  if (c < 0 || r < 0 || c >= zone.tileW || r >= zone.tileH) return true;
  const ch = zone.rows[r].charCodeAt(c);
  if (ch === 35 || ch === 32) return true; // '#', ' '
  if (ch >= 49 && ch <= 57) return !((open >> (ch - 48)) & 1); // '1'~'9'
  return false;
}
export function zoneSolid(zone, x, z, open) {
  return tileSolid(zone, Math.floor((x - zone.ox) / TILE), Math.floor((z - zone.oz) / TILE), open);
}
// 두 점 사이가 벽에 가려지지 않았는지 (화살, 조준, 시야)
export function zoneClearLine(zone, x0, z0, x1, z1, open) {
  const dx = x1 - x0;
  const dz = z1 - z0;
  const n = Math.max(1, Math.ceil(Math.hypot(dx, dz) / 0.75));
  for (let i = 1; i < n; i++) {
    const k = i / n;
    if (zoneSolid(zone, x0 + dx * k, z0 + dz * k, open)) return false;
  }
  return true;
}
// 반지름 rad 인 원이 벽에 닿는지
export function zoneBlocked(zone, x, z, rad, open) {
  return zoneSolid(zone, x - rad, z - rad, open) || zoneSolid(zone, x + rad, z - rad, open) || zoneSolid(zone, x - rad, z + rad, open) || zoneSolid(zone, x + rad, z + rad, open);
}
// 화로(받침대 위의 불)는 가운데만 막는 작은 장애물이다
export const TORCH_R = 0.55;
export function zoneTorchHit(zone, x, z, rad) {
  const rr = (TORCH_R + rad) * (TORCH_R + rad);
  for (const t of zone.torches) {
    const dx = x - t.x;
    const dz = z - t.z;
    if (dx * dx + dz * dz < rr) return true;
  }
  return false;
}

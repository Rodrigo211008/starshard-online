// 직업(전직)과 기술. 서버와 클라이언트가 함께 쓴다.
//
// 레벨 10 에 네 갈래 길 가운데 하나를 골라 1차 전직을 하고, 레벨 20 · 30 · 40 에 2 · 3 · 4차 전직을 한다.
// 전직할 때마다 그 길의 기술 하나와 숨은 힘(패시브) 하나가 열린다.
//
// 기술(skill)
//   stat   피해의 바탕: 'atk' 근접 공격력 / 'bow' 활 공격력 (활 기술은 활을 착용해야 쓸 수 있고, 화살은 들지 않는다)
//   mult   한 번 맞을 때의 배율. mult2: 여파(둘째 타격)의 배율 — 그때는 max 가 첫 타격, max2 가 여파에 맞는 적의 수
//   cd     다시 쓰기까지의 시간(초)
//   hits   한 번 쓸 때 서버가 받아 주는 타격 횟수, window: 그 타격들이 들어올 수 있는 시간(ms)
//   max    한 타격에 맞는 적의 수, range: 내 자리에서 맞는 적까지의 거리 한계 (서버가 검사한다)
//   kb     밀어내는 힘, heavy: 휘청이게 한다, critUp: 치명타 확률에 더해지는 값
//   effect 피해가 아닌 효과: 'guard' 곁의 모두가 받는 피해 감소 + 회복 / 'heal' 곁의 모두 회복 / 'hide' 몬스터의 눈을 피한다
// 모양과 연출에 쓰는 값(r, len, half, dash, cast, ticks, every, wind …)은 클라이언트(public/js/skills.js)가 읽는다.

export const JOB_LEVELS = [10, 20, 30, 40];
export const JOB_MAX = 4;
export const JOB_SWITCH_GOLD = 1500; // 다른 길로 옮길 때 드는 골드 (전직 차수마다)
export const WARD_MULT = 0.6; // 「수호의 함성」을 받은 동안 받는 피해

export const JOBS = [
  null, // 0: 아직 길을 고르지 않은 모험가
  {
    key: 'warrior', name: '검사', color: 0xffa24a, css: '#ffb872',
    titles: ['검사', '기사', '수호 기사', '여명의 수호자'],
    desc: '적 한가운데로 뛰어들어 넓게 베고, 단단한 몸으로 친구들을 지킨다.',
    skills: [
      { key: 'whirl', name: '회전 베기', short: '회전', desc: '몸을 돌려 둘레의 적을 모두 벤다', stat: 'atk', mult: 2.6, cd: 6, hits: 1, window: 1200, max: 10, range: 6, kb: 7, heavy: false, r: 4.8 },
      { key: 'charge', name: '돌진 베기', short: '돌진', desc: '앞으로 내달리며 길 위의 적을 모두 베어 넘긴다 (내달리는 동안은 맞지 않는다)', stat: 'atk', mult: 3.2, cd: 9, hits: 1, window: 1500, max: 10, range: 14, kb: 11, heavy: true, dash: 9, len: 10.5, half: 1.8 },
      { key: 'ward', name: '수호의 함성', short: '함성', desc: '8초 동안 나와 곁의 친구들이 받는 피해가 40% 줄고, 체력을 15% 되찾는다', cd: 30, hits: 0, window: 0, effect: 'guard', dur: 8, heal: 0.15, r: 13 },
      { key: 'dawn', name: '여명 가르기', short: '여명', desc: '힘을 모아 빛의 칼날을 내리친다. 앞으로 길게 뻗어 나가며 모두 벤다', stat: 'atk', mult: 9, cd: 26, hits: 1, window: 2000, max: 12, range: 19, kb: 13, heavy: true, len: 16, half: 3, wind: 0.42 },
    ],
    passives: [
      { name: '굳센 몸', desc: '체력 +60', hp: 6 },
      { name: '방패 수련', desc: '방어력 +20%', def: 1.2 },
      { name: '수호자의 각오', desc: '받는 피해 -10%', taken: 0.9 },
      { name: '여명의 힘', desc: '공격력 +12%', atk: 1.12 },
    ],
  },
  {
    key: 'archer', name: '궁수', color: 0x8fe06a, css: '#a8f08a',
    titles: ['궁수', '사냥꾼', '바람 사수', '별빛 명사수'],
    desc: '멀리서 화살을 퍼붓는다. 기술에는 화살이 들지 않지만 활을 착용하고 있어야 한다.',
    skills: [
      { key: 'triple', name: '세 갈래 화살', short: '세갈래', desc: '화살 세 발을 부채꼴로 쏜다', stat: 'bow', mult: 1.3, cd: 5, hits: 3, window: 3800, max: 1, range: 95, kb: 3.5, heavy: false },
      { key: 'pierce', name: '꿰뚫는 화살', short: '관통', desc: '곧게 뻗는 화살이 길 위의 적을 모두 꿰뚫는다', stat: 'bow', mult: 3.6, cd: 8, hits: 1, window: 1500, max: 10, range: 38, kb: 6, heavy: true, len: 32, half: 1.4 },
      { key: 'rain', name: '화살비', short: '화살비', desc: '겨눈 자리에 화살이 비처럼 다섯 번 쏟아진다', stat: 'bow', mult: 1.5, cd: 18, hits: 5, window: 5200, max: 12, range: 34, kb: 1, heavy: false, r: 6.5, cast: 15, ticks: 5, every: 0.5 },
      { key: 'star', name: '별똥 화살', short: '별똥', desc: '별빛을 모아 쏘는 화살. 처음 닿은 적에게 큰 피해를 주고 둘레까지 터진다', stat: 'bow', mult: 10, mult2: 5, cd: 28, hits: 2, window: 3000, max: 1, max2: 10, range: 60, kb: 9, heavy: true, len: 46, r: 6.5, wind: 0.6 },
    ],
    passives: [
      { name: '활 수련', desc: '활 공격력 +12%', bow: 1.12 },
      { name: '매의 눈', desc: '치명타 확률 +6%', crit: 0.06 },
      { name: '바람의 호흡', desc: '기술을 다시 쓰기까지의 시간 -10%', cd: 0.9 },
      { name: '명사수의 숨결', desc: '치명타 피해 +0.4배', critMul: 0.4 },
    ],
  },
  {
    key: 'rogue', name: '도적', color: 0xc08aff, css: '#d0a8ff',
    titles: ['도적', '그림자 칼잡이', '밤의 추적자', '달그림자'],
    desc: '눈 깜짝할 사이에 파고들어 급소를 찌르고 사라진다.',
    skills: [
      { key: 'flurry', name: '연속 찌르기', short: '연속', desc: '눈앞의 적을 다섯 번 잇달아 찌른다', stat: 'atk', mult: 0.8, cd: 5, hits: 5, window: 1800, max: 4, range: 5, kb: 1.5, heavy: false, reach: 3.7, half: 0.95, ticks: 5, every: 0.11 },
      { key: 'step', name: '그림자 걸음', short: '그림자', desc: '적의 등 뒤로 순식간에 옮겨 가 급소를 찌른다 (치명타 확률 +30%). 적이 없으면 앞으로 미끄러진다', stat: 'atk', mult: 3.6, cd: 9, hits: 1, window: 1200, max: 1, range: 20, kb: 4, heavy: true, cast: 15, critUp: 0.3, blink: 8 },
      { key: 'smoke', name: '연막', short: '연막', desc: '독 연막을 터뜨린다. 안의 적은 다섯 번 독에 시달리고, 나는 3.5초 동안 몬스터의 눈에서 사라진다 (던전의 주인은 속지 않는다)', stat: 'atk', mult: 0.8, cd: 20, hits: 5, window: 6500, max: 12, range: 18, kb: 0, heavy: false, r: 6, ticks: 5, every: 1, effect: 'hide', dur: 3.5 },
      { key: 'dance', name: '달그림자 난무', short: '난무', desc: '둘레의 적들 사이를 번개처럼 옮겨 다니며 여섯 번 벤다 (그동안은 맞지 않는다)', stat: 'atk', mult: 2, cd: 26, hits: 6, window: 2400, max: 1, range: 22, kb: 3, heavy: true, cast: 13, ticks: 6, every: 0.14 },
    ],
    passives: [
      { name: '예리한 칼끝', desc: '치명타 확률 +8%', crit: 0.08 },
      { name: '가벼운 발', desc: '이동 속도 +8%', swift: 0.08 },
      { name: '그림자 구르기', desc: '구르기에 드는 기력 -30%', rollCost: 0.7 },
      { name: '급소 찌르기', desc: '치명타 피해 +0.5배', critMul: 0.5 },
    ],
  },
  {
    key: 'mage', name: '별술사', color: 0x7ac0ff, css: '#9ad0ff',
    titles: ['견습 별술사', '별술사', '별무리 현자', '대별술사'],
    desc: '별빛을 다뤄 멀리서 적을 쓰러뜨리고, 친구들의 상처를 낫게 한다.',
    skills: [
      { key: 'bolt', name: '별똥탄', short: '별똥탄', desc: '별빛 덩어리를 날린다. 겨눈 적을 스스로 쫓아간다', stat: 'atk', mult: 2.6, cd: 3, hits: 1, window: 2400, max: 1, range: 40, kb: 4, heavy: false, cast: 28 },
      { key: 'nova', name: '별빛 고리', short: '고리', desc: '별빛이 고리가 되어 퍼져 나가며 둘레의 적을 밀쳐 낸다', stat: 'atk', mult: 2.6, cd: 9, hits: 1, window: 1200, max: 12, range: 9, kb: 11, heavy: true, r: 7 },
      { key: 'heal', name: '치유의 별빛', short: '치유', desc: '나와 곁의 친구들의 체력을 35% 되찾아 준다', cd: 28, hits: 0, window: 0, effect: 'heal', heal: 0.35, r: 13 },
      { key: 'meteor', name: '별무리 낙하', short: '별무리', desc: '겨눈 자리에 별똥이 여섯 번 쏟아진다', stat: 'atk', mult: 2.2, cd: 30, hits: 6, window: 4800, max: 12, range: 36, kb: 5, heavy: true, r: 8, cast: 16, ticks: 6, every: 0.4 },
    ],
    passives: [
      { name: '별의 집중', desc: '기술을 다시 쓰기까지의 시간 -10%', cd: 0.9 },
      { name: '넘치는 기력', desc: '최대 기력 +25', sta: 25 },
      { name: '별빛 가호', desc: '체력 +40', hp: 4 },
      { name: '별의 공명', desc: '기술 피해 +15%', skill: 1.15 },
    ],
  },
];

// 저장이나 프로필로 들어온 값을 다듬는다. 레벨이 모자라면 그만큼 차수를 낮춘다
export function cleanJob(job, level) {
  const c = job && Number.isInteger(job.c) && job.c >= 1 && job.c < JOBS.length ? job.c : 0;
  let t = c && Number.isInteger(job.t) ? Math.max(0, Math.min(JOB_MAX, job.t)) : 0;
  while (t > 0 && level < JOB_LEVELS[t - 1]) t--;
  return { c: t ? c : 0, t };
}

// 그 차수까지 열린 숨은 힘을 모두 합친 값
export function jobStats(job) {
  const o = { hp: 0, sta: 0, def: 1, atk: 1, bow: 1, crit: 0, critMul: 0, taken: 1, swift: 0, rollCost: 1, cd: 1, skill: 1 };
  const J = job && job.t > 0 ? JOBS[job.c] : null;
  if (!J) return o;
  for (let i = 0; i < job.t && i < J.passives.length; i++) {
    const p = J.passives[i];
    if (p.hp) o.hp += p.hp;
    if (p.sta) o.sta += p.sta;
    if (p.def) o.def *= p.def;
    if (p.atk) o.atk *= p.atk;
    if (p.bow) o.bow *= p.bow;
    if (p.crit) o.crit += p.crit;
    if (p.critMul) o.critMul += p.critMul;
    if (p.taken) o.taken *= p.taken;
    if (p.swift) o.swift += p.swift;
    if (p.rollCost) o.rollCost *= p.rollCost;
    if (p.cd) o.cd *= p.cd;
    if (p.skill) o.skill *= p.skill;
  }
  return o;
}

// 이름 옆에 붙는 칭호 ('' 이면 아직 길을 고르지 않았다)
export function jobTitle(job) {
  const J = job && job.t > 0 ? JOBS[job.c] : null;
  return J ? J.titles[Math.min(job.t, J.titles.length) - 1] : '';
}

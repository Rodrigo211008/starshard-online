// 월드의 주요 지점(별조각, 귀환석, 야영지, 상자, 몬스터 출현 지점 등)을 seed 로부터 생성한다.
import { W, OLD_HALF, BIOME, BIOME_INFO, VILLAGE, VOLCANO, ISLES, LANDS, FRONTIER, areaLevel } from '../shared/world.js';
import { rand2 } from '../shared/noise.js';
import { GOLEM_NAMES, NPC_DEFS, SHARD_COUNT, CHAPTERS } from '../shared/defs.js';
import { ZONES } from '../shared/zones.js';

// 세계를 넓히기 전(한가운데 땅만 있던 때)의 배치가 되도록 유지되게, 격자 기준점은 예전 값을 쓰고
// 한가운데 땅(중심에서 MAIN_R 안쪽)을 먼저 예전과 같은 순서로 채운 뒤 바깥 땅을 채운다.
const O = OLD_HALF;
const MAIN_R = 852;
// 울퉁불퉁한 정도를 재는 범위(칸 수). 한 칸이 6m 이므로 한 칸씩만 본다 (둘레 6m)
const RK = 1;
// 격자를 세계 끝까지 넓혔을 때의 칸 번호 범위 (본섬 기준점 -O 에서 세는 칸)
const gridRange = (step) => [Math.floor((-W.HALF + O) / step) - 1, Math.ceil((W.HALF + O) / step) + 1];

export function generatePOIs(world) {
  const seed = world.seed;
  const N = W.VERTS;
  const H = world.heights;
  const patches = [];

  const vx = (i) => -W.HALF + i * W.CELL;

  function rough(i, j, k) {
    const h0 = H[j * N + i];
    let m = 0;
    for (let dj = -k; dj <= k; dj++) {
      for (let di = -k; di <= k; di++) {
        const ii = i + di;
        const jj = j + dj;
        if (ii < 0 || jj < 0 || ii > W.GRID || jj > W.GRID) return 99;
        const d = Math.abs(H[jj * N + ii] - h0);
        if (d > m) m = d;
      }
    }
    return m;
  }

  // 기준점 주변에서 조건에 맞는 격자점을 찾는다. mode: 'high' | 'flat'
  function findSpot(ax, az, radius, mode, minH = 2) {
    const i0 = Math.max(3, Math.floor((ax - radius + W.HALF) / W.CELL));
    const i1 = Math.min(W.GRID - 3, Math.ceil((ax + radius + W.HALF) / W.CELL));
    const j0 = Math.max(3, Math.floor((az - radius + W.HALF) / W.CELL));
    const j1 = Math.min(W.GRID - 3, Math.ceil((az + radius + W.HALF) / W.CELL));
    let best = null;
    let bestScore = -1e9;
    for (let j = j0; j <= j1; j++) {
      for (let i = i0; i <= i1; i++) {
        const x = vx(i);
        const z = vx(j);
        const dx = x - ax;
        const dz = z - az;
        const d = Math.sqrt(dx * dx + dz * dz);
        if (d > radius) continue;
        const h = H[j * N + i];
        if (h < minH) continue;
        let score;
        if (mode === 'high') score = h - d * 0.01;
        else score = -rough(i, j, RK) * 2 - d * 0.02;
        if (score > bestScore) {
          bestScore = score;
          best = { x, z, h, rough: rough(i, j, RK) };
        }
      }
    }
    return best;
  }

  // 특정 바이옴 안쪽(경계에서 떨어진 곳)에서 가장 높은 지점
  function highestInBiome(b) {
    let best = null;
    for (let j = 4; j < W.GRID - 4; j++) {
      for (let i = 4; i < W.GRID - 4; i++) {
        const idx = j * N + i;
        if (world.biome[idx] !== b) continue;
        if (world.biome[idx - 3] !== b || world.biome[idx + 3] !== b || world.biome[idx - 3 * N] !== b || world.biome[idx + 3 * N] !== b) continue;
        const h = H[idx];
        if (!best || h > best.h) best = { x: vx(i), z: vx(j), h, rough: rough(i, j, RK) };
      }
    }
    return best;
  }

  function flatten(x, z, r, f, h) {
    patches.push({ x, z, r, f, h: Math.round(h * 100) / 100 });
  }

  // ---- 마을 & 보스 경기장 ----
  flatten(VILLAGE.x, VILLAGE.z, VILLAGE.r, 24, VILLAGE.h);
  flatten(VOLCANO.x, VOLCANO.z, VOLCANO.arenaR, 4, VOLCANO.floor);

  // ---- 별조각: 장(章)마다 열두 개 ----
  // 1장은 한가운데 땅, 2장은 그 바깥의 열 지역, 3장은 대륙 끝의 네 지역에 흩어진다. 번호는 장 × 12 + 순서
  const shardDefs = [
    // 1장
    { name: '바람 언덕', ax: -120, az: -110, r: 70, mode: 'high', guard: 'none' },
    { name: '호숫가 도깨비 소굴', ax: 165, az: 150, r: 60, mode: 'flat', guard: 'camp', comp: ['goblin', 'goblin', 'goblin', 'thrower'], elite: 'goblin' },
    { name: '깊은 숲의 제단', ax: 600, az: 90, r: 70, mode: 'flat', guard: 'golem', fix: [600, 66] }, // (가장자리 땅이 바뀌어도 예전 자리에 둔다)
    { name: '늑대 언덕', ax: -560, az: -100, r: 70, mode: 'flat', guard: 'camp', comp: ['wolf', 'wolf', 'wolf'], elite: 'wolf' },
    { name: '붉은 탁상지', ax: 120, az: 540, r: 150, mode: 'high', biomeHigh: BIOME.DESERT, guard: 'none' },
    { name: '모래에 묻힌 유적', ax: -70, az: 560, r: 70, mode: 'flat', guard: 'golem' },
    { name: '늪의 심장', ax: -470, az: 330, r: 80, mode: 'flat', guard: 'golem' },
    { name: '말랑이 둥지', ax: -330, az: 470, r: 70, mode: 'flat', guard: 'camp', comp: ['slime', 'slime', 'slime', 'slime'], elite: 'slime' },
    { name: '서리봉 정상', ax: -140, az: -480, r: 260, mode: 'high', guard: 'none' },
    { name: '설인의 야영지', ax: -330, az: -420, r: 80, mode: 'flat', guard: 'camp', comp: ['yeti', 'wolf', 'wolf'], elite: 'yeti' },
    { name: '분화구 가장자리', ax: VOLCANO.x, az: VOLCANO.z, r: 66, mode: 'high', guard: 'camp', comp: ['imp', 'imp', 'imp'], elite: 'imp' },
    { name: '잿더미 제단', ax: 290, az: -250, r: 60, mode: 'flat', guard: 'golem' },
    // 2장: 바깥 네 지역과 먼 여섯 땅
    { name: '꽃비 내리는 언덕', ax: 940, az: 790, r: 60, mode: 'high', guard: 'none', biome: BIOME.BLOSSOM },
    { name: '큰갓버섯 그늘', ax: -940, az: 910, r: 60, mode: 'flat', guard: 'camp', comp: ['slime', 'slime', 'imp', 'imp', 'scorpion'], elite: 'slime', biome: BIOME.MUSHROOM },
    { name: '수정 벼랑', ax: -930, az: -920, r: 70, mode: 'high', guard: 'none', biome: BIOME.CRYSTAL },
    { name: '그림자 제단', ax: 940, az: -910, r: 60, mode: 'flat', guard: 'golem', biome: BIOME.SHADOW },
    { name: '바람 고원의 야영지', ax: 1750, az: 130, r: 100, mode: 'flat', guard: 'camp', comp: ['scorpion', 'scorpion', 'thrower', 'thrower', 'goblin'], elite: 'scorpion', biome: BIOME.CANYON },
    { name: '얼음 송곳 꼭대기', ax: 70, az: -1770, r: 120, mode: 'high', guard: 'none', biome: BIOME.GLACIER },
    { name: '구름 위 다랑이', ax: -1720, az: -130, r: 110, mode: 'high', guard: 'none', biome: BIOME.TERRACE },
    { name: '산호 고리섬', ax: -130, az: 1770, r: 100, mode: 'flat', guard: 'camp', comp: ['slime', 'slime', 'scorpion', 'scorpion', 'thrower'], elite: 'scorpion', biome: BIOME.REEF, minH: 1.8 },
    { name: '구름 위 돌기둥', ax: 1790, az: -1640, r: 110, mode: 'high', guard: 'none', biome: BIOME.PILLARS },
    { name: '안개 바닥의 제단', ax: 1610, az: -1810, r: 80, mode: 'flat', guard: 'golem', biome: BIOME.PILLARS },
    { name: '둘레 산 마루', ax: -1900, az: 1540, r: 80, mode: 'high', guard: 'none', biome: BIOME.CRATER },
    { name: '물결 둔덕의 야영지', ax: -1610, az: 1830, r: 60, mode: 'flat', guard: 'camp', comp: ['imp', 'imp', 'yeti', 'wolf', 'wolf'], elite: 'yeti', biome: BIOME.CRATER },
    // 3장: 대륙 끝의 네 지역
    { name: '외톨이 바위 언덕', ax: -1630, az: 1090, r: 260, mode: 'high', guard: 'none', biome: BIOME.SAVANNA },
    { name: '마른 물길의 야영지', ax: -960, az: 1810, r: 90, mode: 'flat', guard: 'camp', comp: ['goblin', 'goblin', 'thrower', 'thrower', 'wolf', 'wolf'], elite: 'goblin', biome: BIOME.SAVANNA },
    { name: '붉은 바위섬', ax: 1810, az: -960, r: 300, mode: 'high', guard: 'none', biome: BIOME.SALT },
    { name: '소금 거울 한가운데', ax: 960, az: -1810, r: 90, mode: 'flat', guard: 'golem', biome: BIOME.SALT },
    { name: '벼락 맞은 봉우리', ax: -1810, az: -960, r: 130, mode: 'high', guard: 'none', biome: BIOME.STORM },
    { name: '골짜기 길목', ax: -960, az: -1800, r: 100, mode: 'flat', guard: 'camp', comp: ['yeti', 'yeti', 'imp', 'imp', 'wolf', 'wolf'], elite: 'yeti', biome: BIOME.STORM },
    { name: '천둥의 제단', ax: -1590, az: -1820, r: 100, mode: 'flat', guard: 'golem', biome: BIOME.STORM },
    { name: '산맥의 지붕', ax: -1800, az: -1790, r: 110, mode: 'high', guard: 'none', biome: BIOME.STORM },
    { name: '첫 별못', ax: 1790, az: 960, r: 100, mode: 'flat', guard: 'camp', comp: ['imp', 'imp', 'imp', 'goblin', 'goblin', 'thrower'], elite: 'imp', biome: BIOME.GALAXY },
    { name: '수정 언덕', ax: 960, az: 1800, r: 300, mode: 'high', guard: 'none', biome: BIOME.GALAXY },
    { name: '별못 사이의 제단', ax: 1610, az: 1820, r: 90, mode: 'flat', guard: 'golem', biome: BIOME.GALAXY },
    { name: '세상 끝 바닷가', ax: 1900, az: 1700, r: 80, mode: 'high', guard: 'none', biome: BIOME.GALAXY },
  ];
  if (shardDefs.length !== SHARD_COUNT * CHAPTERS) throw new Error('별조각 수가 맞지 않습니다');

  const shards = [];
  const spawns = [];
  const camps = [];
  const chests = [];

  function addSpawn(type, level, x, z, extra = {}) {
    const s = { id: spawns.length, type, level, x: Math.round(x * 10) / 10, z: Math.round(z * 10) / 10, biome: world.biomeAt(x, z), shard: -1, camp: -1, elite: 0, ...extra };
    spawns.push(s);
    return s;
  }

  // 중심 주변 원형으로 배치 (sin/cos 없이 고정 방향 테이블 사용)
  const RING = [
    [1, 0], [0.7071, 0.7071], [0, 1], [-0.7071, 0.7071], [-1, 0], [-0.7071, -0.7071], [0, -1], [0.7071, -0.7071],
    [0.9239, 0.3827], [0.3827, 0.9239], [-0.3827, 0.9239], [-0.9239, 0.3827], [-0.9239, -0.3827], [-0.3827, -0.9239], [0.3827, -0.9239], [0.9239, -0.3827],
  ];

  // 특정 지역 안에서만 자리를 찾는다 (경계 너머의 다른 지역으로 넘어가지 않게)
  function findSpotIn(ax, az, radius, mode, minH, biome) {
    const i0 = Math.max(3, Math.floor((ax - radius + W.HALF) / W.CELL));
    const i1 = Math.min(W.GRID - 3, Math.ceil((ax + radius + W.HALF) / W.CELL));
    const j0 = Math.max(3, Math.floor((az - radius + W.HALF) / W.CELL));
    const j1 = Math.min(W.GRID - 3, Math.ceil((az + radius + W.HALF) / W.CELL));
    let best = null;
    let bestScore = -1e9;
    for (let j = j0; j <= j1; j++) {
      for (let i = i0; i <= i1; i++) {
        const x = vx(i);
        const z = vx(j);
        const d = Math.hypot(x - ax, z - az);
        if (d > radius) continue;
        const idx = j * N + i;
        const h = H[idx];
        if (h < minH || world.biome[idx] !== biome) continue;
        const ro = rough(i, j, RK);
        // 높은 곳: 가장 높은 꼭대기 (제단 자리는 나중에 판판하게 다듬는다) / 판판한 곳: 가장 고른 곳
        const score = mode === 'high' ? h - d * 0.01 : -ro * 2 - d * 0.02;
        if (score > bestScore) {
          bestScore = score;
          best = { x, z, h, rough: ro };
        }
      }
    }
    return best;
  }

  shardDefs.forEach((d, id) => {
    const minH = d.minH || (d.mode === 'flat' ? 2.2 : 2);
    const spot = (d.fix ? { x: d.fix[0], z: d.fix[1], h: world.heightAt(d.fix[0], d.fix[1]) } : null) || (d.biomeHigh !== undefined ? highestInBiome(d.biomeHigh) : null) ||
      (d.biome !== undefined ? findSpotIn(d.ax, d.az, d.r, d.mode, minH, d.biome) || findSpotIn(d.ax, d.az, d.r * 2, d.mode, minH, d.biome) : null) ||
      findSpot(d.ax, d.az, d.r, d.mode, minH) || { x: d.ax, z: d.az, h: 5 };
    const b = world.biomeAt(spot.x, spot.z);
    const lvl = areaLevel(b, spot.x, spot.z) + 1;
    flatten(spot.x, spot.z, d.mode === 'high' ? 6 : 12, d.mode === 'high' ? 8 : 9, spot.h);
    shards.push({ id, ch: Math.floor(id / SHARD_COUNT), name: d.name, x: spot.x, z: spot.z, guard: d.guard, biome: b });
    if (d.guard === 'golem') {
      addSpawn('golem', lvl, spot.x + 6, spot.z + 3, { shard: id, name: GOLEM_NAMES[b] });
    } else if (d.guard === 'camp') {
      d.comp.forEach((type, k) => {
        const dir = RING[(k * 3 + id) % 8];
        addSpawn(type, lvl, spot.x + dir[0] * 7.5, spot.z + dir[1] * 7.5, { shard: id });
      });
      const dir = RING[(id + 5) % 8];
      addSpawn(d.elite, lvl, spot.x + dir[0] * 5, spot.z + dir[1] * 5, { shard: id, elite: 1 });
    }
    chests.push({ id: chests.length, x: spot.x - 3.5, z: spot.z + 3.2, tier: Math.min(4, 1 + Math.floor(lvl / 3)), kind: 'shrine' });
  });

  const far = (x, z, list, dist) => {
    for (const o of list) {
      const dx = x - o.x;
      const dz = z - o.z;
      if (dx * dx + dz * dz < dist * dist) return false;
    }
    return true;
  };

  // ---- 장마다의 마지막 싸움터 ----
  // 1장은 화산 분화구. 2장은 노을 평원, 3장은 세상의 끝 — 둘레가 가장 고른 자리를 골라 판판하게 다듬는다
  const arenas = [{ x: VOLCANO.x, z: VOLCANO.z, r: VOLCANO.arenaR, h: VOLCANO.floor }];
  function findArena(ax, az, radius, biome) {
    let best = null;
    let bestScore = 1e9;
    const i0 = Math.floor((ax - radius + W.HALF) / W.CELL);
    const i1 = Math.ceil((ax + radius + W.HALF) / W.CELL);
    const j0 = Math.floor((az - radius + W.HALF) / W.CELL);
    const j1 = Math.ceil((az + radius + W.HALF) / W.CELL);
    for (let j = j0; j <= j1; j++) {
      for (let i = i0; i <= i1; i++) {
        const idx = j * N + i;
        const h0 = H[idx];
        if (h0 < 4.5 || world.biome[idx] !== biome) continue;
        const x = vx(i);
        const z = vx(j);
        if (!far(x, z, shards, 110)) continue;
        let worst = 0;
        let ok = true;
        for (let k = 0; k < 16 && ok; k++) {
          for (const rr of [12, 24, 34]) {
            const sx = x + RING[k][0] * rr;
            const sz = z + RING[k][1] * rr;
            const h = world.heightAt(sx, sz);
            if (h < 1.5 || world.biomeAt(sx, sz) !== biome) { ok = false; break; }
            const d = Math.abs(h - h0);
            if (d > worst) worst = d;
          }
        }
        if (!ok) continue;
        const score = worst + Math.hypot(x - ax, z - az) * 0.01;
        if (score < bestScore) {
          bestScore = score;
          best = { x, z, h: h0 };
        }
      }
    }
    return best;
  }
  for (const [ax, az, b] of [[-1940, 900, BIOME.SAVANNA], [1716, 1716, BIOME.GALAXY]]) {
    const spot = findArena(ax, az, 110, b) || findArena(ax, az, 220, b) || { x: ax, z: az, h: Math.max(5, world.heightAt(ax, az)) };
    flatten(spot.x, spot.z, 32, 12, spot.h);
    arenas.push({ x: spot.x, z: spot.z, r: 28, h: Math.round(spot.h * 100) / 100 });
  }
  const farArena = (x, z, d) => far(x, z, arenas, d);

  // ---- 귀환석 (빠른 이동) ----
  const stoneDefs = [
    { name: '새벽 마을', ax: 9, az: -15, fixed: true },
    { name: '속삭임 숲', ax: 370, az: 110 },
    { name: '황금 사막', ax: 30, az: 330 },
    { name: '안개 늪', ax: -320, az: 240 },
    { name: '서리봉 기슭', ax: -130, az: -290 },
    { name: '화산 협곡 입구', ax: VOLCANO.x + VOLCANO.notchX * 142, az: VOLCANO.z + VOLCANO.notchZ * 142 },
    { name: '단풍 고원', ax: -420, az: -90 },
  ];
  const stones = [];
  stoneDefs.forEach((d, id) => {
    let spot;
    if (d.fixed) spot = { x: d.ax, z: d.az, h: VILLAGE.h };
    else {
      spot = findSpot(d.ax, d.az, 36, 'flat', 2.5) || { x: d.ax, z: d.az, h: 6 };
      flatten(spot.x, spot.z, 5, 7, spot.h);
    }
    stones.push({ id, name: d.name, x: spot.x, z: spot.z });
  });

  // 바깥 네 지역의 귀환석 (한가운데 땅에서 걸어 들어오는 쪽)
  const ISLE_STONES = ['벚꽃 언덕', '버섯 숲', '수정 고원', '그림자 황무지'];
  ISLES.forEach((q, k) => {
    const d = Math.sqrt(q.x * q.x + q.z * q.z);
    const ax = q.x - (q.x / d) * q.r * 0.45;
    const az = q.z - (q.z / d) * q.r * 0.45;
    const spot = findSpot(ax, az, 46, 'flat', 3) || { x: ax, z: az, h: 6 };
    flatten(spot.x, spot.z, 5, 7, spot.h);
    stones.push({ id: stones.length, name: ISLE_STONES[k], x: spot.x, z: spot.z });
  });

  // 먼 여섯 땅의 귀환석 (걸어 들어오는 쪽)
  LANDS.forEach((q) => {
    const o = q.from < 0 ? { x: 0, z: 0 } : ISLES[q.from];
    const dx = o.x - q.x;
    const dz = o.z - q.z;
    const d = Math.sqrt(dx * dx + dz * dz);
    const ax = q.x + (dx / d) * q.r * 0.52;
    const az = q.z + (dz / d) * q.r * 0.52;
    const spot = findSpot(ax, az, 60, 'flat', 3) || { x: ax, z: az, h: 6 };
    flatten(spot.x, spot.z, 5, 7, spot.h);
    stones.push({ id: stones.length, name: BIOME_INFO[q.b].name, x: spot.x, z: spot.z });
  });

  // 대륙 끝 네 지역의 귀환석 (걸쳐 있는 곳마다 하나씩, 걸어 들어오는 쪽으로 조금 치우친 자리)
  FRONTIER.forEach((q) => {
    const dx = q.from[0] - q.x;
    const dz = q.from[1] - q.z;
    const d = Math.sqrt(dx * dx + dz * dz);
    const ax = q.x + (dx / d) * 150;
    const az = q.z + (dz / d) * 150;
    let spot = null;
    for (const rr of [60, 100, 160, 240]) {
      const c = findSpotIn(ax, az, rr, 'flat', 2, q.b);
      if (c && far(c.x, c.z, shards, 90) && farArena(c.x, c.z, 90)) { spot = c; break; }
    }
    if (!spot) spot = findSpot(ax, az, 90, 'flat', 2) || { x: ax, z: az, h: 6 };
    flatten(spot.x, spot.z, 5, 7, spot.h);
    stones.push({ id: stones.length, name: q.name, x: spot.x, z: spot.z });
  });

  const distVillage = (x, z) => Math.sqrt((x - VILLAGE.x) * (x - VILLAGE.x) + (z - VILLAGE.z) * (z - VILLAGE.z));
  const distVolcano = (x, z) => Math.sqrt((x - VOLCANO.x) * (x - VOLCANO.x) + (z - VOLCANO.z) * (z - VOLCANO.z));
  // 한가운데 땅(예전의 본섬) 바깥인지
  const outer = (x, z) => x * x + z * z > MAIN_R * MAIN_R || world.addedAt(x, z);
  // 한가운데 땅의 귀환석만 (그곳의 배치 판단에는 예전과 같은 목록을 쓴다)
  const mainStones = stones.slice(0, stoneDefs.length);

  // ---- 일반 야영지 ----
  const CAMP_COMP = [
    ['goblin', 'goblin', 'goblin', 'thrower'],
    ['goblin', 'goblin', 'goblin', 'thrower', 'thrower'],
    ['yeti', 'wolf', 'wolf', 'wolf'],
    ['goblin', 'goblin', 'scorpion', 'scorpion', 'thrower'],
    ['goblin', 'goblin', 'thrower', 'thrower', 'slime', 'slime'],
    ['imp', 'imp', 'imp', 'imp'],
    ['goblin', 'goblin', 'wolf', 'wolf', 'thrower'],
    ['goblin', 'goblin', 'wolf', 'wolf', 'thrower', 'thrower'],
    ['slime', 'slime', 'slime', 'imp', 'imp', 'thrower'],
    ['yeti', 'yeti', 'wolf', 'wolf', 'imp'],
    ['imp', 'imp', 'imp', 'yeti', 'wolf', 'wolf'],
    // 먼 여섯 땅
    ['scorpion', 'scorpion', 'scorpion', 'thrower', 'thrower', 'goblin'], // 바람 협곡
    ['yeti', 'yeti', 'yeti', 'wolf', 'wolf', 'wolf'], // 얼음 호수
    ['goblin', 'goblin', 'goblin', 'thrower', 'thrower', 'wolf', 'wolf'], // 거인의 계단
    ['slime', 'slime', 'slime', 'scorpion', 'scorpion', 'thrower'], // 산호 군도
    ['imp', 'imp', 'thrower', 'thrower', 'yeti', 'yeti'], // 하늘 기둥
    ['imp', 'imp', 'imp', 'yeti', 'yeti', 'wolf', 'wolf'], // 별똥 분지
    // 대륙 끝의 네 지역
    ['goblin', 'goblin', 'goblin', 'thrower', 'thrower', 'wolf', 'wolf'], // 노을 평원
    ['scorpion', 'scorpion', 'scorpion', 'imp', 'imp', 'thrower', 'thrower'], // 거울 소금밭
    ['yeti', 'yeti', 'yeti', 'imp', 'imp', 'wolf', 'wolf'], // 천둥 산맥
    ['imp', 'imp', 'imp', 'yeti', 'yeti', 'goblin', 'goblin', 'thrower'], // 은하수 들판
  ];
  const CSTEP = 150;
  // pass 0: 한가운데 땅 (예전과 같은 칸, 같은 순서), pass 1: 그 바깥
  const placeCamps = (pass) => {
    const [g0, g1] = pass ? gridRange(CSTEP) : [0, 11];
    for (let gz = g0; gz < g1; gz++) {
      for (let gx = g0; gx < g1; gx++) {
        if (rand2(gx, gz, seed + 301) > (pass ? 0.84 : 0.6)) continue; // (대륙이 넓어진 만큼 바깥은 조금 성기게)
        const ax = -O + (gx + 0.2 + 0.6 * rand2(gx, gz, seed + 302)) * CSTEP - 25;
        const az = -O + (gz + 0.2 + 0.6 * rand2(gx, gz, seed + 303)) * CSTEP - 25;
        const spot = findSpot(ax, az, 34, 'flat', 2.5);
        if (!spot || spot.rough > 3.2) continue;
        if (outer(spot.x, spot.z) !== !!pass) continue;
        if (distVillage(spot.x, spot.z) < 170) continue;
        if (distVolcano(spot.x, spot.z) < 75) continue;
        if (!far(spot.x, spot.z, shards, 90) || !far(spot.x, spot.z, pass ? stones : mainStones, 60) || !far(spot.x, spot.z, camps, pass ? 130 : 150)) continue;
        if (pass && !farArena(spot.x, spot.z, 90)) continue;
        const b = world.biomeAt(spot.x, spot.z);
        const lvl = areaLevel(b, spot.x, spot.z);
        const id = camps.length;
        flatten(spot.x, spot.z, 8, 8, spot.h);
        camps.push({ id, x: spot.x, z: spot.z, biome: b });
        CAMP_COMP[b].forEach((type, k) => {
          const dir = RING[(k * 2 + id * 3) % 16];
          // 바깥 땅의 야영지는 우두머리가 이끈다
          addSpawn(type, lvl, spot.x + dir[0] * 6.5, spot.z + dir[1] * 6.5, { camp: id, elite: pass && k === 0 ? 1 : 0 });
        });
        chests.push({ id: chests.length, x: spot.x + 2.8, z: spot.z - 2.4, tier: Math.min(4, 1 + Math.floor(lvl / 3)), kind: 'camp' });
      }
    }
  };

  // ---- 들판의 보물상자 ----
  const XSTEP = 100;
  const placeChests = (pass) => {
    const [g0, g1] = pass ? gridRange(XSTEP) : [0, 16];
    for (let gz = g0; gz < g1; gz++) {
      for (let gx = g0; gx < g1; gx++) {
        if (rand2(gx, gz, seed + 311) > (pass ? 0.3 : 0.36)) continue;
        const x = -O + (gx + 0.1 + 0.8 * rand2(gx, gz, seed + 312)) * XSTEP;
        const z = -O + (gz + 0.1 + 0.8 * rand2(gx, gz, seed + 313)) * XSTEP;
        if (outer(x, z) !== !!pass) continue;
        const h = world.heightAt(x, z);
        if (h < (pass ? lowest(world.biomeAt(x, z)) : 1.3) || world.slopeAt(x, z) > 0.45) continue;
        if (distVillage(x, z) < 110 || distVolcano(x, z) < 60) continue;
        if (!far(x, z, shards, 25) || !far(x, z, pass ? stones : mainStones, 15) || !far(x, z, camps, 25)) continue;
        if (pass && !farArena(x, z, 46)) continue;
        const lvl = areaLevel(world.biomeAt(x, z), x, z);
        chests.push({ id: chests.length, x: Math.round(x * 10) / 10, z: Math.round(z * 10) / 10, tier: Math.min(4, 1 + Math.floor(lvl / 3)), kind: 'wild' });
      }
    }
  };

  // ---- 회복 열매 덤불 ----
  const bushes = [];
  const BSTEP = 52;
  const BG = Math.floor((2 * O) / BSTEP);
  const placeBushes = (pass) => {
    const [g0, g1] = pass ? gridRange(BSTEP) : [0, BG];
    for (let gz = g0; gz < g1; gz++) {
      for (let gx = g0; gx < g1; gx++) {
        if (rand2(gx, gz, seed + 321) > (pass ? 0.22 : 0.34)) continue;
        const x = -O + (gx + 0.1 + 0.8 * rand2(gx, gz, seed + 322)) * BSTEP;
        const z = -O + (gz + 0.1 + 0.8 * rand2(gx, gz, seed + 323)) * BSTEP;
        if (outer(x, z) !== !!pass) continue;
        const h = world.heightAt(x, z);
        if (h < (pass ? 2.4 : 1.2) || world.slopeAt(x, z) > 0.5) continue;
        const b = world.biomeAt(x, z);
        if (b === BIOME.VOLCANO || b === BIOME.SNOW || b === BIOME.SHADOW || b === BIOME.CRYSTAL || b === BIOME.GLACIER || b === BIOME.PILLARS || b === BIOME.CRATER || b === BIOME.CANYON || b === BIOME.SALT || b === BIOME.STORM) {
          if (rand2(gx, gz, seed + 324) > 0.3) continue;
        }
        if (distVillage(x, z) < 50) continue;
        if (!far(x, z, shards, 10) || !far(x, z, pass ? stones : mainStones, 6) || !far(x, z, camps, 10)) continue;
        if (pass && !farArena(x, z, 44)) continue;
        bushes.push({ id: bushes.length, x: Math.round(x * 10) / 10, z: Math.round(z * 10) / 10 });
      }
    }
  };

  // ---- 들판의 몬스터 ----
  const TABLE = {
    [BIOME.MEADOW]: [['slime', 0.62, 1, 3], ['goblin', 0.28, 1, 2], ['thrower', 0.1, 1, 1]],
    [BIOME.FOREST]: [['wolf', 0.38, 2, 3], ['goblin', 0.3, 1, 2], ['thrower', 0.14, 1, 1], ['slime', 0.18, 2, 3]],
    [BIOME.AUTUMN]: [['wolf', 0.36, 2, 3], ['goblin', 0.36, 1, 3], ['thrower', 0.14, 1, 2], ['slime', 0.14, 2, 3]],
    [BIOME.DESERT]: [['scorpion', 0.52, 1, 2], ['goblin', 0.26, 1, 2], ['thrower', 0.22, 1, 2]],
    [BIOME.SWAMP]: [['slime', 0.5, 2, 4], ['thrower', 0.2, 1, 2], ['goblin', 0.3, 1, 2]],
    [BIOME.SNOW]: [['wolf', 0.45, 2, 3], ['yeti', 0.25, 1, 1], ['slime', 0.3, 2, 3]],
    [BIOME.VOLCANO]: [['imp', 0.5, 1, 2], ['slime', 0.3, 2, 3], ['goblin', 0.2, 1, 2]],
    [BIOME.BLOSSOM]: [['wolf', 0.3, 2, 3], ['goblin', 0.3, 2, 3], ['thrower', 0.2, 1, 2], ['slime', 0.2, 2, 4]],
    [BIOME.MUSHROOM]: [['slime', 0.4, 3, 5], ['imp', 0.3, 1, 3], ['scorpion', 0.3, 1, 2]],
    [BIOME.CRYSTAL]: [['yeti', 0.3, 1, 2], ['wolf', 0.35, 2, 4], ['imp', 0.35, 2, 3]],
    [BIOME.SHADOW]: [['imp', 0.35, 2, 4], ['wolf', 0.3, 3, 4], ['yeti', 0.2, 1, 2], ['goblin', 0.15, 2, 3]],
    [BIOME.CANYON]: [['scorpion', 0.45, 2, 4], ['thrower', 0.3, 2, 3], ['goblin', 0.25, 2, 4]],
    [BIOME.GLACIER]: [['wolf', 0.4, 3, 5], ['yeti', 0.4, 1, 3], ['imp', 0.2, 2, 3]],
    [BIOME.TERRACE]: [['goblin', 0.4, 3, 4], ['thrower', 0.25, 2, 3], ['wolf', 0.35, 3, 4]],
    [BIOME.REEF]: [['slime', 0.45, 3, 5], ['scorpion', 0.35, 2, 3], ['thrower', 0.2, 2, 3]],
    [BIOME.PILLARS]: [['imp', 0.4, 3, 4], ['yeti', 0.3, 2, 3], ['thrower', 0.3, 2, 3]],
    [BIOME.CRATER]: [['imp', 0.35, 3, 5], ['yeti', 0.3, 2, 3], ['wolf', 0.35, 3, 5]],
    [BIOME.SAVANNA]: [['wolf', 0.4, 3, 5], ['scorpion', 0.3, 2, 4], ['thrower', 0.15, 2, 3], ['goblin', 0.15, 3, 4]],
    [BIOME.SALT]: [['scorpion', 0.4, 2, 4], ['slime', 0.3, 3, 5], ['imp', 0.3, 2, 4]],
    [BIOME.STORM]: [['yeti', 0.35, 2, 3], ['imp', 0.35, 3, 4], ['wolf', 0.3, 3, 5]],
    [BIOME.GALAXY]: [['imp', 0.3, 3, 5], ['yeti', 0.25, 2, 3], ['slime', 0.2, 3, 5], ['goblin', 0.25, 3, 5]],
  };
  // 바깥 땅에서 몬스터와 보물이 놓일 수 있는 가장 낮은 높이 (얼음 호수의 얼음판, 산호 군도의 작은 섬, 소금 벌판에도 놓인다)
  const lowest = (b) => (b === BIOME.GLACIER ? 0.6 : b === BIOME.REEF ? 1.5 : b === BIOME.SALT ? 1.7 : b === BIOME.SWAMP ? 0.9 : 2.4);
  const SSTEP = 56;
  const SG = Math.floor((2 * O) / SSTEP);
  const placeMobs = (pass) => {
    const [g0, g1] = pass ? gridRange(SSTEP) : [0, SG];
    for (let gz = g0; gz < g1; gz++) {
      for (let gx = g0; gx < g1; gx++) {
        if (rand2(gx, gz, seed + 331) > (pass ? 0.42 : 0.5)) continue;
        const x = -O + (gx + 0.15 + 0.7 * rand2(gx, gz, seed + 332)) * SSTEP;
        const z = -O + (gz + 0.15 + 0.7 * rand2(gx, gz, seed + 333)) * SSTEP;
        if (outer(x, z) !== !!pass) continue;
        const h = world.heightAt(x, z);
        const b = world.biomeAt(x, z);
        // 물가의 낮은 땅에는 몬스터를 두지 않는다
        if (h < (pass ? lowest(b) + 0.2 : b === BIOME.SWAMP ? 0.5 : 1.2) || world.slopeAt(x, z) > 0.6) continue;
        const dv = distVillage(x, z);
        if (dv < 100 || distVolcano(x, z) < 62) continue;
        if (!far(x, z, shards, 34) || !far(x, z, pass ? stones : mainStones, 30) || !far(x, z, camps, 36)) continue;
        if (pass && !farArena(x, z, 70)) continue;
        const table = TABLE[b];
        let pick = rand2(gx, gz, seed + 334);
        let entry = table[0];
        for (const e of table) {
          if (pick < e[1]) { entry = e; break; }
          pick -= e[1];
        }
        let type = entry[0];
        let lvl = areaLevel(b, x, z) + (rand2(gx, gz, seed + 335) < 0.35 ? 1 : 0);
        if (b === BIOME.MEADOW && dv < 230) { type = 'slime'; lvl = 1; }
        const cnt = entry[2] + Math.floor(rand2(gx, gz, seed + 336) * (entry[3] - entry[2] + 1));
        // 바깥 땅에서는 가끔 우두머리가 무리를 이끈다
        const lead = pass && rand2(gx, gz, seed + 337) < 0.14;
        for (let k = 0; k < cnt; k++) {
          const dir = RING[(((k * 5 + gx + gz * 3) % 16) + 16) % 16];
          const rr = k === 0 ? 0 : 3.2;
          const sx = x + dir[0] * rr;
          const sz = z + dir[1] * rr;
          if (world.heightAt(sx, sz) < 0.5) continue;
          addSpawn(type, lvl, sx, sz, lead && k === 0 ? { elite: 1 } : {});
        }
      }
    }
  };

  // 한가운데 땅을 먼저 예전과 같은 순서로 다 채운 다음에 그 바깥을 채운다
  for (let pass = 0; pass < 2; pass++) {
    placeCamps(pass);
    placeChests(pass);
    placeBushes(pass);
    placeMobs(pass);
  }

  // ---- 바깥 네 지역의 수호자 (별조각과 상관없이 그 지역 가운데를 지킨다) ----
  ISLES.forEach((q) => {
    const spot = findSpot(q.x, q.z, 70, 'flat', 4) || { x: q.x, z: q.z, h: 8 };
    flatten(spot.x, spot.z, 10, 9, spot.h);
    addSpawn('golem', BIOME_INFO[q.b].level + 2, spot.x, spot.z, { name: GOLEM_NAMES[q.b] });
    chests.push({ id: chests.length, x: spot.x - 4.5, z: spot.z + 4, tier: 4, kind: 'camp' });
  });

  // ---- 먼 여섯 땅의 수호자 (땅 한가운데 근처) ----
  LANDS.forEach((q) => {
    const spot = findSpot(q.x, q.z, 110, 'flat', 3) || { x: q.x, z: q.z, h: 8 };
    flatten(spot.x, spot.z, 10, 9, spot.h);
    addSpawn('golem', BIOME_INFO[q.b].level + 2, spot.x, spot.z, { name: GOLEM_NAMES[q.b] });
    chests.push({ id: chests.length, x: spot.x - 4.5, z: spot.z + 4, tier: 4, kind: 'camp' });
  });

  // ---- 대륙 끝 네 지역의 수호자 (걸쳐 있는 곳마다 하나씩) ----
  FRONTIER.forEach((q) => {
    const spot = findSpotIn(q.x, q.z, 120, 'flat', 3, q.b) || findSpot(q.x, q.z, 120, 'flat', 3) || { x: q.x, z: q.z, h: 8 };
    if (!far(spot.x, spot.z, shards, 40) || !far(spot.x, spot.z, stones, 30) || !farArena(spot.x, spot.z, 80)) return;
    flatten(spot.x, spot.z, 10, 9, spot.h);
    addSpawn('golem', areaLevel(q.b, spot.x, spot.z) + 2, spot.x, spot.z, { name: GOLEM_NAMES[q.b] });
    chests.push({ id: chests.length, x: spot.x - 4.5, z: spot.z + 4, tier: 4, kind: 'camp' });
  });

  // ---- 시련장과 던전의 입구 ----
  // 시련장은 눈에 띄는 곳에, 던전은 외진 곳에 숨겨 둔다 (주변의 돌등을 모두 밝혀야 문이 드러난다)
  const zones = [];
  const used = [];
  const farFrom = (list, x, z, r) => {
    for (const o of list) {
      const dx = o.x - x;
      const dz = o.z - z;
      if (dx * dx + dz * dz < r * r) return false;
    }
    return true;
  };
  // 다른 시설과 겹치지 않는지
  const clearOf = (x, z, pad) =>
    farFrom(shards, x, z, 18 + pad) && farFrom(stones, x, z, 10 + pad) && farFrom(camps, x, z, 15 + pad) && farFrom(chests, x, z, 4 + pad) &&
    farFrom(bushes, x, z, 2.5 + pad) && farFrom(used, x, z, 9 + pad) && farFrom([VILLAGE], x, z, 56 + pad) && farFrom(arenas, x, z, VOLCANO.arenaR + 12 + pad);
  // 기준점 둘레에서 평평하고 물에 잠기지 않으며 다른 시설과 겹치지 않는 자리
  function findClear(ax, az, radius, minH, maxRough, pad, biome = -1) {
    const i0 = Math.max(3, Math.floor((ax - radius + W.HALF) / W.CELL));
    const i1 = Math.min(W.GRID - 3, Math.ceil((ax + radius + W.HALF) / W.CELL));
    const j0 = Math.max(3, Math.floor((az - radius + W.HALF) / W.CELL));
    const j1 = Math.min(W.GRID - 3, Math.ceil((az + radius + W.HALF) / W.CELL));
    let best = null;
    let bestScore = -1e9;
    for (let j = j0; j <= j1; j++) {
      for (let i = i0; i <= i1; i++) {
        const x = vx(i);
        const z = vx(j);
        const d = Math.hypot(x - ax, z - az);
        if (d > radius) continue;
        const h = H[j * N + i];
        if (h < minH || (biome >= 0 && world.biome[j * N + i] !== biome)) continue;
        const ro = rough(i, j, RK);
        if (ro > maxRough || !clearOf(x, z, pad)) continue;
        const score = -ro * 2 - d * 0.02;
        if (score > bestScore) {
          bestScore = score;
          best = { x, z, h };
        }
      }
    }
    return best;
  }
  for (const zd of ZONES) {
    const [ax, az] = zd.anchor;
    const trial = zd.kind !== 'dungeon'; // 시련장과 레이드의 문은 눈에 띄는 곳에 선다
    // 되도록 그 지역 안의 평평한 곳에 놓는다 (산처럼 험한 곳은 조금 더 넓게, 덜 까다롭게 찾는다)
    const tower = zd.kind === 'tower';
    const zb = zd.biome === undefined ? zd.theme : zd.biome; // 입구가 놓이는 지역
    const spot =
      (tower ? findClear(ax, az, 70, 3, 2.5, 16, zb) || findClear(ax, az, 110, 3, 4, 14, zb) : null) ||
      findClear(ax, az, trial ? 50 : 70, 3, 2.5, 4, zb) || findClear(ax, az, 90, 3, 5, 3, zb) || findClear(ax, az, 140, 2.5, 7, 2, zb) ||
      findClear(ax, az, 160, 2.5, 7, 2) || { x: ax, z: az, h: Math.max(3, world.heightAt(ax, az)) };
    flatten(spot.x, spot.z, 6, 7, spot.h);
    used.push({ x: spot.x, z: spot.z });
    // 별의 탑은 문 뒤로 커다란 몸통이 서 있다: 그 자리까지 판판하게 다듬고 비워 둔다
    if (tower) {
      flatten(spot.x, spot.z - 7.5, 12, 8, spot.h);
      used.push({ x: spot.x, z: spot.z - 7.5 }, { x: spot.x, z: spot.z - 14 });
    }
    const lamps = [];
    for (let k = 0; k < zd.lamps; k++) {
      // 입구 둘레 28~56m 에 흩어 놓는다. 물이나 비탈이면 방향과 거리를 조금씩 바꿔 가며 다시 찾는다.
      const base = Math.floor((k * 16) / zd.lamps) + (zd.id % 2);
      const rr = 30 + ((k * 37 + zd.id * 11) % 26);
      let ls = null;
      for (let t = 0; t < 30 && !ls; t++) {
        const dir = RING[(((base + [0, 1, -1, 2, -2][t % 5]) % 16) + 16) % 16];
        const r2 = [rr, 36, 46, 30, 54, 40][Math.floor(t / 5)];
        const c = findClear(spot.x + dir[0] * r2, spot.z + dir[1] * r2, 9, 2, t < 15 ? 2.2 : 5, 1);
        if (c && Math.hypot(c.x - spot.x, c.z - spot.z) > 24 && farFrom(lamps, c.x, c.z, 16)) ls = c;
      }
      if (!ls) {
        const lx = spot.x + RING[base % 16][0] * rr;
        const lz = spot.z + RING[base % 16][1] * rr;
        ls = { x: lx, z: lz, h: Math.max(2.5, world.heightAt(lx, lz)) };
      }
      flatten(ls.x, ls.z, 2.2, 3, ls.h);
      lamps.push({ x: ls.x, z: ls.z });
      used.push({ x: ls.x, z: ls.z });
    }
    zones.push({ id: zd.id, x: spot.x, z: spot.z, lamps, ...(tower ? { tower: 1 } : {}) });
    // 구역 안의 몬스터 (관문 무리)
    for (const sp of zd.spawns) {
      addSpawn(sp.type, sp.level, sp.x, sp.z, { biome: sp.biome === undefined ? zd.theme : sp.biome, zone: zd.id, group: sp.group, elite: sp.elite, boss: sp.boss && zd.kind !== 'trial' ? 1 : 0, minion: sp.minion });
    }
  }

  // ---- 히든 탈것이 사는 곳: 그 지역에서 다른 시설과 가장 멀리 떨어진 평평한 자리 ----
  const mounts = [];
  // (땅이 이어지며 지역이 넓어졌지만, 말들은 예전에 살던 곳 — 한가운데 땅과 그림자 황무지의 옛 터 — 을 떠나지 않는다)
  const SHADE_HOME = ISLES.find((q) => q.b === BIOME.SHADOW);
  // 예전부터 살던 자리 (기본 세계에서는 그대로 둔다. 다른 씨앗의 세계에서는 아래에서 새로 찾는다)
  const MOUNT_HOME = { ember: [384, -120], frost: [-108, -480], shade: [1032, -768] };
  for (const [k, biome] of [['ember', 5], ['frost', 2], ['shade', 10]]) {
    const others = [...shards, ...stones, ...camps, ...used, VILLAGE];
    let best = null;
    let bd = -1;
    {
      const [hx, hz] = MOUNT_HOME[k];
      const idx = world.vertIndex(hx, hz);
      if (world.biome[idx] === biome && H[idx] >= 4 && rough(Math.round((hx + W.HALF) / W.CELL), Math.round((hz + W.HALF) / W.CELL), RK) <= 2.4 && clearOf(hx, hz, 8)) {
        best = { x: hx, z: hz, h: H[idx] };
        bd = Infinity;
      }
    }
    for (let j = 6; j < W.GRID - 6 && bd < Infinity; j += 2) {
      for (let i = 6; i < W.GRID - 6; i += 2) {
        const idx = j * N + i;
        if (world.biome[idx] !== biome || H[idx] < 4 || rough(i, j, RK) > 2.4) continue;
        const x = vx(i);
        const z = vx(j);
        if (biome === BIOME.SHADOW ? Math.hypot(x - SHADE_HOME.x, z - SHADE_HOME.z) > SHADE_HOME.r * 0.9 : outer(x, z)) continue;
        if (!clearOf(x, z, 8)) continue;
        let dmin = Infinity;
        for (const o of others) dmin = Math.min(dmin, Math.hypot(o.x - x, o.z - z));
        if (dmin > bd) {
          bd = dmin;
          best = { x, z, h: H[idx] };
        }
      }
    }
    if (!best) continue;
    flatten(best.x, best.z, 5, 6, best.h);
    mounts.push({ k, x: best.x, z: best.z });
    used.push({ x: best.x, z: best.z });
  }

  // ---- 바람 정령 하늬가 노니는 곳: 마을 북쪽, 「바람 언덕」으로 가는 길목의 평평한 풀밭 ----
  // 술래잡기를 하며 옮겨 다닐 자리들도 함께 정해 둔다 (물이나 비탈은 피한다)
  let sprite = null;
  {
    // 몬스터가 어슬렁거리지 않는 조용한 자리를 고른다
    const AX = -70;
    const AZ = -112;
    let base = null;
    let bs = -1e9;
    for (let j = Math.floor((AZ - 70 + W.HALF) / W.CELL); j <= Math.ceil((AZ + 70 + W.HALF) / W.CELL); j++) {
      for (let i = Math.floor((AX - 70 + W.HALF) / W.CELL); i <= Math.ceil((AX + 70 + W.HALF) / W.CELL); i++) {
        const idx = j * N + i;
        const x = vx(i);
        const z = vx(j);
        if (H[idx] < 3 || world.biome[idx] !== 0 || rough(i, j, RK) > 2.2 || !clearOf(x, z, 6)) continue;
        let dmin = 60;
        for (const sp of spawns) if (!sp.zone) dmin = Math.min(dmin, Math.hypot(sp.x - x, sp.z - z));
        const score = dmin - Math.hypot(x - AX, z - AZ) * 0.12 - rough(i, j, RK) * 3;
        if (score > bs) {
          bs = score;
          base = { x, z, h: H[idx] };
        }
      }
    }
    if (!base) base = { x: AX, z: AZ, h: Math.max(3, world.heightAt(AX, AZ)) };
    used.push({ x: base.x, z: base.z });
    const spots = [];
    for (let k = 0; k < 16 && spots.length < 6; k++) {
      const dir = RING[(k * 5 + 3) % 16];
      const rr = 15 + ((k * 7) % 12);
      const c = findClear(base.x + dir[0] * rr, base.z + dir[1] * rr, 6, 2.5, 3.5, 1);
      if (c && Math.hypot(c.x - base.x, c.z - base.z) > 9 && farFrom(spots, c.x, c.z, 9)) spots.push({ x: c.x, z: c.z });
    }
    for (let k = 0; spots.length < 5; k++) {
      // 마땅한 자리가 모자라면 둘레에 고르게 놓는다
      const a = (k / 5) * Math.PI * 2;
      spots.push({ x: +(base.x + Math.sin(a) * 16).toFixed(1), z: +(base.z + Math.cos(a) * 16).toFixed(1) });
    }
    sprite = { x: base.x, z: base.z, spots };
  }

  // ---- NPC ----
  const npcs = [];
  for (const kind of Object.keys(NPC_DEFS)) {
    const d = NPC_DEFS[kind];
    npcs.push({ id: npcs.length, kind, name: d.name, x: VILLAGE.x + d.x, z: VILLAGE.z + d.z, yaw: d.yaw });
  }
  // 각 귀환석 옆의 길잡이
  const GUIDE_NAMES = ['', '나무꾼 솔', '상인 모래', '약초꾼 이끼', '산지기 눈솔', '탐험가 불씨', '사냥꾼 단풍', '꽃지기 나래', '버섯꾼 포자', '세공사 유리', '방랑자 그늘',
    '길잡이 돌개', '얼음낚시꾼 고드름', '농부 다랑', '어부 물결', '등반가 솟대', '별지기 유성',
    '풀베기꾼 노을', '몰이꾼 갈기', '소금꾼 하양', '거울지기 비침', '번개잡이 우레', '바위꾼 벼락', '산지기 먹구름', '별못지기 미리내', '꽃지기 샛별', '끝지기 가온'];
  for (let i = 1; i < stones.length; i++) {
    npcs.push({ id: npcs.length, kind: 'guide', name: GUIDE_NAMES[i], x: stones[i].x + 3.2, z: stones[i].z + 1.5, yaw: 4.2, stone: i });
  }

  // 장마다의 마지막 상대와 그 부하들 (평소에는 잠들어 있다). arena: 몇 번째 싸움터인지
  const BOSSES = [
    { type: 'lord', level: 14, adds: ['slime', 'imp'], addLevel: 12 },
    { type: 'dragon', level: 46, adds: ['wolf', 'scorpion'], addLevel: 44 },
    { type: 'blacksun', level: 99, adds: ['imp', 'yeti'], addLevel: 96 },
  ];
  const bossIds = [];
  const minionIds = [];
  BOSSES.forEach((bd, ch) => {
    const A = arenas[ch];
    bossIds.push(addSpawn(bd.type, bd.level, A.x, A.z - 8, { boss: 1, arena: ch }).id);
    const list = [];
    for (let k = 0; k < 6; k++) {
      const dir = RING[(k * 3) % 16];
      list.push(addSpawn(bd.adds[k % 2], bd.addLevel, A.x + dir[0] * 14, A.z + dir[1] * 14, { minion: 1, arena: ch }).id);
    }
    minionIds.push(list);
  });

  return {
    village: { x: VILLAGE.x, z: VILLAGE.z },
    arena: { x: VOLCANO.x, z: VOLCANO.z, r: VOLCANO.arenaR },
    arenas,
    patches,
    shards,
    stones,
    camps,
    chests,
    bushes,
    spawns,
    npcs,
    zones,
    mounts,
    sprite,
    bossId: bossIds[0],
    bossIds,
    minionIds,
  };
}

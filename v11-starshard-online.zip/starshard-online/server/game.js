// 게임 월드 상태와 규칙 (플레이어 동기화, 몬스터 AI, 별조각/보스 진행)
import fs from 'node:fs';
import path from 'node:path';
import { createWorld, exclusionsFor, W, VOLCANO, VILLAGE } from '../shared/world.js';
import { generatePOIs } from './pois.js';
import {
  MON, MON_TYPES, MSTATE, ANIM, TICK_MS, MAX_PLAYERS, SHARD_COUNT, CHAPTERS, MAX_LEVEL,
  monStats, cycleScale, loopOf, chapterOf, TUNIC_COLORS, HAIR_COLORS,
  WEAPONS, SLOTS, slotOf, cleanItem, gearStats, makeItem, MOUNT_COLORS, xpNeed,
  MOUNTS, MOUNT_KEYS, POTIONS, POWER_MULT, CHARGE_BONUS, isRiding, PVP_SCALE, PVP_CAP, PVP_SAFE_R, RAID,
} from '../shared/defs.js';
import { JOBS, cleanJob, jobTitle } from '../shared/jobs.js';
import * as P from '../shared/proto.js';
import {
  ZONES, TILE, zoneIdAt, zoneBlocked, zoneSolid, zoneTorchHit, zoneTough,
  TOWER, towerLevel, towerBossFloor, towerStartOk, towerHpK, towerDmgK, towerBossHp, towerBossDmg,
} from '../shared/zones.js';

const ACTIVE_R = 105; // 이 거리 안에 플레이어가 있어야 몬스터가 움직인다
const VIEW_R = 120; // 스냅샷에 포함되는 거리
const ZONE_RESET_MS = +process.env.ZONE_RESET_MS || 40000; // 시련장·던전이 비고 나서 처음 상태로 돌아가기까지
const SAFE_R = 62; // 마을 안전 구역
const PVP_PROTECT_MS = 5000; // 다시 일어난 뒤 결투 공격을 받지 않는 시간
const TAU = Math.PI * 2;
// 먼 땅 던전의 주인과 레이드 보스의 박자. gap: 공격 사이의 틈(체력 단계별), rec: 공격 뒤의 빈틈, speed: 걸음 배율, barrage: 한 번에 던지는 수
const BOSS2 = {
  empress: { gap: [1400, 1000, 620], rec: 480, speed: [1, 1.2, 1.4], barrage: [5, 7, 9], proj: 'rock', phase: [0.6, 0.3] },
  tidelord: { gap: [1300, 900, 560], rec: 520, speed: [1, 1.15, 1.3], barrage: [7, 9, 11], proj: 'fire', phase: [0.6, 0.3] },
  starborn: { gap: [1100, 760, 430], rec: 400, speed: [1, 1.25, 1.45], barrage: [7, 9, 11], proj: 'fire', phase: [0.6, 0.3] },
  devourer: { gap: [1700, 1300, 900], rec: 600, speed: [1, 1.15, 1.3], barrage: [7, 9, 11], proj: 'fire', phase: [0.7, 0.35] },
  // 2장 · 3장의 마지막 상대 (들판의 싸움터)
  dragon: { gap: [1500, 1100, 700], rec: 520, speed: [1, 1.2, 1.4], barrage: [7, 9, 11], proj: 'fire', phase: [0.6, 0.3] },
  blacksun: { gap: [1300, 950, 600], rec: 460, speed: [1, 1.15, 1.35], barrage: [9, 11, 13], proj: 'fire', phase: [0.65, 0.3] },
};
// 장마다의 마지막 상대: 쓰러뜨렸을 때의 경험치, 함께하는 사람이 한 명 늘 때마다 불어나는 체력
const FINALS = [
  { xp: 2500, addHp: 3000 },
  { xp: 30000, addK: 0.5 },
  { xp: 150000, addK: 0.5 },
];
const ARENA_IDLE_MS = 12000; // 싸움터가 비고 나서 보스가 체력을 되찾기까지

const dist = (ax, az, bx, bz) => Math.hypot(ax - bx, az - bz);
const clampInt = (v, a, b) => {
  v = Number(v);
  if (!Number.isFinite(v)) return a;
  v = Math.floor(v);
  return v < a ? a : v > b ? b : v;
};

function cleanText(s, max) {
  if (typeof s !== 'string') return '';
  // 제어 문자 제거
  let out = '';
  for (const ch of s) {
    const c = ch.codePointAt(0);
    if (c < 32 || c === 127 || (c >= 0x200b && c <= 0x200f) || (c >= 0x202a && c <= 0x202e)) continue;
    out += ch;
    if (out.length >= max) break;
  }
  return out.trim();
}

export class Game {
  constructor({ seed, savePath }) {
    const t0 = Date.now();
    this.seed = seed;
    this.world = createWorld(seed);
    this.pois = generatePOIs(this.world);
    this.world.applyPatches(this.pois.patches);
    this.world.setExclusions(exclusionsFor(this.pois));

    this.players = new Map();
    this.freeIds = [];
    for (let i = MAX_PLAYERS; i >= 1; i--) this.freeIds.push(i);

    this.worldId = Math.random().toString(36).slice(2, 10);
    this.cycle = 0;
    this.shards = new Set();
    this.bossState = 'sleep'; // sleep | awake | dead
    this.resetAt = 0;
    this.pristine = true;
    this.savePath = savePath || null;
    this.projSeq = 1;
    this.tickCount = 0;

    this.loadSave();

    this.monsters = this.pois.spawns.map((s) => this.makeMonster(s));
    // 장마다의 마지막 상대 (this.boss 는 지금 장의 상대)
    this.bosses = this.pois.bossIds.map((id) => this.monsters[id]);
    // 시련장·던전: 관문 상태와 그 안의 몬스터
    // epoch: 구역이 처음 상태로 돌아갈 때마다 바뀌는 번호 (보물상자를 다시 열 수 있는지 가리는 데 쓴다)
    const epoch0 = Math.floor(Date.now() / 1000);
    this.zones = ZONES.map((def) => ({
      def, open: 0, epoch: epoch0, mobs: [], boss: null, players: 0, emptySince: 0,
      puzzle: 0, dist: new Int16Array(def.tileW * def.tileH), queue: new Int16Array(def.tileW * def.tileH),
    }));
    for (const m of this.monsters) {
      if (!m.zone) continue;
      const z = this.zones[m.zone - 1];
      z.mobs.push(m);
      if (m.boss && z.def.kind !== 'tower') z.boss = m;
    }
    // 별의 탑: 층마다 불려 나올 몬스터들을 종류별로 나눠 둔다
    this.tower = this.zones.find((z) => z.def.kind === 'tower') || null;
    if (this.tower) {
      const z = this.tower;
      Object.assign(z, { floor: 0, tstate: 'idle', wave: [], noneSince: 0, pool: {}, elitePool: [], bossPool: [] });
      for (const m of z.mobs) {
        m.tower = true;
        if (m.boss) z.bossPool.push(m);
        else if (m.elite) z.elitePool.push(m);
        else (z.pool[m.type] = z.pool[m.type] || []).push(m);
      }
    }
    this.sealed = new Set();
    this.recomputeSeals(true);
    if (this.shards.size >= SHARD_COUNT && this.bossState === 'sleep') this.wakeBoss();

    // 페이지를 열 때 한 번 내려받는 정적 월드 데이터 (GET /world, 미리 문자열로 만들어 둔다)
    this.staticJson = JSON.stringify({
      seed,
      patches: this.pois.patches,
      village: this.pois.village,
      arena: this.pois.arena,
      shards: this.pois.shards,
      stones: this.pois.stones,
      camps: this.pois.camps,
      chests: this.pois.chests,
      bushes: this.pois.bushes,
      npcs: this.pois.npcs,
      zones: this.pois.zones,
      mounts: this.pois.mounts,
      sprite: this.pois.sprite,
      arenas: this.pois.arenas,
      bossId: this.pois.bossId,
      bossIds: this.pois.bossIds,
      // [typeIndex, level, x, z, biome, flags(1=elite,2=boss,4=minion), shard, zone]
      spawns: this.pois.spawns.map((s) => [
        MON_TYPES.indexOf(s.type), s.level, s.x, s.z, s.biome,
        (s.elite ? 1 : 0) | (s.boss ? 2 : 0) | (s.minion ? 4 : 0), s.shard, s.zone || 0,
      ]),
    });
    console.log(`[world] seed=${seed} 몬스터 ${this.monsters.length} 상자 ${this.pois.chests.length} 생성 ${Date.now() - t0}ms`);
  }

  // ---------- 진행: 장(章) ----------
  // cycle 은 지금까지 쓰러뜨린 「장의 마지막 상대」의 수다. 장은 세 개가 돌아가며 이어지고(1장 → 2장 → 3장 → 다시 1장),
  // 세 장을 모두 마칠 때마다 세상이 한층 험해진다 (loop).
  get chapter() {
    return chapterOf(this.cycle);
  }

  get loop() {
    return loopOf(this.cycle);
  }

  get boss() {
    return this.bosses[this.chapter];
  }

  // 지금 장의 별조각 번호만 남긴다
  chapterShards(list, cycle) {
    const base = chapterOf(cycle) * SHARD_COUNT;
    return (Array.isArray(list) ? list : []).filter((n) => Number.isInteger(n) && n >= base && n < base + SHARD_COUNT);
  }

  // 받은 진행 상황을 지금의 꼴로 맞춘다. 장이 생기기 전(v: 2 가 아닌 것)의 기록은 「순환」 횟수만 들어 있다:
  // 그림자 군주를 한 번이라도 쓰러뜨렸다면 2장에서, 아니라면 1장에서 모은 별조각 그대로 이어 간다
  normalizeSave(d) {
    let cycle = clampInt(d.cycle, 0, 999);
    let shards = d.shards;
    if (d.v !== 2) {
      if (cycle > 0) shards = [];
      cycle = Math.min(cycle, 1);
    }
    return { cycle, shards: this.chapterShards(shards, cycle) };
  }

  // ---------- 저장 ----------
  loadSave() {
    if (!this.savePath) return;
    try {
      const d = JSON.parse(fs.readFileSync(this.savePath, 'utf8'));
      if (d && d.seed === this.seed && typeof d.worldId === 'string') {
        const n = this.normalizeSave(d);
        this.worldId = d.worldId;
        this.cycle = n.cycle;
        this.shards = new Set(n.shards);
        this.pristine = false;
        console.log(`[save] 불러옴: ${this.loop + 1}회차 ${this.chapter + 1}장, 별조각 ${this.shards.size}/${SHARD_COUNT}`);
      }
    } catch {
      /* 저장 파일 없음 */
    }
  }

  persist() {
    if (!this.savePath) return;
    try {
      fs.mkdirSync(path.dirname(this.savePath), { recursive: true });
      fs.writeFileSync(this.savePath, JSON.stringify({ v: 2, seed: this.seed, worldId: this.worldId, cycle: this.cycle, shards: [...this.shards] }));
    } catch {
      /* 디스크를 쓸 수 없는 환경이면 무시 */
    }
  }

  worldState() {
    return {
      worldId: this.worldId,
      cycle: this.cycle,
      ch: this.chapter,
      loop: this.loop,
      shards: [...this.shards],
      sealed: [...this.sealed],
      boss: this.bossState,
      resetIn: this.resetAt ? Math.max(0, this.resetAt - Date.now()) : 0,
    };
  }

  // 클라이언트가 들고 온 진행 상황을 합친다 (무료 서버가 잠들었다 깨어나도 이어서 할 수 있게)
  mergeSave(save) {
    if (!save || typeof save.worldId !== 'string' || !Array.isArray(save.shards)) return false;
    const norm = this.normalizeSave(save);
    const cyc = norm.cycle;
    const list = norm.shards;
    let changed = false;
    if (save.worldId === this.worldId) {
      if (cyc > this.cycle) {
        this.cycle = cyc;
        this.shards = new Set(list);
        changed = true;
      } else if (cyc === this.cycle && this.bossState !== 'dead') {
        for (const n of list) if (!this.shards.has(n)) { this.shards.add(n); changed = true; }
      }
    } else if (this.pristine && (list.length > 0 || cyc > 0)) {
      this.worldId = save.worldId.slice(0, 16);
      this.cycle = cyc;
      this.shards = new Set(list);
      changed = true;
    }
    if (changed) {
      this.pristine = false;
      this.rescaleMonsters();
      this.recomputeSeals(true);
      if (this.shards.size >= SHARD_COUNT && this.bossState === 'sleep') this.wakeBoss();
      this.persist();
    }
    return changed;
  }

  // ---------- 몬스터 ----------
  makeMonster(s) {
    const def = MON[s.type];
    const m = {
      id: s.id, type: s.type, def, level: s.level, elite: !!s.elite, boss: !!s.boss, minion: !!s.minion,
      shard: s.shard, camp: s.camp, zone: s.zone || 0, group: s.group || 0, arena: s.arena === undefined ? -1 : s.arena,
      hx: s.x, hz: s.z, x: s.x, z: s.z, yaw: (s.id * 2.399) % TAU,
      state: MSTATE.IDLE, until: 0, hp: 1, maxHp: 1, dmg: 1, xp: 1, gmin: 0, gmax: 0,
      target: 0, alive: !((s.boss && !s.zone) || s.minion), respawnAt: 0, combo: null,
      kvx: 0, kvz: 0, nextAtk: 0, wanderAt: 0, wx: s.x, wz: s.z,
      pattern: null, idleSince: 0, summons: 0, chain: null, freshUntil: 0, prevState: MSTATE.IDLE,
      radius: def.radius * (s.elite ? 1.45 : 1),
      // 레이드: 받는 피해가 체력 비율이다 / 보스의 「별 삼키기」와 싸움의 진행
      raid: !!(s.zone && ZONES[s.zone - 1].kind === 'raid'), cast: null, casts: 0, engageAt: 0, power: 0, weakUntil: 0, enraged: false, nextSplit: 0, nextAdds: 0, retarget: 0,
    };
    this.applyStats(m);
    return m;
  }

  applyStats(m) {
    const st = monStats(m.type, m.level, m.elite, m.zone > 0); // 시련장·던전 안의 몬스터는 더 단단하다
    const sc = cycleScale(this.cycle);
    const tk = zoneTough(m.zone, m.boss); // 먼 땅의 구역은 한층 더 세다
    m.maxHp = Math.round(st.hp * tk[0] * sc);
    m.hp = m.maxHp;
    m.dmg = Math.round(st.dmg * tk[1] * (1 + 0.15 * this.loop));
    m.xp = Math.round(st.xp * sc);
    m.gmin = st.gmin;
    m.gmax = st.gmax;
    // 레이드에서 불려 나오는 것들은 경험치도 골드도 주지 않는다 (보상은 보물 방에서)
    if (m.raid && !m.boss) m.xp = m.gmin = m.gmax = 0;
  }

  rescaleMonsters() {
    if (!this.monsters) return;
    for (const m of this.monsters) if (!m.tower && (!m.boss || (m.zone && m.hp >= m.maxHp))) this.applyStats(m);
  }

  recomputeSeals(silent) {
    const next = new Set();
    for (const m of this.monsters) {
      if (m.shard >= 0 && m.alive && !this.shards.has(m.shard)) next.add(m.shard);
    }
    for (const s of this.pois.shards) {
      const was = this.sealed.has(s.id);
      const now = next.has(s.id);
      if (was !== now && !silent) this.broadcast({ t: 'seal', id: s.id, v: now ? 1 : 0 });
    }
    this.sealed = next;
  }

  respawn(m) {
    m.alive = true;
    m.x = m.hx;
    m.z = m.hz;
    m.hp = m.maxHp;
    m.state = MSTATE.IDLE;
    m.target = 0;
    m.kvx = m.kvz = 0;
    m.respawnAt = 0;
    m.freshUntil = this.tickCount + 6;
    if (m.shard >= 0) this.recomputeSeals(false);
  }

  walkable(m, nx, nz, step) {
    if (m.zone) {
      // 시련장·던전 안: 벽과 닫힌 관문만 막는다
      const z = this.zones[m.zone - 1];
      const rad = Math.min(1.2, m.radius * 0.5);
      return !zoneBlocked(z.def, nx, nz, rad, z.open) && !zoneTorchHit(z.def, nx, nz, rad * 0.6);
    }
    if (nx < -W.HALF + 8 || nx > W.HALF - 8 || nz < -W.HALF + 8 || nz > W.HALF - 8) return false;
    const h = this.world.heightAt(nx, nz);
    if (h < -0.45) return false;
    if (m.boss) {
      const A = this.pois.arenas[m.arena];
      return dist(nx, nz, A.x, A.z) < A.r + 1;
    }
    const h0 = this.world.heightAt(m.x, m.z);
    if (Math.abs(h - h0) > step * 1.7 + 0.2) return false;
    // 마을에는 들어오지 못한다
    if (dist(nx, nz, VILLAGE.x, VILLAGE.z) < SAFE_R - 6) return false;
    // 나무/바위 충돌
    const cx = Math.floor((nx + W.HALF) / W.CHUNK);
    const cz = Math.floor((nz + W.HALF) / W.CHUNK);
    const props = this.world.chunkProps(cx, cz);
    const rr = m.radius * 0.55;
    for (let i = 0; i < props.length; i++) {
      const p = props[i];
      if (p.cr <= 0) continue;
      const dx = nx - p.x;
      const dz = nz - p.z;
      const r = p.cr + rr;
      if (dx * dx + dz * dz < r * r) return false;
    }
    return true;
  }

  tryMove(m, dx, dz) {
    const step = Math.hypot(dx, dz);
    if (step < 1e-5) return true;
    const nx = m.x + dx;
    const nz = m.z + dz;
    if (this.walkable(m, nx, nz, step)) {
      m.x = nx;
      m.z = nz;
      return true;
    }
    return false;
  }

  // ---------- 구역 안 길찾기 ----------
  // 두 점 사이를 곧게 지나갈 수 있는지 (벽·닫힌 관문에 걸리지 않는지)
  zoneClear(def, open, x0, z0, x1, z1, rad) {
    const dx = x1 - x0;
    const dz = z1 - z0;
    const n = Math.max(1, Math.ceil(Math.hypot(dx, dz) / 0.8));
    for (let i = 1; i <= n; i++) {
      const k = i / n;
      if (zoneBlocked(def, x0 + dx * k, z0 + dz * k, rad, open)) return false;
    }
    return true;
  }

  // 목표까지 곧게 갈 수 없으면 칸 단위로 길을 찾아, 지금 향해야 할 지점을 돌려준다 (곧게 갈 수 있으면 null)
  zoneNav(m, tx, tz) {
    const z = this.zones[m.zone - 1];
    const def = z.def;
    const rad = Math.min(1.2, m.radius * 0.5);
    if (this.zoneClear(def, z.open, m.x, m.z, tx, tz, rad)) return null;
    if (m.nav && m.navUntil > this.tickCount && m.navOpen === z.open) return m.nav;
    const Wd = def.tileW;
    const Hd = def.tileH;
    const tc = Math.floor((tx - def.ox) / TILE);
    const tr = Math.floor((tz - def.oz) / TILE);
    const mc = Math.floor((m.x - def.ox) / TILE);
    const mr = Math.floor((m.z - def.oz) / TILE);
    m.nav = null;
    m.navUntil = this.tickCount + 3;
    m.navOpen = z.open;
    if (tc < 0 || tr < 0 || tc >= Wd || tr >= Hd || mc < 0 || mr < 0 || mc >= Wd || mr >= Hd) return null;
    // 벽·닫힌 관문은 못 지나가고, 화로가 놓인 칸은 돌아간다 (지금 서 있는 칸과 목표 칸은 예외)
    const start = tr * Wd + tc;
    const goal = mr * Wd + mc;
    const pass = (c, r) => {
      const ch = def.rows[r].charCodeAt(c);
      if (ch === 35 || ch === 32) return false;
      if (ch >= 49 && ch <= 57) return ((z.open >> (ch - 48)) & 1) === 1;
      if (ch === 111) return r * Wd + c === goal || r * Wd + c === start;
      return true;
    };
    if (!pass(tc, tr)) return null;
    // 목표 칸에서부터 넓혀 나가며 거리를 적는다
    const dist = z.dist;
    const queue = z.queue;
    dist.fill(-1);
    let head = 0;
    let tail = 0;
    dist[start] = 0;
    queue[tail++] = start;
    while (head < tail && dist[goal] < 0) {
      const cur = queue[head++];
      const c = cur % Wd;
      const r = (cur - c) / Wd;
      const dn = dist[cur] + 1;
      if (c > 0 && dist[cur - 1] < 0 && pass(c - 1, r)) { dist[cur - 1] = dn; queue[tail++] = cur - 1; }
      if (c < Wd - 1 && dist[cur + 1] < 0 && pass(c + 1, r)) { dist[cur + 1] = dn; queue[tail++] = cur + 1; }
      if (r > 0 && dist[cur - Wd] < 0 && pass(c, r - 1)) { dist[cur - Wd] = dn; queue[tail++] = cur - Wd; }
      if (r < Hd - 1 && dist[cur + Wd] < 0 && pass(c, r + 1)) { dist[cur + Wd] = dn; queue[tail++] = cur + Wd; }
    }
    if (dist[goal] < 0) return null;
    // 내 칸에서 거리가 줄어드는 쪽으로 몇 칸 따라가 보고, 곧게 갈 수 있는 가장 먼 칸을 고른다
    let cur = goal;
    let best = null;
    for (let k = 0; k < 7 && dist[cur] > 0; k++) {
      const c = cur % Wd;
      const r = (cur - c) / Wd;
      const dn = dist[cur] - 1;
      let nx = -1;
      if (c > 0 && dist[cur - 1] === dn) nx = cur - 1;
      else if (c < Wd - 1 && dist[cur + 1] === dn) nx = cur + 1;
      else if (r > 0 && dist[cur - Wd] === dn) nx = cur - Wd;
      else if (r < Hd - 1 && dist[cur + Wd] === dn) nx = cur + Wd;
      if (nx < 0) break;
      cur = nx;
      const wc = cur % Wd;
      const wx = def.ox + (wc + 0.5) * TILE;
      const wz = def.oz + ((cur - wc) / Wd + 0.5) * TILE;
      if (!best || this.zoneClear(def, z.open, m.x, m.z, wx, wz, rad)) best = [wx, wz];
      else break;
    }
    m.nav = best;
    return best;
  }

  // 목표 지점으로 이동 (막히면 옆으로 돌아간다). 남은 거리를 돌려준다.
  moveToward(m, tx, tz, step, away = false) {
    let dx = tx - m.x;
    let dz = tz - m.z;
    const d = Math.hypot(dx, dz);
    if (d < 0.05) return d;
    if (away) { dx = -dx; dz = -dz; }
    // 서리송곳에 얼어붙으면 느려진다 (보스는 조금만)
    if (m.slowTick > this.tickCount) step *= m.boss ? 0.72 : 0.45;
    let s = Math.min(step, away ? step : d);
    if (m.zone && !away) {
      // 시련장·던전 안에서는 벽을 돌아가는 길을 찾는다
      const w = this.zoneNav(m, tx, tz);
      if (w) {
        dx = w[0] - m.x;
        dz = w[1] - m.z;
        s = Math.min(step, Math.hypot(dx, dz));
        if (s < 1e-4) return d;
      }
    }
    const base = Math.atan2(dx, dz);
    m.yaw = base;
    const side = m.id % 2 ? 1 : -1;
    const tries = [0, 0.8 * side, -0.8 * side, 1.5 * side, -1.5 * side];
    for (const off of tries) {
      const a = base + off;
      if (this.tryMove(m, Math.sin(a) * s, Math.cos(a) * s)) break;
    }
    return d;
  }

  // 구역 안에서 몬스터가 상대를 볼 수 있는지 (벽에 가려지지 않았는지)
  zoneSees(m, p) {
    const z = this.zones[m.zone - 1];
    return this.zoneClear(z.def, z.open, m.x, m.z, p.x, p.z, 0.15);
  }

  // 한 마리가 상대를 알아채면 같은 무리가 모두 함께 덤빈다 (한 마리씩 꾀어내지 못하게)
  // (불길이 이어지는 용기의 시련에서는 가까이 있는 동료만 부른다 — 긴 통로의 무리가 들머리로 한꺼번에 몰려오지 않고, 나아갈 때마다 막아선다)
  alertGroup(m, p) {
    if (!this.zoneAwake(m)) return;
    const z = this.zones[m.zone - 1];
    const near = z.def.type === 'trap' ? 22 : Infinity;
    for (const o of z.mobs) {
      if (o !== m && o.alive && !o.boss && o.group === m.group && !o.target && dist(o.x, o.z, m.x, m.z) < near) o.target = p.id;
    }
  }

  // 구역 안의 무리는 앞 관문이 열려야 깨어난다 (2번 무리는 1번 관문이 열린 뒤)
  zoneAwake(m) {
    return m.group <= 1 || ((this.zones[m.zone - 1].open >> (m.group - 1)) & 1) === 1;
  }

  acquire(m, players) {
    let best = null;
    // 시련장·던전 안에서는 더 멀리서도 알아채지만, 벽 너머는 보지 못한다
    let bd = m.zone ? Math.max(m.def.aggro, 24) : m.def.aggro;
    if (m.zone && !this.zoneAwake(m)) return null;
    const now = Date.now();
    for (const p of players) {
      if (!p.alive || p.zone !== m.zone) continue;
      if (p.hideUntil > now && !m.boss) continue; // 연막 속에 숨은 사람은 보이지 않는다 (주인들은 속지 않는다)
      const d = dist(p.x, p.z, m.x, m.z);
      if (d >= bd) continue;
      if (m.zone && !this.zoneSees(m, p)) continue;
      if (p.y - this.world.heightAt(p.x, p.z) > 9) continue; // 높이 활공 중이면 못 본다
      if (dist(p.x, p.z, VILLAGE.x, VILLAGE.z) < SAFE_R) continue;
      bd = d;
      best = p;
    }
    return best;
  }

  startWindup(m, tgt, now, kind, extra) {
    const atk = m.def.atk;
    m.state = MSTATE.WINDUP;
    m.pattern = kind;
    const dur = (extra && extra.d) || atk.windup;
    m.until = now + dur;
    if (tgt) {
      m.yaw = Math.atan2(tgt.x - m.x, tgt.z - m.z);
      m.tx = tgt.x;
      m.tz = tgt.z;
      m.ty = tgt.y;
    }
    const ev = { t: 'ma', id: m.id, k: kind, x: +m.x.toFixed(2), z: +m.z.toFixed(2), yaw: +m.yaw.toFixed(3), d: dur, dmg: m.dmg, ...(extra || {}) };
    if (m.raid && ev.pct === undefined) ev.pct = m.boss ? RAID.pct[kind] || 0.25 : RAID.pct.add;
    this.broadcastNear(m.x, m.z, VIEW_R, ev);
  }

  strike(m, now) {
    const atk = m.def.atk;
    const kind = m.pattern;
    if (kind === 'lunge') {
      const dash = m.dash || atk.dash;
      const steps = 6;
      const sx = (Math.sin(m.yaw) * dash) / steps;
      const sz = (Math.cos(m.yaw) * dash) / steps;
      for (let i = 0; i < steps; i++) if (!this.tryMove(m, sx, sz)) break;
    } else if (kind === 'throw') {
      const tgt = this.players.get(m.target);
      const tx = tgt && tgt.alive ? tgt.x : m.tx;
      const tz = tgt && tgt.alive ? tgt.z : m.tz;
      const ty = (tgt && tgt.alive ? tgt.y : m.ty) + 1.0;
      this.throwAt(m, tx, tz, ty, atk.speed || 19, atk.proj || 'rock', m.dmg);
    }
    m.state = MSTATE.RECOVER;
    m.until = now + 420;
    m.nextAtk = now + atk.cd * (0.85 + Math.random() * 0.3);
  }

  // 포물선 투사체를 던진다 (맞았는지는 각자의 기기에서 판정한다)
  throwAt(m, tx, tz, ty, speed, proj, dmg) {
    const oy = this.world.heightAt(m.x, m.z) + m.def.height * 0.85;
    const d = Math.max(1, dist(tx, tz, m.x, m.z));
    const g = 9;
    const tf = d / speed;
    const ev = {
      t: 'pr', k: proj, x: +m.x.toFixed(2), y: +oy.toFixed(2), z: +m.z.toFixed(2),
      vx: +(((tx - m.x) / d) * speed).toFixed(2), vz: +(((tz - m.z) / d) * speed).toFixed(2),
      vy: +((ty - oy) / tf + 0.5 * g * tf).toFixed(2), g, dmg, by: m.id,
    };
    if (m.raid) ev.pct = m.boss ? RAID.pct.throw : RAID.pct.add;
    this.broadcastNear(m.x, m.z, VIEW_R, ev);
  }

  updateMonster(m, now, dt, players) {
    const def = m.def;
    const atk = def.atk;
    if (def.fixed) {
      // 사슬 기둥: 제자리에 서 있을 뿐이다
      m.state = MSTATE.IDLE;
      m.kvx = m.kvz = 0;
      return;
    }
    if (m.kvx !== 0 || m.kvz !== 0) {
      this.tryMove(m, m.kvx * dt, m.kvz * dt);
      m.kvx *= 0.55;
      m.kvz *= 0.55;
      if (Math.abs(m.kvx) + Math.abs(m.kvz) < 0.3) m.kvx = m.kvz = 0;
    }
    let tgt = m.target ? this.players.get(m.target) : null;
    if (tgt && (!tgt.alive || tgt.zone !== m.zone)) tgt = null;
    if (tgt && !m.boss && !m.zone) {
      const dh = dist(tgt.x, tgt.z, m.hx, m.hz);
      const d = dist(tgt.x, tgt.z, m.x, m.z);
      if (dh > def.leash + 14 || d > def.aggro * 2 + 14 || dist(tgt.x, tgt.z, VILLAGE.x, VILLAGE.z) < SAFE_R - 4) tgt = null;
    }
    if (tgt && !m.boss && tgt.hideUntil > now) {
      // 쫓던 상대가 연막 속으로 사라졌다: 제자리에서 두리번거린다 (집으로 돌아가 체력을 되찾지는 않는다)
      tgt = null;
      if (m.state === MSTATE.CHASE) m.state = MSTATE.IDLE;
    }
    if (!tgt) m.target = 0;
    if (m.boss) return def.ai === 2 ? this.updateBoss2(m, now, dt, players, tgt) : !m.zone ? this.updateBoss(m, now, dt, players, tgt) : this.updateZoneBoss(m, now, dt, players, tgt);

    switch (m.state) {
      case MSTATE.STAGGER:
        if (now >= m.until) m.state = tgt ? MSTATE.CHASE : MSTATE.IDLE;
        return;
      case MSTATE.WINDUP:
        if (now >= m.until) this.strike(m, now);
        return;
      case MSTATE.RECOVER:
        if (now >= m.until) m.state = tgt ? MSTATE.CHASE : MSTATE.IDLE;
        return;
      case MSTATE.RETURN: {
        const d = this.moveToward(m, m.hx, m.hz, def.speed * 1.4 * dt);
        m.hp = Math.min(m.maxHp, m.hp + m.maxHp * 0.3 * dt);
        if (d < 1.5 || now >= m.until) {
          if (d >= 1.5) { m.x = m.hx; m.z = m.hz; }
          m.state = MSTATE.IDLE;
          m.hp = m.maxHp;
        }
        return;
      }
      default:
    }

    if (!tgt) {
      tgt = this.acquire(m, players);
      if (tgt) {
        m.target = tgt.id;
        if (m.zone) this.alertGroup(m, tgt);
      }
    }
    if (!tgt) {
      if (m.state === MSTATE.CHASE) {
        m.state = MSTATE.RETURN;
        m.until = now + 12000;
        return;
      }
      if (now >= m.wanderAt) {
        const a = Math.random() * TAU;
        const r = 2 + Math.random() * 5;
        m.wx = m.hx + Math.sin(a) * r;
        m.wz = m.hz + Math.cos(a) * r;
        m.wanderAt = now + 2500 + Math.random() * 5000;
      }
      if (dist(m.x, m.z, m.wx, m.wz) > 0.7) {
        this.moveToward(m, m.wx, m.wz, def.speed * 0.35 * dt);
        m.state = MSTATE.WALK;
      } else m.state = MSTATE.IDLE;
      return;
    }

    m.state = MSTATE.CHASE;
    if (!m.zone && dist(m.x, m.z, m.hx, m.hz) > def.leash) {
      m.state = MSTATE.RETURN;
      m.until = now + 12000;
      m.target = 0;
      return;
    }
    const d = dist(tgt.x, tgt.z, m.x, m.z);
    if (atk.kind === 'throw') {
      // 구역 안에서는 벽에 가려져 있으면 보이는 곳까지 다가간다
      if (m.zone && !this.zoneSees(m, tgt)) this.moveToward(m, tgt.x, tgt.z, def.speed * dt);
      else if (d <= atk.range && now >= m.nextAtk) this.startWindup(m, tgt, now, 'throw');
      else if (d < atk.keep * 0.55) this.moveToward(m, tgt.x, tgt.z, def.speed * dt, true);
      else if (d > atk.keep) this.moveToward(m, tgt.x, tgt.z, def.speed * dt);
      else m.yaw = Math.atan2(tgt.x - m.x, tgt.z - m.z);
    } else if (d <= atk.range + 0.3 && now >= m.nextAtk) {
      const extra = { r: +(atk.reach * (m.elite ? 1.25 : 1)).toFixed(2) };
      let kind = atk.kind;
      // 수호자는 내려찍기와 크게 휩쓸기를 섞어 쓴다
      if (m.type === 'golem' && Math.random() < 0.4) {
        kind = 'arc';
        extra.r = +(atk.reach * 1.2).toFixed(2);
        extra.half = 1.25;
        extra.d = 900;
      }
      if (kind === 'arc' && extra.half === undefined) extra.half = atk.half;
      if (kind === 'lunge') { m.dash = Math.min(atk.dash, d + 1.2); extra.dash = +m.dash.toFixed(2); }
      this.startWindup(m, tgt, now, kind, extra);
    } else if (m.type === 'golem' && d > 10 && d < 28 && now >= m.nextAtk) {
      // 멀리서 활만 쏘는 상대에게는 바위를 던진다
      this.startWindup(m, tgt, now, 'throw', { d: 950 });
    } else if (d > Math.max(1.2, atk.range * 0.7)) {
      this.moveToward(m, tgt.x, tgt.z, def.speed * dt);
    } else {
      m.yaw = Math.atan2(tgt.x - m.x, tgt.z - m.z);
    }
  }

  // ---------- 장의 마지막 상대 (1장 그림자 군주 · 2장 황혼의 용 · 3장 검은 태양) ----------
  wakeBoss() {
    const b = this.boss;
    const F = FINALS[this.chapter];
    const n = Math.max(1, this.players.size);
    const st = monStats(b.type, b.level, false);
    // 함께하는 인원이 많을수록 보스도 강해진다
    b.maxHp = Math.round((F.addHp ? st.hp + F.addHp * (n - 1) : st.hp * (1 + F.addK * (n - 1))) * cycleScale(this.cycle));
    b.hp = b.maxHp;
    b.dmg = Math.round(b.def.dmg * (1 + 0.15 * this.loop));
    b.xp = Math.round(F.xp * cycleScale(this.cycle));
    b.gmin = st.gmin;
    b.gmax = st.gmax;
    b.combo = null;
    b.idleSince = 0;
    b.alive = true;
    b.x = b.hx;
    b.z = b.hz;
    b.state = MSTATE.IDLE;
    b.target = 0;
    b.summons = 0;
    b.chain = null;
    b.nextAtk = Date.now() + 3000;
    this.bossState = 'awake';
    this.broadcast({ t: 'world', state: this.worldState(), ev: 'boss-awake' });
  }

  summonMinions(count, arena = 0) {
    let n = 0;
    for (const id of this.pois.minionIds[arena]) {
      const m = this.monsters[id];
      if (m.alive) continue;
      this.applyStats(m);
      m.alive = true;
      m.x = m.hx;
      m.z = m.hz;
      m.state = MSTATE.IDLE;
      m.target = 0;
      if (++n >= count) break;
    }
  }

  // 들판의 싸움터에 들어와 있는 사람들
  arenaCands(m, players) {
    const A = this.pois.arenas[m.arena];
    const cands = [];
    for (const p of players) {
      if (p.alive && !p.zone && dist(p.x, p.z, A.x, A.z) < A.r + 24 && Math.abs(p.y - A.h) < 30) cands.push(p);
    }
    return cands;
  }

  updateBoss(m, now, dt, players, tgt) {
    const cands = this.arenaCands(m, players);
    // 체력이 줄수록 사나워진다: 2단계(55% 아래)부터 연속기와 회전 베기, 28% 아래에서는 쉴 틈이 거의 없다
    const phase2 = m.hp < m.maxHp * 0.55;
    const enraged = m.hp < m.maxHp * 0.28;
    if (m.state === MSTATE.WINDUP) {
      if (now >= m.until) {
        if (m.pattern === 'lunge') {
          const steps = 8;
          const sx = (Math.sin(m.yaw) * m.dash) / steps;
          const sz = (Math.cos(m.yaw) * m.dash) / steps;
          for (let i = 0; i < steps; i++) if (!this.tryMove(m, sx, sz)) break;
        } else if (m.pattern === 'roar') {
          this.summonMinions(phase2 ? 4 : 3);
        } else if (m.pattern === 'throw') {
          this.bossBarrage(m, phase2 ? 7 : 5);
        }
        m.state = MSTATE.RECOVER;
        m.until = now + (m.chain ? 240 : 560);
        m.nextAtk = now + (enraged ? 650 : phase2 ? 1200 : 1750) + Math.random() * 600;
      }
      return;
    }
    if (m.state === MSTATE.RECOVER) {
      if (now >= m.until) {
        m.state = MSTATE.CHASE;
        const chain = m.chain;
        m.chain = null;
        // 연속기: 내려찍기나 돌진 뒤에 곧바로 크게 휩쓴다
        if (chain && tgt && tgt.alive) {
          this.startWindup(m, tgt, now, 'arc', chain === 'spin' ? { r: 11.5, half: 3.2, d: 900 } : { r: 10.5, half: 1.9, d: 640 });
        }
      }
      return;
    }
    if (cands.length === 0) {
      if (!m.idleSince) m.idleSince = now;
      if (now - m.idleSince > ARENA_IDLE_MS && (m.hp < m.maxHp || dist(m.x, m.z, m.hx, m.hz) > 2)) {
        m.hp = m.maxHp;
        m.summons = 0;
      }
      if (dist(m.x, m.z, m.hx, m.hz) > 1.5) {
        this.moveToward(m, m.hx, m.hz, m.def.speed * dt);
        m.state = MSTATE.WALK;
      } else m.state = MSTATE.IDLE;
      return;
    }
    m.idleSince = 0;
    if (!tgt || !cands.includes(tgt)) {
      tgt = cands[0];
      let bd = Infinity;
      for (const p of cands) {
        const d = dist(p.x, p.z, m.x, m.z);
        if (d < bd) { bd = d; tgt = p; }
      }
      m.target = tgt.id;
    }
    const d = dist(tgt.x, tgt.z, m.x, m.z);
    m.state = MSTATE.CHASE;
    if (now >= m.nextAtk) {
      // 체력이 75% · 50% · 25% 아래로 내려갈 때마다 부하를 부른다
      const want = m.hp < m.maxHp * 0.25 ? 3 : m.hp < m.maxHp * 0.5 ? 2 : m.hp < m.maxHp * 0.75 ? 1 : 0;
      if ((m.summons || 0) < want) {
        m.summons = (m.summons || 0) + 1;
        return this.startWindup(m, tgt, now, 'roar', { d: 1200 });
      }
      const r = Math.random();
      if (d < 9) {
        if (r < 0.34) {
          if (phase2 && Math.random() < 0.65) m.chain = enraged && Math.random() < 0.5 ? 'spin' : 'arc';
          return this.startWindup(m, tgt, now, 'slam', { r: enraged ? 9.5 : 8.5, d: phase2 ? 950 : 1100 });
        }
        if (r < 0.62) return this.startWindup(m, tgt, now, 'arc', { r: 10.5, half: 1.9, d: phase2 ? 800 : 920 });
        if (r < 0.82 && phase2) return this.startWindup(m, tgt, now, 'arc', { r: 12, half: 3.2, d: 1200 });
        return this.startMeteor(m, tgt, now, cands, phase2);
      }
      if (r < 0.4 && d < 34) {
        m.dash = Math.min(24, d + 5);
        if (phase2 && Math.random() < 0.5) m.chain = 'arc';
        return this.startWindup(m, tgt, now, 'lunge', { r: 3.6, dash: +m.dash.toFixed(2), d: phase2 ? 780 : 900 });
      }
      if (r < 0.72) return this.startWindup(m, tgt, now, 'throw', { d: 800 });
      return this.startMeteor(m, tgt, now, cands, phase2);
    }
    if (d > 5.5) this.moveToward(m, tgt.x, tgt.z, m.def.speed * (phase2 ? 1.3 : 1) * dt);
    else m.yaw = Math.atan2(tgt.x - m.x, tgt.z - m.z);
  }

  // 부채꼴로 불덩이를 여러 개 던진다
  bossBarrage(m, count, proj = 'fire') {
    const tgt = this.players.get(m.target);
    const tx = tgt && tgt.alive ? tgt.x : m.tx;
    const tz = tgt && tgt.alive ? tgt.z : m.tz;
    const ty = (tgt && tgt.alive ? tgt.y : m.ty) + 1.0;
    const base = Math.atan2(tx - m.x, tz - m.z);
    const d = Math.max(6, dist(tx, tz, m.x, m.z));
    for (let i = 0; i < count; i++) {
      const a = base + (i - (count - 1) / 2) * 0.2;
      this.throwAt(m, m.x + Math.sin(a) * d, m.z + Math.cos(a) * d, ty, 21, proj, Math.max(1, m.dmg - 2));
    }
  }

  startMeteor(m, tgt, now, cands, more = false, count = 0) {
    const A = this.pois.arenas[m.arena];
    const pts = [];
    const n = count || 5 + Math.min(5, cands.length * 2) + (more ? 4 : 0);
    for (let i = 0; i < n; i++) {
      const p = cands[i % cands.length];
      const a = Math.random() * TAU;
      const r = i < cands.length ? 0 : 2 + Math.random() * 9;
      let x = p.x + Math.sin(a) * r;
      let z = p.z + Math.cos(a) * r;
      const dc = dist(x, z, A.x, A.z);
      if (dc > A.r) {
        x = A.x + ((x - A.x) / dc) * A.r;
        z = A.z + ((z - A.z) / dc) * A.r;
      }
      pts.push([+x.toFixed(1), +z.toFixed(1), i * (more ? 140 : 180)]);
    }
    this.startWindup(m, tgt, now, 'meteor', { r: 4.2, d: 1500, pts });
  }

  // ---------- 피해 처리 ----------
  // heavy: 망치 내려찍기처럼 단단한 적(우두머리·설인)도 휘청이게 하는 공격
  // tag: 히든 무기의 효과 표시 ('frost' 얼림, 'poison' 독, 'bolt' 번개, 'wave' 빛의 파동). 독과 번개는 휘청이게 하지 않는다.
  damageMonster(m, p, dmg, crit, kb, now, heavy = false, tag = '') {
    if (!m.alive) return;
    if (m.cast) {
      // 「별 삼키기」를 외는 동안에는 어떤 공격도 듣지 않는다 (사슬 기둥을 부숴야 한다)
      if (now - (m.guardAt || 0) > 250) {
        m.guardAt = now;
        this.broadcastNear(m.x, m.z, 140, { t: 'h', id: m.id, d: 0, c: 0, by: p.id, hp: Math.max(0, Math.round(m.hp)), s: 0, x: 'guard' });
      }
      return;
    }
    if (m.weakUntil > now) dmg = Math.round(dmg * RAID.stunMult); // 사슬이 끊겨 쓰러져 있는 동안
    if (m.state === MSTATE.RETURN) m.state = MSTATE.CHASE;
    m.hp -= dmg;
    m.freshUntil = this.tickCount + 3;
    const hidden = p.hideUntil > now && !m.boss; // 연막 속에서 때리면 누가 때렸는지 모른다
    if (!hidden && (!m.target || Math.random() < 0.3)) m.target = p.id;
    if (m.zone && !m.boss && !hidden) this.alertGroup(m, p);
    let stag = 0;
    if (tag !== 'poison' && tag !== 'bolt' && !m.def.fixed && ((m.def.stagger && !m.elite) || (heavy && !m.def.boss))) {
      stag = 1;
      m.state = MSTATE.STAGGER;
      m.until = now + 330;
      const dx = m.x - p.x;
      const dz = m.z - p.z;
      const d = Math.hypot(dx, dz) || 1;
      m.kvx = (dx / d) * kb;
      m.kvz = (dz / d) * kb;
    }
    const ev = { t: 'h', id: m.id, d: dmg, c: crit ? 1 : 0, by: p.id, hp: Math.max(0, Math.round(m.hp)), s: stag };
    if (tag) ev.x = tag;
    this.broadcastNear(m.x, m.z, 140, ev);
    if (m.hp <= 0) this.killMonster(m, p, now);
  }

  // 번개가 가까운 다른 적에게 차례로 튄다 (최대 4번, 한 번에 11m 까지)
  chainBolt(p, struck, base, now) {
    const done = new Set(struck);
    const pts = [[+struck[0].x.toFixed(1), +struck[0].z.toFixed(1)]];
    let from = struck[0];
    for (let n = 0; n < 4; n++) {
      let best = null;
      let bd = 11;
      for (const m of this.monsters) {
        if (!m.alive || done.has(m) || m.zone !== from.zone) continue;
        const d = dist(m.x, m.z, from.x, from.z);
        if (d < bd) {
          bd = d;
          best = m;
        }
      }
      if (!best) break;
      done.add(best);
      pts.push([+best.x.toFixed(1), +best.z.toFixed(1)]);
      this.damageMonster(best, p, Math.max(1, Math.round(base * 0.6)), false, 4, now, false, 'bolt');
      from = best;
    }
    if (pts.length > 1) this.broadcastNear(struck[0].x, struck[0].z, 140, { t: 'bolt', pts });
  }

  killMonster(m, p, now) {
    m.alive = false;
    m.hp = 0;
    m.target = 0;
    m.dot = null;
    m.slowTick = 0;
    // 구역 안의 몬스터는 구역이 비워졌다가 다시 채워질 때 한꺼번에 돌아온다
    m.respawnAt = m.def.respawn > 0 && !m.minion && !m.zone ? now + m.def.respawn * 1000 * (m.camp >= 0 || m.shard >= 0 ? 1.5 : 1) : 0;
    const to = [];
    for (const q of this.players.values()) {
      if (m.zone ? q.zone === m.zone : m.boss || dist(q.x, q.z, m.x, m.z) < 75) to.push(q.id);
    }
    // 레이드 보스: 함께 싸운 사람은 그 순간 쓰러져 밖에 나가 있더라도 몫을 받는다
    if (m.raid && m.boss && m.fighters) {
      for (const id of m.fighters) {
        const q = this.players.get(id);
        if (q && q.joined && !to.includes(id)) to.push(id);
      }
      m.fighters = null;
    }
    const gold = m.gmin + Math.floor(Math.random() * (m.gmax - m.gmin + 1));
    this.broadcast({ t: 'md', id: m.id, by: p ? p.id : 0, xp: m.xp, g: gold, to });
    if (m.shard >= 0) this.recomputeSeals(false);
    if (m.tower) this.towerOnKill(this.tower, now);
    else if (m.zone) this.updateZone(this.zones[m.zone - 1]);
    else if (m.boss) this.onBossDead(m, now);
  }

  // ---------- 시련장 · 던전 ----------
  // 관문: 같은 번호의 무리가 모두 쓰러지면 열린다
  updateZone(z) {
    const groups = new Map();
    for (const m of z.mobs) {
      if (m.minion) continue;
      const g = groups.get(m.group) || { n: 0, alive: 0 };
      g.n++;
      if (m.alive) g.alive++;
      groups.set(m.group, g);
    }
    let open = z.puzzle || 0;
    for (const [g, v] of groups) if (v.alive === 0) open |= 1 << g;
    if (open !== z.open) {
      z.open = open;
      this.broadcast(this.zoneState(z));
      if (z.boss && !z.boss.alive) for (const m of z.mobs) if (m.minion) m.alive = false;
    }
  }

  zoneState(z) {
    return { t: 'zs', id: z.def.id, open: z.open, epoch: z.epoch };
  }

  // 아무도 없는 채로 시간이 지나면 처음 상태로 되돌린다
  resetZone(z) {
    for (const m of z.mobs) {
      this.applyStats(m);
      m.alive = !m.minion;
      m.x = m.hx;
      m.z = m.hz;
      m.state = MSTATE.IDLE;
      m.target = 0;
      m.kvx = m.kvz = 0;
      m.combo = null;
      m.summons = 0;
      m.freshUntil = this.tickCount + 6;
      m.cast = null;
      m.casts = 0;
      m.engageAt = 0;
      m.power = 0;
      m.weakUntil = 0;
      m.enraged = false;
    }
    z.open = 0;
    z.puzzle = 0;
    z.epoch = Math.max(z.epoch + 1, Math.floor(Date.now() / 1000));
    if (z === this.tower) {
      z.floor = 0;
      z.tstate = 'idle';
      z.wave = [];
      z.noneSince = 0;
    }
    this.broadcast(this.zoneState(z));
  }

  // ---------- 별의 탑 ----------
  // 층을 시작하면 그 층의 무리가 싸움터에 나타나고, 모두 쓰러뜨리면 다음 층으로 올라갈 수 있다.
  // 다섯 층마다 우두머리가 나온다. 탑 안에 서 있는 사람이 아무도 없게 되면 그 층은 실패하고 탑은 처음으로 돌아간다.
  towerPlayers(z) {
    const list = [];
    for (const p of this.players.values()) if (p.joined && p.zone === z.def.id) list.push(p);
    return list;
  }

  // 지금 탑의 상태 (mobs: [번호, 레벨, 최대 체력] — 화면이 이름표와 체력 막대를 맞추는 데 쓴다)
  towerInfo(z, k) {
    const f = z.floor;
    return {
      t: 'tw', k, f, st: z.tstate, lv: f ? towerLevel(f) : 0, boss: f && towerBossFloor(f) && z.wave[0] ? z.wave[0].type : '',
      mobs: z.wave.filter((m) => m.alive).map((m) => [m.id, m.level, m.maxHp]),
    };
  }

  // 싸움터 안의 빈자리 (벽과 화로를 피하고, 사람에게서 조금 떨어진 곳)
  towerSpot(z, k, n, inside) {
    const C = z.def.center;
    for (let t = 0; t < 14; t++) {
      const a = ((k + t * 0.37) / Math.max(1, n)) * TAU + z.floor * 0.7;
      const r = 13 + ((k * 5 + t * 3) % 4) * 4;
      const x = C.x + Math.sin(a) * r;
      const zz = C.z + Math.cos(a) * r * 1.1;
      if (zoneBlocked(z.def, x, zz, 1.6, 0) || zoneTorchHit(z.def, x, zz, 1.4)) continue;
      let ok = true;
      for (const p of inside) if (dist(p.x, p.z, x, zz) < 9) { ok = false; break; }
      if (ok || t > 9) return [x, zz];
    }
    return [C.x, C.z + 6];
  }

  towerSpawn(z, now) {
    const f = z.floor;
    const L = towerLevel(f);
    const inside = this.towerPlayers(z);
    const n = Math.max(1, inside.length);
    const picks = []; // [몬스터, 레벨]
    const set = TOWER.sets[(f - 1) % TOWER.sets.length];
    const used = new Map();
    const take = (type, lvl) => {
      const list = z.pool[type] || [];
      const i = used.get(type) || 0;
      if (i >= list.length) return false;
      used.set(type, i + 1);
      picks.push([list[i], lvl]);
      return true;
    };
    if (towerBossFloor(f)) {
      const type = z.def.bosses[(f / TOWER.every - 1) % z.def.bosses.length];
      picks.push([z.bossPool.find((m) => m.type === type) || z.bossPool[0], L + 2]);
      // 높은 층에서는 부하들이 함께 기다린다
      const adds = f >= 35 ? 2 + Math.min(2, n - 1) : 0;
      for (let k = 0; k < adds; k++) take(set[k % set.length] === 'golem' ? set[0] : set[k % set.length], L);
    } else {
      // 무리: 층이 오를수록, 사람이 많을수록 늘어난다
      const count = Math.min(10, 4 + Math.floor(f / 4)) + Math.min(4, (n - 1) * 2);
      for (let k = 0; k < count; k++) {
        let type = set[k % set.length];
        if (type === 'golem' && (used.get('golem') || 0) >= (f >= 40 ? 2 : 1)) type = set[0];
        if (!take(type, L)) take(set[0], L) || take(set[1], L);
      }
      // 우두머리 앞의 두 층에는 우두머리 꼴이 하나 섞여 있다
      if (f % TOWER.every >= 3) {
        const et = set[f % set.length] === 'golem' ? set[0] : set[f % set.length];
        picks.push([z.elitePool.find((m) => m.type === et) || z.elitePool[0], L + 1]);
      }
    }
    const hpK = towerHpK(f);
    const dmgK = towerDmgK(f);
    picks.forEach(([m, lvl], k) => {
      m.level = lvl;
      if (m.boss) {
        // 우두머리는 한가운데에서 기다린다 (어디로 달아나도 쫓아온다). 부하는 부르지 않는다
        m.hx = z.def.center.x;
        m.hz = z.def.center.z;
        m.maxHp = towerBossHp(lvl, f, n);
        m.dmg = towerBossDmg(lvl, f);
        m.xp = Math.round(0.35 * xpNeed(Math.min(lvl, MAX_LEVEL)));
        const st = monStats(m.type, lvl, false, true, true);
        m.gmin = st.gmin;
        m.gmax = st.gmax;
        m.summons = 99;
        m.nextAtk = now + 2600;
      } else {
        const [x, zz] = this.towerSpot(z, k, picks.length, inside);
        m.hx = x;
        m.hz = zz;
        const st = monStats(m.type, lvl, m.elite, true, true);
        m.maxHp = Math.round(st.hp * hpK);
        m.dmg = Math.round(st.dmg * dmgK);
        m.xp = st.xp;
        m.gmin = st.gmin;
        m.gmax = st.gmax;
        m.nextAtk = now + 1200 + Math.random() * 800;
      }
      m.hp = m.maxHp;
      m.alive = true;
      m.x = m.hx;
      m.z = m.hz;
      m.state = MSTATE.IDLE;
      m.target = 0;
      m.kvx = m.kvz = 0;
      m.combo = null;
      m.idleSince = 0;
      m.dot = null;
      m.slowTick = 0;
      m.freshUntil = this.tickCount + 6;
    });
    z.wave = picks.map((q) => q[0]);
    z.tstate = 'fight';
    z.noneSince = 0;
    this.broadcastZone(z, this.towerInfo(z, 'wave'));
  }

  // 층을 시작한다 (f: 시작할 층 — 1, 6, 11 … 가운데 그 사람이 올라 본 곳까지)
  towerStart(z, p, f, now) {
    if (p.zone !== z.def.id || !p.alive) return;
    if (z.tstate === 'fight') return;
    if (z.tstate === 'clear') f = z.floor + 1; // 이어서 다음 층으로
    else if (!towerStartOk(f)) return;
    z.floor = f;
    this.towerSpawn(z, now);
  }

  towerOnKill(z, now) {
    if (z.tstate !== 'fight') return;
    for (const m of z.wave) if (m.alive) return;
    z.tstate = 'clear';
    const f = z.floor;
    this.broadcastZone(z, this.towerInfo(z, 'clear'));
    // 우두머리를 넘어설 때마다 모두에게 알린다
    if (towerBossFloor(f)) {
      const names = this.towerPlayers(z).map((p) => p.name);
      if (names.length) this.broadcast({ t: 'sys', text: `🗼 ${names.slice(0, 4).join(', ')}${names.length > 4 ? ' 외' : ''} 님이 별의 탑 ${f}층을 돌파했습니다!` });
    }
  }

  // 그 층에 실패했다: 무리는 사라지고 탑은 처음으로 돌아간다
  towerFail(z) {
    const f = z.floor;
    for (const m of z.wave) {
      m.alive = false;
      m.target = 0;
    }
    z.wave = [];
    z.floor = 0;
    z.tstate = 'idle';
    z.noneSince = 0;
    this.broadcastZone(z, { t: 'tw', k: 'fail', f, st: 'idle', lv: 0, boss: '', mobs: [] });
  }

  towerTick(z, now, players) {
    if (z.tstate !== 'fight') return;
    let alive = 0;
    for (const p of players) if (p.zone === z.def.id && p.alive) alive++;
    if (alive) z.noneSince = 0;
    else if (!z.noneSince) z.noneSince = now;
    else if (now - z.noneSince > TOWER.failMs) this.towerFail(z);
  }

  tickZones(now, players) {
    for (const z of this.zones) z.players = 0;
    for (const p of players) if (p.zone) this.zones[p.zone - 1].players++;
    if (this.tower) this.towerTick(this.tower, now, players);
    for (const z of this.zones) {
      const rb = z.def.kind === 'raid' ? z.boss : null;
      if (rb && rb.alive && rb.engageAt) {
        // 레이드: 방 안에 서 있는 사람이 아무도 없으면(모두 쓰러졌거나 나갔으면) 곧 처음으로 돌아간다.
        // (보스는 가까이에 사람이 있을 때만 움직이므로, 모두 밖에서 다시 일어난 경우는 여기서 챙긴다)
        let alive = 0;
        for (const p of players) if (p.zone === z.def.id && p.alive) alive++;
        if (alive) z.raidEmpty = 0;
        else if (!z.raidEmpty) z.raidEmpty = now;
        else if (now - z.raidEmpty > 2500) {
          z.raidEmpty = 0;
          rb.x = rb.hx;
          rb.z = rb.hz;
          rb.state = MSTATE.IDLE;
          rb.target = 0;
          rb.combo = null;
          rb.freshUntil = this.tickCount + 6;
          this.raidReset(rb, z);
        }
      }
      if (z.players > 0) {
        z.emptySince = 0;
        // 보스는 함께 들어온 사람 수에 맞춰 강해진다 (싸움이 시작되기 전에만 조정)
        const b = z.boss;
        if (b && !b.raid && b.alive && b.hp >= b.maxHp && !b.target) {
          const base = Math.round(monStats(b.type, b.level, false).hp * cycleScale(this.cycle));
          const want = Math.round(base * (1 + 0.6 * (z.players - 1)));
          if (want !== b.maxHp) b.maxHp = b.hp = want;
        }
        continue;
      }
      if (!z.emptySince) z.emptySince = now;
      if (now - z.emptySince < ZONE_RESET_MS) continue;
      let dirty = z.open !== 0 || (z === this.tower && z.floor > 0);
      if (!dirty) for (const m of z.mobs) if (m.alive === !!m.minion || m.hp < m.maxHp) { dirty = true; break; }
      if (dirty) this.resetZone(z);
      z.emptySince = now;
    }
  }

  summonZoneMinions(z, count) {
    if (z === this.tower) return; // 탑의 우두머리는 부하를 부르지 않는다
    let n = 0;
    for (const m of z.mobs) {
      if (!m.minion || m.alive) continue;
      this.applyStats(m);
      m.alive = true;
      m.x = m.hx;
      m.z = m.hz;
      m.state = MSTATE.IDLE;
      m.target = 0;
      m.freshUntil = this.tickCount + 6;
      if (++n >= count) break;
    }
  }

  // 던전 보스: 종류마다 다른 공격 묶음. 체력이 줄수록 연속기가 늘고 쉬는 틈이 줄어든다.
  updateZoneBoss(m, now, dt, players, tgt) {
    const z = this.zones[m.zone - 1];
    const type = m.type;
    const phase2 = m.hp < m.maxHp * 0.6;
    const enraged = m.hp < m.maxHp * 0.3;
    if (m.state === MSTATE.WINDUP) {
      if (now >= m.until) {
        if (m.pattern === 'lunge') {
          const steps = 8;
          const sx = (Math.sin(m.yaw) * m.dash) / steps;
          const sz = (Math.cos(m.yaw) * m.dash) / steps;
          for (let i = 0; i < steps; i++) if (!this.tryMove(m, sx, sz)) break;
        } else if (m.pattern === 'roar') {
          this.summonZoneMinions(z, phase2 ? 4 : 2);
        } else if (m.pattern === 'throw') {
          this.bossBarrage(m, type === 'knight' ? (phase2 ? 9 : 6) : phase2 ? 5 : 3, type === 'knight' ? 'fire' : 'rock');
        }
        m.state = MSTATE.RECOVER;
        const next = m.combo && m.combo.length;
        m.until = now + (next ? 200 : type === 'knight' ? 420 : 560);
        const gap = type === 'knight' ? (enraged ? 520 : phase2 ? 900 : 1300) : type === 'tyrant' ? (enraged ? 800 : phase2 ? 1200 : 1700) : enraged ? 900 : phase2 ? 1300 : 1800;
        m.nextAtk = now + gap + Math.random() * 500;
      }
      return;
    }
    if (m.state === MSTATE.RECOVER) {
      if (now >= m.until) {
        m.state = MSTATE.CHASE;
        // 연속기: 예약해 둔 다음 공격을 곧바로 잇는다
        if (m.combo && m.combo.length && tgt) {
          const c = m.combo.shift();
          const d = dist(tgt.x, tgt.z, m.x, m.z);
          if (c.k === 'lunge') {
            m.dash = Math.min(c.max || 14, d + 3);
            c.dash = +m.dash.toFixed(2);
          }
          const { k, max, ...extra } = c;
          this.startWindup(m, tgt, now, k, extra);
        } else m.combo = null;
      }
      return;
    }
    // 제 방과 그 둘레(42m)에 들어온 상대만 노린다. 멀리 달아나면 돌아가서 체력을 되찾는다.
    const cands = [];
    if (this.zoneAwake(m)) for (const p of players) if (p.alive && p.zone === m.zone && (m.tower || dist(p.x, p.z, m.hx, m.hz) < 42)) cands.push(p);
    if (cands.length === 0) {
      // 상대가 모두 쓰러지거나 나가면 곧 체력을 되찾는다 (쓰러졌다가 바로 돌아와 이어서 싸울 수 없다)
      if (!m.idleSince) m.idleSince = now;
      if (now - m.idleSince > 2500 && m.hp < m.maxHp) {
        m.hp = m.maxHp;
        m.summons = 0;
        m.freshUntil = this.tickCount + 6;
      }
      m.combo = null;
      if (dist(m.x, m.z, m.hx, m.hz) > 1.5) {
        this.moveToward(m, m.hx, m.hz, m.def.speed * dt);
        m.state = MSTATE.WALK;
      } else m.state = MSTATE.IDLE;
      return;
    }
    m.idleSince = 0;
    if (!tgt || !cands.includes(tgt)) {
      let bd = Infinity;
      for (const p of cands) {
        const d = dist(p.x, p.z, m.x, m.z);
        if (d < bd) { bd = d; tgt = p; }
      }
      m.target = tgt.id;
    }
    const d = dist(tgt.x, tgt.z, m.x, m.z);
    m.state = MSTATE.CHASE;
    if (now >= m.nextAtk) {
      const r = Math.random();
      m.combo = null;
      // 체력이 2/3, 1/3 아래로 내려갈 때 부하를 부른다
      const want = m.hp < m.maxHp * 0.34 ? 2 : m.hp < m.maxHp * 0.67 ? 1 : 0;
      if ((m.summons || 0) < want) {
        m.summons = (m.summons || 0) + 1;
        return this.startWindup(m, tgt, now, 'roar', { d: 1100 });
      }
      const lunge = (max, wind, rr) => {
        m.dash = Math.min(max, d + 3);
        return this.startWindup(m, tgt, now, 'lunge', { r: rr, dash: +m.dash.toFixed(2), d: wind });
      };
      if (type === 'kingslime') {
        // 말랑 대왕: 덮치기와 내려찍기. 2단계부터는 연달아 세 번 덮친다
        if (d < 8 && r < 0.45) return this.startWindup(m, tgt, now, 'slam', { r: enraged ? 9 : 7.5, d: phase2 ? 850 : 1000 });
        if (phase2) m.combo = [{ k: 'lunge', r: 3.6, d: 520, max: 14 }, { k: enraged ? 'slam' : 'lunge', r: enraged ? 8 : 3.6, d: enraged ? 700 : 520, max: 14 }];
        return lunge(16, phase2 ? 620 : 800, 3.6);
      }
      if (type === 'tyrant') {
        // 서리 폭군: 내려찍기, 휩쓸기, 돌진, 얼음덩이 던지기, 마지막에는 얼음 비
        if (d < 9) {
          if (r < 0.4) {
            if (phase2) m.combo = [{ k: 'arc', r: 10, half: 1.6, d: 620 }];
            return this.startWindup(m, tgt, now, 'slam', { r: enraged ? 9.5 : 8.5, d: phase2 ? 880 : 1000 });
          }
          if (r < 0.75) return this.startWindup(m, tgt, now, 'arc', { r: 9.5, half: 1.6, d: phase2 ? 720 : 850 });
          if (enraged) return this.startZoneMeteor(m, tgt, now, cands, 10);
          return this.startWindup(m, tgt, now, 'throw', { d: 750 });
        }
        if (r < 0.5) {
          if (phase2) m.combo = [{ k: 'slam', r: 8, d: 620 }];
          return lunge(18, phase2 ? 680 : 800, 3.8);
        }
        if (enraged && r < 0.75) return this.startZoneMeteor(m, tgt, now, cands, 10);
        return this.startWindup(m, tgt, now, 'throw', { d: 750 });
      }
      // 공허의 기사: 빠른 연속 베기, 회전 베기, 돌진 베기, 불꽃 부채, 별똥
      if (d < 8.5) {
        if (r < 0.45) {
          m.combo = phase2 ? [{ k: 'arc', r: 8.5, half: 1.9, d: 420 }, { k: enraged ? 'arc' : 'lunge', r: enraged ? 10 : 3.2, half: 3.2, d: enraged ? 700 : 480, max: 12 }] : [{ k: 'arc', r: 8.5, half: 1.9, d: 460 }];
          return this.startWindup(m, tgt, now, 'arc', { r: 8, half: 1.9, d: phase2 ? 560 : 660 });
        }
        if (r < 0.7) return this.startWindup(m, tgt, now, 'arc', { r: 10, half: 3.2, d: phase2 ? 820 : 950 });
        if (r < 0.85) return this.startZoneMeteor(m, tgt, now, cands, phase2 ? 14 : 9);
        return this.startWindup(m, tgt, now, 'throw', { d: 620 });
      }
      if (r < 0.5) {
        m.combo = [{ k: 'arc', r: 8.5, half: 1.9, d: 420 }];
        return lunge(20, phase2 ? 480 : 580, 3.2);
      }
      if (r < 0.8) return this.startWindup(m, tgt, now, 'throw', { d: 620 });
      return this.startZoneMeteor(m, tgt, now, cands, phase2 ? 14 : 9);
    }
    if (d > Math.max(3.5, m.radius + 2.2)) this.moveToward(m, tgt.x, tgt.z, m.def.speed * (phase2 ? 1.25 : 1) * dt);
    else m.yaw = Math.atan2(tgt.x - m.x, tgt.z - m.z);
  }

  // 방 안 여기저기에 떨어지는 공격 (벽 속에는 떨어지지 않는다)
  startZoneMeteor(m, tgt, now, cands, n) {
    const z = this.zones[m.zone - 1];
    const pts = [];
    for (let i = 0; i < n; i++) {
      const p = cands[i % cands.length];
      const a = Math.random() * TAU;
      const r = i < cands.length ? 0 : 2 + Math.random() * 9;
      const x = p.x + Math.sin(a) * r;
      const zz = p.z + Math.cos(a) * r;
      if (zoneSolid(z.def, x, zz, z.open)) continue;
      pts.push([+x.toFixed(1), +zz.toFixed(1), i * 150]);
    }
    this.startWindup(m, tgt, now, 'meteor', { r: 3.8, d: 1400, pts });
  }

  // ---------- 먼 땅 던전의 주인 · 레이드 보스 ----------
  // 새 공격: 고리 충격파(nova) — 안쪽(r0)에 바짝 붙거나 바깥(r1)으로 벗어나야 한다 / 십자 가르기(cross) — 보스에게서 뻗어 나가는 여러 갈래의 긴 줄
  // 공격 묶음은 [첫 공격, 이어지는 공격들…] 로 돌려준다. 이어지는 공격은 앞 공격이 끝나자마자 곧바로 나온다.
  boss2Moves(type, d, r, ph, n) {
    const P4 = Math.PI / 4;
    if (type === 'empress') {
      // 협곡의 여제: 집게 휩쓸기, 꼬리 내려찍기와 뒤따르는 충격파, 땅을 가르는 십자, 돌진, 독침 뿌리기
      if (d < 10) {
        if (r < 0.34) return [{ k: 'arc', r: 10, half: 1.5, d: [820, 700, 600][ph] }, ...(ph ? [{ k: 'arc', r: 10.5, half: 1.5, d: 500 }] : []), ...(ph > 1 ? [{ k: 'nova', r0: 6, r1: 19, d: 680 }] : [])];
        if (r < 0.62) return [{ k: 'slam', r: [8.5, 9, 9.5][ph], d: [950, 850, 760][ph] }, ...(ph ? [{ k: 'nova', r0: 9, r1: 20, d: 620 }] : [])];
        if (r < 0.86) return [{ k: 'cross', n: 4, len: 30, w: 2.2, d: 1000 }, ...(ph ? [{ k: 'cross', n: 4, len: 30, w: 2.2, d: 640, off: P4 }] : [])];
        return [{ k: 'throw', d: 700 }];
      }
      if (r < 0.5) return [{ k: 'lunge', max: 22, r: 3.8, d: [620, 540, 460][ph] }, ...(ph ? [{ k: 'lunge', max: 18, r: 3.8, d: 460 }] : []), ...(ph > 1 ? [{ k: 'slam', r: 9.5, d: 620 }] : [])];
      if (r < 0.8 || ph < 2) return [{ k: 'throw', d: 700 }];
      return [{ k: 'meteor', n: 12 }];
    }
    if (type === 'tidelord') {
      // 밀물의 군주: 밀려 나가는 물결(안 → 밖)과 밀려드는 물결(밖 → 안), 여섯 갈래 물길, 물기둥 비
      const wave = [{ k: 'slam', r: 7.5, d: [900, 800, 700][ph] }, { k: 'nova', r0: 7.5, r1: 15, d: 560 }, { k: 'nova', r0: 15, r1: 24, d: 560 }];
      const ebb = [{ k: 'nova', r0: 15, r1: 24, d: 900 }, { k: 'nova', r0: 7.5, r1: 15, d: 560 }, { k: 'slam', r: 7.5, d: 560 }];
      if (d < 10) {
        if (r < 0.3) return ph > 1 && Math.random() < 0.5 ? ebb : wave.slice(0, ph ? 3 : 2);
        if (r < 0.55) return [{ k: 'arc', r: 10.5, half: 1.8, d: [820, 720, 620][ph] }, ...(ph ? [{ k: 'arc', r: 10.5, half: 1.8, d: 520 }] : [])];
        if (r < 0.8) return [{ k: 'cross', n: ph ? 6 : 4, len: 32, w: 1.9, d: 1000 }, ...(ph ? [{ k: 'cross', n: 6, len: 32, w: 1.9, d: 620, off: Math.PI / 6 }] : [])];
        return [{ k: 'throw', d: 680 }];
      }
      if (r < 0.3) return [{ k: 'lunge', max: 20, r: 3.4, d: [640, 560, 480][ph] }, { k: 'slam', r: 8, d: 600 }];
      if (r < 0.6) return [{ k: 'meteor', n: [10, 14, 18][ph] }];
      if (r < 0.8 && ph) return ebb;
      return [{ k: 'throw', d: 680 }];
    }
    if (type === 'starborn') {
      // 떨어진 별의 화신: 숨 돌릴 틈 없는 연속 베기, 겹쳐 오는 십자, 안팎을 번갈아 치는 충격파, 거듭되는 돌진
      const rain = [{ k: 'meteor', n: [12, 16, 22][ph] }];
      if (d < 9.5) {
        if (r < 0.34) return [{ k: 'arc', r: 9, half: 1.9, d: [600, 520, 440][ph] }, { k: 'arc', r: 9.5, half: 1.9, d: 400 }, ...(ph ? [{ k: 'arc', r: 11, half: 3.2, d: 620 }] : []), ...(ph > 1 ? [{ k: 'nova', r0: 5, r1: 20, d: 560 }] : [])];
        if (r < 0.58) return [{ k: 'cross', n: 4, len: 34, w: 2.1, d: 900 }, { k: 'cross', n: 4, len: 34, w: 2.1, d: 520, off: P4 }, ...(ph > 1 ? [{ k: 'cross', n: 8, len: 34, w: 1.5, d: 700, off: P4 / 2 }] : [])];
        if (r < 0.8) return [{ k: 'nova', r0: 6.5, r1: 21, d: [900, 780, 660][ph] }, { k: 'slam', r: 7, d: 520 }, ...(ph ? [{ k: 'nova', r0: 6.5, r1: 21, d: 520 }] : [])];
        return rain;
      }
      if (r < 0.5) return [{ k: 'lunge', max: 26, r: 3.3, d: [520, 440, 380][ph] }, { k: 'arc', r: 9.5, half: 1.9, d: 400 }, ...(ph ? [{ k: 'lunge', max: 22, r: 3.3, d: 380 }] : []), ...(ph > 1 ? [{ k: 'lunge', max: 22, r: 3.3, d: 360 }, { k: 'arc', r: 11, half: 3.2, d: 520 }] : [])];
      if (r < 0.75) return [{ k: 'throw', d: 600 }];
      return rain;
    }
    if (type === 'dragon') {
      // 황혼의 용: 꼬리 휩쓸기, 발톱 내려찍기와 번지는 불길, 불길 숨결(부채꼴로 흩뿌린다), 날아올라 내리꽂기, 사방으로 뻗는 불줄기
      const dive = [{ k: 'lunge', max: 26, r: 4.2, d: [760, 660, 560][ph] }, { k: 'slam', r: [9.5, 10, 10.5][ph], d: 620 }, ...(ph > 1 ? [{ k: 'nova', r0: 10, r1: 22, d: 600 }] : [])];
      if (d < 11) {
        if (r < 0.3) return [{ k: 'arc', r: 12, half: 1.7, d: [880, 760, 640][ph] }, ...(ph ? [{ k: 'arc', r: 12.5, half: 3.2, d: 760 }] : [])];
        if (r < 0.55) return [{ k: 'slam', r: [9, 9.5, 10][ph], d: [980, 860, 760][ph] }, ...(ph ? [{ k: 'nova', r0: 9.5, r1: 21, d: 640 }] : []), ...(ph > 1 ? [{ k: 'nova', r0: 4, r1: 9.5, d: 560 }] : [])];
        if (r < 0.75) return [{ k: 'cross', n: ph > 1 ? 6 : 4, len: 34, w: 2.3, d: 1000 }, ...(ph ? [{ k: 'cross', n: ph > 1 ? 6 : 4, len: 34, w: 2.3, d: 640, off: ph > 1 ? Math.PI / 6 : P4 }] : [])];
        if (r < 0.9) return [{ k: 'throw', d: 720 }, ...(ph ? [{ k: 'throw', d: 520 }] : [])];
        return dive;
      }
      if (r < 0.45) return dive;
      if (r < 0.75) return [{ k: 'throw', d: 720 }, ...(ph ? [{ k: 'throw', d: 520 }] : [])];
      return [{ k: 'meteor', n: [10, 14, 18][ph] }];
    }
    if (type === 'blacksun') {
      // 검은 태양: 겹겹이 번지는 고리 불길(안 → 밖, 밖 → 안), 돌아가는 빛줄기, 쏟아지는 불씨, 짓누르기
      const out = [{ k: 'slam', r: 7, d: [920, 800, 680][ph] }, { k: 'nova', r0: 7, r1: 14, d: 540 }, { k: 'nova', r0: 14, r1: 21, d: 540 }, ...(ph ? [{ k: 'nova', r0: 21, r1: 30, d: 540 }] : [])];
      const inw = [{ k: 'nova', r0: 20, r1: 30, d: 940 }, { k: 'nova', r0: 13, r1: 20, d: 540 }, { k: 'nova', r0: 6.5, r1: 13, d: 540 }, { k: 'slam', r: 6.5, d: 540 }];
      const beams = [{ k: 'cross', n: 4, len: 38, w: 2.0, d: 960 }, { k: 'cross', n: 4, len: 38, w: 2.0, d: 500, off: P4 / 2 }, { k: 'cross', n: 4, len: 38, w: 2.0, d: 500, off: P4 }, ...(ph ? [{ k: 'cross', n: 4, len: 38, w: 2.0, d: 500, off: P4 * 1.5 }] : []), ...(ph > 1 ? [{ k: 'cross', n: 8, len: 38, w: 1.6, d: 760, off: P4 / 2 }] : [])];
      const rain = [{ k: 'meteor', n: [14, 18, 24][ph] }, ...(ph > 1 ? [{ k: 'nova', r0: 6, r1: 26, d: 760 }] : [])];
      if (d < 12) {
        if (r < 0.28) return ph > 0 && Math.random() < 0.5 ? inw : out;
        if (r < 0.54) return beams;
        if (r < 0.72) return [{ k: 'slam', r: [9, 10, 11][ph], d: [900, 780, 660][ph] }, ...(ph ? [{ k: 'slam', r: 12, d: 600 }] : []), ...(ph > 1 ? [{ k: 'nova', r0: 12, r1: 26, d: 600 }] : [])];
        if (r < 0.86) return rain;
        return [{ k: 'throw', d: 640 }, ...(ph ? [{ k: 'throw', d: 460 }] : [])];
      }
      if (r < 0.3) return [{ k: 'lunge', max: 28, r: 4.0, d: [700, 600, 500][ph] }, { k: 'slam', r: 9.5, d: 560 }, ...(ph ? [{ k: 'nova', r0: 9.5, r1: 22, d: 560 }] : [])];
      if (r < 0.55) return rain;
      if (r < 0.8) return ph ? inw : beams;
      return [{ k: 'throw', d: 640 }, ...(ph ? [{ k: 'throw', d: 460 }] : [])];
    }
    // 별 포식자 (레이드): 느리지만 방 전체를 뒤덮는다. n: 싸우는 사람 수
    const rain = [{ k: 'meteor', n: Math.min(22, 6 + n * 3 + ph * 3) }];
    if (d < 14) {
      if (r < 0.3) return [{ k: 'slam', r: 12, d: [1100, 980, 860][ph] }, ...(ph ? [{ k: 'nova', r0: 12, r1: 27, d: 640 }] : []), ...(ph > 1 ? [{ k: 'slam', r: 12, d: 560 }] : [])];
      if (r < 0.55) return [{ k: 'arc', r: 14.5, half: 1.7, d: [950, 850, 750][ph] }, ...(ph ? [{ k: 'arc', r: 14.5, half: 1.7, d: 560 }] : [])];
      if (r < 0.8) return [{ k: 'cross', n: 4, len: 46, w: 2.8, d: 1100 }, ...(ph ? [{ k: 'cross', n: 4, len: 46, w: 2.8, d: 660, off: P4 }] : []), ...(ph > 1 ? [{ k: 'cross', n: 4, len: 46, w: 2.8, d: 660 }] : [])];
      return rain;
    }
    if (r < 0.35) return [{ k: 'lunge', max: 30, r: 4.4, d: [760, 680, 600][ph] }, ...(ph ? [{ k: 'slam', r: 12, d: 640 }] : [])];
    if (r < 0.6) return rain;
    if (r < 0.85) return [{ k: 'nova', r0: 13, r1: 34, d: 1050 }, ...(ph ? [{ k: 'slam', r: 13, d: 620 }] : [])];
    return [{ k: 'throw', d: 760 }];
  }

  // 공격 하나를 시작한다. c: { k, d, … } — lunge 는 max(가장 멀리 뛰는 거리), cross 는 off(틀어지는 각도), meteor 는 n(떨어지는 수)
  boss2Start(m, tgt, now, c, cands) {
    const { k, max, off, ...extra } = c;
    if (k === 'meteor') return m.zone ? this.startZoneMeteor(m, tgt, now, cands, c.n) : this.startMeteor(m, tgt, now, cands, false, c.n);
    if (k === 'lunge') {
      m.dash = Math.min(max || 16, dist(tgt.x, tgt.z, m.x, m.z) + 3);
      extra.dash = +m.dash.toFixed(2);
    } else if (k === 'cross') extra.a = +(Math.atan2(tgt.x - m.x, tgt.z - m.z) + (off || 0)).toFixed(3);
    this.startWindup(m, tgt, now, k, extra);
  }

  updateBoss2(m, now, dt, players, tgt) {
    // z 가 없으면 들판의 싸움터에 깨어난 「장의 마지막 상대」다
    const z = m.zone ? this.zones[m.zone - 1] : null;
    const T = BOSS2[m.type];
    const raid = m.raid;
    const frac = m.hp / m.maxHp;
    const ph = frac < T.phase[1] ? 2 : frac < T.phase[0] ? 1 : 0;
    if (raid && m.engageAt && this.tickCount % 5 === 0) this.raidScale(m, players); // 뒤늦게 들어온 사람의 몫만큼 체력이 늘어난다
    if (m.cast) return this.updateRaidCast(m, z, now);
    if (m.state === MSTATE.STAGGER) {
      // 사슬이 끊겨 쓰러져 있다
      if (now >= m.until) m.state = MSTATE.CHASE;
      return;
    }
    // 싸울 상대: 던전의 주인은 제 방과 그 둘레, 레이드 보스는 방 안의 모두, 장의 마지막 상대는 싸움터에 들어온 모두
    let cands = [];
    if (!z) cands = this.arenaCands(m, players);
    else if (raid || this.zoneAwake(m)) for (const p of players) if (p.alive && p.zone === m.zone && (raid || m.tower || dist(p.x, p.z, m.hx, m.hz) < 42)) cands.push(p);
    if (m.state === MSTATE.WINDUP) {
      if (now < m.until) return;
      const k = m.pattern;
      if (k === 'lunge') {
        const steps = 8;
        const sx = (Math.sin(m.yaw) * m.dash) / steps;
        const sz = (Math.cos(m.yaw) * m.dash) / steps;
        for (let i = 0; i < steps; i++) if (!this.tryMove(m, sx, sz)) break;
      } else if (k === 'roar') {
        if (raid) this.summonRaidAdds(m, z, Math.min(8, 1 + cands.length));
        else if (z) this.summonZoneMinions(z, ph ? 4 : 2);
        else this.summonMinions(ph ? 4 : 3, m.arena);
      } else if (k === 'throw') this.bossBarrage(m, T.barrage[ph], T.proj);
      m.state = MSTATE.RECOVER;
      const next = m.combo && m.combo.length;
      m.until = now + (next ? 190 : T.rec);
      m.nextAtk = now + T.gap[ph] + Math.random() * 450;
      return;
    }
    if (m.state === MSTATE.RECOVER) {
      if (now < m.until) return;
      m.state = MSTATE.CHASE;
      // 이어지는 공격: 그때 가장 가까운 상대를 다시 겨눈다
      if (m.combo && m.combo.length && cands.length) {
        if (!tgt || !cands.includes(tgt)) tgt = cands[0];
        return this.boss2Start(m, tgt, now, m.combo.shift(), cands);
      }
      m.combo = null;
      return;
    }
    // 레이드: 누군가 가까이 오거나 먼저 건드려야 싸움이 시작된다 (들머리에 서 있는 것만으로는 깨어나지 않는다)
    if (raid && !m.engageAt && cands.length) {
      let near = m.hp < m.maxHp;
      for (const p of cands) if (dist(p.x, p.z, m.x, m.z) < 30) near = true;
      if (near) this.raidEngage(m, z, now, players);
      else cands.length = 0;
    }
    if (cands.length === 0) {
      // 상대가 모두 쓰러지거나 나가면 곧 처음으로 돌아간다 (쓰러졌다가 돌아와 이어서 싸울 수 없다)
      if (!m.idleSince) m.idleSince = now;
      if (now - m.idleSince > (z ? 2500 : ARENA_IDLE_MS) && (m.hp < m.maxHp || m.engageAt)) {
        m.hp = m.maxHp;
        m.summons = 0;
        m.freshUntil = this.tickCount + 6;
        if (raid) this.raidReset(m, z);
      }
      m.combo = null;
      if (dist(m.x, m.z, m.hx, m.hz) > 1.5) {
        this.moveToward(m, m.hx, m.hz, m.def.speed * dt);
        m.state = MSTATE.WALK;
      } else m.state = MSTATE.IDLE;
      return;
    }
    m.idleSince = 0;
    // 레이드 보스는 가끔 다른 사람에게 눈을 돌린다
    if (!tgt || !cands.includes(tgt) || (raid && now >= m.retarget)) {
      if (raid && cands.length > 1 && now >= m.retarget) tgt = cands[Math.floor(Math.random() * cands.length)];
      else {
        let bd = Infinity;
        for (const p of cands) {
          const d = dist(p.x, p.z, m.x, m.z);
          if (d < bd) { bd = d; tgt = p; }
        }
      }
      m.target = tgt.id;
      m.retarget = now + 7000 + Math.random() * 5000;
    }
    const d = dist(tgt.x, tgt.z, m.x, m.z);
    m.state = MSTATE.CHASE;
    if (now >= m.nextAtk) {
      m.combo = null;
      if (raid) {
        // 시간이 다 되면 모든 빛을 삼킨다 (막을 수 없다)
        if (!m.enraged && now - m.engageAt > RAID.enrageMs) {
          m.enraged = true;
          return this.startRaidCast(m, z, now, 6000, false, cands);
        }
        // 체력이 정해진 만큼 내려갈 때마다 「별 삼키기」
        if (m.casts < RAID.casts.length && frac <= RAID.casts[m.casts]) return this.startRaidCast(m, z, now, RAID.castMs[m.casts++], true, cands);
        // 별똥 나누기: 한 사람 위로 떨어지는 큰 별똥. 원 안에 모인 사람들이 피해를 나눠 받는다
        if (now >= m.nextSplit) {
          m.nextSplit = now + RAID.splitEvery;
          const who = cands[Math.floor(Math.random() * cands.length)];
          // 혼자 싸울 때는 나눠 받을 사람이 없으므로 조금 덜 아프다
          return this.startWindup(m, who, now, 'split', { d: 3600, r: 5.5, pid: who.id, pct: cands.length > 1 ? RAID.pct.split : RAID.pct.splitSolo });
        }
        if (ph >= 1 && now >= m.nextAdds) {
          m.nextAdds = now + 42000;
          return this.startWindup(m, tgt, now, 'roar', { d: 1100 });
        }
      } else {
        // 체력이 2/3, 1/3 아래로 내려갈 때 부하를 부른다
        const want = frac < 0.34 ? 2 : frac < 0.67 ? 1 : 0;
        if ((m.summons || 0) < want) {
          m.summons = (m.summons || 0) + 1;
          return this.startWindup(m, tgt, now, 'roar', { d: 1100 });
        }
      }
      const moves = this.boss2Moves(m.type, d, Math.random(), ph, cands.length);
      m.combo = moves.slice(1);
      return this.boss2Start(m, tgt, now, moves[0], cands);
    }
    if (d > Math.max(3.5, m.radius + 2.2)) this.moveToward(m, tgt.x, tgt.z, m.def.speed * T.speed[ph] * dt);
    else m.yaw = Math.atan2(tgt.x - m.x, tgt.z - m.z);
  }

  // ---------- 레이드 「잠든 별의 심장」 ----------
  // 그 구역 안에 있는 사람들에게만 알린다
  broadcastZone(z, obj) {
    const s = JSON.stringify(obj);
    for (const p of this.players.values()) if (p.joined && p.zone === z.def.id && p.ws.readyState === 1) p.ws.send(s);
  }

  inRaid(p) {
    return p.zone > 0 && this.zones[p.zone - 1].def.kind === 'raid';
  }

  // 보스의 체력을 모인 사람 수에 맞춘다 (싸우는 도중에 사람이 더 오면 그만큼 늘어난다. 줄어들지는 않는다)
  // m.power: 지금까지 가장 많았던 사람 수
  raidScale(m, players) {
    let n = 0;
    for (const p of players) {
      if (p.zone !== m.zone) continue;
      n++;
      if (m.fighters) m.fighters.add(p.id);
    }
    if (!n) return;
    if (!m.power) {
      m.maxHp = m.hp = Math.round(n * RAID.unit * RAID.hpHits * cycleScale(this.cycle));
      m.power = n;
    } else if (n > m.power) {
      const k = n / m.power;
      m.maxHp = Math.round(m.maxHp * k);
      m.hp = Math.round(m.hp * k);
      m.power = n;
    }
  }

  raidEngage(m, z, now, players) {
    m.engageAt = now;
    m.casts = 0;
    m.enraged = false;
    m.power = 0;
    m.fighters = new Set(); // 이 싸움에 함께한 사람들
    m.nextSplit = now + 22000;
    m.nextAdds = now + 20000;
    m.nextAtk = now + 1200;
    this.raidScale(m, players);
    this.broadcastZone(z, { t: 'rd', k: 'start', id: m.id, left: RAID.enrageMs });
  }

  raidReset(m, z) {
    m.cast = null;
    m.casts = 0;
    m.engageAt = 0;
    m.enraged = false;
    m.weakUntil = 0;
    m.power = 0;
    m.fighters = null;
    for (const q of z.mobs) if (q.minion) q.alive = false;
    this.applyStats(m);
    this.broadcastZone(z, { t: 'rd', k: 'reset', id: m.id });
  }

  // 불려 나온 부하의 체력도 모인 사람들의 힘에 맞춘다
  summonRaidAdds(m, z, count) {
    let n = 0;
    for (const q of z.mobs) {
      if (!q.minion || q.alive || q.def.fixed) continue;
      q.maxHp = q.hp = RAID.unit * RAID.addHits;
      q.alive = true;
      q.x = q.hx;
      q.z = q.hz;
      q.state = MSTATE.IDLE;
      q.target = 0;
      q.freshUntil = this.tickCount + 6;
      if (++n >= count) break;
    }
  }

  // 「별 삼키기」: 보스가 방패를 두르고 주문을 왼다. 사슬 기둥을 모두 부수면 끊긴다.
  // 기둥은 싸우는 사람 수만큼(많아야 넷) 서고, 거의 동시에 부숴야 한다 — 먼저 부순 기둥은 다른 기둥이 남아 있으면 되살아난다.
  startRaidCast(m, z, now, ms, breakable, cands) {
    const all = z.mobs.filter((q) => q.def.fixed);
    const want = breakable ? Math.max(1, Math.min(all.length, cands.length)) : 0;
    let chosen = [];
    if (want >= all.length) chosen = all;
    else if (want === 2) {
      // 마주 보는 두 모퉁이
      const a = all[Math.floor(Math.random() * all.length)];
      let far = a;
      for (const q of all) if (dist(q.hx, q.hz, a.hx, a.hz) > dist(far.hx, far.hz, a.hx, a.hz)) far = q;
      chosen = [a, far];
    } else if (want > 0) {
      const pool = all.slice().sort(() => Math.random() - 0.5);
      chosen = pool.slice(0, want);
    }
    for (const q of chosen) {
      q.maxHp = q.hp = RAID.unit * RAID.pylonHits;
      q.alive = true;
      q.x = q.hx;
      q.z = q.hz;
      q.state = MSTATE.IDLE;
      q.freshUntil = this.tickCount + 6;
    }
    m.cast = { until: now + ms, pylons: chosen, dead: new Map(), breakable };
    m.combo = null;
    this.startWindup(m, null, now, 'wipe', { d: ms, n: chosen.length, pts: chosen.map((q) => [+q.hx.toFixed(1), +q.hz.toFixed(1)]) });
  }

  updateRaidCast(m, z, now) {
    const c = m.cast;
    if (c.breakable) {
      let alive = 0;
      for (const q of c.pylons) {
        if (q.alive) alive++;
        else if (!c.dead.has(q)) c.dead.set(q, now);
      }
      if (alive === 0) {
        // 사슬이 모두 끊겼다: 보스가 쓰러져 한동안 크게 다친다
        m.cast = null;
        m.state = MSTATE.STAGGER;
        m.pattern = null;
        m.until = now + RAID.stunMs;
        m.weakUntil = m.until;
        m.nextAtk = m.until + 700;
        this.broadcastZone(z, { t: 'rd', k: 'break', id: m.id, d: RAID.stunMs });
        return;
      }
      for (const [q, at] of c.dead) {
        if (now - at < RAID.regrowMs) continue;
        q.alive = true;
        q.hp = q.maxHp;
        q.freshUntil = this.tickCount + 6;
        c.dead.delete(q);
        this.broadcastZone(z, { t: 'rd', k: 'regrow', id: q.id });
      }
    }
    if (now >= c.until) {
      // 끝까지 외웠다: 방 안의 모두가 쓰러진다 (각자의 화면에서 판정한다)
      for (const q of c.pylons) q.alive = false;
      m.cast = null;
      m.state = MSTATE.RECOVER;
      m.until = now + 1600;
      m.nextAtk = now + 3200;
      if (!c.breakable) {
        // 그래도 버틴 사람이 있다면 곧 다시 삼킨다
        m.enraged = false;
        m.engageAt = now - RAID.enrageMs + 12000;
      }
    }
  }

  onBossDead(m, now) {
    this.bossState = 'dead';
    this.resetAt = now + 90000;
    for (const id of this.pois.minionIds[m.arena]) this.monsters[id].alive = false;
    this.broadcast({ t: 'world', state: this.worldState(), ev: 'victory' });
  }

  // 다음 장으로: 별조각이 다른 곳에 다시 흩어진다. 세 장을 모두 마쳤다면 세상이 한층 험해진다
  newCycle() {
    this.cycle += 1;
    this.shards.clear();
    this.bossState = 'sleep';
    this.resetAt = 0;
    for (const b of this.bosses) b.alive = false;
    for (const list of this.pois.minionIds) for (const id of list) this.monsters[id].alive = false;
    for (const m of this.monsters) {
      if (m.boss || m.minion || m.zone) continue;
      this.applyStats(m);
      this.respawn(m);
    }
    // 시련장·던전: 비어 있는 곳만 지금 되돌린다 (안에 사람이 있으면 나간 뒤에 되돌아간다)
    for (const z of this.zones) if (z.players === 0) this.resetZone(z);
    this.recomputeSeals(true);
    this.persist();
    this.broadcast({ t: 'world', state: this.worldState(), ev: 'cycle' });
  }

  // ---------- 플레이어 ----------
  profileOf(p) {
    return { id: p.id, name: p.name, tunic: p.tunic, hair: p.hair, lvl: p.lvl, eq: p.eq, mc: p.mc, mk: p.mk, pv: p.pv, sp: p.sp, rw: p.rw, jc: p.job.c, jt: p.job.t };
  }

  applyProfile(p, d) {
    if (!d || typeof d !== 'object') return;
    if (d.name !== undefined) p.name = cleanText(d.name, 12) || '모험가';
    if (d.tunic !== undefined) p.tunic = clampInt(d.tunic, 0, TUNIC_COLORS.length - 1);
    if (d.hair !== undefined) p.hair = clampInt(d.hair, 0, HAIR_COLORS.length - 1);
    if (d.lvl !== undefined) p.lvl = clampInt(d.lvl, 1, MAX_LEVEL);
    if (d.mc !== undefined) p.mc = clampInt(d.mc, 0, MOUNT_COLORS.length - 1);
    if (d.mk !== undefined) p.mk = clampInt(d.mk, 0, MOUNT_KEYS.length - 1); // 타는 탈것의 종류
    if (d.pv !== undefined) p.pv = d.pv ? 1 : 0; // 결투 모드
    if (d.sp !== undefined) p.sp = d.sp ? 1 : 0; // 바람 정령 하늬와 함께 다닌다
    if (d.rw !== undefined) p.rw = clampInt(d.rw, 0, 9999); // 레이드를 이긴 횟수
    if (d.eq && typeof d.eq === 'object') {
      // 착용 장비: 칸에 맞는 종류만 받는다
      const eq = {};
      for (const slot of SLOTS) {
        const it = cleanItem(d.eq[slot]);
        eq[slot] = it && slotOf(it.t) === slot ? it : null;
      }
      p.eq = eq;
    }
    // 시련 보상으로 늘어난 체력·기력
    if (d.bh !== undefined) p.bonus.hp = clampInt(d.bh, 0, 60);
    if (d.bs !== undefined) p.bonus.sta = clampInt(d.bs, 0, 150);
    // 직업과 전직 차수 (레벨이 모자라면 그만큼 낮춘다)
    if (d.jc !== undefined || d.jt !== undefined) {
      const jc = clampInt(d.jc, 0, 99);
      p.jobRaw = { c: jc < JOBS.length ? jc : 0, t: clampInt(d.jt, 0, 4) };
    }
    const wasJob = p.job.c;
    p.job = cleanJob(p.jobRaw, p.lvl);
    if (p.job.c !== wasJob) p.skCd.fill(0); // 다른 길로 옮기면 새 기술을 바로 쓸 수 있다
    const st = gearStats(p.lvl, p.eq, p.bonus, p.job);
    p.cdK = st.cdK; // 기술을 다시 쓰기까지의 시간, 기술 피해 배율
    p.skillK = st.skillK;
    p.wk = st.kind;
    p.atk = st.atk;
    p.bowAtk = st.bowAtk;
    p.crit = st.crit;
    p.critMul = st.critMul; // 레벨 능력: 치명타 피해 배율, 마지막 일격 배율
    p.finMul = st.finMul;
    p.bowCrit = st.bowCrit;
    p.fx = st.fx; // 히든 무기의 고유한 힘
    p.bowFx = st.bowFx;
    p.maxHp = st.maxHp;
  }

  addPlayer(ws) {
    if (this.freeIds.length === 0) return null;
    const id = this.freeIds.pop();
    const p = {
      id, ws, joined: false, name: '모험가', tunic: 0, hair: 0, lvl: 1, mc: 0, mk: 0, pv: 0, sp: 0, rw: 0, lastGust: 0, pvSafe: 0, pvLast: null, pvDot: null, pvArrow: 0, pvArrowN: 0,
      fx: null, bowFx: null, bowCrit: 0, powerUntil: 0, lastProc: 0,
      job: { c: 0, t: 0 }, jobRaw: null, cdK: 1, skillK: 1, skCd: [0, 0, 0, 0], skUse: [null, null, null, null], hideUntil: 0,
      eq: { weapon: makeItem('sword', 0, 1), bow: makeItem('bow', 0, 1), armor: null, helm: null, charm: null }, bonus: { hp: 0, sta: 0 },
      wk: 'sword', atk: 4, bowAtk: 5, crit: 0.1, critMul: 2, finMul: 1, maxHp: 6, hp: 6, trade: null, trReq: 0, trReqAt: 0, zone: 0,
      x: VILLAGE.x, y: VILLAGE.h, z: VILLAGE.z + 21, yaw: Math.PI, anim: 0, alive: true,
      lastMsg: Date.now(), lastAtk: 0, lastChat: 0, chatBurst: 0, msgCount: 0, msgWindow: Date.now(),
    };
    this.players.set(id, p);
    return p;
  }

  removePlayer(p) {
    if (!this.players.has(p.id)) return;
    this.endTrade(p);
    this.players.delete(p.id);
    this.freeIds.push(p.id);
    if (p.joined) {
      this.broadcast({ t: 'pl', id: p.id });
      console.log(`[leave] ${p.name} (${this.joinedCount()}명 접속 중)`);
    }
  }

  joinedCount() {
    let n = 0;
    for (const p of this.players.values()) if (p.joined) n++;
    return n;
  }

  send(p, obj) {
    if (p.ws.readyState === 1) p.ws.send(typeof obj === 'string' ? obj : JSON.stringify(obj));
  }

  broadcast(obj, exceptId = 0) {
    const s = JSON.stringify(obj);
    for (const p of this.players.values()) {
      if (p.joined && p.id !== exceptId && p.ws.readyState === 1) p.ws.send(s);
    }
  }

  // 가까이 있는 사람에게만 보낸다 (시련장·던전 안의 일은 그 안에 있는 사람에게만)
  broadcastNear(x, z, r, obj, exceptId = 0) {
    const s = JSON.stringify(obj);
    const zid = zoneIdAt(x, z);
    for (const p of this.players.values()) {
      if (!p.joined || p.id === exceptId || p.ws.readyState !== 1 || p.zone !== zid) continue;
      if (dist(p.x, p.z, x, z) <= r) p.ws.send(s);
    }
  }

  onBinary(p, buf) {
    if (!p.joined || buf.length < P.STATE_SIZE || buf[0] !== P.PKT_STATE) return;
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    P.decodeState(dv, p);
    p.zone = zoneIdAt(p.x, p.z);
    const wasAlive = p.alive;
    p.alive = p.anim !== ANIM.DEAD && p.hp > 0;
    if (wasAlive && !p.alive) {
      // 결투에서 쓰러졌다면 누가 쓰러뜨렸는지 알린다
      const k = p.pvLast && Date.now() - p.pvLast.at < 6000 ? this.players.get(p.pvLast.by) : null;
      p.pvLast = null;
      p.pvDot = null;
      if (k && k.joined) {
        this.broadcast({ t: 'sys', text: `⚔ ${k.name} 님이 결투에서 ${p.name} 님을 쓰러뜨렸습니다!` });
        this.send(k, { t: 'pvw', name: p.name });
      } else this.broadcast({ t: 'sys', text: `${p.name} 님이 쓰러졌습니다…` });
    } else if (!wasAlive && p.alive) p.pvSafe = Date.now() + PVP_PROTECT_MS;
  }

  onMessage(p, msg) {
    const now = Date.now();
    switch (msg.t) {
      case 'join': {
        if (p.joined) return;
        if (msg.v !== P.PROTO_VER) {
          // 옛 판의 화면(서버가 새로 올라오기 전에 열어 둔 탭)이다. 세계의 씨앗이 다르다고 답하면 화면이 스스로 새로고침한다
          this.send(p, { t: 'welcome', id: 0, now, tick: TICK_MS, seed: -1, me: null, players: [], state: this.worldState() });
          return;
        }
        this.applyProfile(p, msg.prof);
        p.hp = p.maxHp;
        p.joined = true;
        const merged = this.mergeSave(msg.save);
        const others = [];
        for (const q of this.players.values()) if (q.joined && q.id !== p.id) others.push(this.profileOf(q));
        this.send(p, { t: 'welcome', id: p.id, now, tick: TICK_MS, seed: this.seed, me: this.profileOf(p), players: others, state: this.worldState() });
        this.broadcast({ t: 'pj', p: this.profileOf(p) }, p.id);
        if (merged) this.broadcast({ t: 'world', state: this.worldState(), ev: 'restore' }, p.id);
        console.log(`[join] ${p.name} (${this.joinedCount()}명 접속 중)`);
        return;
      }
      case 'ping':
        this.send(p, { t: 'pong', c: msg.c, s: now });
        return;
      default:
    }
    if (!p.joined) return;
    switch (msg.t) {
      case 'prof': {
        const was = p.job.t;
        this.applyProfile(p, msg.prof);
        this.broadcast({ t: 'pp', p: this.profileOf(p) }, p.id);
        // 전직했다면 모두에게 알린다
        if (p.job.t > was) this.broadcast({ t: 'sys', text: `🎖 ${p.name} 님이 ${p.job.t}차 전직을 했습니다 — 「${jobTitle(p.job)}」!` }, p.id);
        return;
      }
      case 'a': {
        // 무기 종류에 따라 연속 공격의 피해 배율과 밀어내는 힘이 다르다
        const wpn = WEAPONS[p.wk] || WEAPONS.sword;
        if (!p.alive || !Array.isArray(msg.ids)) return;
        // x: 1 = 여명의 대검이 일으킨 빛의 파동 (마지막 일격 뒤에 한 번 더 들어온다)
        const wave = msg.x === 1 && p.fx === 'wave';
        if (wave) {
          if (now - p.lastProc < 600) return;
          p.lastProc = now;
        } else {
          if (now - p.lastAtk < (p.wk === 'dagger' ? 130 : 170)) return;
          p.lastAtk = now;
        }
        const hit = wpn.hits[clampInt(msg.k, 0, wpn.hits.length - 1)];
        // 기마 돌격: 말을 달리며 벨수록 피해가 커진다 (ch: 0~1, 달리는 빠르기)
        const riding = isRiding(p.anim);
        const ch = riding ? Math.max(0, Math.min(1, +msg.ch || 0)) : 0;
        const mount = MOUNTS[MOUNT_KEYS[p.mk]] || MOUNTS.horse;
        const k = clampInt(msg.k, 0, wpn.hits.length - 1);
        const fin = !wave && k === wpn.hits.length - 1 ? p.finMul : 1; // 레벨 능력: 마지막 일격
        // 레이드 안에서는 누구의 한 방이든 같은 무게다 (레벨과 장비의 공격력 대신 정해진 값을 쓴다. 무기 종류와 치명타, 물약은 그대로 듣는다)
        const pw = this.inRaid(p) ? RAID.unit : p.atk;
        const base = pw * (wave ? 1.4 : hit.mult * fin) * (1 + CHARGE_BONUS * ch * mount.charge) * (now < p.powerUntil ? POWER_MULT : 1);
        const reach = wave ? 17 : hit.reach + (riding ? 1.6 : 0);
        const struck = [];
        for (const raw of msg.ids.slice(0, 10)) {
          const m = this.monsters[raw | 0];
          if (!m || !m.alive) continue;
          if (dist(p.x, p.z, m.x, m.z) > reach + 6 + m.radius) continue;
          const crit = Math.random() < p.crit;
          const dmg = base * (0.9 + Math.random() * 0.2) * (crit ? p.critMul : 1);
          // 히든 무기: 서리송곳은 얼려서 느리게, 늪독 쌍날은 독을 남긴다
          if (p.fx === 'frost') m.slowTick = this.tickCount + 30;
          else if (p.fx === 'poison') m.dot = { by: p.id, dmg: Math.max(1, Math.round(pw * 0.22)), n: 6, next: now + 500 };
          this.damageMonster(m, p, Math.max(1, Math.round(dmg)), crit, hit.kb * (1 + ch * 0.5), now, !!(wpn.stagger && hit.quake), p.fx === 'frost' ? 'frost' : wave ? 'wave' : '');
          struck.push(m);
        }
        // 천둥 망치: 내려찍으면 번개가 주변의 적들에게 튄다
        if (p.fx === 'chain' && hit.quake && struck.length) this.chainBolt(p, struck, base, now);
        // 결투: 결투 모드를 켠 상대에게도 닿는다
        if (p.pv && Array.isArray(msg.pids)) {
          for (const raw of msg.pids.slice(0, 6)) {
            const q = this.players.get(raw | 0);
            if (!this.canDuel(p, q, now) || dist(p.x, p.z, q.x, q.z) > reach + 5) continue;
            const crit = Math.random() < p.crit;
            this.pvpHit(p, q, base * (0.9 + Math.random() * 0.2) * (crit ? p.critMul : 1), crit, hit.kb * (1 + ch * 0.5), wave ? 'wave' : p.fx === 'frost' || p.fx === 'poison' ? p.fx : '', now);
          }
        }
        return;
      }
      case 'pvr': {
        // 결투에서 맞은 사람이 알려 주는 결과 (d: 실제로 입은 피해, 0 이면 피했다) -> 주변에 보여 준다
        const k = this.players.get(msg.by | 0);
        if (!p.pv || !k || !p.pvLast || p.pvLast.by !== k.id || now - p.pvLast.at > 3000) return;
        const d = clampInt(msg.d, 0, Math.ceil(p.maxHp * PVP_CAP) + 1);
        this.broadcastNear(p.x, p.z, 130, { t: 'pvh', id: p.id, by: k.id, d, c: msg.c ? 1 : 0, x: typeof msg.x === 'string' ? msg.x.slice(0, 8) : '' }, p.id);
        return;
      }
      case 'pot':
        // 힘의 물약: 서버가 피해를 계산하므로 알려 준다
        if (msg.k === 'power') p.powerUntil = now + POTIONS.power.dur * 1000;
        return;
      case 'tr':
        this.onTrade(p, msg, now);
        return;
      case 'zone': {
        // 구역에 들어온 사람에게 지금의 관문 상태를 알려 준다
        const z = this.zones[(msg.id | 0) - 1];
        if (!z) return;
        this.send(p, this.zoneState(z));
        if (z === this.tower) this.send(p, this.towerInfo(z, 'sync'));
        // 레이드가 한창일 때 들어온 사람에게: 남은 시간과, 외고 있는 「별 삼키기」를 알려 준다 (뒤늦게 들어와도 함께 겪는다)
        const b = z.boss;
        if (b && b.raid && b.alive && b.engageAt) {
          this.send(p, { t: 'rd', k: 'start', id: b.id, left: Math.max(0, RAID.enrageMs - (now - b.engageAt)), late: 1 });
          if (b.cast && b.cast.until - now > 500) {
            this.send(p, {
              t: 'ma', id: b.id, k: 'wipe', x: +b.x.toFixed(2), z: +b.z.toFixed(2), yaw: +b.yaw.toFixed(3), d: b.cast.until - now, dmg: b.dmg, pct: RAID.pct.wipe,
              n: b.cast.pylons.length, pts: b.cast.pylons.map((q) => [+q.hx.toFixed(1), +q.hz.toFixed(1)]),
            });
          }
        }
        return;
      }
      case 'zopen': {
        // 퍼즐을 풀어 여는 관문 (그 구역 안에 있는 사람만 열 수 있다)
        const z = this.zones[p.zone - 1];
        if (!z || !z.def.puzzle || z.def.puzzle.gate !== (msg.gate | 0)) return;
        const bit = 1 << z.def.puzzle.gate;
        if (z.open & bit) return;
        z.open |= bit;
        z.puzzle = bit;
        this.broadcast({ ...this.zoneState(z), by: p.id });
        return;
      }
      case 'tw': {
        // 별의 탑: 층을 시작하거나(start), 다음 층으로 올라간다(next)
        const z = this.tower;
        if (!z) return;
        this.towerStart(z, p, msg.a === 'next' ? 0 : msg.f | 0, now);
        return;
      }
      case 'lamp': {
        // 숨겨진 던전의 돌등을 밝혔다: 근처에 있는 친구들의 돌등도 함께 켜진다
        const ent = this.pois.zones[(msg.z | 0) - 1];
        const k = msg.k | 0;
        if (!ent || !ent.lamps[k] || dist(p.x, p.z, ent.lamps[k].x, ent.lamps[k].z) > 12) return;
        this.broadcastNear(p.x, p.z, 160, { t: 'lamp', z: ent.id, k, by: p.id }, p.id);
        return;
      }
      case 'sk': {
        // 직업 기술. c: 1 = 쓰기 시작(재사용 시간이 돌기 시작한다), 그 밖에는 그 기술의 타격
        const J = JOBS[p.job.c];
        const k = msg.k | 0;
        if (!p.alive || !J || k < 0 || k >= p.job.t) return;
        const sk = J.skills[k];
        if (sk.stat === 'bow' && !p.bowAtk) return;
        if (msg.c) {
          if (now < p.skCd[k] - 500) return; // 아직 다시 쓸 수 없다 (통신이 늦는 만큼은 봐준다)
          p.skCd[k] = now + sk.cd * 1000 * p.cdK;
          p.skUse[k] = { until: now + sk.window + 500, n: 0, prim: false };
          // 주변 사람들에게 연출을 보여 준다 (x, z: 겨눈 자리, pts: 옮겨 다닌 자리들)
          const n1 = (v) => (Number.isFinite(+v) ? +(+v).toFixed(1) : 0);
          const ev = { t: 'skx', by: p.id, c: p.job.c, k, x: n1(msg.x), y: n1(msg.y), z: n1(msg.z), yaw: +(+msg.yaw || 0).toFixed(2) };
          if (Array.isArray(msg.pts)) ev.pts = msg.pts.slice(0, 8).map((q) => (Array.isArray(q) ? [n1(q[0]), n1(q[1])] : [0, 0]));
          this.broadcastNear(p.x, p.z, 150, ev, p.id);
          if (sk.effect === 'hide') p.hideUntil = now + sk.dur * 1000;
          else if (sk.effect) {
            // 곁에 있는 사람들도 함께 받는다 (결투 중인 상대는 빼고)
            for (const q of this.players.values()) {
              if (q === p || !q.joined || !q.alive || q.zone !== p.zone || dist(q.x, q.z, p.x, p.z) > sk.r) continue;
              if (this.canDuel(p, q, now)) continue;
              this.send(q, { t: 'skb', by: p.id, c: p.job.c, k });
            }
          }
          return;
        }
        const use = p.skUse[k];
        if (!sk.stat || !use || now > use.until || use.n >= sk.hits || !Array.isArray(msg.ids)) return;
        use.n++;
        // s: 1 = 여파 (별똥 화살의 폭발). 첫 타격은 한 번만 받는다
        const second = !!(msg.s && sk.mult2);
        if (sk.mult2 && !second) {
          if (use.prim) return;
          use.prim = true;
        }
        const bow = sk.stat === 'bow';
        // 레이드 안에서는 누구의 기술이든 같은 무게다
        const pw = this.inRaid(p) ? RAID.unit * (bow ? RAID.bow : 1) : bow ? p.bowAtk : p.atk;
        const base = pw * (second ? sk.mult2 : sk.mult) * p.skillK * (now < p.powerUntil ? POWER_MULT : 1);
        const critP = p.crit + (bow ? 0.05 + p.bowCrit : 0) + (sk.critUp || 0);
        const max = second ? sk.max2 : sk.max;
        for (const raw of msg.ids.slice(0, max)) {
          const m = this.monsters[raw | 0];
          if (!m || !m.alive || m.zone !== p.zone) continue;
          if (dist(p.x, p.z, m.x, m.z) > sk.range + 6 + m.radius) continue;
          const crit = Math.random() < critP;
          const dmg = base * (0.9 + Math.random() * 0.2) * (crit ? p.critMul : 1);
          this.damageMonster(m, p, Math.max(1, Math.round(dmg)), crit, sk.kb, now, sk.heavy, 'sk');
        }
        // 결투: 결투 모드를 켠 상대에게도 닿는다
        if (p.pv && Array.isArray(msg.pids)) {
          for (const raw of msg.pids.slice(0, Math.min(6, max))) {
            const q = this.players.get(raw | 0);
            if (!this.canDuel(p, q, now) || dist(p.x, p.z, q.x, q.z) > sk.range + 6) continue;
            const crit = Math.random() < critP;
            this.pvpHit(p, q, base * (0.9 + Math.random() * 0.2) * (crit ? p.critMul : 1), crit, sk.kb, '', now);
          }
        }
        return;
      }
      case 'ar': {
        if (!p.alive || !p.bowAtk) return;
        if (msg.pid !== undefined) {
          // 결투 상대에게 맞은 화살 (바람가르기의 세 발까지는 한꺼번에 받는다)
          const q = this.players.get(msg.pid | 0);
          if (!p.pv || !this.canDuel(p, q, now) || dist(p.x, p.z, q.x, q.z) > 95) return;
          if (now - p.pvArrow < 250 && ++p.pvArrowN > 3) return;
          if (now - p.pvArrow >= 250) {
            p.pvArrow = now;
            p.pvArrowN = 1;
          }
          const crit = Math.random() < p.crit + 0.05 + p.bowCrit;
          this.pvpHit(p, q, p.bowAtk * (p.bowFx === 'multi' ? 0.62 : 1) * (now < p.powerUntil ? POWER_MULT : 1) * (0.9 + Math.random() * 0.2) * (crit ? p.critMul : 1), crit, 3.5, '', now);
          return;
        }
        const m = this.monsters[msg.id | 0];
        if (!m || !m.alive || dist(p.x, p.z, m.x, m.z) > 95) return;
        const crit = Math.random() < p.crit + 0.05 + p.bowCrit;
        // 바람가르기는 세 발을 한꺼번에 쏘는 대신 한 발의 힘이 덜하다
        const dmg = (this.inRaid(p) ? RAID.unit * RAID.bow : p.bowAtk) * (p.bowFx === 'multi' ? 0.62 : 1) * (now < p.powerUntil ? POWER_MULT : 1) * (0.9 + Math.random() * 0.2) * (crit ? p.critMul : 1);
        this.damageMonster(m, p, Math.max(1, Math.round(dmg)), crit, 3.5, now);
        return;
      }
      case 'gust': {
        // 바람 정령이 일으킨 바람 기둥: 가까이 있는 친구들도 함께 타고 오를 수 있다 (실내에서는 불지 않는다)
        if (!p.alive || p.zone || now - p.lastGust < 700) return;
        const n = (v) => (Number.isFinite(+v) ? +(+v).toFixed(1) : 0);
        const gx = n(msg.x);
        const gz = n(msg.z);
        if (dist(gx, gz, p.x, p.z) > 12) return;
        p.lastGust = now;
        this.broadcastNear(p.x, p.z, 220, { t: 'gust', by: p.id, x: gx, y: n(msg.y), z: gz }, p.id);
        return;
      }
      case 'shot': {
        const n = (v) => (Number.isFinite(+v) ? +(+v).toFixed(2) : 0);
        this.broadcastNear(p.x, p.z, 150, { t: 'shot', by: p.id, x: n(msg.x), y: n(msg.y), z: n(msg.z), dx: n(msg.dx), dy: n(msg.dy), dz: n(msg.dz) }, p.id);
        return;
      }
      case 'shard': {
        const s = this.pois.shards[msg.id | 0];
        if (!s || s.ch !== this.chapter || this.shards.has(s.id) || this.bossState === 'dead') return;
        if (dist(p.x, p.z, s.x, s.z) > 8) return;
        if (this.sealed.has(s.id)) {
          this.send(p, { t: 'sys', text: '수호자를 모두 쓰러뜨려야 봉인이 풀립니다!' });
          return;
        }
        this.shards.add(s.id);
        this.pristine = false;
        this.persist();
        this.broadcast({ t: 'sg', id: s.id, by: p.id, n: this.shards.size });
        this.broadcast({ t: 'world', state: this.worldState() });
        if (this.shards.size >= SHARD_COUNT && this.bossState === 'sleep') this.wakeBoss();
        return;
      }
      case 'debug': {
        // 개발용 명령 (환경 변수 DEBUG_CMDS=1 일 때만 동작)
        if (!process.env.DEBUG_CMDS) return;
        if (msg.cmd === 'allshards') {
          for (let i = 0; i < SHARD_COUNT; i++) this.shards.add(this.chapter * SHARD_COUNT + i);
          this.pristine = false;
          this.recomputeSeals(true);
          this.broadcast({ t: 'world', state: this.worldState() });
          if (this.bossState === 'sleep') this.wakeBoss();
        } else if (msg.cmd === 'kill') {
          const m = this.monsters[msg.id | 0];
          if (m && m.alive) this.damageMonster(m, p, m.hp + 1, false, 0, now);
        } else if (msg.cmd === 'hurt') {
          // 몬스터의 체력을 비율로 맞춘다 (보스 단계 시험용)
          const m = this.monsters[msg.id | 0];
          if (m && m.alive) m.hp = Math.max(1, Math.round(m.maxHp * Math.min(1, Math.max(0.01, +msg.frac || 0.5))));
        } else if (msg.cmd === 'bosshp') {
          this.boss.hp = Math.max(1, Math.min(this.boss.maxHp, msg.hp | 0));
        } else if (msg.cmd === 'cycle') {
          this.newCycle();
        } else if (msg.cmd === 'twkill') {
          if (this.tower) for (const m of [...this.tower.wave]) if (m.alive) this.damageMonster(m, p, m.hp + 1, false, 0, now);
        } else if (msg.cmd === 'chapter') {
          // 장을 바로 옮긴다 (n: 지금까지 쓰러뜨린 마지막 상대의 수)
          this.cycle = clampInt(msg.n, 0, 999) - 1;
          this.newCycle();
        }
        return;
      }
      case 'chat': {
        const text = cleanText(msg.text, 100);
        if (!text) return;
        if (now - p.lastChat > 6000) p.chatBurst = 0;
        if (++p.chatBurst > 6) return;
        p.lastChat = now;
        this.broadcast({ t: 'chat', id: p.id, name: p.name, text });
        return;
      }
      default:
    }
  }

  // ---------- 결투 (PvP) ----------
  // 둘 다 결투 모드를 켰고, 살아 있고, 마을과 시련장·던전 밖에 있을 때만 서로 공격할 수 있다
  canDuel(p, q, now) {
    if (!q || q === p || !q.joined || !p.pv || !q.pv || !p.alive || !q.alive) return false;
    if (p.zone || q.zone || now < q.pvSafe) return false;
    return dist(p.x, p.z, VILLAGE.x, VILLAGE.z) > PVP_SAFE_R && dist(q.x, q.z, VILLAGE.x, VILLAGE.z) > PVP_SAFE_R;
  }

  // raw: 몬스터에게 들어갔을 피해. 맞은 사람의 화면에서 실제로 적용하고(구르기로 피할 수 있다) 결과를 돌려준다
  pvpHit(p, q, raw, crit, kb, tag, now) {
    const d = Math.max(1, Math.min(Math.ceil(q.maxHp * PVP_CAP), Math.round(raw * PVP_SCALE)));
    q.pvLast = { by: p.id, at: now };
    this.send(q, { t: 'pvq', by: p.id, d, c: crit ? 1 : 0, kb: Math.round(kb), x: tag, ax: +p.x.toFixed(1), az: +p.z.toFixed(1) });
    // 늪독 쌍날: 독이 잠깐 이어진다
    if (tag === 'poison') q.pvDot = { by: p.id, d: Math.max(1, Math.round(d * 0.25)), n: 4, next: now + 700 };
  }

  // ---------- 친구와 교환 ----------
  // 가방은 각자의 기기에 있으므로, 서버는 양쪽이 올린 물건을 전달하고 둘 다 확인했을 때 동시에 성사시킨다.
  onTrade(p, msg, now) {
    const a = msg.a;
    if (a === 'req') {
      const q = this.players.get(msg.to | 0);
      if (!q || !q.joined || q === p || now - p.trReqAt < 1500) return;
      if (p.trade || q.trade) {
        this.send(p, { t: 'tr', a: 'busy', name: q.name });
        return;
      }
      p.trReqAt = now;
      p.trReq = q.id;
      this.send(q, { t: 'tr', a: 'req', from: p.id, name: p.name });
      return;
    }
    if (a === 'acc' || a === 'dec') {
      const q = this.players.get(msg.from | 0);
      if (!q || !q.joined || q.trReq !== p.id) {
        if (a === 'acc') this.send(p, { t: 'tr', a: 'cancel' });
        return;
      }
      q.trReq = 0;
      if (a === 'dec') {
        this.send(q, { t: 'tr', a: 'dec', name: p.name });
        return;
      }
      if (p.trade || q.trade) {
        this.send(p, { t: 'tr', a: 'cancel' });
        return;
      }
      const tr = { a: q, b: p, offers: new Map([[q.id, { items: [], gold: 0, ok: false, ver: 0 }], [p.id, { items: [], gold: 0, ok: false, ver: 0 }]]) };
      p.trade = q.trade = tr;
      this.send(q, { t: 'tr', a: 'open', with: p.id, name: p.name });
      this.send(p, { t: 'tr', a: 'open', with: q.id, name: q.name });
      return;
    }
    const tr = p.trade;
    if (!tr) return;
    const other = tr.a === p ? tr.b : tr.a;
    const mine = tr.offers.get(p.id);
    const theirs = tr.offers.get(other.id);
    if (a === 'offer') {
      mine.items = (Array.isArray(msg.items) ? msg.items : []).slice(0, 6).map(cleanItem).filter(Boolean);
      mine.gold = clampInt(msg.gold, 0, 9999999);
      mine.ver++;
      // 내용이 바뀌면 양쪽 확인을 모두 푼다
      mine.ok = theirs.ok = false;
      this.send(other, { t: 'tr', a: 'offer', items: mine.items, gold: mine.gold, ver: mine.ver });
    } else if (a === 'ok') {
      // 상대가 마지막으로 올린 내용을 보고 누른 확인만 받는다
      if (msg.v && (msg.seen | 0) !== theirs.ver) return;
      mine.ok = !!msg.v;
      this.send(other, { t: 'tr', a: 'ok', v: mine.ok ? 1 : 0 });
      if (mine.ok && theirs.ok) {
        p.trade = other.trade = null;
        this.send(p, { t: 'tr', a: 'done', give: { items: mine.items, gold: mine.gold }, get: { items: theirs.items, gold: theirs.gold }, name: other.name });
        this.send(other, { t: 'tr', a: 'done', give: { items: theirs.items, gold: theirs.gold }, get: { items: mine.items, gold: mine.gold }, name: p.name });
      }
    } else if (a === 'cancel') this.endTrade(p);
  }

  endTrade(p) {
    const tr = p.trade;
    if (!tr) return;
    const other = tr.a === p ? tr.b : tr.a;
    p.trade = other.trade = null;
    this.send(other, { t: 'tr', a: 'cancel', name: p.name });
  }

  // ---------- 메인 루프 ----------
  tick() {
    const now = Date.now();
    const dt = TICK_MS / 1000;
    this.tickCount++;
    const players = [];
    for (const p of this.players.values()) if (p.joined) players.push(p);

    if (this.resetAt && now >= this.resetAt) this.newCycle();
    if (this.tickCount % 5 === 0) this.tickZones(now, players);
    // 결투에서 걸린 독
    for (const q of players) {
      const t = q.pvDot;
      if (!t || now < t.next) continue;
      t.next = now + 700;
      if (--t.n <= 0) q.pvDot = null;
      if (!q.alive || !q.pv) {
        q.pvDot = null;
        continue;
      }
      q.pvLast = { by: t.by, at: now };
      this.send(q, { t: 'pvq', by: t.by, d: t.d, c: 0, kb: 0, x: 'dot', ax: q.x, az: q.z });
    }

    const active = [];
    const R2 = ACTIVE_R * ACTIVE_R;
    for (const m of this.monsters) {
      if (!m.alive) {
        if (m.respawnAt && now >= m.respawnAt) {
          let ok = true;
          for (const p of players) if (dist(p.x, p.z, m.hx, m.hz) < 45) { ok = false; break; }
          if (ok) this.respawn(m);
          else m.respawnAt = now + 5000;
        }
        continue;
      }
      let near = Infinity;
      for (const p of players) {
        const dx = p.x - m.x;
        const dz = p.z - m.z;
        const d2 = dx * dx + dz * dz;
        if (d2 < near) near = d2;
      }
      if (near > R2) {
        if (!m.boss && (m.state !== MSTATE.IDLE || m.x !== m.hx || m.z !== m.hz || m.hp !== m.maxHp)) {
          m.x = m.hx;
          m.z = m.hz;
          m.hp = m.maxHp;
          m.state = MSTATE.IDLE;
          m.target = 0;
          m.kvx = m.kvz = 0;
        }
        continue;
      }
      active.push(m);
      if (m.dot && now >= m.dot.next) {
        // 늪독 쌍날의 독: 0.5초마다 피해
        const src = this.players.get(m.dot.by);
        const tick = m.dot;
        tick.next = now + 500;
        if (--tick.n <= 0 || !src) m.dot = null;
        if (src) this.damageMonster(m, src, tick.dmg, false, 0, now, false, 'poison');
        if (!m.alive) continue;
      }
      this.updateMonster(m, now, dt, players);
      if (m.state !== m.prevState) {
        m.prevState = m.state;
        m.freshUntil = this.tickCount + 3;
      }
    }

    // 몬스터끼리 겹치지 않게 밀어내기
    for (let i = 0; i < active.length; i++) {
      const a = active[i];
      if (a.boss || a.def.fixed || a.state === MSTATE.WINDUP) continue;
      for (let j = i + 1; j < active.length; j++) {
        const b = active[j];
        if (b.boss || b.def.fixed || b.state === MSTATE.WINDUP) continue;
        const dx = b.x - a.x;
        const dz = b.z - a.z;
        const rr = (a.radius + b.radius) * 0.85;
        const d2 = dx * dx + dz * dz;
        if (d2 >= rr * rr || d2 < 1e-6) continue;
        const d = Math.sqrt(d2);
        const push = (rr - d) * 0.5;
        const nx = dx / d;
        const nz = dz / d;
        this.tryMove(a, -nx * push, -nz * push);
        this.tryMove(b, nx * push, nz * push);
      }
    }

    // 스냅샷 전송
    const tc = this.tickCount;
    const V2 = VIEW_R * VIEW_R;
    const vis = [];
    for (const p of players) {
      if (p.ws.readyState !== 1) continue;
      vis.length = 0;
      for (const m of active) {
        if (m.zone !== p.zone) continue;
        const dx = p.x - m.x;
        const dz = p.z - m.z;
        if (dx * dx + dz * dz > V2) continue;
        // 데이터 절약: 가만히 있는 몬스터는 0.5초마다, 어슬렁거리는 몬스터는 0.2초마다만 보낸다
        if (m.state === MSTATE.IDLE && m.kvx === 0 && m.kvz === 0) {
          if ((tc + m.id) % 5 !== 0 && m.freshUntil < tc) continue;
        } else if (m.state === MSTATE.WALK) {
          if ((tc + m.id) % 2 !== 0 && m.freshUntil < tc) continue;
        }
        vis.push(m);
      }
      const nP = players.length - 1;
      const buf = Buffer.allocUnsafe(P.snapSize(nP, vis.length));
      const dv = new DataView(buf.buffer, buf.byteOffset, buf.length);
      let o = P.writeSnapHeader(dv, now, nP, vis.length);
      for (const q of players) {
        if (q === p) continue;
        o = P.writeSnapPlayer(dv, o, q);
      }
      for (const m of vis) {
        dv.setUint16(o, m.id);
        dv.setInt16(o + 2, P.q(m.x));
        dv.setInt16(o + 4, P.q(m.z));
        dv.setUint8(o + 6, P.yawToByte(m.yaw));
        const hp5 = Math.max(0, Math.min(31, Math.ceil((31 * m.hp) / m.maxHp)));
        dv.setUint8(o + 7, (m.state & 7) | (hp5 << 3));
        o += P.SNAP_MONSTER;
      }
      p.ws.send(buf, { binary: true });
    }
  }

  status() {
    return {
      players: this.joinedCount(),
      cycle: this.cycle,
      chapter: this.chapter + 1,
      shards: this.shards.size,
      boss: this.bossState,
    };
  }
}

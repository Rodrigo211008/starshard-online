// 전리품: 몬스터와 보물상자에서 나오는 장비와 강화 재료.
// 각자 자기 몫이 자기 화면에만 떨어지므로 친구와 다툴 일이 없다.
import * as THREE from '/vendor/three/three.module.js';
import { RARITY, SLOT_NAME, rollItem, itemName, slotOf } from '/shared/defs.js';
import { Geo, M } from './geo.js';

const LIFE = 150; // 바닥에 남아 있는 시간(초)

export class Loot {
  constructor(game) {
    this.game = game;
    this.scene = game.gfx.scene;
    this.drops = [];
    this.fullT = 0;
    this.hinted = {};
    const mat = game.gfx.matGlow;
    // 장비: 등급 색의 마름모 보석
    this.gearGeo = RARITY.map((r) => {
      const g = new Geo();
      g.cone(0.2, 0.3, 4, M(0, 0.15, 0), r.color);
      g.cone(0.2, 0.3, 4, M(0, -0.15, 0, Math.PI, 0, 0), r.color);
      return g.build(false);
    });
    const dg = new Geo();
    dg.ico(0.13, 0, null, 0xfff2a8);
    dg.ico(0.07, 0, M(0.16, 0.1, 0.05), 0xffffff);
    dg.ico(0.06, 0, M(-0.13, -0.06, 0.1), 0xffe27a);
    this.dustGeo = dg.build(false);
    const cg = new Geo();
    cg.ico(0.2, 0, null, 0xc79bff);
    cg.cone(0.1, 0.2, 4, M(0, 0.26, 0), 0xffffff);
    cg.cone(0.1, 0.2, 4, M(0, -0.26, 0, Math.PI, 0, 0), 0xffffff);
    this.coreGeo = cg.build(false);
    this.mat = mat;
    // 희귀 이상은 빛기둥이 선다
    this.beamGeo = new THREE.CylinderGeometry(0.08, 0.2, 7, 8, 1, true);
    this.beamGeo.translate(0, 3.5, 0);
    this.beamMat = RARITY.map((r) => new THREE.MeshBasicMaterial({ color: r.color, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false }));
  }

  _spawn(geo, x, y, z, data) {
    const g = this.game;
    const m = new THREE.Mesh(geo, this.mat);
    m.position.set(x, y + 0.8, z);
    this.scene.add(m);
    // 튀어 올랐다가 근처에 떨어진다
    const a = Math.random() * Math.PI * 2;
    const r = 1.2 + Math.random() * 1.4;
    let tx = x + Math.cos(a) * r;
    let tz = z + Math.sin(a) * r;
    if (g.world.heightAt(tx, tz) < -0.6 || g.world.slopeAt(tx, tz) > 1.6) {
      tx = x;
      tz = z;
    }
    const d = { m, beam: null, x, z, sx: x, sz: z, tx, tz, sy: y + 0.8, t: 0, age: 0, pull: 0, ...data };
    if (data.item && data.item.r >= 2) {
      d.beam = new THREE.Mesh(this.beamGeo, this.beamMat[data.item.r]);
      d.beam.renderOrder = 6;
      d.beam.visible = false;
      this.scene.add(d.beam);
    }
    this.drops.push(d);
    return d;
  }

  dropItem(item, x, y, z) {
    this._spawn(this.gearGeo[item.r], x, y, z, { item });
    if (item.r >= 2) this.game.audio.loot(item.r);
  }

  dropMat(kind, n, x, y, z) {
    for (let i = 0; i < n; i++) this._spawn(kind === 'core' ? this.coreGeo : this.dustGeo, x, y, z, { mat: kind });
  }

  // 몬스터를 쓰러뜨렸을 때의 전리품
  onKill(info, x, y, z) {
    const g = this.game;
    const R = Math.random;
    const lvl = info.level + 3 * g.cycle;
    const src = info.dungeon ? (info.boss ? 'dboss' : 'dungeon') : info.type === 'lord' ? 'boss' : info.type === 'golem' ? 'golem' : info.elite ? 'elite' : 'mob';
    let chance = { mob: 0.075, elite: 0.6, golem: 1, boss: 1, dungeon: 0.14, dboss: 1 }[src];
    let count = { boss: 3, dboss: 3, golem: R() < 0.35 ? 2 : 1 }[src] || 1;
    let dust = { mob: R() < 0.32 ? 1 : 0, elite: 2 + (R() < 0.5 ? 1 : 0), golem: 4 + Math.floor(R() * 3), boss: 12, dungeon: R() < 0.6 ? 1 + (R() < 0.3 ? 1 : 0) : 0, dboss: 10 }[src];
    let core = { mob: R() < 0.015 ? 1 : 0, elite: R() < 0.35 ? 1 : 0, golem: 1, boss: 4, dungeon: R() < 0.07 ? 1 : 0, dboss: 3 }[src];
    if (info.minion) {
      chance = 0.03;
      count = 1;
      dust = R() < 0.15 ? 1 : 0;
      core = 0;
    }
    chance *= 1 + g.player.luck;
    for (let i = 0; i < count; i++) if (R() < chance) this.dropItem(rollItem(src, lvl), x, y, z);
    if (dust) this.dropMat('dust', dust, x, y, z);
    if (core) this.dropMat('core', core, x, y, z);
  }

  // 보물상자: 재료는 늘 조금, 장비는 가끔 (큰 상자일수록 자주)
  onChest(chest, level, x, y, z) {
    const R = Math.random;
    const big = chest.kind !== 'wild';
    const chance = chest.kind === 'shrine' ? 1 : big ? 0.65 : 0.38;
    if (R() < chance * (1 + this.game.player.luck)) this.dropItem(rollItem('chest' + Math.max(1, Math.min(4, chest.tier)), level + 3 * this.game.cycle), x, y, z);
    this.dropMat('dust', 1 + Math.floor(R() * chest.tier) + (big ? 1 : 0), x, y, z);
    if (chest.kind === 'shrine' && R() < 0.5) this.dropMat('core', 1, x, y, z);
  }

  _pickup(d) {
    const g = this.game;
    const { ui, fx, audio, save } = g;
    const p = g.player.pos;
    if (d.mat) {
      save.mats[d.mat]++;
      fx.text(p.x, p.y + 2.0, p.z, d.mat === 'core' ? '+1 별의 핵' : '+1 별가루', d.mat === 'core' ? 'r3' : 'gold');
      audio.pickup();
      g.saveSoon();
      ui.bagDirty = true;
      return true;
    }
    const it = d.item;
    if (!g.inv.add(it)) {
      if (this.fullT <= 0) {
        this.fullT = 4;
        ui.toast('가방이 가득 찼습니다. 상인에게 팔거나 버려서 자리를 만드세요.');
      }
      return false;
    }
    const name = `[${RARITY[it.r].name}] ${itemName(it)}`;
    fx.text(p.x, p.y + 2.2, p.z, itemName(it), 'r' + it.r);
    fx.burst(p.x, p.y + 1.2, p.z, RARITY[it.r].color, 10 + it.r * 5, 3.5, { size: 0.28, life: 0.6, grav: -1, glow: 2 });
    audio.loot(it.r);
    // 빈 칸이면 바로 착용하고, 더 좋은 장비면 알려 준다
    const slot = SLOT_NAME[slotOf(it.t)];
    if (!save.eq[slotOf(it.t)]) {
      g.inv.equip(it.id);
      ui.toast(`${name} 획득 — 바로 착용했습니다`, true, 'r' + it.r);
    } else if (g.inv.better(it)) {
      ui.toast(`${name} 획득 — 지금 ${slot}보다 좋아요! ${g.input.isTouch ? '메뉴의 가방' : 'B 키 가방'}에서 착용하세요`, true, 'r' + it.r);
    } else ui.toast(`${name} 획득`, false, 'r' + it.r);
    return true;
  }

  update(dt, time) {
    if (!this.drops.length) return;
    const g = this.game;
    const pl = g.player;
    const world = g.world;
    this.fullT -= dt;
    const alive = pl.state !== 'dead';
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      d.age += dt;
      const m = d.m;
      if (d.t < 1) {
        // 포물선으로 튀어나온다
        d.t = Math.min(1, d.t + dt * 2.4);
        d.x = d.sx + (d.tx - d.sx) * d.t;
        d.z = d.sz + (d.tz - d.sz) * d.t;
        const gy = Math.max(world.heightAt(d.x, d.z), 0) + 0.75;
        m.position.set(d.x, d.sy + (gy - d.sy) * d.t + Math.sin(d.t * Math.PI) * 1.8, d.z);
        if (d.t >= 1 && d.beam) {
          d.beam.position.set(d.x, gy - 0.6, d.z);
          d.beam.visible = true;
        }
      } else {
        const dx = pl.pos.x - d.x;
        const dz = pl.pos.z - d.z;
        const dist = Math.hypot(dx, dz);
        const gy = Math.max(world.heightAt(d.x, d.z), 0) + 0.75;
        // 가까이 가면 끌려온다
        if (alive && dist < 5 && Math.abs(pl.pos.y - gy) < 4 && (d.mat || g.inv.free() > 0)) {
          d.pull = Math.min(16, d.pull + dt * 30);
          const k = Math.min(1, (d.pull * dt) / Math.max(dist, 0.01));
          d.x += dx * k;
          d.z += dz * k;
          if (d.beam) d.beam.position.set(d.x, gy - 0.6, d.z);
        } else d.pull = 0;
        m.position.set(d.x, gy + Math.sin(time * 3 + d.sx) * 0.12, d.z);
        if (alive && dist < 1.1 && Math.abs(pl.pos.y - gy) < 3 && this._pickup(d)) d.age = LIFE + 1;
      }
      m.rotation.y += dt * 2.4;
      // 사라지기 직전에는 깜빡인다
      m.visible = d.age < LIFE - 12 || Math.floor(time * 6) % 2 === 0;
      if (d.age > LIFE) {
        this.scene.remove(m);
        if (d.beam) this.scene.remove(d.beam);
        this.drops.splice(i, 1);
      }
    }
  }
}

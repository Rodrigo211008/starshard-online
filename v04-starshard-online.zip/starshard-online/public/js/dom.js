// 화면(UI) 코드가 함께 쓰는 작은 도우미
export const $ = (id) => document.getElementById(id);
export const hex = (n) => '#' + n.toString(16).padStart(6, '0');
export const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

// 화면에 쓰는 작은 그림들
export const ICONS = {
  sword: '<svg viewBox="0 0 24 24"><path d="M7.9 14L18.5 3.4l2.8-.7-.7 2.8L10 16.1z" fill="#e8eef5"/><path d="M9 15.1L20 4.1l.6 1.4L10 16.1z" fill="#b4c0cf"/><path d="M5.4 12.9l.9-.8 5.6 5.6-.8.9z" fill="#f6c95a"/><path d="M4.3 18.2l3.2-3.2 1.5 1.5-3.2 3.2z" fill="#9c7449"/><circle cx="4.4" cy="19.6" r="1.6" fill="#f6c95a"/></svg>',
  great: '<svg viewBox="0 0 24 24"><path d="M6.6 13.2L17.4 2.4l4.4-.8-.8 4.4L10.2 16.8z" fill="#e8eef5"/><path d="M8.2 15L20.6 2.6l.6 2.2L10.2 16.8z" fill="#b4c0cf"/><path d="M3.6 11.8l1.5-1.5 8.6 8.6-1.5 1.5z" fill="#f6c95a"/><path d="M3 18.3l3.4-3.4 2.7 2.7-3.4 3.4z" fill="#9c7449"/><circle cx="3.6" cy="20.4" r="2" fill="#f6c95a"/></svg>',
  spear: '<svg viewBox="0 0 24 24"><path d="M3 21L15.5 8.5" stroke="#c9905a" stroke-width="2.2" stroke-linecap="round"/><path d="M13.6 6.2L21.6 2.4l-3.8 8-3-1.2z" fill="#e8eef5"/><path d="M15.2 8.8l6.4-6.4-3.8 8z" fill="#b4c0cf"/><path d="M12.4 9.6l2 2" stroke="#f6c95a" stroke-width="2.6" stroke-linecap="round"/></svg>',
  dagger: '<svg viewBox="0 0 24 24"><path d="M6 16L15.6 4l2.4-.6-.6 2.4L8 18z" fill="#e8eef5"/><path d="M4.2 14.6l5.2 5.2-1.2 1.2L3 15.8z" fill="#f6c95a"/><path d="M18 16L8.4 4 6 3.4l.6 2.4L16 18z" fill="#b4c0cf"/><path d="M19.8 14.6l-5.2 5.2 1.2 1.2 5.2-5.2z" fill="#f6c95a"/></svg>',
  hammer: '<svg viewBox="0 0 24 24"><path d="M4 20.5L13.5 11" stroke="#c9905a" stroke-width="2.8" stroke-linecap="round"/><path d="M11.2 5.6l4.4-4.4 7.2 7.2-4.4 4.4z" fill="#b4c0cf"/><path d="M13 5.6l2.6-2.6 5.4 5.4-2.6 2.6z" fill="#e8eef5"/><path d="M12.4 9.2l2.4 2.4" stroke="#f6c95a" stroke-width="2.4"/></svg>',
  bow: '<svg viewBox="0 0 24 24"><path d="M7 3c9 2.5 9 15.5 0 18" fill="none" stroke="#c9905a" stroke-width="2.3" stroke-linecap="round"/><path d="M7 3v18" stroke="#e8eef5" stroke-width="1"/><path d="M3 12h15" stroke="#e8eef5" stroke-width="1.6" stroke-linecap="round"/><path d="M21.5 12l-4.5-2.7v5.4z" fill="#e8eef5"/></svg>',
  armor: '<svg viewBox="0 0 24 24"><path d="M12 2.5l8 3v6c0 5-3.4 8.4-8 10-4.6-1.6-8-5-8-10v-6z" fill="#7f8ea8"/><path d="M12 5l5.5 2v4.6c0 3.6-2.3 6.1-5.5 7.4z" fill="#a9b6cc"/></svg>',
  helm: '<svg viewBox="0 0 24 24"><path d="M4 14.5a8 8 0 0116 0V19h-4.6v-4.4h-1.5V20h-3.8v-5.4H8.6V19H4z" fill="#a9b6cc"/><path d="M12 6.5a8 8 0 018 8V19h-4.6v-4.4h-1.5V20H12z" fill="#7f8ea8"/><path d="M12 2.6v4.2" stroke="#f6c95a" stroke-width="2.4" stroke-linecap="round"/></svg>',
  charm: '<svg viewBox="0 0 24 24"><path d="M7.5 7.5C7.5 4.6 9.4 3 12 3s4.5 1.6 4.5 4.5" fill="none" stroke="#c9905a" stroke-width="1.7"/><path d="M12 7l5.5 6L12 21.5 6.5 13z" fill="#c79bff"/><path d="M12 7l2.4 6L12 21.5z" fill="#ead9ff"/></svg>',
  berry: '<svg viewBox="0 0 24 24"><circle cx="12" cy="14" r="7" fill="#e0304a"/><circle cx="9.6" cy="11.6" r="1.9" fill="#ff9aa5"/><path d="M12 8c0-3 2-4.5 5-4.5 0 3-1.8 4.5-5 4.5z" fill="#58a848"/></svg>',
  arrows: '<svg viewBox="0 0 24 24"><path d="M4 20L18 6" stroke="#e8eef5" stroke-width="1.8" stroke-linecap="round"/><path d="M20.5 3.5l-1 5.2-4.2-4.2z" fill="#e8eef5"/><path d="M4 20l1-4M4 20l4-1" stroke="#c9905a" stroke-width="1.8" stroke-linecap="round"/></svg>',
  glider: '<svg viewBox="0 0 24 24"><path d="M2 9c6-5 14-5 20 0l-10 3z" fill="#f6c95a"/><path d="M7 10.7l5 9.3 5-9.3M12 12v8" stroke="#e8eef5" stroke-width="1" fill="none"/></svg>',
  star: '<svg viewBox="0 0 24 24"><path d="M12 2l2.9 6.6 7.1.7-5.4 4.8 1.6 7L12 17.4 5.8 21.1l1.6-7L2 9.3l7.1-.7z" fill="#f6c95a"/></svg>',
  coin: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="#f2a93b"/><circle cx="12" cy="12" r="6" fill="#fff3b0"/></svg>',
  dust: '<svg viewBox="0 0 24 24"><path d="M11 3l1.9 5.6L18.5 10.5l-5.6 1.9L11 18l-1.9-5.6L3.5 10.5l5.6-1.9z" fill="#fff2a8"/><circle cx="18.6" cy="17.6" r="2" fill="#ffe27a"/><circle cx="5.4" cy="18.6" r="1.3" fill="#fff"/></svg>',
  core: '<svg viewBox="0 0 24 24"><path d="M12 2.5l7.5 6.5L12 21.5 4.5 9z" fill="#c79bff"/><path d="M12 2.5l2.8 6.5L12 21.5z" fill="#ead9ff"/><path d="M4.5 9h15" stroke="#8a5fd0" stroke-width="1.1"/></svg>',
  horse: '<svg viewBox="0 0 24 24"><path d="M4.5 20.5v-6.2L3 11l3.8-5.4L8.4 2.5l1.4 3.1c4.6.2 8.2 2.8 8.2 7.4v7.5h-3.2v-5H9.4v5z" fill="#c9905a"/><path d="M8.4 2.5l1.4 3.1c2 .1 3.9.7 5.3 1.7L11 9z" fill="#8a5a34"/><circle cx="6.3" cy="9.4" r=".9" fill="#2a2018"/></svg>',
};
export const icon = (name) => `<span class="slot-ic">${ICONS[name] || ''}</span>`;

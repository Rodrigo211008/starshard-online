// 키보드·마우스·터치 입력
// - 키보드만으로 모든 조작이 가능하다 (이동 WASD, 시점 방향키, 나머지는 아래 KEYMAP)
// - 마지막으로 쓴 장치(키보드/터치)에 맞춰 화면의 조작 안내가 바뀐다

// 게임 중 한 번 누르는 동작 키
const KEYMAP = {
  Space: 'jump', KeyE: 'interact', KeyQ: 'heal',
  KeyF: 'attack', KeyJ: 'attack', KeyR: 'bow', KeyK: 'bow',
  KeyX: 'roll', KeyI: 'roll', KeyC: 'lock', KeyL: 'lock', KeyT: 'autorun', KeyV: 'camreset', KeyG: 'mount',
  Digit1: 'emote1', Digit2: 'emote2', Digit3: 'emote3',
};
// 브라우저 기본 동작(스크롤, 포커스 이동)을 막을 키
// (메뉴 Tab·Esc, 지도 M, 모험가 B, 조작법 H, 채팅 Enter 는 ui.handleKey 가 누른 즉시 처리한다)
const GAME_KEYS = new Set([...Object.keys(KEYMAP), 'Tab', 'KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ShiftLeft', 'ShiftRight', 'Minus', 'Equal', 'PageUp', 'PageDown']);

export class Input {
  constructor(canvas) {
    this.canvas = canvas;
    // 휴대폰·태블릿이면 터치 조작으로 시작. 키보드를 누르면 키보드 조작으로, 화면을 터치하면 다시 터치 조작으로 바뀐다.
    this.isTouch = matchMedia('(pointer: coarse)').matches || (navigator.maxTouchPoints > 0 && /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent));
    this.onMode = null; // (isTouch) => void
    this.onUiKey = null; // (event, typing) => boolean : 시작 화면·메뉴·대화가 키를 가져가면 true
    this.moveX = 0;
    this.moveY = 0;
    this.joyX = 0; // 터치 조이스틱 값 (키보드와 따로 관리)
    this.joyY = 0;
    this.sprint = false;
    this.sprintToggle = false;
    this.autoRun = false;
    this.jumpHeld = false;
    this.touchJump = false;
    this.lookDX = 0;
    this.lookDY = 0;
    this.zoom = 0;
    this.pressed = new Set();
    this.keys = new Set();
    this.locked = false;
    this.enabled = false; // 게임 플레이 중일 때만 입력을 받는다
    this.blocked = () => false; // UI 패널이 열려 있으면 true
    this.sens = 1;
    this.kbLookT = 0;
    this.editing = false; // 터치 버튼 배치를 바꾸는 중

    this._bindKeyboard();
    this._bindMouse();
    this._bindTouch();
  }

  consume(name) {
    if (this.pressed.has(name)) {
      this.pressed.delete(name);
      return true;
    }
    return false;
  }

  _press(name) {
    if (this.enabled) this.pressed.add(name);
  }

  _setTouch(v) {
    if (this.isTouch === v) return;
    this.isTouch = v;
    if (v) this.unlock();
    else {
      this.joyX = 0;
      this.joyY = 0;
      this.sprintToggle = false;
      this.touchJump = false;
    }
    if (this.onMode) this.onMode(v);
  }

  releaseAll() {
    this.keys.clear();
    this.jumpHeld = false;
    this.touchJump = false;
  }

  _bindKeyboard() {
    window.addEventListener('keydown', (e) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return; // 브라우저 단축키는 건드리지 않는다
      const typing = !!document.activeElement && /INPUT|TEXTAREA/.test(document.activeElement.tagName) && document.activeElement.type !== 'range';
      if (this.onUiKey && this.onUiKey(e, typing)) {
        e.preventDefault();
        if (!typing) this._setTouch(false);
        return;
      }
      if (typing) return;
      if (GAME_KEYS.has(e.code)) e.preventDefault();
      if (e.repeat) return;
      if (GAME_KEYS.has(e.code)) this._setTouch(false);
      this.keys.add(e.code);
      if (KEYMAP[e.code]) this._press(KEYMAP[e.code]);
    });
    window.addEventListener('keyup', (e) => {
      this.keys.delete(e.code);
      // 일부 기기에서는 Command 키를 누른 동안 다른 키의 "뗌" 신호가 오지 않는다 -> 모두 뗀 것으로 처리
      if (e.code === 'MetaLeft' || e.code === 'MetaRight' || e.key === 'Meta') this.releaseAll();
    });
    // 창을 벗어나거나 입력란에 들어가면 눌린 키를 모두 뗀 것으로 본다 (키가 눌린 채 남는 문제 방지)
    window.addEventListener('blur', () => this.releaseAll());
    document.addEventListener('visibilitychange', () => this.releaseAll());
    document.addEventListener('focusin', (e) => {
      if (e.target && /INPUT|TEXTAREA/.test(e.target.tagName)) this.releaseAll();
    });
  }

  _bindMouse() {
    const c = this.canvas;
    c.addEventListener('mousedown', (e) => {
      if (this.isTouch || !this.enabled || this.blocked()) return;
      if (!this.locked) {
        if (c.requestPointerLock) {
          try {
            const p = c.requestPointerLock();
            if (p && p.catch) p.catch(() => {});
          } catch {
            /* 마우스 고정을 쓸 수 없는 환경 */
          }
        }
        this._drag = true;
        this._downAt = performance.now();
        this._moved = 0;
        this._downBtn = e.button;
        return;
      }
      if (e.button === 0) this._press('attack');
      else if (e.button === 2) this._press('bow');
    });
    window.addEventListener('mouseup', () => {
      // 마우스 고정이 안 되는 환경에서는 "드래그 = 시점, 짧은 클릭 = 공격"
      if (this._drag && !this.locked && this._lockTried && this._moved < 6 && performance.now() - this._downAt < 260) {
        this._press(this._downBtn === 2 ? 'bow' : 'attack');
      }
      if (this._drag && !this.locked) this._lockTried = true;
      this._drag = false;
    });
    c.addEventListener('contextmenu', (e) => e.preventDefault());
    document.addEventListener('pointerlockchange', () => {
      this.locked = document.pointerLockElement === c;
    });
    window.addEventListener('mousemove', (e) => {
      if (this.isTouch || !this.enabled) return;
      if (this.locked || this._drag) {
        this._moved = (this._moved || 0) + Math.abs(e.movementX) + Math.abs(e.movementY);
        this.lookDX += e.movementX * 0.0024 * this.sens;
        this.lookDY += e.movementY * 0.0024 * this.sens;
      }
    });
    c.addEventListener('wheel', (e) => {
      this.zoom += Math.sign(e.deltaY);
      e.preventDefault();
    }, { passive: false });
  }

  unlock() {
    if (this.locked && document.exitPointerLock) document.exitPointerLock();
  }

  _bindTouch() {
    const joy = document.getElementById('joy');
    const knob = document.getElementById('joy-knob');
    const zone = document.getElementById('touch-zone');
    if (!zone) return;
    let joyId = null;
    let joyX = 0;
    let joyY = 0;
    const looks = new Map();
    const R = 56;

    const setKnob = (dx, dy) => {
      knob.style.transform = `translate(${dx}px, ${dy}px)`;
    };
    // 화면을 터치하면 터치 조작으로 전환
    window.addEventListener('touchstart', () => this._setTouch(true), { passive: true });
    zone.addEventListener('touchstart', (e) => {
      if (!this.enabled || this.blocked()) return;
      e.preventDefault();
      for (const t of e.changedTouches) {
        const leftSide = t.clientX < window.innerWidth * 0.42 && t.clientY > window.innerHeight * 0.25;
        if (leftSide && joyId === null) {
          joyId = t.identifier;
          joyX = t.clientX;
          joyY = t.clientY;
          joy.style.left = joyX + 'px';
          joy.style.top = joyY + 'px';
          joy.classList.add('on');
          setKnob(0, 0);
        } else {
          looks.set(t.identifier, { x: t.clientX, y: t.clientY });
        }
      }
    }, { passive: false });
    zone.addEventListener('touchmove', (e) => {
      e.preventDefault();
      for (const t of e.changedTouches) {
        if (t.identifier === joyId) {
          let dx = t.clientX - joyX;
          let dy = t.clientY - joyY;
          const d = Math.hypot(dx, dy);
          if (d > R) {
            dx = (dx / d) * R;
            dy = (dy / d) * R;
          }
          setKnob(dx, dy);
          const mag = Math.min(1, d / R);
          const dead = 0.14;
          if (mag < dead) {
            this.joyX = 0;
            this.joyY = 0;
          } else {
            this.joyX = dx / R;
            this.joyY = -dy / R;
          }
        } else if (looks.has(t.identifier)) {
          const l = looks.get(t.identifier);
          this.lookDX += (t.clientX - l.x) * 0.0052 * this.sens;
          this.lookDY += (t.clientY - l.y) * 0.0042 * this.sens;
          l.x = t.clientX;
          l.y = t.clientY;
        }
      }
    }, { passive: false });
    const end = (e) => {
      for (const t of e.changedTouches) {
        if (t.identifier === joyId) {
          joyId = null;
          this.joyX = 0;
          this.joyY = 0;
          joy.classList.remove('on');
        }
        looks.delete(t.identifier);
      }
    };
    zone.addEventListener('touchend', end);
    zone.addEventListener('touchcancel', end);

    // 액션 버튼
    for (const btn of document.querySelectorAll('.abtn')) {
      const act = btn.dataset.act;
      const down = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!this.enabled || this.editing) return;
        btn.classList.add('down');
        if (act === 'sprint') {
          this.sprintToggle = !this.sprintToggle;
          btn.classList.toggle('active', this.sprintToggle);
          return;
        }
        if (act === 'jump') this.touchJump = true;
        this._press(act);
      };
      const up = (e) => {
        e.preventDefault();
        btn.classList.remove('down');
        if (act === 'jump') this.touchJump = false;
      };
      btn.addEventListener('touchstart', down, { passive: false });
      btn.addEventListener('touchend', up, { passive: false });
      btn.addEventListener('touchcancel', up, { passive: false });
      btn.addEventListener('mousedown', (e) => {
        if (!this.isTouch) down(e);
      });
      btn.addEventListener('mouseup', (e) => {
        if (!this.isTouch) up(e);
      });
    }
  }

  // 매 프레임 호출: 눌린 키와 조이스틱을 이동·시점 값으로 바꾼다
  update(dt = 0.016) {
    const k = this.keys;
    let x = 0;
    let y = 0;
    if (k.has('KeyW')) y += 1;
    if (k.has('KeyS')) y -= 1;
    if (k.has('KeyD')) x += 1;
    if (k.has('KeyA')) x -= 1;
    // 자동 달리기: 켜 두면 앞으로 계속 달린다. 뒤로(S)를 누르면 꺼진다.
    if (this.autoRun) {
      if (y < 0) this.autoRun = false;
      else y = 1;
    }
    if (x || y) {
      const d = Math.hypot(x, y);
      this.moveX = x / d;
      this.moveY = y / d;
    } else {
      // 키보드 입력이 없으면 조이스틱 값을 쓴다 (키를 떼면 반드시 멈춘다)
      this.moveX = this.joyX;
      this.moveY = this.joyY;
    }
    // 방향키로 시점 돌리기 (누르고 있으면 조금씩 빨라진다)
    const lx = (k.has('ArrowRight') ? 1 : 0) - (k.has('ArrowLeft') ? 1 : 0);
    const ly = (k.has('ArrowDown') ? 1 : 0) - (k.has('ArrowUp') ? 1 : 0);
    if (lx || ly) {
      this.kbLookT += dt;
      const acc = 0.5 + 0.5 * Math.min(1, this.kbLookT / 0.28);
      this.lookDX += lx * 2.7 * acc * dt * this.sens;
      this.lookDY += ly * 1.5 * acc * dt * this.sens;
    } else this.kbLookT = 0;
    const zm = (k.has('Minus') || k.has('PageDown') ? 1 : 0) - (k.has('Equal') || k.has('PageUp') ? 1 : 0);
    if (zm) this.zoom += zm * dt * 8;

    this.sprint = this.sprintToggle || k.has('ShiftLeft') || k.has('ShiftRight');
    this.jumpHeld = this.touchJump || k.has('Space');
    if (!this.enabled || this.blocked()) {
      this.moveX = 0;
      this.moveY = 0;
      this.lookDX = 0;
      this.lookDY = 0;
      this.zoom = 0;
    }
  }
}

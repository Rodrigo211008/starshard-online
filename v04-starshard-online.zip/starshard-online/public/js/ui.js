// 화면 UI: 시작 화면, 게임 화면(HUD), 메뉴(지도·모험가·설정·조작법), 대화, 상점, 채팅
// 모든 화면은 키보드만으로도, 터치만으로도 조작할 수 있다.
import { Vector3 } from '/vendor/three/three.module.js';
import { TUNIC_COLORS, HAIR_COLORS, RARITY, SLOTS, SLOT_NAME, WEAPONS, xpNeed, SHARD_COUNT, MAX_LEVEL, MON, itemName, itemStatText } from '/shared/defs.js';
import { W, BIOME_INFO, BIOME_CENTERS, VOLCANO } from '/shared/world.js';
import { $, hex, esc, ICONS, icon } from './dom.js';
import { installItemsUI } from './ui-items.js';

const _v = new Vector3();

const HEART = 'M11 19 C4 13 1 9.5 1 6.2 C1 3.2 3.3 1 6.1 1 C8.2 1 10 2.2 11 4 C12 2.2 13.8 1 15.9 1 C18.7 1 21 3.2 21 6.2 C21 9.5 18 13 11 19 Z';
const heartSvg = (kind) =>
  `<svg viewBox="0 0 22 20"><path d="${HEART}" fill="${kind === 2 ? '#ff4d5e' : kind === 1 ? 'url(#half-heart)' : 'rgba(10,15,31,0.55)'}" stroke="${kind ? '#fff6df' : 'rgba(255,246,223,0.6)'}" stroke-width="1.5" stroke-linejoin="round"/></svg>`;

// 방향 입력 (방향키와 WASD 모두)
const DIRS = {
  ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0],
  KeyW: [0, -1], KeyS: [0, 1], KeyA: [-1, 0], KeyD: [1, 0],
};
const CONFIRM = new Set(['Enter', 'NumpadEnter', 'Space', 'KeyF', 'KeyJ']);
const TABS = ['panel-map', 'panel-inv', 'panel-bag', 'panel-settings', 'panel-help'];
// 메뉴를 바로 여는 키
const TAB_KEYS = { KeyM: 'panel-map', KeyB: 'panel-inv', KeyP: 'panel-bag', KeyH: 'panel-help' };

const KID_TIPS = [
  '달리면 초록색 기력 막대가 줄어들어. 다 떨어지면 잠깐 쉬어야 해!',
  '모닥불 옆이나 마을 안에 있으면 하트가 조금씩 차올라.',
  '빨간 열매가 달린 덤불을 지나가면 회복 열매를 딸 수 있어!',
  '가파른 절벽도 기력만 있으면 오를 수 있대. 기력이 떨어지면 주르륵 미끄러져!',
  '귀환석을 깨워 두면 지도에서 눌러서 바로 날아갈 수 있어.',
  '몬스터가 바닥에 빨간 표시를 그리면 얼른 밖으로 피해야 해!',
  '높은 데서 뛰어내린 다음 점프를 한 번 더 누르면 활공 천이 펴져. 진짜 신나!',
  '친구랑 같이 싸우면 경험치랑 골드를 둘 다 받을 수 있어. 뺏기는 게 아니야!',
];
const GUIDE_TIPS = [
  '',
  '이 숲 동쪽 끝 깊은 곳에 오래된 제단이 있어요. 커다란 바위 수호자가 지키고 있으니 단단히 준비하세요.',
  '남쪽 사막에서 가장 높은 붉은 탁상지 꼭대기에 무언가 반짝여요. 더 남쪽 유적에도 수호자가 있다더군요.',
  '늪 깊은 곳과 남쪽 말랑이 둥지에 별조각이 있다는 소문이에요. 물이 깊은 곳에서는 기력이 닳으니 조심하세요.',
  '서리봉 정상에 별조각이 있어요. 기력을 아껴 가며 완만한 길을 찾아 오르세요. 서쪽에는 설인들의 야영지가 있답니다.',
  '이 협곡을 따라가면 분화구예요. 별조각 열두 개가 모두 모이면 그곳에서 그림자 군주가 깨어난대요…',
  '고원 서쪽 늑대 언덕에 별조각이 있어요. 우두머리 늑대가 무리를 이끌고 있으니 친구와 함께 가세요.',
];

export class UI {
  constructor(game) {
    this.game = game;
    this.dirty = true;
    this.cache = {};
    this.mapCanvas = null;
    this.mmCtx = $('minimap').getContext('2d');
    this.mapOpen = false;
    this.mapSel = null;
    this.dialogQueue = null;
    this.type = null; // 대사를 한 글자씩 보여 주는 중이면 { full, n }
    this.mmT = 0;
    this.focusEl = null;
    this.lastTab = 'panel-map';
    this.panels = [...TABS, 'panel-shop', 'panel-trade'];
    this.bagDirty = false; // 가방 내용이 바뀌어 화면을 다시 그려야 하는지
    this.invSel = null;
    this.trade = null; // 진행 중인 교환
    this.tradeReq = null; // 받은 교환 신청

    // 반쪽 하트용 그라데이션
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    defs.setAttribute('width', '0');
    defs.setAttribute('height', '0');
    defs.style.position = 'absolute';
    defs.innerHTML = '<defs><linearGradient id="half-heart"><stop offset="50%" stop-color="#ff4d5e"/><stop offset="50%" stop-color="rgba(10,15,31,0.55)"/></linearGradient></defs>';
    document.body.appendChild(defs);
    for (const el of document.querySelectorAll('.slot-ic[data-ic]')) el.innerHTML = ICONS[el.dataset.ic];

    this._bindTitle();
    this._bindHud();
    this._bindPanels();
    this._bindChat();
    this._bindTouchEdit();
    this._bindTrade();
    // 마우스나 터치를 쓰면 키보드 선택 표시를 숨긴다
    window.addEventListener('pointerdown', () => document.body.classList.remove('kb'));
  }

  // ================= 키보드로 고르기 (공통) =================
  _focusables(root) {
    return [...root.querySelectorAll('button, input, [data-nav]')].filter((el) => !el.disabled && !el.classList.contains('x') && !el.hasAttribute('data-nonav') && el.offsetParent !== null);
  }

  setFocus(el, scroll = true) {
    if (this.focusEl && this.focusEl !== el) this.focusEl.classList.remove('kf');
    this.focusEl = el || null;
    if (el) {
      el.classList.add('kf');
      // 키보드로 고르는 중일 때만 그 항목이 보이도록 스크롤한다
      if (scroll && el.scrollIntoView && document.body.classList.contains('kb')) el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      if (el._onFocus) el._onFocus();
    }
  }

  // 누른 방향에서 가장 가까운 항목으로 옮긴다
  navMove(root, dx, dy) {
    const list = this._focusables(root);
    if (!list.length) return false;
    const cur = this.focusEl && list.includes(this.focusEl) ? this.focusEl : null;
    if (!cur) {
      this.setFocus(list[0]);
      return true;
    }
    const a = cur.getBoundingClientRect();
    const ax = a.left + a.width / 2;
    const ay = a.top + a.height / 2;
    const cands = [];
    for (const el of list) {
      if (el === cur) continue;
      const r = el.getBoundingClientRect();
      const ddx = r.left + r.width / 2 - ax;
      const ddy = r.top + r.height / 2 - ay;
      const along = dx ? ddx * dx : ddy * dy;
      if (along < 4) continue;
      cands.push({ el, along, across: dx ? Math.abs(ddy) : Math.abs(ddx), size: dx ? Math.max(a.height, r.height) : 0 });
    }
    let best = null;
    if (dy) {
      // 위아래: 가장 가까운 줄로 가서, 그 줄에서 가로로 가장 가까운 것
      let near = Infinity;
      for (const c of cands) near = Math.min(near, c.along);
      let bs = Infinity;
      for (const c of cands) {
        if (c.along <= near + 14 && c.across < bs) {
          bs = c.across;
          best = c.el;
        }
      }
    } else {
      // 좌우: 같은 줄에서 가장 가까운 것
      let bs = Infinity;
      for (const c of cands) {
        if (c.across < c.size * 0.6 && c.along < bs) {
          bs = c.along;
          best = c.el;
        }
      }
    }
    if (best) {
      this.setFocus(best);
      this.game.audio.click();
    }
    return !!best;
  }

  activate(el) {
    if (!el) return;
    if (el.tagName === 'INPUT' && el.type !== 'range') el.focus();
    else (el._act || el).click();
  }

  // 시작 화면·메뉴·대화가 열려 있을 때의 키 처리. 처리했으면 true (게임 조작으로 넘어가지 않는다)
  handleKey(e, typing) {
    const g = this.game;
    const code = e.code;
    if (!g.input.enabled) {
      if ($('title').classList.contains('hidden')) return false;
      const used = this._titleKey(e, typing);
      if (used) document.body.classList.add('kb');
      return used;
    }
    if (!$('chat-row').classList.contains('hidden')) {
      if (code === 'Escape' || code === 'Tab') {
        this.closeChat();
        return true;
      }
      if (typing) return false;
      $('chat-input').focus();
      return true;
    }
    if (typing) return false;
    if (e.repeat && !DIRS[code]) return this.anyOpen();
    if (!$('dialog').classList.contains('hidden')) {
      document.body.classList.add('kb');
      const dir = DIRS[code];
      if (CONFIRM.has(code) || code === 'KeyE') this.dialogKey();
      else if (code === 'Escape' || code === 'Backspace') {
        const btns = $('dialog-btns').querySelectorAll('button');
        if (btns.length) btns[btns.length - 1].click();
      } else if (dir && dir[0] && !this.type) this.navMove($('dialog-btns'), dir[0], 0);
      return true;
    }
    const id = this.openPanel();
    if (id) {
      document.body.classList.add('kb');
      this._panelKey(e, id);
      return true;
    }
    // 아무것도 열려 있지 않을 때: 메뉴·채팅을 여는 키는 누른 즉시 처리한다
    if (e.repeat) return false;
    // 받은 교환 신청에 답하기
    if (this.tradeReq && (code === 'KeyY' || code === 'KeyN')) {
      this.answerTrade(code === 'KeyY');
      return true;
    }
    const direct = code === 'Tab' || code === 'Escape' ? this.lastTab : TAB_KEYS[code];
    if (direct) {
      document.body.classList.add('kb');
      this.open(direct);
      return true;
    }
    if (code === 'Enter' || code === 'NumpadEnter') {
      this.openChat();
      return true;
    }
    return false;
  }

  openPanel() {
    for (const id of this.panels) if (!$(id).classList.contains('hidden')) return id;
    return null;
  }

  _panelKey(e, id) {
    const code = e.code;
    const isTab = TABS.includes(id);
    if (code === 'Escape' || code === 'Tab' || code === 'Backspace') {
      this.closeAll();
      return;
    }
    if (isTab) {
      if (code === 'KeyQ' || code === 'BracketLeft') return this.tabStep(-1);
      if (code === 'KeyE' || code === 'BracketRight') return this.tabStep(1);
      const jump = TAB_KEYS[code];
      if (jump) return jump === id ? this.closeAll() : this.open(jump);
    }
    if (id === 'panel-shop') {
      // 사기 · 팔기 · 강화 전환
      if (code === 'KeyQ' || code === 'BracketLeft') return this.shopStep(-1);
      if (code === 'KeyE' || code === 'BracketRight') return this.shopStep(1);
    }
    if (id === 'panel-inv' && (code === 'KeyX' || code === 'Delete') && this.invSel) return this._invDiscard(this.invSel);
    const dir = DIRS[code];
    const confirm = CONFIRM.has(code);
    if (id === 'panel-map') {
      if (dir) this.mapMove(dir[0], dir[1]);
      else if (confirm) this.mapGo();
      return;
    }
    const box = $(id).querySelector('.panel-box');
    const f = this.focusEl;
    if (dir) {
      // 슬라이더는 좌우 키로 값을 바꾼다
      if (dir[0] && f && f.tagName === 'INPUT' && f.type === 'range') {
        const step = +f.step || 1;
        f.value = Math.min(+f.max, Math.max(+f.min, +f.value + dir[0] * step));
        f.dispatchEvent(new Event('input', { bubbles: true }));
      } else if (!this.navMove(box, dir[0], dir[1]) && dir[1]) box.scrollTop += dir[1] * 80;
    } else if (confirm) this.activate(f && box.contains(f) ? f : this._focusables(box)[0]);
  }

  tabStep(d) {
    const i = TABS.indexOf(this.openPanel());
    this.open(TABS[(i + d + TABS.length) % TABS.length]);
    this.game.audio.click();
  }

  // ================= 시작 화면 =================
  _bindTitle() {
    const save = this.game.save;
    const name = $('name-input');
    name.value = save.name || '';
    const mk = (wrap, colors, key) => {
      wrap.innerHTML = '';
      colors.forEach((c, i) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.style.background = hex(c);
        b.setAttribute('aria-label', `색 ${i + 1}`);
        if (save[key] === i) b.classList.add('on');
        b.addEventListener('click', () => {
          save[key] = i;
          for (const q of wrap.children) q.classList.remove('on');
          b.classList.add('on');
          this.game.audio.click();
        });
        wrap.appendChild(b);
      });
    };
    mk($('tunic-swatches'), TUNIC_COLORS, 'tunic');
    mk($('hair-swatches'), HAIR_COLORS, 'hair');
    // 이름은 처음 한 번만 정한다. 다시 왔을 때는 인사만 하고 바로 이어서 할 수 있다.
    this.returning = !!save.name;
    const showFields = (v) => {
      $('title-new').classList.toggle('hidden', !v);
      $('title-back').classList.toggle('hidden', v);
    };
    showFields(!this.returning);
    $('title-hello').innerHTML = `<b>${esc(save.name || '')}</b> 님, 다시 오셨군요!`;
    $('title-edit').addEventListener('click', () => {
      showFields(true);
      this.setFocus(name);
      name.focus();
    });
    this._go = () => {
      if ($('start-btn').disabled) return;
      save.name = name.value.trim().slice(0, 12) || save.name || '모험가';
      this.game.startPlay();
    };
    $('start-btn').addEventListener('click', this._go);
    $('title-invite').addEventListener('click', () => this.invite());
    this.setFocus($('start-btn'));
    if (!this.returning && !this.game.input.isTouch) {
      this.setFocus(name);
      name.focus();
    }
  }

  _titleKey(e, typing) {
    const code = e.code;
    const box = $('title');
    const name = $('name-input');
    if (code === 'Enter' || code === 'NumpadEnter') {
      // 초대·모습 바꾸기 버튼 위에서는 그 버튼을, 그 밖에는 바로 시작
      if (!typing && (this.focusEl === $('title-invite') || this.focusEl === $('title-edit'))) this.focusEl.click();
      else this._go();
      return true;
    }
    if (typing) {
      // 이름을 쓰는 중: 아래 화살표나 Tab 으로 다음 항목으로 넘어간다
      if (code === 'ArrowDown' || code === 'Tab' || code === 'Escape') {
        name.blur();
        this.setFocus(name);
        if (code !== 'Escape') this.navMove(box, 0, 1);
        return true;
      }
      return false;
    }
    const dir = DIRS[code];
    if (dir && code.startsWith('Arrow')) {
      this.navMove(box, dir[0], dir[1]);
      // 색 고르기 줄에서는 좌우로 옮기는 즉시 그 색이 적용된다
      const f = this.focusEl;
      if (f && f.parentElement && f.parentElement.classList.contains('swatches')) f.click();
      if (f === name) name.focus();
      return true;
    }
    if (code === 'Tab') {
      this.navMove(box, 0, e.shiftKey ? -1 : 1);
      if (this.focusEl === name) name.focus();
      return true;
    }
    if (code === 'Space') {
      this.activate(this.focusEl);
      return true;
    }
    // 글자를 치기 시작하면 이름 칸으로 (이름 칸이 보일 때만)
    if (e.key && (e.key.length === 1 || e.key === 'Process' || e.keyCode === 229) && name.offsetParent !== null) {
      this.setFocus(name);
      name.focus();
    }
    return false;
  }

  titleStatus(text, ready) {
    $('title-status').textContent = text;
    const b = $('start-btn');
    if (ready !== undefined) {
      b.disabled = !ready;
      b.textContent = ready ? (this.returning ? '이어서 하기' : '모험 시작') : '세계를 만드는 중…';
      if (ready && (!this.focusEl || !$('title').contains(this.focusEl))) this.setFocus(b);
    }
  }

  showGame() {
    $('title').classList.add('hidden');
    $('hud').classList.remove('hidden');
    $('name-input').blur();
    this.setFocus(null);
    this.checkRotate();
  }

  checkRotate() {
    const g = this.game;
    const portrait = window.innerHeight > window.innerWidth * 1.15;
    $('rotate-hint').classList.toggle('hidden', !(g.input.isTouch && portrait && g.playing && !this.rotateOk));
  }

  // 조작 장치가 바뀌면(키보드 <-> 터치) 안내를 그에 맞게 바꾼다
  onInputMode() {
    this.cache = {};
    if (!$('panel-help').classList.contains('hidden')) this.refreshHelp();
    this.checkRotate();
  }

  // ================= 게임 화면 =================
  _bindHud() {
    const g = this.game;
    for (const b of document.querySelectorAll('#menu-btns button')) {
      b.addEventListener('click', () => {
        g.audio.click();
        if (b.dataset.ui === 'chat') this.openChat();
        else this.openMenu();
      });
    }
    // 키 안내는 눌러서도 쓸 수 있다 (마우스만 쓰는 경우)
    const hints = [['roll', 'X', '구르기'], ['lock', 'C', '주목'], ['mount', 'G', '탈것'], ['autorun', 'T', '자동 달리기'], ['menu', 'Tab', '메뉴'], ['bag', 'B', '가방'], ['map', 'M', '지도'], ['chat', 'Enter', '채팅']];
    const kh = $('keyhints');
    for (const [act, key, label] of hints) {
      const b = document.createElement('button');
      b.innerHTML = `<kbd>${key}</kbd>${label}`;
      if (act === 'mount') b.className = 'mount-only';
      b.addEventListener('click', () => g.input.pressed.add(act));
      kh.appendChild(b);
    }
    $('prompt').addEventListener('click', () => g.interact());
    $('prompt').addEventListener('touchstart', (e) => {
      e.preventDefault();
      g.interact();
    }, { passive: false });
    $('rotate-ok').addEventListener('click', () => {
      this.rotateOk = true;
      $('rotate-hint').classList.add('hidden');
    });
  }

  set(id, key, value, fn) {
    if (this.cache[key] === value) return;
    this.cache[key] = value;
    fn($(id), value);
  }

  update(dt) {
    const g = this.game;
    const p = g.player;
    const s = g.save;
    if (!p) return;

    this.set('hearts', 'hearts', p.hp * 100 + p.maxHp, (el) => {
      let h = '';
      const n = Math.ceil(p.maxHp / 2);
      for (let i = 0; i < n; i++) h += heartSvg(p.hp >= (i + 1) * 2 ? 2 : p.hp === i * 2 + 1 ? 1 : 0);
      el.innerHTML = h;
    });
    const st = Math.round((p.stamina / p.maxStamina) * 100);
    this.set('stamina-fill', 'st', st, (el, v) => (el.style.width = v + '%'));
    this.set('stamina', 'stc', (st < 100 ? 1 : 0) + (p.exhausted ? 4 : st < 30 ? 2 : 0), (el) => {
      el.classList.toggle('show', st < 100);
      el.classList.toggle('low', st < 30 && !p.exhausted);
      el.classList.toggle('out', p.exhausted);
      el.style.width = Math.round(p.maxStamina * 1.5) + 'px';
    });
    this.set('lvl', 'lvl', s.level, (el, v) => (el.textContent = 'Lv.' + v));
    const need = xpNeed(s.level);
    this.set('xp-fill', 'xp', s.level >= MAX_LEVEL ? 100 : Math.round((s.xp / need) * 100), (el, v) => (el.style.width = v + '%'));
    this.set('res-gold', 'gold', s.gold, (el, v) => (el.textContent = v));
    this.set('res-berry', 'berry', s.berries, (el, v) => {
      el.textContent = v;
      $('slot-berry').classList.toggle('empty', v <= 0);
      $('b-heal').firstElementChild.textContent = `열매 ${v}`;
    });
    this.set('res-arrow', 'arrow', s.arrows, (el, v) => {
      el.textContent = v;
      $('slot-bow').classList.toggle('empty', v <= 0);
      $('b-bow').firstElementChild.textContent = `활 ${v}`;
    });
    // 가방 내용이 바뀌었으면 열려 있는 화면을 다시 그린다
    if (this.bagDirty) {
      this.bagDirty = false;
      if (!$('panel-inv').classList.contains('hidden')) this.refreshInv(this.invSel);
      else if (this.trade) this.refreshTrade(this._tradeFocus());
    }
    if (this.tradeReq) {
      this.tradeReq.t -= dt;
      if (this.tradeReq.t <= 0) this.answerTrade(false);
    }
    // 무기 칸은 지금 든 무기 종류를 보여 준다
    this.set('slot-sword', 'wkind', p.wkind + ':' + (s.eq.weapon ? s.eq.weapon.r : 0), (el) => {
      el.querySelector('.slot-ic').innerHTML = ICONS[p.wkind] || ICONS.sword;
      el.style.borderColor = s.eq.weapon && s.eq.weapon.r >= 1 ? RARITY[s.eq.weapon.r].css : '';
    });
    this.set('b-mount', 'mount', (s.mount ? 1 : 0) + (p.mounted ? 2 : 0), (el) => {
      document.body.classList.toggle('has-mount', !!s.mount);
      el.classList.toggle('active', p.mounted);
    });
    // 지금 쓰고 있는 장비 칸을 눌린 것처럼 보여 준다
    const act = p.action;
    this.set('slot-sword', 'swOn', !!(act && act.type === 'atk'), (el, v) => el.classList.toggle('on', v));
    this.set('slot-bow', 'bowOn', !!(act && act.type === 'bow'), (el, v) => el.classList.toggle('on', v));
    this.set('slot-berry', 'berOn', p.healCd > 0.5, (el, v) => el.classList.toggle('on', v));
    this.set('autorun', 'auto', g.input.autoRun, (el, v) => el.classList.toggle('hidden', !v));
    this.set('mm-time', 'night', g.gfx.night > 0.5, (el, v) => el.classList.toggle('night', v));

    // 목표
    let q;
    if (!s.talkedElder) q = '촌장 한울과 이야기하기<small>마을 한가운데 제단 옆에 있어요</small>';
    else if (g.bossState === 'dead') q = '승리! 섬에 빛이 돌아왔습니다<small>곧 더 강한 새 순환이 시작됩니다</small>';
    else if (g.bossState === 'awake') q = '그림자 군주 쓰러뜨리기<small>화산 협곡을 지나 분화구로</small>';
    else q = `별조각 모으기 ${g.shards.size}/${SHARD_COUNT}<small>지도에서 ★ 위치를 확인하세요</small>`;
    this.set('quest', 'quest', q, (el, v) => (el.innerHTML = v));

    const b = BIOME_INFO[g.world.biomeAt(p.pos.x, p.pos.z)];
    const inVillage = Math.hypot(p.pos.x, p.pos.z) < 44;
    this.set('region', 'region', inVillage ? '새벽 마을' : `${b.name} · Lv.${b.level}`, (el, v) => (el.textContent = v));
    const friends = g.ents.players.size;
    this.set('friends', 'friends', friends, (el, v) => {
      el.classList.toggle('hidden', v === 0);
      el.textContent = `● 함께하는 친구 ${v}명`;
    });
    this.set('rest', 'rest', p.resting && p.hp < p.maxHp, (el, v) => el.classList.toggle('hidden', !v));
    this.set('vignette', 'low', p.hp > 0 && p.hp <= 2 && p.state !== 'dead', (el, v) => el.classList.toggle('low', v));
    this.set('death', 'dead', p.state === 'dead', (el, v) => el.classList.toggle('hidden', !v));

    // 대상 정보
    const t = g.ents.target;
    if (t && !t.info.boss) {
      const frac = Math.max(0, Math.min(1, t.hp / t.maxHp));
      this.set('target', 'tshow', true, (el) => el.classList.remove('hidden'));
      this.set('target-name', 'tname', `${t.info.name} Lv.${t.info.level}`, (el, v) => (el.textContent = v));
      this.set('target-fill', 'tfill', Math.round(frac * 100), (el, v) => (el.style.width = v + '%'));
    } else this.set('target', 'tshow', false, (el) => el.classList.add('hidden'));
    // 보스 체력
    const boss = g.ents.monsters.get(g.pois.bossId);
    if (boss && !boss.dying) {
      this.set('boss', 'bshow', true, (el) => el.classList.remove('hidden'));
      this.set('boss-name', 'bname', MON.lord.name, (el, v) => (el.textContent = v));
      this.set('boss-fill', 'bfill', Math.round((boss.hp5 / 31) * 100), (el, v) => (el.style.width = v + '%'));
    } else this.set('boss', 'bshow', false, (el) => el.classList.add('hidden'));

    // 주목한 대상 위에 표시를 띄운다
    const lk = p.lock;
    let lockOn = false;
    if (lk) {
      _v.set(lk.x, lk.y + lk.info.def.height * (lk.info.elite ? 1.45 : 1) * 0.55, lk.z).project(g.gfx.camera);
      if (_v.z > -1 && _v.z < 1) {
        lockOn = true;
        $('lock').style.transform = `translate(${((_v.x * 0.5 + 0.5) * window.innerWidth).toFixed(1)}px, ${((-_v.y * 0.5 + 0.5) * window.innerHeight).toFixed(1)}px)`;
      }
    }
    this.set('lock', 'lock', lockOn, (el, v) => el.classList.toggle('hidden', !v));

    // 상호작용 안내
    const uiOpen = this.anyOpen();
    this.set('keyhints', 'uiopen', uiOpen, (el, v) => (el.style.visibility = v ? 'hidden' : ''));
    const it = g.currentInteract;
    const label = it && !uiOpen ? it.label() : '';
    this.set('prompt', 'prompt', label, (el, v) => {
      el.classList.toggle('hidden', !v);
      if (v) el.innerHTML = `<kbd>E</kbd><span>${esc(v)}</span>`;
      el.classList.toggle('locked', v.startsWith('봉인'));
    });

    // 대사를 한 글자씩
    const ty = this.type;
    if (ty) {
      ty.n += dt * 46;
      if (ty.n >= ty.full.length) this._typeDone();
      else $('dialog-text').textContent = ty.full.slice(0, Math.floor(ty.n));
    }

    this.mmT -= dt;
    if (this.mmT <= 0) {
      this.mmT = 0.066;
      this.drawMinimap();
      if (this.mapOpen) this.drawMap();
    }
  }

  hurtFlash() {
    const v = $('vignette');
    v.classList.add('hit');
    clearTimeout(this._hv);
    this._hv = setTimeout(() => v.classList.remove('hit'), 90);
  }

  toast(text, good, cls = '') {
    const wrap = $('toasts');
    // 같은 문구가 연달아 뜨지 않게
    if (this._lastToast === text && Date.now() - this._lastToastAt < 1800) return;
    this._lastToast = text;
    this._lastToastAt = Date.now();
    const el = document.createElement('div');
    el.className = 'toast' + (good ? ' good' : '') + (cls ? ' ' + cls : '');
    el.textContent = text;
    wrap.appendChild(el);
    while (wrap.children.length > 4) wrap.removeChild(wrap.firstChild);
    setTimeout(() => el.remove(), 3300);
  }

  _replay(el, ms) {
    el.classList.remove('hidden');
    el.style.animation = 'none';
    void el.offsetWidth;
    el.style.animation = '';
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.add('hidden'), ms);
  }

  banner(title, sub = '') {
    $('banner-title').textContent = title;
    $('banner-sub').textContent = sub;
    $('region-card').classList.add('hidden');
    this._replay($('banner'), 3700);
  }

  // 새 지역에 들어섰을 때 뜨는 지역 이름
  region(title, sub = '', warn = false) {
    if (!$('banner').classList.contains('hidden')) return;
    $('region-title').textContent = title;
    $('region-sub').textContent = sub;
    $('region-card').classList.toggle('warn', warn);
    this._replay($('region-card'), 4300);
  }

  netStatus(text) {
    const el = $('net');
    el.textContent = text || '';
    el.classList.toggle('hidden', !text);
  }

  // ================= 터치 버튼 배치 바꾸기 =================
  // 저장 형식: settings.touch = { opacity, btn: { attack: { r, b, w }, ... } }  (r·b: 오른쪽·아래에서의 거리, w: 지름)
  _bindTouchEdit() {
    const g = this.game;
    this.editing = false;
    this.editSel = null;
    const wrap = $('abtns');
    let drag = null;
    for (const btn of document.querySelectorAll('.abtn')) {
      btn.addEventListener('pointerdown', (e) => {
        if (!this.editing) return;
        e.preventDefault();
        this._editSelect(btn);
        const r = btn.getBoundingClientRect();
        drag = { btn, ox: e.clientX - (r.left + r.width / 2), oy: e.clientY - (r.top + r.height / 2), id: e.pointerId };
        if (btn.setPointerCapture) btn.setPointerCapture(e.pointerId);
      });
      btn.addEventListener('pointermove', (e) => {
        if (!drag || drag.btn !== btn || e.pointerId !== drag.id) return;
        // 화면 좌표 -> 버튼 묶음(#abtns) 기준의 오른쪽·아래 거리로 바꾼다 (작은 화면에서는 묶음이 축소돼 있다)
        const wr = wrap.getBoundingClientRect();
        const k = wr.width / wrap.offsetWidth || 1;
        const w = btn.offsetWidth;
        const cx = Math.min(window.innerWidth - 20, Math.max(20, e.clientX - drag.ox));
        const cy = Math.min(window.innerHeight - 20, Math.max(20, e.clientY - drag.oy));
        btn.style.right = Math.round((wr.right - cx) / k - w / 2) + 'px';
        btn.style.bottom = Math.round((wr.bottom - cy) / k - w / 2) + 'px';
      });
      const end = (e) => {
        if (drag && drag.btn === btn && e.pointerId === drag.id) drag = null;
      };
      btn.addEventListener('pointerup', end);
      btn.addEventListener('pointercancel', end);
    }
    for (const b of document.querySelectorAll('#touch-edit [data-te]')) {
      b.addEventListener('click', () => {
        const act = b.dataset.te;
        const sel = this.editSel;
        if (act === 'smaller' || act === 'bigger') {
          if (!sel) return this.toast('먼저 크기를 바꿀 버튼을 눌러 주세요.');
          const w = Math.min(150, Math.max(40, sel.offsetWidth + (act === 'bigger' ? 8 : -8)));
          // 가운데를 유지한 채 크기만 바꾼다
          const d = (w - sel.offsetWidth) / 2;
          const cs = getComputedStyle(sel);
          sel.style.right = Math.round(parseFloat(cs.right) - d) + 'px';
          sel.style.bottom = Math.round(parseFloat(cs.bottom) - d) + 'px';
          sel.style.width = sel.style.height = w + 'px';
          sel.style.fontSize = Math.round(Math.max(11, w * 0.19)) + 'px';
        } else if (act === 'fainter' || act === 'solid') {
          const o = Math.min(1, Math.max(0.25, (this._touchOpacity || 1) + (act === 'solid' ? 0.15 : -0.15)));
          this._touchOpacity = o;
          for (const q of document.querySelectorAll('.abtn')) q.style.opacity = o;
        } else if (act === 'reset') {
          delete g.save.settings.touch;
          this.applyTouchLayout();
          this._editSelect(null);
        } else if (act === 'done') this.endTouchEdit();
      });
    }
    this.applyTouchLayout();
  }

  _editSelect(btn) {
    if (this.editSel) this.editSel.classList.remove('sel');
    this.editSel = btn;
    if (btn) btn.classList.add('sel');
  }

  // 저장된 배치를 버튼에 적용한다 (없으면 기본 배치)
  applyTouchLayout() {
    const t = this.game.save.settings.touch;
    this._touchOpacity = (t && t.opacity) || 1;
    for (const btn of document.querySelectorAll('.abtn')) {
      const q = t && t.btn && t.btn[btn.dataset.act];
      btn.style.right = q ? q.r + 'px' : '';
      btn.style.bottom = q ? q.b + 'px' : '';
      btn.style.width = btn.style.height = q ? q.w + 'px' : '';
      btn.style.fontSize = q ? Math.round(Math.max(11, q.w * 0.19)) + 'px' : '';
      btn.style.opacity = t && t.opacity ? t.opacity : '';
    }
  }

  startTouchEdit() {
    this.closeAll();
    this.editing = true;
    this.game.input.editing = true;
    document.body.classList.add('touch-edit');
    $('touch-edit').classList.remove('hidden');
    this._editSelect(null);
  }

  endTouchEdit() {
    const g = this.game;
    const btn = {};
    for (const b of document.querySelectorAll('.abtn')) {
      const cs = getComputedStyle(b);
      btn[b.dataset.act] = { r: Math.round(parseFloat(cs.right)), b: Math.round(parseFloat(cs.bottom)), w: b.offsetWidth };
    }
    g.save.settings.touch = { opacity: this._touchOpacity || 1, btn };
    g.saveSoon();
    this.editing = false;
    g.input.editing = false;
    document.body.classList.remove('touch-edit');
    $('touch-edit').classList.add('hidden');
    this._editSelect(null);
    this.applyTouchLayout();
    this.toast('버튼 배치를 저장했습니다.', true);
  }

  // ================= 채팅 =================
  _bindChat() {
    const quick = ['안녕!', '이리 와!', '도와줘!', '고마워!', '같이 가자', '잠깐만', '좋았어!', 'ㅋㅋㅋ'];
    const qw = $('chat-quick');
    for (const q of quick) {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = q;
      b.addEventListener('click', () => {
        this.game.net.send({ t: 'chat', text: q });
        this.closeChat();
      });
      qw.appendChild(b);
    }
    $('chat-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const inp = $('chat-input');
      const text = inp.value.trim();
      if (text) this.game.net.send({ t: 'chat', text });
      inp.value = '';
      this.closeChat();
    });
    $('chat-close').addEventListener('click', () => this.closeChat());
  }

  openChat() {
    this.closeAll();
    $('chat-row').classList.remove('hidden');
    this.game.input.unlock();
    this.game.input.autoRun = false;
    $('chat-input').placeholder = this.game.input.isTouch ? '메시지를 입력하세요' : '메시지 입력 · Enter 보내기 · Tab 닫기';
    $('chat-input').focus();
    setTimeout(() => $('chat-input').focus(), 30);
  }

  closeChat() {
    $('chat-row').classList.add('hidden');
    $('chat-input').blur();
  }

  chatAdd(name, text, cls = '') {
    const log = $('chat-log');
    const el = document.createElement('div');
    el.className = 'chat-line ' + cls;
    el.innerHTML = name ? `<b>${esc(name)}</b>${esc(text)}` : esc(text);
    log.appendChild(el);
    while (log.children.length > 6) log.removeChild(log.firstChild);
    setTimeout(() => el.remove(), 12500);
  }

  // ================= 메뉴 · 패널 =================
  _bindPanels() {
    for (const b of document.querySelectorAll('[data-close]')) b.addEventListener('click', () => this.closeAll());
    for (const b of document.querySelectorAll('#menu-tabs [data-tab]')) {
      b.addEventListener('click', () => {
        this.game.audio.click();
        this.open(b.dataset.tab);
      });
    }
    for (const id of this.panels) {
      $(id).addEventListener('click', (e) => {
        if (e.target === $(id)) this.closeAll();
      });
    }
    const g = this.game;
    for (const b of document.querySelectorAll('#set-quality button')) {
      b.addEventListener('click', () => {
        g.setQuality(b.dataset.q, true);
        this.refreshSettings();
      });
    }
    $('set-sound').addEventListener('click', () => {
      g.save.settings.sound = !g.save.settings.sound;
      g.audio.setSound(g.save.settings.sound);
      this.refreshSettings();
    });
    $('set-music').addEventListener('click', () => {
      g.save.settings.music = !g.save.settings.music;
      g.audio.setMusic(g.save.settings.music);
      this.refreshSettings();
    });
    $('set-follow').addEventListener('click', () => {
      g.save.settings.follow = !g.save.settings.follow;
      g.saveSoon();
      this.refreshSettings();
    });
    $('set-sens').addEventListener('input', (e) => {
      g.save.settings.sens = +e.target.value;
      g.input.sens = g.save.settings.sens;
      g.saveSoon();
    });
    $('set-full').addEventListener('click', () => {
      const d = document;
      if (d.fullscreenElement) d.exitFullscreen();
      else if (d.documentElement.requestFullscreen) d.documentElement.requestFullscreen().catch(() => this.toast('이 기기에서는 전체 화면을 쓸 수 없어요.'));
      else this.toast('브라우저 메뉴의 "홈 화면에 추가"를 쓰면 전체 화면으로 즐길 수 있어요.');
    });
    $('set-invite').addEventListener('click', () => this.invite());
    $('set-touch').addEventListener('click', () => this.startTouchEdit());
    $('set-reset').addEventListener('click', () => {
      const b = $('set-reset');
      if (b.dataset.sure) g.resetCharacter();
      else {
        b.dataset.sure = '1';
        b.textContent = '정말요? 한 번 더';
        setTimeout(() => {
          delete b.dataset.sure;
          b.textContent = '처음부터';
        }, 3000);
      }
    });
    $('map').addEventListener('click', (e) => this._mapClick(e));
  }

  // 친구 초대: 휴대폰에서는 공유 창(카카오톡 등), PC 에서는 주소 복사
  async invite() {
    const url = location.origin + '/';
    if (navigator.share) {
      try {
        await navigator.share({ title: '별조각 원정대', text: '같이 모험하자! 링크를 누르면 바로 같은 세계에서 만날 수 있어.', url });
        return;
      } catch (err) {
        if (err && err.name === 'AbortError') return;
      }
    }
    try {
      await navigator.clipboard.writeText(url);
      this.toast('주소를 복사했어요. 친구에게 보내 주세요!', true);
    } catch {
      this.toast(url);
    }
  }

  anyOpen() {
    if (this.editing) return true;
    if (!$('chat-row').classList.contains('hidden') || !$('dialog').classList.contains('hidden')) return true;
    return !!this.openPanel();
  }

  openMenu() {
    this.open(this.lastTab);
  }

  // remember: 다음에 메뉴를 열 때 이 탭부터 보여 줄지 (처음 뜨는 조작법 안내는 기억하지 않는다)
  open(id, remember = true) {
    this.closeAll();
    const g = this.game;
    g.input.unlock();
    g.input.autoRun = false;
    $(id).classList.remove('hidden');
    const isTab = TABS.includes(id);
    $('menu-tabs').classList.toggle('hidden', !isTab);
    if (isTab) {
      if (remember) this.lastTab = id;
      for (const b of document.querySelectorAll('#menu-tabs [data-tab]')) b.classList.toggle('on', b.dataset.tab === id);
    }
    const foot = $('menu-foot');
    foot.classList.remove('hidden');
    const k = (keys, label) => `<span>${keys.map((x) => `<kbd>${x}</kbd>`).join('')}${label}</span>`;
    if (id === 'panel-map') foot.innerHTML = k(['↑', '↓', '←', '→'], '귀환석 고르기') + k(['Enter'], '이동') + k(['Q', 'E'], '탭') + k(['Tab'], '닫기');
    else if (isTab) foot.innerHTML = k(['↑', '↓', '←', '→'], '고르기') + k(['Enter'], '선택') + k(['Q', 'E'], '탭') + k(['Tab'], '닫기');
    else foot.innerHTML = k(['↑', '↓'], '고르기') + k(['Enter'], '사기') + k(['Tab'], '닫기');

    if (id === 'panel-map') {
      this.mapOpen = true;
      this._mapInitSel();
      this.drawMap();
    } else if (id === 'panel-bag') this.refreshBag();
    else if (id === 'panel-inv') {
      foot.innerHTML = k(['↑', '↓', '←', '→'], '고르기') + k(['Enter'], '착용 · 벗기') + k(['X'], '버리기') + k(['Q', 'E'], '탭') + k(['Tab'], '닫기');
      this.bagDirty = false;
      this.refreshInv();
      return;
    } else if (id === 'panel-settings') this.refreshSettings();
    else if (id === 'panel-help') this.refreshHelp();
    if (id !== 'panel-map') {
      const box = $(id).querySelector('.panel-box');
      box.scrollTop = 0;
      this.setFocus(this._focusables(box)[0] || null, false);
    }
  }

  toggle(id) {
    if ($(id).classList.contains('hidden')) this.open(id);
    else this.closeAll();
  }

  closeAll() {
    // 교환 창을 닫으면 교환이 취소된다
    if (this.trade) {
      this.trade = null;
      this.game.net.send({ t: 'tr', a: 'cancel' });
    }
    for (const id of this.panels) $(id).classList.add('hidden');
    $('menu-tabs').classList.add('hidden');
    $('menu-foot').classList.add('hidden');
    $('dialog').classList.add('hidden');
    this.closeChat();
    this.mapOpen = false;
    this.dialogQueue = null;
    this.type = null;
    this.setFocus(null);
  }

  refreshSettings() {
    const g = this.game;
    for (const b of document.querySelectorAll('#set-quality button')) b.classList.toggle('on', b.dataset.q === g.gfx.qualityName);
    const s = g.save.settings;
    $('set-sound').textContent = s.sound ? '켜짐' : '꺼짐';
    $('set-sound').classList.toggle('on', s.sound);
    $('set-music').textContent = s.music ? '켜짐' : '꺼짐';
    $('set-music').classList.toggle('on', s.music);
    $('set-sens').value = s.sens;
    $('set-follow').textContent = s.follow ? '켜짐' : '꺼짐';
    $('set-follow').classList.toggle('on', !!s.follow);
  }

  refreshHelp() {
    const touch = this.game.input.isTouch;
    const K = (...keys) => keys.map((x) => (x === '/' ? '<em>또는</em>' : `<kbd>${esc(x)}</kbd>`)).join('');
    let rows;
    if (touch) {
      rows = [
        ['왼쪽 화면 드래그', '이동'], ['오른쪽 화면 드래그', '시점 돌리기'], ['공격', '검 휘두르기 (연타하면 3연속 공격)'],
        ['점프', '뛰기 · 공중에서 한 번 더 누르면 활공'], ['구르기', '구르는 동안은 공격에 맞지 않음 (기력 소모)'], ['활', '가까운 적에게 화살 쏘기'], ['열매', '회복 열매 먹기 (하트 3칸)'],
        ['달리기', '켜 두면 빠르게 달림 (기력 소모)'], ['탈것', '말을 타고 내리기 (상인에게서 말 피리를 사면 생겨요)'], ['화면 가운데 버튼', '대화 · 상자 열기 · 별조각 얻기'],
        ['오른쪽 위 ≡', '메뉴 (지도 · 가방 · 모험가 · 설정)'],
      ].map(([a, b]) => [esc(a), b]);
    } else {
      rows = [
        [K('W', 'A', 'S', 'D'), '이동'],
        [K('←', '→', '↑', '↓'), '시점 돌리기 (마우스로도 됩니다)'],
        [K('Space'), '점프 · 공중에서 한 번 더 누르면 활공'],
        [K('Shift'), '누르는 동안 달리기 (기력 소모)'],
        [K('T'), '자동 달리기 켜기/끄기 (S 를 누르면 꺼짐)'],
        [K('F', '/', 'J'), '무기 휘두르기 (연타하면 연속 공격 · 무기마다 다름)'],
        [K('X', '/', 'I'), '구르기 — 구르는 동안은 공격에 맞지 않음 (기력 소모)'],
        [K('R', '/', 'K'), '활 쏘기'],
        [K('C', '/', 'L'), '주목 — 가까운 몬스터를 계속 바라보기 (다시 누르면 해제)'],
        [K('E'), '대화 · 상자 열기 · 별조각 얻기'],
        [K('Q'), '회복 열매 먹기'],
        [K('G'), '탈것 타고 내리기 (상인에게서 말 피리를 사면 생겨요)'],
        [K('Tab'), '메뉴 열기/닫기 (Q · E 로 탭 넘기기, Esc 로도 닫힘)'],
        [K('B'), '가방 — 얻은 장비 보기 · 착용하기'],
        [K('M', 'P', 'H'), '지도 · 모험가 · 조작법 바로 열기'],
        [K('Enter'), '채팅'],
        [K('1', '2', '3'), '손 흔들기 · 환호 · 앉기'],
        [K('−', '='), '시점 멀리 · 가까이'],
        [K('V'), '시점을 캐릭터 뒤쪽으로'],
      ];
    }
    $('help-body').innerHTML =
      `<div class="help-grid">${rows.map(([k, v]) => `<div class="keys">${k}</div><span>${esc(v)}</span>`).join('')}</div>` +
      '<div class="sec">장비와 강화</div><div class="help-note">몬스터를 쓰러뜨리거나 보물상자를 열면 장비(무기 · 활 · 갑옷 · 투구 · 부적)와 별가루가 나옵니다. 등급은 일반 → 고급 → 희귀 → 영웅 → 전설 순으로 좋아져요. 가방에서 착용하고, 필요 없는 것은 상인에게 팔고, 대장장이에게 별가루를 주면 강화할 수 있습니다. 강화에 성공하면 무기의 모습도 달라져요.</div>' +
      '<div class="sec">알아 두면 좋은 것</div><div class="help-note">가파른 절벽은 기력으로 오를 수 있고, 깊은 물에서는 헤엄칩니다. 기력이 바닥나면 미끄러지거나 물가로 떠밀려 가요. 진행 상황은 이 기기에 자동으로 저장됩니다.</div>' +
      (touch ? '<div class="help-note" style="margin-top:6px">키보드를 연결해 아무 키나 누르면 키보드 조작으로 바뀝니다.</div>' : '');
  }

  refreshBag() {
    const g = this.game;
    const s = g.save;
    const p = g.player;
    const max = s.level >= MAX_LEVEL;
    const need = xpNeed(s.level);
    let h = `<div class="hero"><div class="hero-badge"><small>Lv</small><b>${s.level}</b></div><div class="hero-info"><h3>${esc(s.name)}</h3>`;
    h += `<div class="hero-xp"><div style="width:${max ? 100 : Math.round((s.xp / need) * 100)}%"></div></div><small>${max ? '최고 레벨입니다' : `다음 레벨까지 경험치 ${need - s.xp}`}</small></div></div>`;
    h += '<div class="sec">능력치</div><div class="stat-grid">';
    const stat = (label, v) => `<div><span>${label}</span><b>${v}</b></div>`;
    h += stat(`공격력 <em>${WEAPONS[p.wkind].name}</em>`, p.atk) + stat('활 공격력', p.bowAtk || '—') + stat('방어력', p.def) + stat('치명타', Math.round(p.crit * 100) + '%');
    h += stat('하트', p.maxHp / 2 + '칸') + stat('기력', p.maxStamina) + (p.swift ? stat('이동 속도', '+' + Math.round(p.swift * 100) + '%') : '') + (p.luck ? stat('장비 발견', '+' + Math.round(p.luck * 100) + '%') : '');
    h += '</div><div class="sec">착용 장비</div><div class="gear-grid">';
    for (const slot of SLOTS) {
      const it = s.eq[slot];
      const ic = icon(it ? it.t : slot === 'weapon' ? 'sword' : slot);
      if (it) h += `<div class="gear">${ic}<div><b style="color:${RARITY[it.r].css}">${esc(itemName(it))}</b><small>${esc(itemStatText(it))}</small></div></div>`;
      else h += `<div class="gear none">${ic}<div><b>${SLOT_NAME[slot]} 없음</b><small>사냥이나 상자에서 얻을 수 있어요</small></div></div>`;
    }
    h += `<div class="gear${s.glider ? '' : ' none'}">${icon('glider')}<div><b>활공 천</b><small>${s.glider ? '공중에서 점프를 한 번 더' : '아직 없음 — 촌장에게'}</small></div></div>`;
    h += `<div class="gear${s.mount ? '' : ' none'}">${icon('horse')}<div><b>말</b><small>${s.mount ? (g.input.isTouch ? '탈것 버튼으로 타고 내리기' : 'G 키로 타고 내리기') : '아직 없음 — 상인의 말 피리'}</small></div></div>`;
    h += '</div><div class="row-btns" style="margin-top:10px"><button data-open="panel-inv" class="primary">가방 열기 · 장비 바꾸기</button></div>';
    h += '<div class="sec">감정 표현</div><div class="row-btns"><button data-em="emote1">손 흔들기</button><button data-em="emote2">환호</button><button data-em="emote3">앉기</button></div>';
    h += `<div class="sec">함께하는 모험가 ${g.ents.players.size + 1}명</div><div class="plist"><div><span>${esc(s.name)} (나)</span><b>Lv.${s.level}</b></div>`;
    for (const e of g.ents.players.values()) h += `<div><span>${esc(e.prof.name)}</span><b>Lv.${e.prof.lvl}</b><button data-trade="${e.id}">교환 신청</button></div>`;
    if (!g.ents.players.size) h += '<p class="it-desc" style="margin:4px 2px 0">친구가 들어오면 여기서 장비와 골드를 교환할 수 있어요.</p>';
    h += `</div><div class="sec">기록</div><div class="plist"><div><span>처치한 몬스터</span><b>${s.kills}</b></div><div><span>별조각</span><b>${g.shards.size}/${SHARD_COUNT}</b></div><div><span>세계 순환</span><b>${g.cycle + 1}회차</b></div></div>`;
    $('bag-body').innerHTML = h;
    for (const b of document.querySelectorAll('#bag-body [data-em]')) {
      b.addEventListener('click', () => {
        this.closeAll();
        g.input.pressed.add(b.dataset.em);
      });
    }
    for (const b of document.querySelectorAll('#bag-body [data-open]')) b.addEventListener('click', () => this.open(b.dataset.open));
    for (const b of document.querySelectorAll('#bag-body [data-trade]')) b.addEventListener('click', () => this.requestTrade(+b.dataset.trade));
  }

  // ================= 대화 / 상점 =================
  // lines: 문자열 배열, 마지막 줄에서 buttons [{text, primary, fn}] 표시
  dialog(name, lines, buttons, onDone) {
    this.closeAll();
    const g = this.game;
    g.input.unlock();
    g.input.autoRun = false;
    this.dialogQueue = { name, lines: lines.slice(), buttons, onDone };
    $('dialog').classList.remove('hidden');
    $('dialog-hint').innerHTML = '<kbd>Enter</kbd>계속';
    this._dialogNext();
  }

  _dialogNext() {
    const q = this.dialogQueue;
    if (!q) return;
    const line = q.lines.shift();
    $('dialog-name').textContent = q.name;
    $('dialog-text').textContent = '';
    this.type = { full: line, n: 0 };
    const wrap = $('dialog-btns');
    wrap.innerHTML = '';
    const add = (text, primary, fn, cls = '') => {
      const b = document.createElement('button');
      b.textContent = text;
      b.className = (primary ? 'primary ' : '') + cls;
      b.addEventListener('click', () => {
        this.game.audio.click();
        // 글자가 아직 나오는 중이면 먼저 끝까지 보여 준다
        if (this.type) this._typeDone();
        else fn();
      });
      wrap.appendChild(b);
      return b;
    };
    let first;
    if (q.lines.length) first = add('다음', true, () => this._dialogNext(), 'next');
    else {
      for (const bt of q.buttons || []) {
        const b = add(bt.text, bt.primary, bt.fn);
        if (!first && bt.primary) first = b;
      }
      const close = add(q.buttons && q.buttons.length ? '닫기' : '확인', !(q.buttons && q.buttons.length), () => {
        const done = q.onDone;
        this.closeAll();
        if (done) done();
      });
      if (!first) first = close;
    }
    this.setFocus(first);
  }

  _typeDone() {
    if (!this.type) return;
    $('dialog-text').textContent = this.type.full;
    this.type = null;
  }

  // Enter/E/Space 로 대화 넘기기
  dialogKey() {
    if ($('dialog').classList.contains('hidden')) return false;
    const wrap = $('dialog-btns');
    const b = (this.focusEl && wrap.contains(this.focusEl) && this.focusEl) || wrap.querySelector('button.primary') || wrap.querySelector('button');
    if (b) b.click();
    return true;
  }

  talk(npc) {
    const g = this.game;
    const s = g.save;
    const n = npc.def;
    npc.talkT = 1.6;
    if (n.kind === 'elder') {
      if (!s.talkedElder) {
        this.dialog(n.name, [
          '어서 오게, 젊은 모험가여. 나는 이 새벽 마을의 촌장 한울이라네.',
          '오래전 하늘의 별이 부서져 열두 개의 별조각이 섬 곳곳에 흩어졌지. 그 뒤로 화산 깊은 곳의 「그림자 군주」가 섬을 어둠으로 물들이고 있다네.',
          '별조각 열두 개를 모두 모아 이 제단을 밝히면 군주에게 맞설 길이 열릴 걸세. 별조각이 있을 만한 곳을 자네 지도에 표시해 두었네.',
          '이 활공 천을 가져가게. 높은 곳에서 뛰어내린 뒤 점프를 한 번 더 누르면 하늘을 날 수 있지. 친구들과 힘을 모으게나!',
        ], null, () => g.onElderIntro());
      } else {
        const left = SHARD_COUNT - g.shards.size;
        let lines;
        if (g.bossState === 'dead') lines = ['자네들 덕분에 섬에 빛이 돌아왔네! 하지만 어둠은 언젠가 더 강해져서 돌아오는 법… 그때도 부탁하네.'];
        else if (g.bossState === 'awake') lines = ['별조각이 모두 모였네! 제단이 이렇게 밝게 빛나다니…', '북동쪽 잿불 화산의 협곡을 지나 분화구로 가게. 그림자 군주가 깨어났다네. 혼자는 벅찰 테니 친구들과 함께 가게나.'];
        else lines = [`지금까지 별조각 ${g.shards.size}개를 밝혔군. 아직 ${left}개가 남았네.`, '초원부터 차근차근 돌아보게. 먼 곳일수록 몬스터가 강하니 대장간에서 장비를 갖추는 것도 잊지 말게.'];
        this.dialog(n.name, lines);
      }
    } else if (n.kind === 'merchant') {
      this.dialog(n.name, ['어서 오세요! 모험에 필요한 건 다 있답니다. 사냥해서 얻은 장비도 좋은 값에 사 드려요.'], [
        { text: '물건 사기', primary: true, fn: () => this.openShop('merchant', 'buy') },
        { text: '장비 팔기', fn: () => this.openShop('merchant', 'sell') },
      ]);
    } else if (n.kind === 'smith') {
      this.dialog(n.name, ['쓸 만한 무기가 필요한가? 검, 대검, 창, 쌍단검, 망치… 손에 맞는 걸 골라 보게. 별가루를 가져오면 강화도 해 주지.'], [
        { text: '장비 사기', primary: true, fn: () => this.openShop('smith', 'buy') },
        { text: '강화하기', fn: () => this.openShop('smith', 'enh') },
      ]);
    } else if (n.kind === 'kid') {
      this._kidTip = ((this._kidTip ?? -1) + 1) % KID_TIPS.length;
      this.dialog(n.name, [KID_TIPS[this._kidTip]]);
    } else {
      this.dialog(n.name, [GUIDE_TIPS[n.stone] || '조심해서 다니세요!']);
    }
  }

  // ================= 지도 =================
  buildMapCanvas(pixels) {
    const c = document.createElement('canvas');
    c.width = W.VERTS;
    c.height = W.VERTS;
    c.getContext('2d').putImageData(new ImageData(pixels, W.VERTS, W.VERTS), 0, 0);
    this.mapCanvas = c;
  }

  drawMinimap() {
    const g = this.game;
    const ctx = this.mmCtx;
    const S = 280;
    const p = g.player;
    const RANGE = 120; // 지도에 보이는 반경 (월드 단위)
    const scale = S / (RANGE * 2);
    ctx.fillStyle = '#123154';
    ctx.fillRect(0, 0, S, S);
    if (this.mapCanvas) {
      const src = (RANGE * 2) / W.CELL;
      const sx = (p.pos.x + W.HALF) / W.CELL - src / 2;
      const sy = (p.pos.z + W.HALF) / W.CELL - src / 2;
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(this.mapCanvas, sx, sy, src, src, 0, 0, S, S);
    }
    const toX = (x) => (x - p.pos.x) * scale + S / 2;
    const toY = (z) => (z - p.pos.z) * scale + S / 2;
    const inside = (x, z) => Math.hypot(x - p.pos.x, z - p.pos.z) < RANGE - 6;

    // 목표 방향 화살표
    const goal = g.questGoal();
    if (goal && !inside(goal.x, goal.z)) {
      const a = Math.atan2(goal.z - p.pos.z, goal.x - p.pos.x);
      ctx.save();
      ctx.translate(S / 2 + Math.cos(a) * (S / 2 - 16), S / 2 + Math.sin(a) * (S / 2 - 16));
      ctx.rotate(a);
      ctx.fillStyle = '#ffd35a';
      ctx.strokeStyle = '#3a2a08';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(12, 0);
      ctx.lineTo(-8, -9);
      ctx.lineTo(-8, 9);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
    for (const st of g.objects.stones) {
      if (!inside(st.x, st.z)) continue;
      this._diamond(ctx, toX(st.x), toY(st.z), 8, st.active ? '#5fe0ff' : '#8a94a8');
    }
    if (g.save.talkedElder) {
      for (const sh of g.objects.shards) {
        if (sh.collected || !inside(sh.x, sh.z)) continue;
        this._star(ctx, toX(sh.x), toY(sh.z), 11, sh.sealed ? '#d08aff' : '#ffd35a');
      }
    }
    for (const n of g.objects.npcs) {
      if (!inside(n.x, n.z)) continue;
      ctx.fillStyle = '#ffe9a8';
      ctx.beginPath();
      ctx.arc(toX(n.x), toY(n.z), 4, 0, 6.3);
      ctx.fill();
    }
    const lock = p.lock;
    for (const e of g.ents.monsters.values()) {
      if (e.dying || !e.shown || !inside(e.x, e.z)) continue;
      ctx.fillStyle = e === lock ? '#ffd35a' : '#ff5a5f';
      ctx.beginPath();
      ctx.arc(toX(e.x), toY(e.z), e === lock ? 6 : e.info.elite || e.info.type === 'golem' || e.info.boss ? 6 : 3.5, 0, 6.3);
      ctx.fill();
    }
    for (const e of g.ents.players.values()) {
      if (!e.seen) continue;
      let x = toX(e.x);
      let y = toY(e.z);
      const d = Math.hypot(x - S / 2, y - S / 2);
      const lim = S / 2 - 10;
      if (d > lim) {
        x = S / 2 + ((x - S / 2) / d) * lim;
        y = S / 2 + ((y - S / 2) / d) * lim;
      }
      ctx.fillStyle = '#7fe08a';
      ctx.strokeStyle = '#0c2a12';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, y, 6, 0, 6.3);
      ctx.fill();
      ctx.stroke();
    }
    // 시야 방향 (부채꼴)
    ctx.save();
    ctx.translate(S / 2, S / 2);
    ctx.rotate(-p.camYaw);
    const fan = ctx.createRadialGradient(0, 0, 4, 0, 0, 62);
    fan.addColorStop(0, 'rgba(255,255,255,0.34)');
    fan.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = fan;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, 62, Math.PI / 2 - 0.5, Math.PI / 2 + 0.5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    // 나
    ctx.save();
    ctx.translate(S / 2, S / 2);
    ctx.rotate(-p.yaw);
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#1f5fd0';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, 13);
    ctx.lineTo(-9, -9);
    ctx.lineTo(0, -4);
    ctx.lineTo(9, -9);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
    ctx.restore();
  }

  _diamond(ctx, x, y, r, color) {
    ctx.fillStyle = color;
    ctx.strokeStyle = '#0b1222';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, y - r);
    ctx.lineTo(x + r, y);
    ctx.lineTo(x, y + r);
    ctx.lineTo(x - r, y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  _star(ctx, x, y, r, color) {
    ctx.fillStyle = color;
    ctx.strokeStyle = '#3a2a08';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + (i * Math.PI) / 5;
      const rr = i % 2 ? r * 0.45 : r;
      ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  drawMap() {
    const g = this.game;
    const cv = $('map');
    const ctx = cv.getContext('2d');
    const S = cv.width;
    const k = S / W.SIZE;
    const X = (x) => (x + W.HALF) * k;
    const Y = (z) => (z + W.HALF) * k;
    // 작은 화면에서도 글자와 표시가 읽히도록 크기를 키운다
    const disp = cv.getBoundingClientRect().width || 640;
    const f = Math.max(1, Math.min(2.4, 640 / disp));
    const small = disp < 430;
    ctx.imageSmoothingEnabled = true;
    if (this.mapCanvas) ctx.drawImage(this.mapCanvas, 0, 0, S, S);
    ctx.textAlign = 'center';
    ctx.lineJoin = 'round';
    const text = (str, x, y, size, color) => {
      ctx.font = `800 ${Math.round(size * f)}px "Pretendard", "Apple SD Gothic Neo", "Noto Sans KR", "Malgun Gothic", sans-serif`;
      ctx.lineWidth = 5 * f;
      ctx.strokeStyle = 'rgba(10,16,30,0.85)';
      ctx.strokeText(str, x, y);
      ctx.fillStyle = color;
      ctx.fillText(str, x, y);
    };
    BIOME_CENTERS.forEach(([x, z], i) => {
      if (i === 0) return;
      ctx.globalAlpha = 0.62;
      text(BIOME_INFO[i].name, X(x * 0.9), Y(z * 0.9) - 30 * f, 22, '#fff6df');
      ctx.globalAlpha = 1;
    });
    if (g.bossState === 'awake') {
      ctx.fillStyle = 'rgba(255,90,208,0.9)';
      ctx.beginPath();
      ctx.arc(X(VOLCANO.x), Y(VOLCANO.z), (13 + Math.sin(g.time * 5) * 3) * f, 0, 6.3);
      ctx.fill();
      text('그림자 군주', X(VOLCANO.x), Y(VOLCANO.z) - 20 * f, 17, '#ffb8f0');
    }
    const sel = this.mapSel;
    for (const st of g.objects.stones) {
      this._diamond(ctx, X(st.x), Y(st.z), 11 * f, st.active ? '#5fe0ff' : '#7a8498');
      if (st.active && !small && st !== sel) text(st.def.name, X(st.x), Y(st.z) - 17 * f, 14, '#c8f6ff');
    }
    if (g.save.talkedElder) {
      for (const sh of g.objects.shards) {
        if (sh.collected) {
          ctx.globalAlpha = 0.5;
          this._star(ctx, X(sh.x), Y(sh.z), 9 * f, '#b8b8b8');
          ctx.globalAlpha = 1;
        } else {
          this._star(ctx, X(sh.x), Y(sh.z), 14 * f, sh.sealed ? '#d08aff' : '#ffd35a');
          if (!small) text(sh.def.name, X(sh.x), Y(sh.z) + 30 * f, 13, '#fff3c0');
        }
      }
    }
    for (const e of g.ents.players.values()) {
      if (!e.seen) continue;
      ctx.fillStyle = '#7fe08a';
      ctx.strokeStyle = '#0c2a12';
      ctx.lineWidth = 3 * f;
      ctx.beginPath();
      ctx.arc(X(e.x), Y(e.z), 8 * f, 0, 6.3);
      ctx.fill();
      ctx.stroke();
      text(e.prof.name, X(e.x), Y(e.z) - 14 * f, 14, '#c8ffd0');
    }
    // 고른 귀환석
    if (sel) {
      const pulse = 1 + Math.sin(g.time * 5) * 0.12;
      ctx.strokeStyle = sel.active ? '#ffd35a' : '#c8d0e0';
      ctx.lineWidth = 4 * f;
      ctx.beginPath();
      ctx.arc(X(sel.x), Y(sel.z), 21 * f * pulse, 0, 6.3);
      ctx.stroke();
      text(sel.def.name, X(sel.x), Y(sel.z) - 30 * f, 16, sel.active ? '#ffe9a8' : '#dfe4ee');
    }
    const p = g.player;
    ctx.save();
    ctx.translate(X(p.pos.x), Y(p.pos.z));
    ctx.rotate(-p.yaw);
    ctx.scale(f, f);
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#1f5fd0';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(0, 16);
    ctx.lineTo(-11, -11);
    ctx.lineTo(0, -5);
    ctx.lineTo(11, -11);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
    ctx.restore();
  }

  // 지도를 열면 가장 가까운(깨운) 귀환석이 골라져 있다
  _mapInitSel() {
    const g = this.game;
    const p = g.player.pos;
    let best = null;
    let bd = Infinity;
    for (const st of g.objects.stones) {
      const d = Math.hypot(st.x - p.x, st.z - p.z) + (st.active ? 0 : 5000);
      if (d < bd) {
        bd = d;
        best = st;
      }
    }
    this.mapSel = best;
    this._mapSelInfo();
  }

  _mapSelInfo() {
    const g = this.game;
    const st = this.mapSel;
    const el = $('map-sel');
    let h = `<p>별조각 <b>${g.shards.size}/${SHARD_COUNT}</b> · 깨운 귀환석 <b>${g.objects.stones.filter((q) => q.active).length}/${g.objects.stones.length}</b></p>`;
    if (st) {
      h += `<h3>${esc(st.def.name)}</h3>`;
      h += st.active ? '<p>깨워 둔 귀환석입니다. 바로 이동할 수 있어요.</p>' : '<p>아직 깨우지 않은 귀환석입니다. 직접 찾아가서 깨워야 해요.</p>';
      h += `<button class="go${st.active ? '' : ' off'}" data-nonav><kbd>Enter</kbd>${st.active ? '여기로 이동' : '이동할 수 없음'}</button>`;
    }
    el.innerHTML = h;
    const go = el.querySelector('.go');
    if (go) go.addEventListener('click', () => this.mapGo());
  }

  // 누른 방향에 있는 귀환석 고르기
  mapMove(dx, dy) {
    const g = this.game;
    const cur = this.mapSel;
    if (!cur) return this._mapInitSel();
    let best = null;
    let bs = Infinity;
    for (const st of g.objects.stones) {
      if (st === cur) continue;
      const ddx = st.x - cur.x;
      const ddy = st.z - cur.z;
      const along = dx ? ddx * dx : ddy * dy;
      const across = dx ? Math.abs(ddy) : Math.abs(ddx);
      if (along < 20) continue;
      const score = along + across * 1.6;
      if (score < bs) {
        bs = score;
        best = st;
      }
    }
    if (best) {
      this.mapSel = best;
      g.audio.click();
      this._mapSelInfo();
      this.drawMap();
    }
  }

  mapGo() {
    const st = this.mapSel;
    if (!st) return;
    if (!st.active) {
      this.toast('아직 깨우지 않은 귀환석입니다. 직접 찾아가서 깨워야 해요.');
      return;
    }
    this.closeAll();
    this.game.fastTravel(st);
  }

  _mapClick(e) {
    const g = this.game;
    const cv = $('map');
    const r = cv.getBoundingClientRect();
    const wx = ((e.clientX - r.left) / r.width) * W.SIZE - W.HALF;
    const wz = ((e.clientY - r.top) / r.height) * W.SIZE - W.HALF;
    let best = null;
    let bd = 46;
    for (const st of g.objects.stones) {
      const d = Math.hypot(st.x - wx, st.z - wz);
      if (d < bd) {
        bd = d;
        best = st;
      }
    }
    if (!best) return;
    this.mapSel = best;
    this._mapSelInfo();
    this.mapGo();
    if (this.mapOpen) this.drawMap();
  }
}

installItemsUI(UI);

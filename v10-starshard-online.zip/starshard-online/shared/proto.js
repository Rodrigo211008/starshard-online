// 자주 오가는 위치 데이터는 작은 바이너리 패킷으로, 나머지 이벤트는 JSON 으로 주고받는다.
// 서버와 화면이 주고받는 방식의 판 번호. 서버가 새 판으로 바뀌었는데 화면이 옛것이면(새로고침하지 않은 탭) 화면이 스스로 새로고침한다
export const PROTO_VER = 10;
export const POS_SCALE = 10; // 0.1m 단위 (세계가 넓어져 ±3276m 까지 담는다)
export const PKT_STATE = 1; // 클라이언트 -> 서버: 내 상태
export const PKT_SNAP = 2; // 서버 -> 클라이언트: 주변 스냅샷

const TAU = Math.PI * 2;

export function q(v) {
  const n = Math.round(v * POS_SCALE);
  return n < -32768 ? -32768 : n > 32767 ? 32767 : n;
}
export function yawToByte(yaw) {
  let a = yaw % TAU;
  if (a < 0) a += TAU;
  return Math.round((a / TAU) * 256) & 255;
}
export function byteToYaw(b) {
  return (b / 256) * TAU;
}

// 클라이언트 -> 서버 (10바이트)
export function encodeState(x, y, z, yaw, anim, hp, flags) {
  const buf = new ArrayBuffer(10);
  const dv = new DataView(buf);
  dv.setUint8(0, PKT_STATE);
  dv.setInt16(1, q(x));
  dv.setInt16(3, q(y));
  dv.setInt16(5, q(z));
  dv.setUint8(7, yawToByte(yaw));
  dv.setUint8(8, anim & 255);
  dv.setUint8(9, hp < 0 ? 0 : hp > 255 ? 255 : hp);
  return buf;
}

export function decodeState(dv, out) {
  out.x = dv.getInt16(1) / POS_SCALE;
  out.y = dv.getInt16(3) / POS_SCALE;
  out.z = dv.getInt16(5) / POS_SCALE;
  out.yaw = byteToYaw(dv.getUint8(7));
  out.anim = dv.getUint8(8);
  out.hp = dv.getUint8(9);
  return out;
}

export const SNAP_HEADER = 8;
export const SNAP_PLAYER = 11;
export const SNAP_MONSTER = 8;

// 서버 -> 클라이언트 스냅샷을 DataView 에 기록한다.
export function snapSize(nPlayers, nMonsters) {
  return SNAP_HEADER + nPlayers * SNAP_PLAYER + nMonsters * SNAP_MONSTER;
}

export function writeSnapHeader(dv, timeMs, nPlayers, nMonsters) {
  dv.setUint8(0, PKT_SNAP);
  dv.setUint32(1, timeMs >>> 0);
  dv.setUint8(5, nPlayers);
  dv.setUint16(6, nMonsters);
  return SNAP_HEADER;
}

export function writeSnapPlayer(dv, o, p) {
  dv.setUint8(o, p.id);
  dv.setInt16(o + 1, q(p.x));
  dv.setInt16(o + 3, q(p.y));
  dv.setInt16(o + 5, q(p.z));
  dv.setUint8(o + 7, yawToByte(p.yaw));
  dv.setUint8(o + 8, p.anim);
  dv.setUint8(o + 9, p.hp);
  dv.setUint8(o + 10, p.maxHp);
  return o + SNAP_PLAYER;
}

export function writeSnapMonster(dv, o, m) {
  dv.setUint16(o, m.id);
  dv.setInt16(o + 2, q(m.x));
  dv.setInt16(o + 4, q(m.z));
  dv.setUint8(o + 6, yawToByte(m.yaw));
  dv.setUint8(o + 7, m.state & 255);
  return o + SNAP_MONSTER;
}

// 클라이언트에서 스냅샷 해석. onPlayer(id,x,y,z,yaw,anim,hp,maxHp), onMonster(id,x,z,yaw,state,hpFrac)
export function readSnap(dv, onPlayer, onMonster) {
  const time = dv.getUint32(1);
  const nP = dv.getUint8(5);
  const nM = dv.getUint16(6);
  let o = SNAP_HEADER;
  for (let i = 0; i < nP; i++) {
    onPlayer(
      dv.getUint8(o),
      dv.getInt16(o + 1) / POS_SCALE,
      dv.getInt16(o + 3) / POS_SCALE,
      dv.getInt16(o + 5) / POS_SCALE,
      byteToYaw(dv.getUint8(o + 7)),
      dv.getUint8(o + 8),
      dv.getUint8(o + 9),
      dv.getUint8(o + 10)
    );
    o += SNAP_PLAYER;
  }
  for (let i = 0; i < nM; i++) {
    onMonster(
      dv.getUint16(o),
      dv.getInt16(o + 2) / POS_SCALE,
      dv.getInt16(o + 4) / POS_SCALE,
      byteToYaw(dv.getUint8(o + 6)),
      dv.getUint8(o + 7)
    );
    o += SNAP_MONSTER;
  }
  return time;
}

// 캐릭터 진행 상황을 브라우저(localStorage)에 저장한다.
import { cleanItem, makeItem, newItemId, INV_CAP, SLOTS, slotOf } from '/shared/defs.js';

const KEY = 'starshard-save-v1';

export function defaultSave() {
  return {
    v: 2,
    name: '',
    tunic: Math.floor(Math.random() * 8),
    hair: Math.floor(Math.random() * 6),
    level: 1,
    xp: 0,
    gold: 0,
    hp: 6,
    // 착용 장비와 가방 (아이템: { id, t, r, l, e, a })
    eq: { weapon: makeItem('sword', 0, 1), bow: makeItem('bow', 0, 1), armor: null, helm: null, charm: null },
    inv: [],
    mats: { dust: 0, core: 0 },
    mount: false,
    mountColor: Math.floor(Math.random() * 5),
    berries: 2,
    arrows: 15,
    glider: false,
    talkedElder: false,
    stones: [0],
    lastStone: 0,
    chestKey: '',
    chests: [],
    bushes: {},
    world: null,
    kills: 0,
    // 별의 시련장과 숨겨진 던전
    trials: [], // 인장을 받은 시련장 번호
    zfound: [], // 찾아낸 입구 (지도에 표시된다)
    lamps: {}, // 던전 번호 -> 밝힌 돌등 (비트 묶음)
    dclear: [], // 정복한 던전
    zchest: {}, // 던전 번호 -> 마지막으로 보물상자를 연 회차
    bonusHp: 0, // 인장으로 늘어난 체력(하트 반 칸 단위)과 기력
    bonusSta: 0,
    settings: { quality: '', sound: true, music: true, sens: 1, follow: false },
  };
}

// 예전 저장(검·갑옷·활이 단계 숫자였던 때)을 아이템으로 바꾼다
function migrate(s, d) {
  const sw = [[0, 1], [1, 6], [2, 12], [3, 18]][Math.min(3, Math.max(0, d.sword | 0))];
  const bw = [[0, 1], [1, 10], [2, 18]][Math.min(2, Math.max(0, d.bow | 0))];
  const ar = [null, [1, 6], [2, 14]][Math.min(2, Math.max(0, d.armor | 0))];
  s.eq = {
    weapon: makeItem('sword', sw[0], sw[1]),
    bow: makeItem('bow', bw[0], bw[1]),
    armor: ar ? makeItem('armor', ar[0], ar[1]) : null,
    helm: null,
    charm: null,
  };
  s.inv = [];
}

export function loadSave() {
  const base = defaultSave();
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return base;
    const d = JSON.parse(raw);
    if (!d || typeof d !== 'object') return base;
    const s = { ...base, ...d };
    s.settings = { ...base.settings, ...(d.settings || {}) };
    if (!Array.isArray(s.stones) || !s.stones.includes(0)) s.stones = [0];
    if (!Array.isArray(s.chests)) s.chests = [];
    if (!s.bushes || typeof s.bushes !== 'object') s.bushes = {};
    for (const k of ['level', 'xp', 'gold', 'hp', 'berries', 'arrows', 'lastStone', 'kills']) {
      s[k] = Number.isFinite(+s[k]) ? Math.max(0, Math.floor(+s[k])) : base[k];
    }
    s.level = Math.max(1, Math.min(30, s.level));
    if (!(d.v >= 2) || !d.eq || typeof d.eq !== 'object') migrate(s, d);
    else {
      // 저장된 장비를 검사한다 (칸에 맞지 않는 것은 가방으로)
      const eq = {};
      const extra = [];
      for (const slot of SLOTS) {
        const it = cleanItem(d.eq[slot]);
        if (it && slotOf(it.t) === slot) eq[slot] = it;
        else {
          eq[slot] = null;
          if (it) extra.push(it);
        }
      }
      s.eq = eq;
      s.inv = (Array.isArray(d.inv) ? d.inv : []).map(cleanItem).filter(Boolean).concat(extra).slice(0, INV_CAP);
    }
    const seen = new Set();
    for (const it of [...SLOTS.map((k) => s.eq[k]), ...s.inv]) {
      if (!it) continue;
      if (!it.id || seen.has(it.id)) it.id = newItemId();
      seen.add(it.id);
    }
    if (!s.eq.weapon) s.eq.weapon = makeItem('sword', 0, 1);
    const m = d.mats && typeof d.mats === 'object' ? d.mats : {};
    s.mats = { dust: Math.max(0, Math.floor(+m.dust || 0)), core: Math.max(0, Math.floor(+m.core || 0)) };
    s.mount = !!s.mount;
    s.mountColor = Math.max(0, Math.min(4, s.mountColor | 0));
    const ids = (v) => (Array.isArray(v) ? [...new Set(v.map((n) => n | 0).filter((n) => n > 0 && n < 64))] : []);
    s.trials = ids(d.trials);
    s.zfound = ids(d.zfound);
    s.dclear = ids(d.dclear);
    s.lamps = d.lamps && typeof d.lamps === 'object' ? { ...d.lamps } : {};
    s.zchest = d.zchest && typeof d.zchest === 'object' ? { ...d.zchest } : {};
    // 인장 하나마다 번갈아 하트 한 칸(2) 또는 기력 10 (저장된 값이 어긋나 있으면 인장 수에 맞춘다)
    s.bonusHp = Math.ceil(s.trials.length / 2) * 2;
    s.bonusSta = Math.floor(s.trials.length / 2) * 10;
    s.v = 2;
    delete s.sword;
    delete s.armor;
    delete s.bow;
    return s;
  } catch {
    return base;
  }
}

let pending = null;
export function storeSave(save) {
  if (pending) return;
  pending = setTimeout(() => {
    pending = null;
    try {
      localStorage.setItem(KEY, JSON.stringify(save));
    } catch {
      /* 저장 공간을 쓸 수 없으면 무시 */
    }
  }, 400);
}

export function storeSaveNow(save) {
  try {
    localStorage.setItem(KEY, JSON.stringify(save));
  } catch {
    /* 무시 */
  }
}

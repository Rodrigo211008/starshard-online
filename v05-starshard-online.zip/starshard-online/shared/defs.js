// 서버와 클라이언트가 함께 쓰는 게임 규칙/수치 정의

export const GAME_TITLE = '별조각 원정대';
export const TICK_MS = 100; // 서버 시뮬레이션 주기 (10Hz)
export const SEND_MS = 80; // 클라이언트 위치 전송 주기
export const MAX_PLAYERS = 20;
export const DAY_MS = 14 * 60 * 1000; // 게임 속 하루 길이
export const SHARD_COUNT = 12;
export const DEFAULT_SEED = 20261111;

// 플레이어 애니메이션 상태 (네트워크 전송용)
export const ANIM = {
  IDLE: 0,
  RUN: 1,
  SPRINT: 2,
  JUMP: 3,
  FALL: 4,
  GLIDE: 5,
  SWIM: 6,
  CLIMB: 7,
  ATK1: 8,
  ATK2: 9,
  ATK3: 10,
  BOW: 11,
  HURT: 12,
  DEAD: 13,
  SIT: 14,
  WAVE: 15,
  CHEER: 16,
  SWIMIDLE: 17,
  CLIMBIDLE: 18,
  ROLL: 19,
  THRUST: 20, // 창 찌르기
  RIDE: 21, // 탈것을 타고 달리는 중
  RIDEIDLE: 22,
};

// 몬스터 상태 (네트워크 전송용)
export const MSTATE = { IDLE: 0, WALK: 1, CHASE: 2, WINDUP: 3, RECOVER: 4, STAGGER: 5, RETURN: 6 };

export const MON_TYPES = ['slime', 'goblin', 'thrower', 'wolf', 'scorpion', 'yeti', 'imp', 'golem', 'lord', 'kingslime', 'tyrant', 'knight'];

// atk.kind: arc(부채꼴 근접) / lunge(돌진) / throw(투사체) / slam(원형 내려찍기)
export const MON = {
  slime: {
    name: '말랑이', hp: 12, dmg: 1, speed: 2.7, aggro: 11, leash: 34, radius: 0.8, height: 1.0,
    atk: { kind: 'lunge', range: 3.2, reach: 1.5, dash: 3.4, windup: 520, cd: 1500 },
    xp: 5, gold: [1, 4], stagger: true, respawn: 150,
  },
  goblin: {
    name: '도깨비', hp: 22, dmg: 2, speed: 4.5, aggro: 16, leash: 42, radius: 0.7, height: 1.7,
    atk: { kind: 'arc', range: 2.3, reach: 2.9, half: 1.05, windup: 560, cd: 1500 },
    xp: 11, gold: [4, 9], stagger: true, respawn: 200,
  },
  thrower: {
    name: '돌팔매 도깨비', hp: 16, dmg: 2, speed: 3.9, aggro: 24, leash: 46, radius: 0.7, height: 1.6,
    atk: { kind: 'throw', range: 17, keep: 9, speed: 17, windup: 700, cd: 2500, proj: 'rock' },
    xp: 12, gold: [4, 10], stagger: true, respawn: 200,
  },
  wolf: {
    name: '늑대', hp: 20, dmg: 2, speed: 7.4, aggro: 19, leash: 52, radius: 0.8, height: 1.1,
    atk: { kind: 'lunge', range: 5.0, reach: 1.5, dash: 5.5, windup: 420, cd: 1700 },
    xp: 11, gold: [2, 6], stagger: true, respawn: 180,
  },
  scorpion: {
    name: '모래 전갈', hp: 30, dmg: 3, speed: 5.0, aggro: 14, leash: 40, radius: 0.9, height: 1.0,
    atk: { kind: 'arc', range: 2.4, reach: 3.0, half: 0.9, windup: 500, cd: 1600 },
    xp: 14, gold: [5, 11], stagger: true, respawn: 200,
  },
  yeti: {
    name: '설인', hp: 64, dmg: 4, speed: 4.4, aggro: 17, leash: 44, radius: 1.2, height: 2.8,
    atk: { kind: 'slam', range: 3.4, reach: 4.2, windup: 800, cd: 2200 },
    xp: 30, gold: [10, 20], stagger: false, respawn: 240,
  },
  imp: {
    name: '불도깨비', hp: 30, dmg: 3, speed: 4.8, aggro: 24, leash: 46, radius: 0.65, height: 1.5,
    atk: { kind: 'throw', range: 16, keep: 7, speed: 20, windup: 600, cd: 2100, proj: 'fire' },
    xp: 16, gold: [6, 12], stagger: true, respawn: 200,
  },
  golem: {
    name: '바위 수호자', hp: 240, dmg: 5, speed: 3.2, aggro: 26, leash: 40, radius: 1.9, height: 4.2,
    atk: { kind: 'slam', range: 4.6, reach: 6.2, windup: 1050, cd: 2500 },
    xp: 110, gold: [45, 70], stagger: false, respawn: 600, boss: true,
  },
  lord: {
    name: '그림자 군주', hp: 2200, dmg: 9, speed: 4.4, aggro: 60, leash: 60, radius: 2.4, height: 6.0,
    atk: { kind: 'slam', range: 6.0, reach: 8.0, windup: 1150, cd: 2000 },
    xp: 1500, gold: [400, 500], stagger: false, respawn: 0, boss: true,
  },
  // ---- 던전 보스 ----
  kingslime: {
    name: '말랑 대왕', hp: 520, dmg: 5, speed: 3.6, aggro: 40, leash: 90, radius: 2.5, height: 3.6,
    atk: { kind: 'lunge', range: 9, reach: 3.4, dash: 9, windup: 800, cd: 2000 },
    xp: 700, gold: [150, 220], stagger: false, respawn: 0, boss: true,
  },
  tyrant: {
    name: '서리 폭군', hp: 760, dmg: 7, speed: 4.8, aggro: 40, leash: 90, radius: 2.1, height: 5.2,
    atk: { kind: 'slam', range: 5.0, reach: 7.0, windup: 1000, cd: 2000 },
    xp: 1200, gold: [250, 350], stagger: false, respawn: 0, boss: true,
  },
  knight: {
    name: '공허의 기사', hp: 950, dmg: 9, speed: 5.4, aggro: 40, leash: 90, radius: 1.5, height: 4.4,
    atk: { kind: 'arc', range: 4.2, reach: 7.5, half: 1.9, windup: 700, cd: 1600 },
    xp: 2000, gold: [400, 550], stagger: false, respawn: 0, boss: true,
  },
};

export function monStats(type, level, elite) {
  const d = MON[type];
  const L = level - 1;
  let hp = Math.round(d.hp * (1 + 0.2 * L));
  let dmg = d.dmg + Math.floor(L / 3);
  let xp = Math.round(d.xp * (1 + 0.3 * L));
  let gmin = Math.round(d.gold[0] * (1 + 0.15 * L));
  let gmax = Math.round(d.gold[1] * (1 + 0.15 * L));
  if (elite) {
    hp = Math.round(hp * 3.5);
    dmg += 1;
    xp *= 4;
    gmin *= 4;
    gmax *= 4;
  }
  return { hp, dmg, xp, gmin, gmax };
}

export const ELITE_NAMES = {
  slime: '왕 말랑이',
  goblin: '도깨비 대장',
  wolf: '우두머리 늑대',
  yeti: '설인 족장',
  imp: '불도깨비 두목',
  scorpion: '여왕 전갈',
  thrower: '명사수 도깨비',
};

export const GOLEM_NAMES = ['바위 수호자', '이끼 수호자', '서리 수호자', '모래 수호자', '늪의 수호자', '용암 수호자', '단풍 수호자', '꽃잎 수호자', '포자 수호자', '수정 수호자', '그림자 수호자'];

// ---- 플레이어 성장 ----
export const MAX_LEVEL = 30;
export function xpNeed(level) {
  const l = level - 1;
  return 30 + 22 * l + 6 * l * l;
}
export function maxHpFor(level) {
  return 6 + 2 * Math.floor((level - 1) / 2);
}
export function maxStaminaFor(level) {
  return Math.min(190, 100 + 3 * (level - 1));
}

export const SHOP = {
  berry: { name: '회복 열매', price: 15, desc: '하트 3칸 회복' },
  arrows: { name: '화살 10개', price: 20, desc: '활 공격에 사용' },
};
export const BERRY_HEAL = 6;

// ============================================================
// 장비 아이템
// 아이템 한 개: { id, t: 종류, r: 등급(0~4), l: 아이템 레벨, e: 강화 단계, a: 부적 효과 }
// ============================================================
export const RARITY = [
  { name: '일반', color: 0xcfd6e2, css: '#cfd6e2', mult: 1.0 },
  { name: '고급', color: 0x6fe08a, css: '#6fe08a', mult: 1.14 },
  { name: '희귀', color: 0x5fb8ff, css: '#5fb8ff', mult: 1.3 },
  { name: '영웅', color: 0xc79bff, css: '#c79bff', mult: 1.5 },
  { name: '전설', color: 0xffb02a, css: '#ffb02a', mult: 1.75 },
];
export const MAX_ENH = 10;
export const MAX_ITEM_LEVEL = 40;
export const INV_CAP = 36;

export const WEAPON_KINDS = ['sword', 'great', 'spear', 'dagger', 'hammer'];
export const GEAR_TYPES = [...WEAPON_KINDS, 'bow', 'armor', 'helm', 'charm'];
export const SLOTS = ['weapon', 'bow', 'armor', 'helm', 'charm'];
export const SLOT_NAME = { weapon: '무기', bow: '활', armor: '갑옷', helm: '투구', charm: '부적' };
export const TYPE_NAME = { sword: '검', great: '대검', spear: '창', dagger: '쌍단검', hammer: '망치', bow: '활', armor: '갑옷', helm: '투구', charm: '부적' };
export function slotOf(t) {
  return WEAPON_KINDS.includes(t) ? 'weapon' : t;
}

// 무기 종류별 공격 동작. hits[k]: k번째 연속 공격
//  dur 전체 시간, at 타격 시점, reach 거리, half 부채꼴 반각, mult 피해 배율, kb 밀어내기,
//  anim 동작(0 가로 베기, 1 반대로 베기, 2 내려찍기, 3 찌르기), stop 타격 순간 멈춤, shake 화면 흔들림, quake 땅 울림
export const WEAPONS = {
  sword: {
    name: '검', desc: '균형 잡힌 3연속 베기', crit: 0,
    hits: [
      { dur: 0.36, at: 0.15, reach: 3.1, half: 1.5, mult: 1.0, kb: 6.5, anim: 0, stop: 0.045, shake: 0.16 },
      { dur: 0.36, at: 0.15, reach: 3.1, half: 1.5, mult: 1.0, kb: 6.5, anim: 1, stop: 0.045, shake: 0.16 },
      { dur: 0.5, at: 0.24, reach: 3.6, half: 1.7, mult: 1.6, kb: 10, anim: 2, stop: 0.075, shake: 0.3 },
    ],
  },
  great: {
    name: '대검', desc: '느리지만 넓고 묵직한 휘두르기', crit: 0,
    hits: [
      { dur: 0.62, at: 0.3, reach: 4.1, half: 1.9, mult: 1.9, kb: 11, anim: 0, stop: 0.085, shake: 0.32 },
      { dur: 0.62, at: 0.3, reach: 4.1, half: 1.9, mult: 1.9, kb: 11, anim: 1, stop: 0.085, shake: 0.32 },
      { dur: 0.86, at: 0.46, reach: 4.5, half: 2.3, mult: 3.0, kb: 15, anim: 2, stop: 0.12, shake: 0.52, quake: 1 },
    ],
  },
  spear: {
    name: '창', desc: '멀리 닿는 찌르기, 마지막은 크게 휩쓸기', crit: 0.05,
    hits: [
      { dur: 0.38, at: 0.16, reach: 5.2, half: 0.42, mult: 1.15, kb: 7, anim: 3, stop: 0.045, shake: 0.15 },
      { dur: 0.38, at: 0.16, reach: 5.2, half: 0.42, mult: 1.15, kb: 7, anim: 3, stop: 0.045, shake: 0.15 },
      { dur: 0.56, at: 0.27, reach: 5.0, half: 2.5, mult: 1.7, kb: 11, anim: 0, stop: 0.075, shake: 0.3 },
    ],
  },
  dagger: {
    name: '쌍단검', desc: '아주 빠른 4연속 공격 · 치명타 확률 +15%', crit: 0.15,
    hits: [
      { dur: 0.2, at: 0.08, reach: 2.7, half: 1.3, mult: 0.56, kb: 3, anim: 0, stop: 0.022, shake: 0.08 },
      { dur: 0.2, at: 0.08, reach: 2.7, half: 1.3, mult: 0.56, kb: 3, anim: 1, stop: 0.022, shake: 0.08 },
      { dur: 0.2, at: 0.08, reach: 2.7, half: 1.3, mult: 0.56, kb: 3, anim: 0, stop: 0.022, shake: 0.08 },
      { dur: 0.36, at: 0.15, reach: 3.0, half: 1.7, mult: 1.15, kb: 8, anim: 2, stop: 0.055, shake: 0.22 },
    ],
  },
  hammer: {
    name: '망치', desc: '아주 느리지만 땅을 내려찍어 주변을 휩쓸고, 단단한 적도 휘청이게 한다', crit: 0, stagger: true,
    hits: [
      { dur: 0.74, at: 0.4, reach: 3.7, half: 1.4, mult: 2.6, kb: 13, anim: 0, stop: 0.1, shake: 0.42 },
      { dur: 0.96, at: 0.54, reach: 4.8, half: 3.2, mult: 3.7, kb: 16, anim: 2, stop: 0.14, shake: 0.72, quake: 1 },
    ],
  },
};

// 부적 효과
export const CHARMS = {
  crit: { name: '매의 부적', stat: (r, l) => 4 + 3 * r + Math.floor(l / 8), text: (v) => `치명타 확률 +${v}%` },
  sta: { name: '바람의 부적', stat: (r, l) => 10 + 8 * r + Math.floor(l / 4), text: (v) => `최대 기력 +${v}` },
  luck: { name: '행운의 부적', stat: (r, l) => 8 + 7 * r + Math.floor(l / 6), text: (v) => `장비 발견 확률 +${v}%` },
  swift: { name: '날개의 부적', stat: (r, l) => 3 + 2 * r + Math.floor(l / 12), text: (v) => `이동 속도 +${v}%` },
};
export const CHARM_KEYS = Object.keys(CHARMS);

// 아이템 레벨 구간별 이름 (외형도 이 구간을 따른다)
const BANDS = [[1, '낡은'], [4, '강철'], [9, '은빛'], [15, '별빛'], [22, '달빛'], [30, '태양빛']];
export function bandOf(l) {
  let b = 0;
  for (let i = 0; i < BANDS.length; i++) if (l >= BANDS[i][0]) b = i;
  return b;
}
export function itemName(it) {
  const base = it.t === 'charm' ? (CHARMS[it.a] || CHARMS.crit).name : `${BANDS[bandOf(it.l)][1]} ${TYPE_NAME[it.t]}`;
  return it.e > 0 ? `+${it.e} ${base}` : base;
}

// 주 능력치: 무기·활 = 공격력, 갑옷 = 방어력, 투구 = 늘어나는 체력(하트 반 칸 단위), 부적 = 효과 수치
export function itemPower(it) {
  const m = RARITY[it.r].mult;
  const e = it.e || 0;
  switch (it.t) {
    case 'bow':
      return Math.round((4 + 0.5 * it.l) * m * (1 + 0.07 * e));
    case 'armor':
      return Math.max(1, Math.round((0.35 + 0.075 * it.l) * m * (1 + 0.05 * e)));
    case 'helm':
      return 2 * Math.max(1, Math.round((0.6 + 0.07 * it.l) * m * (1 + 0.05 * e)));
    case 'charm':
      return (CHARMS[it.a] || CHARMS.crit).stat(it.r, it.l);
    default:
      return Math.round((3.2 + 0.62 * it.l) * m * (1 + 0.07 * e));
  }
}
export function itemStatText(it) {
  const v = itemPower(it);
  if (it.t === 'bow') return `활 공격력 ${v}`;
  if (it.t === 'armor') return `방어력 ${v}`;
  if (it.t === 'helm') return `하트 +${v / 2}칸`;
  if (it.t === 'charm') return (CHARMS[it.a] || CHARMS.crit).text(v);
  return `공격력 ${v}`;
}

// 상인에게 팔 때 받는 골드 (살 때는 4배)
export function itemValue(it) {
  const l = it.l;
  return Math.round((6 + l * 3.2 + l * l * 0.22) * [1, 2, 4.5, 10, 24][it.r] * (1 + 0.25 * (it.e || 0)));
}

// ---- 강화 ----
// 재료: 별가루(dust)는 사냥으로, 별의 핵(core)은 우두머리·수호자·던전에서 얻는다
export const ENH_CHANCE = [1, 0.95, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.32, 0.25];
export function canEnhance(it) {
  return !!it && it.t !== 'charm' && (it.e || 0) < MAX_ENH;
}
export function enhanceCost(it) {
  const e = it.e || 0;
  return { dust: 2 + 2 * e, core: e >= 5 ? e - 4 : 0, gold: Math.round(15 * (e + 1) + itemValue({ ...it, e: 0 }) * 0.25 * (1 + e * 0.3)) };
}
// 실패할 때마다 다음 성공 확률이 조금씩 오른다 (it.f: 연속 실패 횟수)
export function enhanceChance(it) {
  return Math.min(1, ENH_CHANCE[it.e || 0] + 0.06 * (it.f || 0));
}
// 강화 단계에 따른 빛깔 (외형·베기 궤적에 쓴다). 0 이면 빛나지 않는다
export function enhGlow(e) {
  return e >= 10 ? 0xfff6dc : e >= 7 ? 0xffc23a : e >= 5 ? 0xb98aff : e >= 3 ? 0x6fc8ff : 0;
}

// 받은 값을 검사해서 올바른 아이템으로 만든다 (올바르지 않으면 null)
export function cleanItem(raw) {
  if (!raw || typeof raw !== 'object' || !GEAR_TYPES.includes(raw.t)) return null;
  const n = (v, a, b) => {
    v = Math.floor(Number(v));
    return Number.isFinite(v) ? (v < a ? a : v > b ? b : v) : a;
  };
  const it = { id: typeof raw.id === 'string' ? raw.id.slice(0, 16) : '', t: raw.t, r: n(raw.r, 0, RARITY.length - 1), l: n(raw.l, 1, MAX_ITEM_LEVEL), e: n(raw.e, 0, MAX_ENH) };
  if (it.t === 'charm') {
    it.a = CHARM_KEYS.includes(raw.a) ? raw.a : 'crit';
    it.e = 0;
  }
  if (raw.f) it.f = n(raw.f, 0, 20);
  return it;
}

// 착용한 장비로 능력치를 계산한다. eq: { weapon, bow, armor, helm, charm }, bonus: { hp, sta } (시련 보상)
export function gearStats(level, eq, bonus) {
  eq = eq || {};
  const w = eq.weapon;
  const c = eq.charm;
  const cv = c ? itemPower(c) : 0;
  const kind = w && WEAPONS[w.t] ? w.t : 'sword';
  return {
    kind,
    atk: (w ? itemPower(w) : 2) + Math.floor((level - 1) * 0.8),
    bowAtk: eq.bow ? itemPower(eq.bow) + Math.floor((level - 1) * 0.6) : 0,
    def: eq.armor ? itemPower(eq.armor) : 0,
    maxHp: Math.min(250, maxHpFor(level) + (eq.helm ? itemPower(eq.helm) : 0) + ((bonus && bonus.hp) || 0)),
    maxStamina: maxStaminaFor(level) + (c && c.a === 'sta' ? cv : 0) + ((bonus && bonus.sta) || 0),
    crit: 0.1 + WEAPONS[kind].crit + (c && c.a === 'crit' ? cv / 100 : 0),
    luck: c && c.a === 'luck' ? cv / 100 : 0,
    swift: c && c.a === 'swift' ? cv / 100 : 0,
  };
}

// ---- 전리품 ----
// 등급 확률표 (일반, 고급, 희귀, 영웅, 전설)
export const RARITY_ODDS = {
  mob: [700, 225, 62, 11, 2],
  elite: [300, 400, 220, 65, 15],
  golem: [80, 400, 350, 140, 30],
  boss: [0, 100, 400, 370, 130],
  chest1: [640, 280, 70, 10, 0],
  chest2: [450, 360, 150, 35, 5],
  chest3: [250, 400, 260, 75, 15],
  chest4: [100, 340, 360, 160, 40],
  trial: [0, 150, 500, 280, 70],
  dungeon: [0, 0, 420, 430, 150],
  dboss: [0, 0, 250, 500, 250],
};
const TYPE_ODDS = [['sword', 9], ['great', 9], ['spear', 9], ['dagger', 9], ['hammer', 9], ['bow', 10], ['armor', 18], ['helm', 15], ['charm', 12]];
function pick(list, total, rnd) {
  let v = rnd() * total;
  for (const [k, w] of list) {
    if (v < w) return k;
    v -= w;
  }
  return list[list.length - 1][0];
}
let itemSeq = 0;
export function newItemId() {
  return Date.now().toString(36) + (itemSeq++ % 1296).toString(36).padStart(2, '0') + Math.floor(Math.random() * 1296).toString(36).padStart(2, '0');
}
export function makeItem(t, r, l, e = 0, a) {
  const it = { id: newItemId(), t, r, l: Math.max(1, Math.min(MAX_ITEM_LEVEL, Math.round(l))), e };
  if (t === 'charm') it.a = a || CHARM_KEYS[Math.floor(Math.random() * CHARM_KEYS.length)];
  return it;
}
// source: RARITY_ODDS 의 키, level: 떨어뜨린 대상의 레벨
export function rollItem(source, level, rnd = Math.random, type) {
  const odds = RARITY_ODDS[source] || RARITY_ODDS.mob;
  const r = pick(odds.map((w, i) => [i, w]), odds.reduce((a, b) => a + b, 0), rnd);
  const t = type || pick(TYPE_ODDS, 100, rnd);
  return makeItem(t, r, level + Math.floor(rnd() * 3) - 1, 0);
}

// 탈것
export const MOUNT_PRICE = 250;
export const MOUNT_COLORS = [0x8a5a34, 0xe9e2d4, 0x2c2a30, 0xc9a66a, 0x9a9aa4];

// 캐릭터 색상 팔레트
export const TUNIC_COLORS = [0xd9483b, 0x3b7dd9, 0xe8b730, 0x8a4fd1, 0x2aa59a, 0xe07a2f, 0xdb5fa0, 0x5c6b7a];
export const HAIR_COLORS = [0x3a2a1e, 0x1f1f24, 0xc98a3d, 0xe6d27a, 0xb5432e, 0xe9e9ee];

// ---- 마을 배치 (마을 중심 기준 좌표, 북쪽 = -z) ----
export const VILLAGE_LAYOUT = {
  spawn: { x: 0, z: 21 },
  altar: { x: 0, z: 0, r: 3.2 },
  well: { x: -10, z: -7, r: 1.5 },
  campfire: { x: -5, z: 13 },
  houses: [
    { x: -23, z: -17, w: 9, d: 7, rot: 0, roof: 0xb5523a },
    { x: 23, z: -15, w: 8, d: 8, rot: 0, roof: 0x4f7fb5 },
    { x: -27, z: 16, w: 8, d: 7, rot: 0, roof: 0x5c9a55 },
    { x: 26, z: 20, w: 9, d: 7, rot: 0, roof: 0xb5523a },
    { x: 0, z: -31, w: 12, d: 8, rot: 0, roof: 0x8a5fb0 },
  ],
  stalls: [
    { x: 15, z: 5, kind: 'merchant' },
    { x: -16, z: 4, kind: 'smith' },
  ],
};

export const NPC_DEFS = {
  elder: { name: '촌장 한울', x: 3.6, z: -4.2, yaw: 0.4 },
  merchant: { name: '상인 보리', x: 15, z: 7.2, yaw: 0 },
  smith: { name: '대장장이 무쇠', x: -16, z: 6.2, yaw: 0 },
  kid: { name: '꼬마 다래', x: 6, z: 14, yaw: 2.6 },
};

// 순환(NG+) 배율
export function cycleScale(cycle) {
  return 1 + 0.3 * cycle;
}

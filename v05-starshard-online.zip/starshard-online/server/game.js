// 게임 월드 상태와 규칙 (플레이어 동기화, 몬스터 AI, 별조각/보스 진행)
import fs from 'node:fs';
import path from 'node:path';
import { createWorld, exclusionsFor, W, VOLCANO, VILLAGE } from '../shared/world.js';
import { generatePOIs } from './pois.js';
import {
  MON, MON_TYPES, MSTATE, ANIM, TICK_MS, MAX_PLAYERS, SHARD_COUNT, MAX_LEVEL,
  monStats, cycleScale, TUNIC_COLORS, HAIR_COLORS,
  WEAPONS, SLOTS, slotOf, cleanItem, gearStats, makeItem, MOUNT_COLORS,
} from '../shared/defs.js';
import * as P from '../shared/proto.js';
import { ZONES, TILE, zoneIdAt, zoneBlocked, zoneSolid, zoneTorchHit } from '../shared/zones.js';

const ACTIVE_R = 105; // 이 거리 안에 플레이어가 있어야 몬스터가 움직인다
const VIEW_R = 120; // 스냅샷에 포함되는 거리
const ZONE_RESET_MS = +process.env.ZONE_RESET_MS || 40000; // 시련장·던전이 비고 나서 처음 상태로 돌아가기까지
const SAFE_R = 62; // 마을 안전 구역
const TAU = Math.PI * 2;

const dist = (ax, az, bx, bz) => Math.hypot(ax - bx, az - bz);
const clampInt = (v, a, b) => {
  v = Number(v);
  if (!Number.isFinite(v)) return a;
  v = Math.floor(v);
  return v < a ? a : v > b ? b : v;
};

function cleanText(s, max) {
  if (typeof s !== 'string') return '';
  // 제어 문자 제거
  let out = '';
  for (const ch of s) {
    const c = ch.codePointAt(0);
    if (c < 32 || c === 127 || (c >= 0x200b && c <= 0x200f) || (c >= 0x202a && c <= 0x202e)) continue;
    out += ch;
    if (out.length >= max) break;
  }
  return out.trim();
}

export class Game {
  constructor({ seed, savePath }) {
    const t0 = Date.now();
    this.seed = seed;
    this.world = createWorld(seed);
    this.pois = generatePOIs(this.world);
    this.world.applyPatches(this.pois.patches);
    this.world.setExclusions(exclusionsFor(this.pois));

    this.players = new Map();
    this.freeIds = [];
    for (let i = MAX_PLAYERS; i >= 1; i--) this.freeIds.push(i);

    this.worldId = Math.random().toString(36).slice(2, 10);
    this.cycle = 0;
    this.shards = new Set();
    this.bossState = 'sleep'; // sleep | awake | dead
    this.resetAt = 0;
    this.pristine = true;
    this.savePath = savePath || null;
    this.projSeq = 1;
    this.tickCount = 0;

    this.loadSave();

    this.monsters = this.pois.spawns.map((s) => this.makeMonster(s));
    this.boss = this.monsters[this.pois.bossId];
    // 시련장·던전: 관문 상태와 그 안의 몬스터
    // epoch: 구역이 처음 상태로 돌아갈 때마다 바뀌는 번호 (보물상자를 다시 열 수 있는지 가리는 데 쓴다)
    const epoch0 = Math.floor(Date.now() / 1000);
    this.zones = ZONES.map((def) => ({
      def, open: 0, epoch: epoch0, mobs: [], boss: null, players: 0, emptySince: 0,
      puzzle: 0, dist: new Int16Array(def.tileW * def.tileH), queue: new Int16Array(def.tileW * def.tileH),
    }));
    for (const m of this.monsters) {
      if (!m.zone) continue;
      const z = this.zones[m.zone - 1];
      z.mobs.push(m);
      if (m.boss) z.boss = m;
    }
    this.sealed = new Set();
    this.recomputeSeals(true);
    if (this.shards.size >= SHARD_COUNT && this.bossState === 'sleep') this.wakeBoss();

    // 페이지를 열 때 한 번 내려받는 정적 월드 데이터 (GET /world, 미리 문자열로 만들어 둔다)
    this.staticJson = JSON.stringify({
      seed,
      patches: this.pois.patches,
      village: this.pois.village,
      arena: this.pois.arena,
      shards: this.pois.shards,
      stones: this.pois.stones,
      camps: this.pois.camps,
      chests: this.pois.chests,
      bushes: this.pois.bushes,
      npcs: this.pois.npcs,
      zones: this.pois.zones,
      bossId: this.pois.bossId,
      // [typeIndex, level, x, z, biome, flags(1=elite,2=boss,4=minion), shard, zone]
      spawns: this.pois.spawns.map((s) => [
        MON_TYPES.indexOf(s.type), s.level, s.x, s.z, s.biome,
        (s.elite ? 1 : 0) | (s.boss ? 2 : 0) | (s.minion ? 4 : 0), s.shard, s.zone || 0,
      ]),
    });
    console.log(`[world] seed=${seed} 몬스터 ${this.monsters.length} 상자 ${this.pois.chests.length} 생성 ${Date.now() - t0}ms`);
  }

  // ---------- 저장 ----------
  loadSave() {
    if (!this.savePath) return;
    try {
      const d = JSON.parse(fs.readFileSync(this.savePath, 'utf8'));
      if (d && d.seed === this.seed && typeof d.worldId === 'string') {
        this.worldId = d.worldId;
        this.cycle = clampInt(d.cycle, 0, 99);
        this.shards = new Set((d.shards || []).filter((n) => Number.isInteger(n) && n >= 0 && n < SHARD_COUNT));
        this.pristine = false;
        console.log(`[save] 불러옴: 순환 ${this.cycle}, 별조각 ${this.shards.size}/${SHARD_COUNT}`);
      }
    } catch {
      /* 저장 파일 없음 */
    }
  }

  persist() {
    if (!this.savePath) return;
    try {
      fs.mkdirSync(path.dirname(this.savePath), { recursive: true });
      fs.writeFileSync(this.savePath, JSON.stringify({ seed: this.seed, worldId: this.worldId, cycle: this.cycle, shards: [...this.shards] }));
    } catch {
      /* 디스크를 쓸 수 없는 환경이면 무시 */
    }
  }

  worldState() {
    return {
      worldId: this.worldId,
      cycle: this.cycle,
      shards: [...this.shards],
      sealed: [...this.sealed],
      boss: this.bossState,
      resetIn: this.resetAt ? Math.max(0, this.resetAt - Date.now()) : 0,
    };
  }

  // 클라이언트가 들고 온 진행 상황을 합친다 (무료 서버가 잠들었다 깨어나도 이어서 할 수 있게)
  mergeSave(save) {
    if (!save || typeof save.worldId !== 'string' || !Array.isArray(save.shards)) return false;
    const cyc = clampInt(save.cycle, 0, 99);
    const list = save.shards.filter((n) => Number.isInteger(n) && n >= 0 && n < SHARD_COUNT);
    let changed = false;
    if (save.worldId === this.worldId) {
      if (cyc > this.cycle) {
        this.cycle = cyc;
        this.shards = new Set(list);
        changed = true;
      } else if (cyc === this.cycle && this.bossState !== 'dead') {
        for (const n of list) if (!this.shards.has(n)) { this.shards.add(n); changed = true; }
      }
    } else if (this.pristine && (list.length > 0 || cyc > 0)) {
      this.worldId = save.worldId.slice(0, 16);
      this.cycle = cyc;
      this.shards = new Set(list);
      changed = true;
    }
    if (changed) {
      this.pristine = false;
      this.rescaleMonsters();
      this.recomputeSeals(true);
      if (this.shards.size >= SHARD_COUNT && this.bossState === 'sleep') this.wakeBoss();
      this.persist();
    }
    return changed;
  }

  // ---------- 몬스터 ----------
  makeMonster(s) {
    const def = MON[s.type];
    const m = {
      id: s.id, type: s.type, def, level: s.level, elite: !!s.elite, boss: !!s.boss, minion: !!s.minion,
      shard: s.shard, camp: s.camp, zone: s.zone || 0, group: s.group || 0,
      hx: s.x, hz: s.z, x: s.x, z: s.z, yaw: (s.id * 2.399) % TAU,
      state: MSTATE.IDLE, until: 0, hp: 1, maxHp: 1, dmg: 1, xp: 1, gmin: 0, gmax: 0,
      target: 0, alive: !((s.boss && !s.zone) || s.minion), respawnAt: 0, combo: null,
      kvx: 0, kvz: 0, nextAtk: 0, wanderAt: 0, wx: s.x, wz: s.z,
      pattern: null, idleSince: 0, summons: 0, chain: null, freshUntil: 0, prevState: MSTATE.IDLE,
      radius: def.radius * (s.elite ? 1.45 : 1),
    };
    this.applyStats(m);
    return m;
  }

  applyStats(m) {
    const st = monStats(m.type, m.level, m.elite);
    const sc = cycleScale(this.cycle);
    m.maxHp = Math.round(st.hp * sc);
    m.hp = m.maxHp;
    m.dmg = Math.round(st.dmg * (1 + 0.15 * this.cycle));
    m.xp = Math.round(st.xp * sc);
    m.gmin = st.gmin;
    m.gmax = st.gmax;
  }

  rescaleMonsters() {
    if (!this.monsters) return;
    for (const m of this.monsters) if (!m.boss || (m.zone && m.hp >= m.maxHp)) this.applyStats(m);
  }

  recomputeSeals(silent) {
    const next = new Set();
    for (const m of this.monsters) {
      if (m.shard >= 0 && m.alive && !this.shards.has(m.shard)) next.add(m.shard);
    }
    for (const s of this.pois.shards) {
      const was = this.sealed.has(s.id);
      const now = next.has(s.id);
      if (was !== now && !silent) this.broadcast({ t: 'seal', id: s.id, v: now ? 1 : 0 });
    }
    this.sealed = next;
  }

  respawn(m) {
    m.alive = true;
    m.x = m.hx;
    m.z = m.hz;
    m.hp = m.maxHp;
    m.state = MSTATE.IDLE;
    m.target = 0;
    m.kvx = m.kvz = 0;
    m.respawnAt = 0;
    m.freshUntil = this.tickCount + 6;
    if (m.shard >= 0) this.recomputeSeals(false);
  }

  walkable(m, nx, nz, step) {
    if (m.zone) {
      // 시련장·던전 안: 벽과 닫힌 관문만 막는다
      const z = this.zones[m.zone - 1];
      const rad = Math.min(1.2, m.radius * 0.5);
      return !zoneBlocked(z.def, nx, nz, rad, z.open) && !zoneTorchHit(z.def, nx, nz, rad * 0.6);
    }
    if (nx < -W.HALF + 8 || nx > W.HALF - 8 || nz < -W.HALF + 8 || nz > W.HALF - 8) return false;
    const h = this.world.heightAt(nx, nz);
    if (h < -0.45) return false;
    if (m.boss) return dist(nx, nz, VOLCANO.x, VOLCANO.z) < VOLCANO.arenaR + 1;
    const h0 = this.world.heightAt(m.x, m.z);
    if (Math.abs(h - h0) > step * 1.7 + 0.2) return false;
    // 마을에는 들어오지 못한다
    if (dist(nx, nz, VILLAGE.x, VILLAGE.z) < SAFE_R - 6) return false;
    // 나무/바위 충돌
    const cx = Math.floor((nx + W.HALF) / W.CHUNK);
    const cz = Math.floor((nz + W.HALF) / W.CHUNK);
    const props = this.world.chunkProps(cx, cz);
    const rr = m.radius * 0.55;
    for (let i = 0; i < props.length; i++) {
      const p = props[i];
      if (p.cr <= 0) continue;
      const dx = nx - p.x;
      const dz = nz - p.z;
      const r = p.cr + rr;
      if (dx * dx + dz * dz < r * r) return false;
    }
    return true;
  }

  tryMove(m, dx, dz) {
    const step = Math.hypot(dx, dz);
    if (step < 1e-5) return true;
    const nx = m.x + dx;
    const nz = m.z + dz;
    if (this.walkable(m, nx, nz, step)) {
      m.x = nx;
      m.z = nz;
      return true;
    }
    return false;
  }

  // ---------- 구역 안 길찾기 ----------
  // 두 점 사이를 곧게 지나갈 수 있는지 (벽·닫힌 관문에 걸리지 않는지)
  zoneClear(def, open, x0, z0, x1, z1, rad) {
    const dx = x1 - x0;
    const dz = z1 - z0;
    const n = Math.max(1, Math.ceil(Math.hypot(dx, dz) / 0.8));
    for (let i = 1; i <= n; i++) {
      const k = i / n;
      if (zoneBlocked(def, x0 + dx * k, z0 + dz * k, rad, open)) return false;
    }
    return true;
  }

  // 목표까지 곧게 갈 수 없으면 칸 단위로 길을 찾아, 지금 향해야 할 지점을 돌려준다 (곧게 갈 수 있으면 null)
  zoneNav(m, tx, tz) {
    const z = this.zones[m.zone - 1];
    const def = z.def;
    const rad = Math.min(1.2, m.radius * 0.5);
    if (this.zoneClear(def, z.open, m.x, m.z, tx, tz, rad)) return null;
    if (m.nav && m.navUntil > this.tickCount && m.navOpen === z.open) return m.nav;
    const Wd = def.tileW;
    const Hd = def.tileH;
    const tc = Math.floor((tx - def.ox) / TILE);
    const tr = Math.floor((tz - def.oz) / TILE);
    const mc = Math.floor((m.x - def.ox) / TILE);
    const mr = Math.floor((m.z - def.oz) / TILE);
    m.nav = null;
    m.navUntil = this.tickCount + 3;
    m.navOpen = z.open;
    if (tc < 0 || tr < 0 || tc >= Wd || tr >= Hd || mc < 0 || mr < 0 || mc >= Wd || mr >= Hd) return null;
    // 벽·닫힌 관문은 못 지나가고, 화로가 놓인 칸은 돌아간다 (지금 서 있는 칸과 목표 칸은 예외)
    const start = tr * Wd + tc;
    const goal = mr * Wd + mc;
    const pass = (c, r) => {
      const ch = def.rows[r].charCodeAt(c);
      if (ch === 35 || ch === 32) return false;
      if (ch >= 49 && ch <= 57) return ((z.open >> (ch - 48)) & 1) === 1;
      if (ch === 111) return r * Wd + c === goal || r * Wd + c === start;
      return true;
    };
    if (!pass(tc, tr)) return null;
    // 목표 칸에서부터 넓혀 나가며 거리를 적는다
    const dist = z.dist;
    const queue = z.queue;
    dist.fill(-1);
    let head = 0;
    let tail = 0;
    dist[start] = 0;
    queue[tail++] = start;
    while (head < tail && dist[goal] < 0) {
      const cur = queue[head++];
      const c = cur % Wd;
      const r = (cur - c) / Wd;
      const dn = dist[cur] + 1;
      if (c > 0 && dist[cur - 1] < 0 && pass(c - 1, r)) { dist[cur - 1] = dn; queue[tail++] = cur - 1; }
      if (c < Wd - 1 && dist[cur + 1] < 0 && pass(c + 1, r)) { dist[cur + 1] = dn; queue[tail++] = cur + 1; }
      if (r > 0 && dist[cur - Wd] < 0 && pass(c, r - 1)) { dist[cur - Wd] = dn; queue[tail++] = cur - Wd; }
      if (r < Hd - 1 && dist[cur + Wd] < 0 && pass(c, r + 1)) { dist[cur + Wd] = dn; queue[tail++] = cur + Wd; }
    }
    if (dist[goal] < 0) return null;
    // 내 칸에서 거리가 줄어드는 쪽으로 몇 칸 따라가 보고, 곧게 갈 수 있는 가장 먼 칸을 고른다
    let cur = goal;
    let best = null;
    for (let k = 0; k < 7 && dist[cur] > 0; k++) {
      const c = cur % Wd;
      const r = (cur - c) / Wd;
      const dn = dist[cur] - 1;
      let nx = -1;
      if (c > 0 && dist[cur - 1] === dn) nx = cur - 1;
      else if (c < Wd - 1 && dist[cur + 1] === dn) nx = cur + 1;
      else if (r > 0 && dist[cur - Wd] === dn) nx = cur - Wd;
      else if (r < Hd - 1 && dist[cur + Wd] === dn) nx = cur + Wd;
      if (nx < 0) break;
      cur = nx;
      const wc = cur % Wd;
      const wx = def.ox + (wc + 0.5) * TILE;
      const wz = def.oz + ((cur - wc) / Wd + 0.5) * TILE;
      if (!best || this.zoneClear(def, z.open, m.x, m.z, wx, wz, rad)) best = [wx, wz];
      else break;
    }
    m.nav = best;
    return best;
  }

  // 목표 지점으로 이동 (막히면 옆으로 돌아간다). 남은 거리를 돌려준다.
  moveToward(m, tx, tz, step, away = false) {
    let dx = tx - m.x;
    let dz = tz - m.z;
    const d = Math.hypot(dx, dz);
    if (d < 0.05) return d;
    if (away) { dx = -dx; dz = -dz; }
    let s = Math.min(step, away ? step : d);
    if (m.zone && !away) {
      // 시련장·던전 안에서는 벽을 돌아가는 길을 찾는다
      const w = this.zoneNav(m, tx, tz);
      if (w) {
        dx = w[0] - m.x;
        dz = w[1] - m.z;
        s = Math.min(step, Math.hypot(dx, dz));
        if (s < 1e-4) return d;
      }
    }
    const base = Math.atan2(dx, dz);
    m.yaw = base;
    const side = m.id % 2 ? 1 : -1;
    const tries = [0, 0.8 * side, -0.8 * side, 1.5 * side, -1.5 * side];
    for (const off of tries) {
      const a = base + off;
      if (this.tryMove(m, Math.sin(a) * s, Math.cos(a) * s)) break;
    }
    return d;
  }

  // 구역 안에서 몬스터가 상대를 볼 수 있는지 (벽에 가려지지 않았는지)
  zoneSees(m, p) {
    const z = this.zones[m.zone - 1];
    return this.zoneClear(z.def, z.open, m.x, m.z, p.x, p.z, 0.15);
  }

  // 한 마리가 상대를 알아채면 같은 무리가 모두 함께 덤빈다 (한 마리씩 꾀어내지 못하게)
  alertGroup(m, p) {
    if (!this.zoneAwake(m)) return;
    for (const o of this.zones[m.zone - 1].mobs) {
      if (o !== m && o.alive && !o.boss && o.group === m.group && !o.target) o.target = p.id;
    }
  }

  // 구역 안의 무리는 앞 관문이 열려야 깨어난다 (2번 무리는 1번 관문이 열린 뒤)
  zoneAwake(m) {
    return m.group <= 1 || ((this.zones[m.zone - 1].open >> (m.group - 1)) & 1) === 1;
  }

  acquire(m, players) {
    let best = null;
    // 시련장·던전 안에서는 더 멀리서도 알아채지만, 벽 너머는 보지 못한다
    let bd = m.zone ? Math.max(m.def.aggro, 24) : m.def.aggro;
    if (m.zone && !this.zoneAwake(m)) return null;
    for (const p of players) {
      if (!p.alive || p.zone !== m.zone) continue;
      const d = dist(p.x, p.z, m.x, m.z);
      if (d >= bd) continue;
      if (m.zone && !this.zoneSees(m, p)) continue;
      if (p.y - this.world.heightAt(p.x, p.z) > 9) continue; // 높이 활공 중이면 못 본다
      if (dist(p.x, p.z, VILLAGE.x, VILLAGE.z) < SAFE_R) continue;
      bd = d;
      best = p;
    }
    return best;
  }

  startWindup(m, tgt, now, kind, extra) {
    const atk = m.def.atk;
    m.state = MSTATE.WINDUP;
    m.pattern = kind;
    const dur = (extra && extra.d) || atk.windup;
    m.until = now + dur;
    if (tgt) {
      m.yaw = Math.atan2(tgt.x - m.x, tgt.z - m.z);
      m.tx = tgt.x;
      m.tz = tgt.z;
      m.ty = tgt.y;
    }
    const ev = { t: 'ma', id: m.id, k: kind, x: +m.x.toFixed(2), z: +m.z.toFixed(2), yaw: +m.yaw.toFixed(3), d: dur, dmg: m.dmg, ...(extra || {}) };
    this.broadcastNear(m.x, m.z, VIEW_R, ev);
  }

  strike(m, now) {
    const atk = m.def.atk;
    const kind = m.pattern;
    if (kind === 'lunge') {
      const dash = m.dash || atk.dash;
      const steps = 6;
      const sx = (Math.sin(m.yaw) * dash) / steps;
      const sz = (Math.cos(m.yaw) * dash) / steps;
      for (let i = 0; i < steps; i++) if (!this.tryMove(m, sx, sz)) break;
    } else if (kind === 'throw') {
      const tgt = this.players.get(m.target);
      const tx = tgt && tgt.alive ? tgt.x : m.tx;
      const tz = tgt && tgt.alive ? tgt.z : m.tz;
      const ty = (tgt && tgt.alive ? tgt.y : m.ty) + 1.0;
      this.throwAt(m, tx, tz, ty, atk.speed || 19, atk.proj || 'rock', m.dmg);
    }
    m.state = MSTATE.RECOVER;
    m.until = now + 420;
    m.nextAtk = now + atk.cd * (0.85 + Math.random() * 0.3);
  }

  // 포물선 투사체를 던진다 (맞았는지는 각자의 기기에서 판정한다)
  throwAt(m, tx, tz, ty, speed, proj, dmg) {
    const oy = this.world.heightAt(m.x, m.z) + m.def.height * 0.85;
    const d = Math.max(1, dist(tx, tz, m.x, m.z));
    const g = 9;
    const tf = d / speed;
    this.broadcastNear(m.x, m.z, VIEW_R, {
      t: 'pr', k: proj, x: +m.x.toFixed(2), y: +oy.toFixed(2), z: +m.z.toFixed(2),
      vx: +(((tx - m.x) / d) * speed).toFixed(2), vz: +(((tz - m.z) / d) * speed).toFixed(2),
      vy: +((ty - oy) / tf + 0.5 * g * tf).toFixed(2), g, dmg, by: m.id,
    });
  }

  updateMonster(m, now, dt, players) {
    const def = m.def;
    const atk = def.atk;
    if (m.kvx !== 0 || m.kvz !== 0) {
      this.tryMove(m, m.kvx * dt, m.kvz * dt);
      m.kvx *= 0.55;
      m.kvz *= 0.55;
      if (Math.abs(m.kvx) + Math.abs(m.kvz) < 0.3) m.kvx = m.kvz = 0;
    }
    let tgt = m.target ? this.players.get(m.target) : null;
    if (tgt && (!tgt.alive || tgt.zone !== m.zone)) tgt = null;
    if (tgt && !m.boss && !m.zone) {
      const dh = dist(tgt.x, tgt.z, m.hx, m.hz);
      const d = dist(tgt.x, tgt.z, m.x, m.z);
      if (dh > def.leash + 14 || d > def.aggro * 2 + 14 || dist(tgt.x, tgt.z, VILLAGE.x, VILLAGE.z) < SAFE_R - 4) tgt = null;
    }
    if (!tgt) m.target = 0;
    if (m.boss) return m.zone ? this.updateZoneBoss(m, now, dt, players, tgt) : this.updateBoss(m, now, dt, players, tgt);

    switch (m.state) {
      case MSTATE.STAGGER:
        if (now >= m.until) m.state = tgt ? MSTATE.CHASE : MSTATE.IDLE;
        return;
      case MSTATE.WINDUP:
        if (now >= m.until) this.strike(m, now);
        return;
      case MSTATE.RECOVER:
        if (now >= m.until) m.state = tgt ? MSTATE.CHASE : MSTATE.IDLE;
        return;
      case MSTATE.RETURN: {
        const d = this.moveToward(m, m.hx, m.hz, def.speed * 1.4 * dt);
        m.hp = Math.min(m.maxHp, m.hp + m.maxHp * 0.3 * dt);
        if (d < 1.5 || now >= m.until) {
          if (d >= 1.5) { m.x = m.hx; m.z = m.hz; }
          m.state = MSTATE.IDLE;
          m.hp = m.maxHp;
        }
        return;
      }
      default:
    }

    if (!tgt) {
      tgt = this.acquire(m, players);
      if (tgt) {
        m.target = tgt.id;
        if (m.zone) this.alertGroup(m, tgt);
      }
    }
    if (!tgt) {
      if (m.state === MSTATE.CHASE) {
        m.state = MSTATE.RETURN;
        m.until = now + 12000;
        return;
      }
      if (now >= m.wanderAt) {
        const a = Math.random() * TAU;
        const r = 2 + Math.random() * 5;
        m.wx = m.hx + Math.sin(a) * r;
        m.wz = m.hz + Math.cos(a) * r;
        m.wanderAt = now + 2500 + Math.random() * 5000;
      }
      if (dist(m.x, m.z, m.wx, m.wz) > 0.7) {
        this.moveToward(m, m.wx, m.wz, def.speed * 0.35 * dt);
        m.state = MSTATE.WALK;
      } else m.state = MSTATE.IDLE;
      return;
    }

    m.state = MSTATE.CHASE;
    if (!m.zone && dist(m.x, m.z, m.hx, m.hz) > def.leash) {
      m.state = MSTATE.RETURN;
      m.until = now + 12000;
      m.target = 0;
      return;
    }
    const d = dist(tgt.x, tgt.z, m.x, m.z);
    if (atk.kind === 'throw') {
      // 구역 안에서는 벽에 가려져 있으면 보이는 곳까지 다가간다
      if (m.zone && !this.zoneSees(m, tgt)) this.moveToward(m, tgt.x, tgt.z, def.speed * dt);
      else if (d <= atk.range && now >= m.nextAtk) this.startWindup(m, tgt, now, 'throw');
      else if (d < atk.keep * 0.55) this.moveToward(m, tgt.x, tgt.z, def.speed * dt, true);
      else if (d > atk.keep) this.moveToward(m, tgt.x, tgt.z, def.speed * dt);
      else m.yaw = Math.atan2(tgt.x - m.x, tgt.z - m.z);
    } else if (d <= atk.range + 0.3 && now >= m.nextAtk) {
      const extra = { r: +(atk.reach * (m.elite ? 1.25 : 1)).toFixed(2) };
      let kind = atk.kind;
      // 수호자는 내려찍기와 크게 휩쓸기를 섞어 쓴다
      if (m.type === 'golem' && Math.random() < 0.4) {
        kind = 'arc';
        extra.r = +(atk.reach * 1.2).toFixed(2);
        extra.half = 1.25;
        extra.d = 900;
      }
      if (kind === 'arc' && extra.half === undefined) extra.half = atk.half;
      if (kind === 'lunge') { m.dash = Math.min(atk.dash, d + 1.2); extra.dash = +m.dash.toFixed(2); }
      this.startWindup(m, tgt, now, kind, extra);
    } else if (m.type === 'golem' && d > 10 && d < 28 && now >= m.nextAtk) {
      // 멀리서 활만 쏘는 상대에게는 바위를 던진다
      this.startWindup(m, tgt, now, 'throw', { d: 950 });
    } else if (d > Math.max(1.2, atk.range * 0.7)) {
      this.moveToward(m, tgt.x, tgt.z, def.speed * dt);
    } else {
      m.yaw = Math.atan2(tgt.x - m.x, tgt.z - m.z);
    }
  }

  // ---------- 보스: 그림자 군주 ----------
  wakeBoss() {
    const b = this.boss;
    const n = Math.max(1, this.players.size);
    const st = monStats('lord', b.level, false);
    // 함께하는 인원이 많을수록 보스도 강해진다
    b.maxHp = Math.round((st.hp + 3000 * (n - 1)) * cycleScale(this.cycle));
    b.hp = b.maxHp;
    b.dmg = Math.round(MON.lord.dmg * (1 + 0.15 * this.cycle));
    b.xp = Math.round(2500 * cycleScale(this.cycle));
    b.alive = true;
    b.x = b.hx;
    b.z = b.hz;
    b.state = MSTATE.IDLE;
    b.target = 0;
    b.summons = 0;
    b.chain = null;
    b.nextAtk = Date.now() + 3000;
    this.bossState = 'awake';
    this.broadcast({ t: 'world', state: this.worldState(), ev: 'boss-awake' });
  }

  summonMinions(count) {
    let n = 0;
    for (const id of this.pois.minionIds) {
      const m = this.monsters[id];
      if (m.alive) continue;
      this.applyStats(m);
      m.alive = true;
      m.x = m.hx;
      m.z = m.hz;
      m.state = MSTATE.IDLE;
      m.target = 0;
      if (++n >= count) break;
    }
  }

  updateBoss(m, now, dt, players, tgt) {
    const A = this.pois.arena;
    const cands = [];
    for (const p of players) {
      if (p.alive && dist(p.x, p.z, A.x, A.z) < A.r + 24 && Math.abs(p.y - VOLCANO.floor) < 30) cands.push(p);
    }
    // 체력이 줄수록 사나워진다: 2단계(55% 아래)부터 연속기와 회전 베기, 28% 아래에서는 쉴 틈이 거의 없다
    const phase2 = m.hp < m.maxHp * 0.55;
    const enraged = m.hp < m.maxHp * 0.28;
    if (m.state === MSTATE.WINDUP) {
      if (now >= m.until) {
        if (m.pattern === 'lunge') {
          const steps = 8;
          const sx = (Math.sin(m.yaw) * m.dash) / steps;
          const sz = (Math.cos(m.yaw) * m.dash) / steps;
          for (let i = 0; i < steps; i++) if (!this.tryMove(m, sx, sz)) break;
        } else if (m.pattern === 'roar') {
          this.summonMinions(phase2 ? 4 : 3);
        } else if (m.pattern === 'throw') {
          this.bossBarrage(m, phase2 ? 7 : 5);
        }
        m.state = MSTATE.RECOVER;
        m.until = now + (m.chain ? 240 : 560);
        m.nextAtk = now + (enraged ? 650 : phase2 ? 1200 : 1750) + Math.random() * 600;
      }
      return;
    }
    if (m.state === MSTATE.RECOVER) {
      if (now >= m.until) {
        m.state = MSTATE.CHASE;
        const chain = m.chain;
        m.chain = null;
        // 연속기: 내려찍기나 돌진 뒤에 곧바로 크게 휩쓴다
        if (chain && tgt && tgt.alive) {
          this.startWindup(m, tgt, now, 'arc', chain === 'spin' ? { r: 11.5, half: 3.2, d: 900 } : { r: 10.5, half: 1.9, d: 640 });
        }
      }
      return;
    }
    if (cands.length === 0) {
      if (!m.idleSince) m.idleSince = now;
      if (now - m.idleSince > 12000 && (m.hp < m.maxHp || dist(m.x, m.z, m.hx, m.hz) > 2)) {
        m.hp = m.maxHp;
        m.summons = 0;
      }
      if (dist(m.x, m.z, m.hx, m.hz) > 1.5) {
        this.moveToward(m, m.hx, m.hz, m.def.speed * dt);
        m.state = MSTATE.WALK;
      } else m.state = MSTATE.IDLE;
      return;
    }
    m.idleSince = 0;
    if (!tgt || !cands.includes(tgt)) {
      tgt = cands[0];
      let bd = Infinity;
      for (const p of cands) {
        const d = dist(p.x, p.z, m.x, m.z);
        if (d < bd) { bd = d; tgt = p; }
      }
      m.target = tgt.id;
    }
    const d = dist(tgt.x, tgt.z, m.x, m.z);
    m.state = MSTATE.CHASE;
    if (now >= m.nextAtk) {
      // 체력이 75% · 50% · 25% 아래로 내려갈 때마다 부하를 부른다
      const want = m.hp < m.maxHp * 0.25 ? 3 : m.hp < m.maxHp * 0.5 ? 2 : m.hp < m.maxHp * 0.75 ? 1 : 0;
      if ((m.summons || 0) < want) {
        m.summons = (m.summons || 0) + 1;
        return this.startWindup(m, tgt, now, 'roar', { d: 1200 });
      }
      const r = Math.random();
      if (d < 9) {
        if (r < 0.34) {
          if (phase2 && Math.random() < 0.65) m.chain = enraged && Math.random() < 0.5 ? 'spin' : 'arc';
          return this.startWindup(m, tgt, now, 'slam', { r: enraged ? 9.5 : 8.5, d: phase2 ? 950 : 1100 });
        }
        if (r < 0.62) return this.startWindup(m, tgt, now, 'arc', { r: 10.5, half: 1.9, d: phase2 ? 800 : 920 });
        if (r < 0.82 && phase2) return this.startWindup(m, tgt, now, 'arc', { r: 12, half: 3.2, d: 1200 });
        return this.startMeteor(m, tgt, now, cands, phase2);
      }
      if (r < 0.4 && d < 34) {
        m.dash = Math.min(24, d + 5);
        if (phase2 && Math.random() < 0.5) m.chain = 'arc';
        return this.startWindup(m, tgt, now, 'lunge', { r: 3.6, dash: +m.dash.toFixed(2), d: phase2 ? 780 : 900 });
      }
      if (r < 0.72) return this.startWindup(m, tgt, now, 'throw', { d: 800 });
      return this.startMeteor(m, tgt, now, cands, phase2);
    }
    if (d > 5.5) this.moveToward(m, tgt.x, tgt.z, m.def.speed * (phase2 ? 1.3 : 1) * dt);
    else m.yaw = Math.atan2(tgt.x - m.x, tgt.z - m.z);
  }

  // 부채꼴로 불덩이를 여러 개 던진다
  bossBarrage(m, count, proj = 'fire') {
    const tgt = this.players.get(m.target);
    const tx = tgt && tgt.alive ? tgt.x : m.tx;
    const tz = tgt && tgt.alive ? tgt.z : m.tz;
    const ty = (tgt && tgt.alive ? tgt.y : m.ty) + 1.0;
    const base = Math.atan2(tx - m.x, tz - m.z);
    const d = Math.max(6, dist(tx, tz, m.x, m.z));
    for (let i = 0; i < count; i++) {
      const a = base + (i - (count - 1) / 2) * 0.2;
      this.throwAt(m, m.x + Math.sin(a) * d, m.z + Math.cos(a) * d, ty, 21, proj, Math.max(1, m.dmg - 2));
    }
  }

  startMeteor(m, tgt, now, cands, more = false) {
    const A = this.pois.arena;
    const pts = [];
    const n = 5 + Math.min(5, cands.length * 2) + (more ? 4 : 0);
    for (let i = 0; i < n; i++) {
      const p = cands[i % cands.length];
      const a = Math.random() * TAU;
      const r = i < cands.length ? 0 : 2 + Math.random() * 9;
      let x = p.x + Math.sin(a) * r;
      let z = p.z + Math.cos(a) * r;
      const dc = dist(x, z, A.x, A.z);
      if (dc > A.r) {
        x = A.x + ((x - A.x) / dc) * A.r;
        z = A.z + ((z - A.z) / dc) * A.r;
      }
      pts.push([+x.toFixed(1), +z.toFixed(1), i * (more ? 140 : 180)]);
    }
    this.startWindup(m, tgt, now, 'meteor', { r: 4.2, d: 1500, pts });
  }

  // ---------- 피해 처리 ----------
  // heavy: 망치 내려찍기처럼 단단한 적(우두머리·설인)도 휘청이게 하는 공격
  damageMonster(m, p, dmg, crit, kb, now, heavy = false) {
    if (!m.alive) return;
    if (m.state === MSTATE.RETURN) m.state = MSTATE.CHASE;
    m.hp -= dmg;
    m.freshUntil = this.tickCount + 3;
    if (!m.target || Math.random() < 0.3) m.target = p.id;
    if (m.zone && !m.boss) this.alertGroup(m, p);
    let stag = 0;
    if ((m.def.stagger && !m.elite) || (heavy && !m.def.boss)) {
      stag = 1;
      m.state = MSTATE.STAGGER;
      m.until = now + 330;
      const dx = m.x - p.x;
      const dz = m.z - p.z;
      const d = Math.hypot(dx, dz) || 1;
      m.kvx = (dx / d) * kb;
      m.kvz = (dz / d) * kb;
    }
    this.broadcastNear(m.x, m.z, 140, { t: 'h', id: m.id, d: dmg, c: crit ? 1 : 0, by: p.id, hp: Math.max(0, Math.round(m.hp)), s: stag });
    if (m.hp <= 0) this.killMonster(m, p, now);
  }

  killMonster(m, p, now) {
    m.alive = false;
    m.hp = 0;
    m.target = 0;
    // 구역 안의 몬스터는 구역이 비워졌다가 다시 채워질 때 한꺼번에 돌아온다
    m.respawnAt = m.def.respawn > 0 && !m.minion && !m.zone ? now + m.def.respawn * 1000 * (m.camp >= 0 || m.shard >= 0 ? 1.5 : 1) : 0;
    const to = [];
    for (const q of this.players.values()) {
      if (m.zone ? q.zone === m.zone : m.boss || dist(q.x, q.z, m.x, m.z) < 75) to.push(q.id);
    }
    const gold = m.gmin + Math.floor(Math.random() * (m.gmax - m.gmin + 1));
    this.broadcast({ t: 'md', id: m.id, by: p ? p.id : 0, xp: m.xp, g: gold, to });
    if (m.shard >= 0) this.recomputeSeals(false);
    if (m.zone) this.updateZone(this.zones[m.zone - 1]);
    else if (m.boss) this.onBossDead(now);
  }

  // ---------- 시련장 · 던전 ----------
  // 관문: 같은 번호의 무리가 모두 쓰러지면 열린다
  updateZone(z) {
    const groups = new Map();
    for (const m of z.mobs) {
      if (m.minion) continue;
      const g = groups.get(m.group) || { n: 0, alive: 0 };
      g.n++;
      if (m.alive) g.alive++;
      groups.set(m.group, g);
    }
    let open = z.puzzle || 0;
    for (const [g, v] of groups) if (v.alive === 0) open |= 1 << g;
    if (open !== z.open) {
      z.open = open;
      this.broadcast(this.zoneState(z));
      if (z.boss && !z.boss.alive) for (const m of z.mobs) if (m.minion) m.alive = false;
    }
  }

  zoneState(z) {
    return { t: 'zs', id: z.def.id, open: z.open, epoch: z.epoch };
  }

  // 아무도 없는 채로 시간이 지나면 처음 상태로 되돌린다
  resetZone(z) {
    for (const m of z.mobs) {
      this.applyStats(m);
      m.alive = !m.minion;
      m.x = m.hx;
      m.z = m.hz;
      m.state = MSTATE.IDLE;
      m.target = 0;
      m.kvx = m.kvz = 0;
      m.combo = null;
      m.summons = 0;
      m.freshUntil = this.tickCount + 6;
    }
    z.open = 0;
    z.puzzle = 0;
    z.epoch = Math.max(z.epoch + 1, Math.floor(Date.now() / 1000));
    this.broadcast(this.zoneState(z));
  }

  tickZones(now, players) {
    for (const z of this.zones) z.players = 0;
    for (const p of players) if (p.zone) this.zones[p.zone - 1].players++;
    for (const z of this.zones) {
      if (z.players > 0) {
        z.emptySince = 0;
        // 보스는 함께 들어온 사람 수에 맞춰 강해진다 (싸움이 시작되기 전에만 조정)
        const b = z.boss;
        if (b && b.alive && b.hp >= b.maxHp && !b.target) {
          const base = Math.round(monStats(b.type, b.level, false).hp * cycleScale(this.cycle));
          const want = Math.round(base * (1 + 0.6 * (z.players - 1)));
          if (want !== b.maxHp) b.maxHp = b.hp = want;
        }
        continue;
      }
      if (!z.emptySince) z.emptySince = now;
      if (now - z.emptySince < ZONE_RESET_MS) continue;
      let dirty = z.open !== 0;
      if (!dirty) for (const m of z.mobs) if (m.alive === !!m.minion || m.hp < m.maxHp) { dirty = true; break; }
      if (dirty) this.resetZone(z);
      z.emptySince = now;
    }
  }

  summonZoneMinions(z, count) {
    let n = 0;
    for (const m of z.mobs) {
      if (!m.minion || m.alive) continue;
      this.applyStats(m);
      m.alive = true;
      m.x = m.hx;
      m.z = m.hz;
      m.state = MSTATE.IDLE;
      m.target = 0;
      m.freshUntil = this.tickCount + 6;
      if (++n >= count) break;
    }
  }

  // 던전 보스: 종류마다 다른 공격 묶음. 체력이 줄수록 연속기가 늘고 쉬는 틈이 줄어든다.
  updateZoneBoss(m, now, dt, players, tgt) {
    const z = this.zones[m.zone - 1];
    const type = m.type;
    const phase2 = m.hp < m.maxHp * 0.6;
    const enraged = m.hp < m.maxHp * 0.3;
    if (m.state === MSTATE.WINDUP) {
      if (now >= m.until) {
        if (m.pattern === 'lunge') {
          const steps = 8;
          const sx = (Math.sin(m.yaw) * m.dash) / steps;
          const sz = (Math.cos(m.yaw) * m.dash) / steps;
          for (let i = 0; i < steps; i++) if (!this.tryMove(m, sx, sz)) break;
        } else if (m.pattern === 'roar') {
          this.summonZoneMinions(z, phase2 ? 4 : 2);
        } else if (m.pattern === 'throw') {
          this.bossBarrage(m, type === 'knight' ? (phase2 ? 9 : 6) : phase2 ? 5 : 3, type === 'knight' ? 'fire' : 'rock');
        }
        m.state = MSTATE.RECOVER;
        const next = m.combo && m.combo.length;
        m.until = now + (next ? 200 : type === 'knight' ? 420 : 560);
        const gap = type === 'knight' ? (enraged ? 520 : phase2 ? 900 : 1300) : type === 'tyrant' ? (enraged ? 800 : phase2 ? 1200 : 1700) : enraged ? 900 : phase2 ? 1300 : 1800;
        m.nextAtk = now + gap + Math.random() * 500;
      }
      return;
    }
    if (m.state === MSTATE.RECOVER) {
      if (now >= m.until) {
        m.state = MSTATE.CHASE;
        // 연속기: 예약해 둔 다음 공격을 곧바로 잇는다
        if (m.combo && m.combo.length && tgt) {
          const c = m.combo.shift();
          const d = dist(tgt.x, tgt.z, m.x, m.z);
          if (c.k === 'lunge') {
            m.dash = Math.min(c.max || 14, d + 3);
            c.dash = +m.dash.toFixed(2);
          }
          const { k, max, ...extra } = c;
          this.startWindup(m, tgt, now, k, extra);
        } else m.combo = null;
      }
      return;
    }
    // 제 방과 그 둘레(42m)에 들어온 상대만 노린다. 멀리 달아나면 돌아가서 체력을 되찾는다.
    const cands = [];
    if (this.zoneAwake(m)) for (const p of players) if (p.alive && p.zone === m.zone && dist(p.x, p.z, m.hx, m.hz) < 42) cands.push(p);
    if (cands.length === 0) {
      // 상대가 모두 쓰러지거나 나가면 곧 체력을 되찾는다 (쓰러졌다가 바로 돌아와 이어서 싸울 수 없다)
      if (!m.idleSince) m.idleSince = now;
      if (now - m.idleSince > 2500 && m.hp < m.maxHp) {
        m.hp = m.maxHp;
        m.summons = 0;
        m.freshUntil = this.tickCount + 6;
      }
      m.combo = null;
      if (dist(m.x, m.z, m.hx, m.hz) > 1.5) {
        this.moveToward(m, m.hx, m.hz, m.def.speed * dt);
        m.state = MSTATE.WALK;
      } else m.state = MSTATE.IDLE;
      return;
    }
    m.idleSince = 0;
    if (!tgt || !cands.includes(tgt)) {
      let bd = Infinity;
      for (const p of cands) {
        const d = dist(p.x, p.z, m.x, m.z);
        if (d < bd) { bd = d; tgt = p; }
      }
      m.target = tgt.id;
    }
    const d = dist(tgt.x, tgt.z, m.x, m.z);
    m.state = MSTATE.CHASE;
    if (now >= m.nextAtk) {
      const r = Math.random();
      m.combo = null;
      // 체력이 2/3, 1/3 아래로 내려갈 때 부하를 부른다
      const want = m.hp < m.maxHp * 0.34 ? 2 : m.hp < m.maxHp * 0.67 ? 1 : 0;
      if ((m.summons || 0) < want) {
        m.summons = (m.summons || 0) + 1;
        return this.startWindup(m, tgt, now, 'roar', { d: 1100 });
      }
      const lunge = (max, wind, rr) => {
        m.dash = Math.min(max, d + 3);
        return this.startWindup(m, tgt, now, 'lunge', { r: rr, dash: +m.dash.toFixed(2), d: wind });
      };
      if (type === 'kingslime') {
        // 말랑 대왕: 덮치기와 내려찍기. 2단계부터는 연달아 세 번 덮친다
        if (d < 8 && r < 0.45) return this.startWindup(m, tgt, now, 'slam', { r: enraged ? 9 : 7.5, d: phase2 ? 850 : 1000 });
        if (phase2) m.combo = [{ k: 'lunge', r: 3.6, d: 520, max: 14 }, { k: enraged ? 'slam' : 'lunge', r: enraged ? 8 : 3.6, d: enraged ? 700 : 520, max: 14 }];
        return lunge(16, phase2 ? 620 : 800, 3.6);
      }
      if (type === 'tyrant') {
        // 서리 폭군: 내려찍기, 휩쓸기, 돌진, 얼음덩이 던지기, 마지막에는 얼음 비
        if (d < 9) {
          if (r < 0.4) {
            if (phase2) m.combo = [{ k: 'arc', r: 10, half: 1.6, d: 620 }];
            return this.startWindup(m, tgt, now, 'slam', { r: enraged ? 9.5 : 8.5, d: phase2 ? 880 : 1000 });
          }
          if (r < 0.75) return this.startWindup(m, tgt, now, 'arc', { r: 9.5, half: 1.6, d: phase2 ? 720 : 850 });
          if (enraged) return this.startZoneMeteor(m, tgt, now, cands, 10);
          return this.startWindup(m, tgt, now, 'throw', { d: 750 });
        }
        if (r < 0.5) {
          if (phase2) m.combo = [{ k: 'slam', r: 8, d: 620 }];
          return lunge(18, phase2 ? 680 : 800, 3.8);
        }
        if (enraged && r < 0.75) return this.startZoneMeteor(m, tgt, now, cands, 10);
        return this.startWindup(m, tgt, now, 'throw', { d: 750 });
      }
      // 공허의 기사: 빠른 연속 베기, 회전 베기, 돌진 베기, 불꽃 부채, 별똥
      if (d < 8.5) {
        if (r < 0.45) {
          m.combo = phase2 ? [{ k: 'arc', r: 8.5, half: 1.9, d: 420 }, { k: enraged ? 'arc' : 'lunge', r: enraged ? 10 : 3.2, half: 3.2, d: enraged ? 700 : 480, max: 12 }] : [{ k: 'arc', r: 8.5, half: 1.9, d: 460 }];
          return this.startWindup(m, tgt, now, 'arc', { r: 8, half: 1.9, d: phase2 ? 560 : 660 });
        }
        if (r < 0.7) return this.startWindup(m, tgt, now, 'arc', { r: 10, half: 3.2, d: phase2 ? 820 : 950 });
        if (r < 0.85) return this.startZoneMeteor(m, tgt, now, cands, phase2 ? 14 : 9);
        return this.startWindup(m, tgt, now, 'throw', { d: 620 });
      }
      if (r < 0.5) {
        m.combo = [{ k: 'arc', r: 8.5, half: 1.9, d: 420 }];
        return lunge(20, phase2 ? 480 : 580, 3.2);
      }
      if (r < 0.8) return this.startWindup(m, tgt, now, 'throw', { d: 620 });
      return this.startZoneMeteor(m, tgt, now, cands, phase2 ? 14 : 9);
    }
    if (d > Math.max(3.5, m.radius + 2.2)) this.moveToward(m, tgt.x, tgt.z, m.def.speed * (phase2 ? 1.25 : 1) * dt);
    else m.yaw = Math.atan2(tgt.x - m.x, tgt.z - m.z);
  }

  // 방 안 여기저기에 떨어지는 공격 (벽 속에는 떨어지지 않는다)
  startZoneMeteor(m, tgt, now, cands, n) {
    const z = this.zones[m.zone - 1];
    const pts = [];
    for (let i = 0; i < n; i++) {
      const p = cands[i % cands.length];
      const a = Math.random() * TAU;
      const r = i < cands.length ? 0 : 2 + Math.random() * 9;
      const x = p.x + Math.sin(a) * r;
      const zz = p.z + Math.cos(a) * r;
      if (zoneSolid(z.def, x, zz, z.open)) continue;
      pts.push([+x.toFixed(1), +zz.toFixed(1), i * 150]);
    }
    this.startWindup(m, tgt, now, 'meteor', { r: 3.8, d: 1400, pts });
  }

  onBossDead(now) {
    this.bossState = 'dead';
    this.resetAt = now + 90000;
    for (const id of this.pois.minionIds) this.monsters[id].alive = false;
    this.broadcast({ t: 'world', state: this.worldState(), ev: 'victory' });
  }

  newCycle() {
    this.cycle += 1;
    this.shards.clear();
    this.bossState = 'sleep';
    this.resetAt = 0;
    this.boss.alive = false;
    for (const m of this.monsters) {
      if (m.boss || m.minion || m.zone) continue;
      this.applyStats(m);
      this.respawn(m);
    }
    // 시련장·던전: 비어 있는 곳만 지금 되돌린다 (안에 사람이 있으면 나간 뒤에 되돌아간다)
    for (const z of this.zones) if (z.players === 0) this.resetZone(z);
    this.recomputeSeals(true);
    this.persist();
    this.broadcast({ t: 'world', state: this.worldState(), ev: 'cycle' });
  }

  // ---------- 플레이어 ----------
  profileOf(p) {
    return { id: p.id, name: p.name, tunic: p.tunic, hair: p.hair, lvl: p.lvl, eq: p.eq, mc: p.mc };
  }

  applyProfile(p, d) {
    if (!d || typeof d !== 'object') return;
    if (d.name !== undefined) p.name = cleanText(d.name, 12) || '모험가';
    if (d.tunic !== undefined) p.tunic = clampInt(d.tunic, 0, TUNIC_COLORS.length - 1);
    if (d.hair !== undefined) p.hair = clampInt(d.hair, 0, HAIR_COLORS.length - 1);
    if (d.lvl !== undefined) p.lvl = clampInt(d.lvl, 1, MAX_LEVEL);
    if (d.mc !== undefined) p.mc = clampInt(d.mc, 0, MOUNT_COLORS.length - 1);
    if (d.eq && typeof d.eq === 'object') {
      // 착용 장비: 칸에 맞는 종류만 받는다
      const eq = {};
      for (const slot of SLOTS) {
        const it = cleanItem(d.eq[slot]);
        eq[slot] = it && slotOf(it.t) === slot ? it : null;
      }
      p.eq = eq;
    }
    // 시련 보상으로 늘어난 체력·기력
    if (d.bh !== undefined) p.bonus.hp = clampInt(d.bh, 0, 60);
    if (d.bs !== undefined) p.bonus.sta = clampInt(d.bs, 0, 150);
    const st = gearStats(p.lvl, p.eq, p.bonus);
    p.wk = st.kind;
    p.atk = st.atk;
    p.bowAtk = st.bowAtk;
    p.crit = st.crit;
    p.maxHp = st.maxHp;
  }

  addPlayer(ws) {
    if (this.freeIds.length === 0) return null;
    const id = this.freeIds.pop();
    const p = {
      id, ws, joined: false, name: '모험가', tunic: 0, hair: 0, lvl: 1, mc: 0,
      eq: { weapon: makeItem('sword', 0, 1), bow: makeItem('bow', 0, 1), armor: null, helm: null, charm: null }, bonus: { hp: 0, sta: 0 },
      wk: 'sword', atk: 4, bowAtk: 5, crit: 0.1, maxHp: 6, hp: 6, trade: null, trReq: 0, trReqAt: 0, zone: 0,
      x: VILLAGE.x, y: VILLAGE.h, z: VILLAGE.z + 21, yaw: Math.PI, anim: 0, alive: true,
      lastMsg: Date.now(), lastAtk: 0, lastChat: 0, chatBurst: 0, msgCount: 0, msgWindow: Date.now(),
    };
    this.players.set(id, p);
    return p;
  }

  removePlayer(p) {
    if (!this.players.has(p.id)) return;
    this.endTrade(p);
    this.players.delete(p.id);
    this.freeIds.push(p.id);
    if (p.joined) {
      this.broadcast({ t: 'pl', id: p.id });
      console.log(`[leave] ${p.name} (${this.joinedCount()}명 접속 중)`);
    }
  }

  joinedCount() {
    let n = 0;
    for (const p of this.players.values()) if (p.joined) n++;
    return n;
  }

  send(p, obj) {
    if (p.ws.readyState === 1) p.ws.send(typeof obj === 'string' ? obj : JSON.stringify(obj));
  }

  broadcast(obj, exceptId = 0) {
    const s = JSON.stringify(obj);
    for (const p of this.players.values()) {
      if (p.joined && p.id !== exceptId && p.ws.readyState === 1) p.ws.send(s);
    }
  }

  // 가까이 있는 사람에게만 보낸다 (시련장·던전 안의 일은 그 안에 있는 사람에게만)
  broadcastNear(x, z, r, obj, exceptId = 0) {
    const s = JSON.stringify(obj);
    const zid = zoneIdAt(x, z);
    for (const p of this.players.values()) {
      if (!p.joined || p.id === exceptId || p.ws.readyState !== 1 || p.zone !== zid) continue;
      if (dist(p.x, p.z, x, z) <= r) p.ws.send(s);
    }
  }

  onBinary(p, buf) {
    if (!p.joined || buf.length < 10 || buf[0] !== P.PKT_STATE) return;
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    P.decodeState(dv, p);
    p.zone = zoneIdAt(p.x, p.z);
    const wasAlive = p.alive;
    p.alive = p.anim !== ANIM.DEAD && p.hp > 0;
    if (wasAlive && !p.alive) this.broadcast({ t: 'sys', text: `${p.name} 님이 쓰러졌습니다…` });
  }

  onMessage(p, msg) {
    const now = Date.now();
    switch (msg.t) {
      case 'join': {
        if (p.joined) return;
        this.applyProfile(p, msg.prof);
        p.hp = p.maxHp;
        p.joined = true;
        const merged = this.mergeSave(msg.save);
        const others = [];
        for (const q of this.players.values()) if (q.joined && q.id !== p.id) others.push(this.profileOf(q));
        this.send(p, { t: 'welcome', id: p.id, now, tick: TICK_MS, seed: this.seed, me: this.profileOf(p), players: others, state: this.worldState() });
        this.broadcast({ t: 'pj', p: this.profileOf(p) }, p.id);
        if (merged) this.broadcast({ t: 'world', state: this.worldState(), ev: 'restore' }, p.id);
        console.log(`[join] ${p.name} (${this.joinedCount()}명 접속 중)`);
        return;
      }
      case 'ping':
        this.send(p, { t: 'pong', c: msg.c, s: now });
        return;
      default:
    }
    if (!p.joined) return;
    switch (msg.t) {
      case 'prof':
        this.applyProfile(p, msg.prof);
        this.broadcast({ t: 'pp', p: this.profileOf(p) }, p.id);
        return;
      case 'a': {
        // 무기 종류에 따라 연속 공격의 피해 배율과 밀어내는 힘이 다르다
        const wpn = WEAPONS[p.wk] || WEAPONS.sword;
        if (!p.alive || now - p.lastAtk < (p.wk === 'dagger' ? 130 : 170) || !Array.isArray(msg.ids)) return;
        p.lastAtk = now;
        const hit = wpn.hits[clampInt(msg.k, 0, wpn.hits.length - 1)];
        for (const raw of msg.ids.slice(0, 10)) {
          const m = this.monsters[raw | 0];
          if (!m || !m.alive) continue;
          if (dist(p.x, p.z, m.x, m.z) > hit.reach + 6 + m.radius) continue;
          const crit = Math.random() < p.crit;
          const dmg = p.atk * hit.mult * (0.9 + Math.random() * 0.2) * (crit ? 2 : 1);
          this.damageMonster(m, p, Math.max(1, Math.round(dmg)), crit, hit.kb, now, !!(wpn.stagger && hit.quake));
        }
        return;
      }
      case 'tr':
        this.onTrade(p, msg, now);
        return;
      case 'zone': {
        // 구역에 들어온 사람에게 지금의 관문 상태를 알려 준다
        const z = this.zones[(msg.id | 0) - 1];
        if (z) this.send(p, this.zoneState(z));
        return;
      }
      case 'zopen': {
        // 퍼즐을 풀어 여는 관문 (그 구역 안에 있는 사람만 열 수 있다)
        const z = this.zones[p.zone - 1];
        if (!z || !z.def.puzzle || z.def.puzzle.gate !== (msg.gate | 0)) return;
        const bit = 1 << z.def.puzzle.gate;
        if (z.open & bit) return;
        z.open |= bit;
        z.puzzle = bit;
        this.broadcast({ ...this.zoneState(z), by: p.id });
        return;
      }
      case 'lamp': {
        // 숨겨진 던전의 돌등을 밝혔다: 근처에 있는 친구들의 돌등도 함께 켜진다
        const ent = this.pois.zones[(msg.z | 0) - 1];
        const k = msg.k | 0;
        if (!ent || !ent.lamps[k] || dist(p.x, p.z, ent.lamps[k].x, ent.lamps[k].z) > 12) return;
        this.broadcastNear(p.x, p.z, 160, { t: 'lamp', z: ent.id, k, by: p.id }, p.id);
        return;
      }
      case 'ar': {
        if (!p.alive || !p.bowAtk) return;
        const m = this.monsters[msg.id | 0];
        if (!m || !m.alive || dist(p.x, p.z, m.x, m.z) > 95) return;
        const crit = Math.random() < p.crit + 0.05;
        const dmg = p.bowAtk * (0.9 + Math.random() * 0.2) * (crit ? 2 : 1);
        this.damageMonster(m, p, Math.max(1, Math.round(dmg)), crit, 3.5, now);
        return;
      }
      case 'shot': {
        const n = (v) => (Number.isFinite(+v) ? +(+v).toFixed(2) : 0);
        this.broadcastNear(p.x, p.z, 150, { t: 'shot', by: p.id, x: n(msg.x), y: n(msg.y), z: n(msg.z), dx: n(msg.dx), dy: n(msg.dy), dz: n(msg.dz) }, p.id);
        return;
      }
      case 'shard': {
        const s = this.pois.shards[msg.id | 0];
        if (!s || this.shards.has(s.id) || this.bossState === 'dead') return;
        if (dist(p.x, p.z, s.x, s.z) > 8) return;
        if (this.sealed.has(s.id)) {
          this.send(p, { t: 'sys', text: '수호자를 모두 쓰러뜨려야 봉인이 풀립니다!' });
          return;
        }
        this.shards.add(s.id);
        this.pristine = false;
        this.persist();
        this.broadcast({ t: 'sg', id: s.id, by: p.id, n: this.shards.size });
        this.broadcast({ t: 'world', state: this.worldState() });
        if (this.shards.size >= SHARD_COUNT && this.bossState === 'sleep') this.wakeBoss();
        return;
      }
      case 'debug': {
        // 개발용 명령 (환경 변수 DEBUG_CMDS=1 일 때만 동작)
        if (!process.env.DEBUG_CMDS) return;
        if (msg.cmd === 'allshards') {
          for (let i = 0; i < SHARD_COUNT; i++) this.shards.add(i);
          this.pristine = false;
          this.recomputeSeals(true);
          this.broadcast({ t: 'world', state: this.worldState() });
          if (this.bossState === 'sleep') this.wakeBoss();
        } else if (msg.cmd === 'kill') {
          const m = this.monsters[msg.id | 0];
          if (m && m.alive) this.damageMonster(m, p, m.hp + 1, false, 0, now);
        } else if (msg.cmd === 'hurt') {
          // 몬스터의 체력을 비율로 맞춘다 (보스 단계 시험용)
          const m = this.monsters[msg.id | 0];
          if (m && m.alive) m.hp = Math.max(1, Math.round(m.maxHp * Math.min(1, Math.max(0.01, +msg.frac || 0.5))));
        } else if (msg.cmd === 'bosshp') {
          this.boss.hp = Math.max(1, Math.min(this.boss.maxHp, msg.hp | 0));
        } else if (msg.cmd === 'cycle') {
          this.newCycle();
        }
        return;
      }
      case 'chat': {
        const text = cleanText(msg.text, 100);
        if (!text) return;
        if (now - p.lastChat > 6000) p.chatBurst = 0;
        if (++p.chatBurst > 6) return;
        p.lastChat = now;
        this.broadcast({ t: 'chat', id: p.id, name: p.name, text });
        return;
      }
      default:
    }
  }

  // ---------- 친구와 교환 ----------
  // 가방은 각자의 기기에 있으므로, 서버는 양쪽이 올린 물건을 전달하고 둘 다 확인했을 때 동시에 성사시킨다.
  onTrade(p, msg, now) {
    const a = msg.a;
    if (a === 'req') {
      const q = this.players.get(msg.to | 0);
      if (!q || !q.joined || q === p || now - p.trReqAt < 1500) return;
      if (p.trade || q.trade) {
        this.send(p, { t: 'tr', a: 'busy', name: q.name });
        return;
      }
      p.trReqAt = now;
      p.trReq = q.id;
      this.send(q, { t: 'tr', a: 'req', from: p.id, name: p.name });
      return;
    }
    if (a === 'acc' || a === 'dec') {
      const q = this.players.get(msg.from | 0);
      if (!q || !q.joined || q.trReq !== p.id) {
        if (a === 'acc') this.send(p, { t: 'tr', a: 'cancel' });
        return;
      }
      q.trReq = 0;
      if (a === 'dec') {
        this.send(q, { t: 'tr', a: 'dec', name: p.name });
        return;
      }
      if (p.trade || q.trade) {
        this.send(p, { t: 'tr', a: 'cancel' });
        return;
      }
      const tr = { a: q, b: p, offers: new Map([[q.id, { items: [], gold: 0, ok: false, ver: 0 }], [p.id, { items: [], gold: 0, ok: false, ver: 0 }]]) };
      p.trade = q.trade = tr;
      this.send(q, { t: 'tr', a: 'open', with: p.id, name: p.name });
      this.send(p, { t: 'tr', a: 'open', with: q.id, name: q.name });
      return;
    }
    const tr = p.trade;
    if (!tr) return;
    const other = tr.a === p ? tr.b : tr.a;
    const mine = tr.offers.get(p.id);
    const theirs = tr.offers.get(other.id);
    if (a === 'offer') {
      mine.items = (Array.isArray(msg.items) ? msg.items : []).slice(0, 6).map(cleanItem).filter(Boolean);
      mine.gold = clampInt(msg.gold, 0, 9999999);
      mine.ver++;
      // 내용이 바뀌면 양쪽 확인을 모두 푼다
      mine.ok = theirs.ok = false;
      this.send(other, { t: 'tr', a: 'offer', items: mine.items, gold: mine.gold, ver: mine.ver });
    } else if (a === 'ok') {
      // 상대가 마지막으로 올린 내용을 보고 누른 확인만 받는다
      if (msg.v && (msg.seen | 0) !== theirs.ver) return;
      mine.ok = !!msg.v;
      this.send(other, { t: 'tr', a: 'ok', v: mine.ok ? 1 : 0 });
      if (mine.ok && theirs.ok) {
        p.trade = other.trade = null;
        this.send(p, { t: 'tr', a: 'done', give: { items: mine.items, gold: mine.gold }, get: { items: theirs.items, gold: theirs.gold }, name: other.name });
        this.send(other, { t: 'tr', a: 'done', give: { items: theirs.items, gold: theirs.gold }, get: { items: mine.items, gold: mine.gold }, name: p.name });
      }
    } else if (a === 'cancel') this.endTrade(p);
  }

  endTrade(p) {
    const tr = p.trade;
    if (!tr) return;
    const other = tr.a === p ? tr.b : tr.a;
    p.trade = other.trade = null;
    this.send(other, { t: 'tr', a: 'cancel', name: p.name });
  }

  // ---------- 메인 루프 ----------
  tick() {
    const now = Date.now();
    const dt = TICK_MS / 1000;
    this.tickCount++;
    const players = [];
    for (const p of this.players.values()) if (p.joined) players.push(p);

    if (this.resetAt && now >= this.resetAt) this.newCycle();
    if (this.tickCount % 5 === 0) this.tickZones(now, players);

    const active = [];
    const R2 = ACTIVE_R * ACTIVE_R;
    for (const m of this.monsters) {
      if (!m.alive) {
        if (m.respawnAt && now >= m.respawnAt) {
          let ok = true;
          for (const p of players) if (dist(p.x, p.z, m.hx, m.hz) < 45) { ok = false; break; }
          if (ok) this.respawn(m);
          else m.respawnAt = now + 5000;
        }
        continue;
      }
      let near = Infinity;
      for (const p of players) {
        const dx = p.x - m.x;
        const dz = p.z - m.z;
        const d2 = dx * dx + dz * dz;
        if (d2 < near) near = d2;
      }
      if (near > R2) {
        if (!m.boss && (m.state !== MSTATE.IDLE || m.x !== m.hx || m.z !== m.hz || m.hp !== m.maxHp)) {
          m.x = m.hx;
          m.z = m.hz;
          m.hp = m.maxHp;
          m.state = MSTATE.IDLE;
          m.target = 0;
          m.kvx = m.kvz = 0;
        }
        continue;
      }
      active.push(m);
      this.updateMonster(m, now, dt, players);
      if (m.state !== m.prevState) {
        m.prevState = m.state;
        m.freshUntil = this.tickCount + 3;
      }
    }

    // 몬스터끼리 겹치지 않게 밀어내기
    for (let i = 0; i < active.length; i++) {
      const a = active[i];
      if (a.boss || a.state === MSTATE.WINDUP) continue;
      for (let j = i + 1; j < active.length; j++) {
        const b = active[j];
        if (b.boss || b.state === MSTATE.WINDUP) continue;
        const dx = b.x - a.x;
        const dz = b.z - a.z;
        const rr = (a.radius + b.radius) * 0.85;
        const d2 = dx * dx + dz * dz;
        if (d2 >= rr * rr || d2 < 1e-6) continue;
        const d = Math.sqrt(d2);
        const push = (rr - d) * 0.5;
        const nx = dx / d;
        const nz = dz / d;
        this.tryMove(a, -nx * push, -nz * push);
        this.tryMove(b, nx * push, nz * push);
      }
    }

    // 스냅샷 전송
    const tc = this.tickCount;
    const V2 = VIEW_R * VIEW_R;
    const vis = [];
    for (const p of players) {
      if (p.ws.readyState !== 1) continue;
      vis.length = 0;
      for (const m of active) {
        if (m.zone !== p.zone) continue;
        const dx = p.x - m.x;
        const dz = p.z - m.z;
        if (dx * dx + dz * dz > V2) continue;
        // 데이터 절약: 가만히 있는 몬스터는 0.5초마다, 어슬렁거리는 몬스터는 0.2초마다만 보낸다
        if (m.state === MSTATE.IDLE && m.kvx === 0 && m.kvz === 0) {
          if ((tc + m.id) % 5 !== 0 && m.freshUntil < tc) continue;
        } else if (m.state === MSTATE.WALK) {
          if ((tc + m.id) % 2 !== 0 && m.freshUntil < tc) continue;
        }
        vis.push(m);
      }
      const nP = players.length - 1;
      const buf = Buffer.allocUnsafe(P.snapSize(nP, vis.length));
      const dv = new DataView(buf.buffer, buf.byteOffset, buf.length);
      let o = P.writeSnapHeader(dv, now, nP, vis.length);
      for (const q of players) {
        if (q === p) continue;
        o = P.writeSnapPlayer(dv, o, q);
      }
      for (const m of vis) {
        dv.setUint16(o, m.id);
        dv.setInt16(o + 2, P.q(m.x));
        dv.setInt16(o + 4, P.q(m.z));
        dv.setUint8(o + 6, P.yawToByte(m.yaw));
        const hp5 = Math.max(0, Math.min(31, Math.ceil((31 * m.hp) / m.maxHp)));
        dv.setUint8(o + 7, (m.state & 7) | (hp5 << 3));
        o += P.SNAP_MONSTER;
      }
      p.ws.send(buf, { binary: true });
    }
  }

  status() {
    return {
      players: this.joinedCount(),
      cycle: this.cycle,
      shards: this.shards.size,
      boss: this.bossState,
    };
  }
}

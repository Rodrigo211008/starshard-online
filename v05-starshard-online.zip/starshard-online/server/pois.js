// 월드의 주요 지점(별조각, 귀환석, 야영지, 상자, 몬스터 출현 지점 등)을 seed 로부터 생성한다.
import { W, OLD_HALF, BIOME, BIOME_INFO, VILLAGE, VOLCANO, ISLES } from '../shared/world.js';
import { rand2 } from '../shared/noise.js';
import { GOLEM_NAMES, NPC_DEFS } from '../shared/defs.js';
import { ZONES } from '../shared/zones.js';

// 세계를 넓히기 전(본섬만 있던 때)의 배치가 그대로 유지되도록, 격자 기준점은 예전 값을 쓰고
// 본섬(중심에서 MAIN_R 안쪽)을 먼저 예전과 같은 순서로 채운 뒤 바깥 섬을 채운다.
const O = OLD_HALF;
const MAIN_R = 852;

export function generatePOIs(world) {
  const seed = world.seed;
  const N = W.VERTS;
  const H = world.heights;
  const patches = [];

  const vx = (i) => -W.HALF + i * W.CELL;

  function rough(i, j, k) {
    const h0 = H[j * N + i];
    let m = 0;
    for (let dj = -k; dj <= k; dj++) {
      for (let di = -k; di <= k; di++) {
        const ii = i + di;
        const jj = j + dj;
        if (ii < 0 || jj < 0 || ii > W.GRID || jj > W.GRID) return 99;
        const d = Math.abs(H[jj * N + ii] - h0);
        if (d > m) m = d;
      }
    }
    return m;
  }

  // 기준점 주변에서 조건에 맞는 격자점을 찾는다. mode: 'high' | 'flat'
  function findSpot(ax, az, radius, mode, minH = 2) {
    const i0 = Math.max(3, Math.floor((ax - radius + W.HALF) / W.CELL));
    const i1 = Math.min(W.GRID - 3, Math.ceil((ax + radius + W.HALF) / W.CELL));
    const j0 = Math.max(3, Math.floor((az - radius + W.HALF) / W.CELL));
    const j1 = Math.min(W.GRID - 3, Math.ceil((az + radius + W.HALF) / W.CELL));
    let best = null;
    let bestScore = -1e9;
    for (let j = j0; j <= j1; j++) {
      for (let i = i0; i <= i1; i++) {
        const x = vx(i);
        const z = vx(j);
        const dx = x - ax;
        const dz = z - az;
        const d = Math.sqrt(dx * dx + dz * dz);
        if (d > radius) continue;
        const h = H[j * N + i];
        if (h < minH) continue;
        let score;
        if (mode === 'high') score = h - d * 0.01;
        else score = -rough(i, j, 2) * 2 - d * 0.02;
        if (score > bestScore) {
          bestScore = score;
          best = { x, z, h, rough: rough(i, j, 2) };
        }
      }
    }
    return best;
  }

  // 특정 바이옴 안쪽(경계에서 떨어진 곳)에서 가장 높은 지점
  function highestInBiome(b) {
    let best = null;
    for (let j = 4; j < W.GRID - 4; j++) {
      for (let i = 4; i < W.GRID - 4; i++) {
        const idx = j * N + i;
        if (world.biome[idx] !== b) continue;
        if (world.biome[idx - 3] !== b || world.biome[idx + 3] !== b || world.biome[idx - 3 * N] !== b || world.biome[idx + 3 * N] !== b) continue;
        const h = H[idx];
        if (!best || h > best.h) best = { x: vx(i), z: vx(j), h, rough: rough(i, j, 2) };
      }
    }
    return best;
  }

  function flatten(x, z, r, f, h) {
    patches.push({ x, z, r, f, h: Math.round(h * 100) / 100 });
  }

  // ---- 마을 & 보스 경기장 ----
  flatten(VILLAGE.x, VILLAGE.z, VILLAGE.r, 24, VILLAGE.h);
  flatten(VOLCANO.x, VOLCANO.z, VOLCANO.arenaR, 4, VOLCANO.floor);

  // ---- 별조각 12개 ----
  const shardDefs = [
    { name: '바람 언덕', ax: -120, az: -110, r: 70, mode: 'high', guard: 'none' },
    { name: '호숫가 도깨비 소굴', ax: 165, az: 150, r: 60, mode: 'flat', guard: 'camp', comp: ['goblin', 'goblin', 'goblin', 'thrower'], elite: 'goblin' },
    { name: '깊은 숲의 제단', ax: 600, az: 90, r: 70, mode: 'flat', guard: 'golem' },
    { name: '늑대 언덕', ax: -560, az: -100, r: 70, mode: 'flat', guard: 'camp', comp: ['wolf', 'wolf', 'wolf'], elite: 'wolf' },
    { name: '붉은 탁상지', ax: 120, az: 540, r: 150, mode: 'high', biomeHigh: BIOME.DESERT, guard: 'none' },
    { name: '모래에 묻힌 유적', ax: -70, az: 560, r: 70, mode: 'flat', guard: 'golem' },
    { name: '늪의 심장', ax: -470, az: 330, r: 80, mode: 'flat', guard: 'golem' },
    { name: '말랑이 둥지', ax: -330, az: 470, r: 70, mode: 'flat', guard: 'camp', comp: ['slime', 'slime', 'slime', 'slime'], elite: 'slime' },
    { name: '서리봉 정상', ax: -140, az: -480, r: 260, mode: 'high', guard: 'none' },
    { name: '설인의 야영지', ax: -330, az: -420, r: 80, mode: 'flat', guard: 'camp', comp: ['yeti', 'wolf', 'wolf'], elite: 'yeti' },
    { name: '분화구 가장자리', ax: VOLCANO.x, az: VOLCANO.z, r: 66, mode: 'high', guard: 'camp', comp: ['imp', 'imp', 'imp'], elite: 'imp' },
    { name: '잿더미 제단', ax: 290, az: -250, r: 60, mode: 'flat', guard: 'golem' },
  ];

  const shards = [];
  const spawns = [];
  const camps = [];
  const chests = [];

  function addSpawn(type, level, x, z, extra = {}) {
    const s = { id: spawns.length, type, level, x: Math.round(x * 10) / 10, z: Math.round(z * 10) / 10, biome: world.biomeAt(x, z), shard: -1, camp: -1, elite: 0, ...extra };
    spawns.push(s);
    return s;
  }

  // 중심 주변 원형으로 배치 (sin/cos 없이 고정 방향 테이블 사용)
  const RING = [
    [1, 0], [0.7071, 0.7071], [0, 1], [-0.7071, 0.7071], [-1, 0], [-0.7071, -0.7071], [0, -1], [0.7071, -0.7071],
    [0.9239, 0.3827], [0.3827, 0.9239], [-0.3827, 0.9239], [-0.9239, 0.3827], [-0.9239, -0.3827], [-0.3827, -0.9239], [0.3827, -0.9239], [0.9239, -0.3827],
  ];

  shardDefs.forEach((d, id) => {
    const spot = (d.biomeHigh !== undefined ? highestInBiome(d.biomeHigh) : null) || findSpot(d.ax, d.az, d.r, d.mode, d.mode === 'flat' ? 2.2 : 2) || { x: d.ax, z: d.az, h: 5 };
    const b = world.biomeAt(spot.x, spot.z);
    const lvl = BIOME_INFO[b].level + 1;
    flatten(spot.x, spot.z, d.mode === 'high' ? 6 : 12, d.mode === 'high' ? 8 : 9, spot.h);
    shards.push({ id, name: d.name, x: spot.x, z: spot.z, guard: d.guard, biome: b });
    if (d.guard === 'golem') {
      addSpawn('golem', lvl, spot.x + 6, spot.z + 3, { shard: id, name: GOLEM_NAMES[b] });
    } else if (d.guard === 'camp') {
      d.comp.forEach((type, k) => {
        const dir = RING[(k * 3 + id) % 8];
        addSpawn(type, lvl, spot.x + dir[0] * 7.5, spot.z + dir[1] * 7.5, { shard: id });
      });
      const dir = RING[(id + 5) % 8];
      addSpawn(d.elite, lvl, spot.x + dir[0] * 5, spot.z + dir[1] * 5, { shard: id, elite: 1 });
    }
    chests.push({ id: chests.length, x: spot.x - 3.5, z: spot.z + 3.2, tier: Math.min(4, 1 + Math.floor(lvl / 3)), kind: 'shrine' });
  });

  // ---- 귀환석 (빠른 이동) ----
  const stoneDefs = [
    { name: '새벽 마을', ax: 9, az: -15, fixed: true },
    { name: '속삭임 숲', ax: 370, az: 110 },
    { name: '황금 사막', ax: 30, az: 330 },
    { name: '안개 늪', ax: -320, az: 240 },
    { name: '서리봉 기슭', ax: -130, az: -290 },
    { name: '화산 협곡 입구', ax: VOLCANO.x + VOLCANO.notchX * 142, az: VOLCANO.z + VOLCANO.notchZ * 142 },
    { name: '단풍 고원', ax: -420, az: -90 },
  ];
  const stones = [];
  stoneDefs.forEach((d, id) => {
    let spot;
    if (d.fixed) spot = { x: d.ax, z: d.az, h: VILLAGE.h };
    else {
      spot = findSpot(d.ax, d.az, 36, 'flat', 2.5) || { x: d.ax, z: d.az, h: 6 };
      flatten(spot.x, spot.z, 5, 7, spot.h);
    }
    stones.push({ id, name: d.name, x: spot.x, z: spot.z });
  });

  // 바깥 섬의 귀환석 (본섬에서 건너오는 모래톱 길이 닿는 쪽)
  const ISLE_STONES = ['벚꽃 언덕', '버섯 숲', '수정 고원', '그림자 황무지'];
  ISLES.forEach((q, k) => {
    const d = Math.sqrt(q.x * q.x + q.z * q.z);
    const ax = q.x - (q.x / d) * q.r * 0.45;
    const az = q.z - (q.z / d) * q.r * 0.45;
    const spot = findSpot(ax, az, 46, 'flat', 3) || { x: ax, z: az, h: 6 };
    flatten(spot.x, spot.z, 5, 7, spot.h);
    stones.push({ id: stones.length, name: ISLE_STONES[k], x: spot.x, z: spot.z });
  });

  const far = (x, z, list, dist) => {
    for (const o of list) {
      const dx = x - o.x;
      const dz = z - o.z;
      if (dx * dx + dz * dz < dist * dist) return false;
    }
    return true;
  };
  const distVillage = (x, z) => Math.sqrt((x - VILLAGE.x) * (x - VILLAGE.x) + (z - VILLAGE.z) * (z - VILLAGE.z));
  const distVolcano = (x, z) => Math.sqrt((x - VOLCANO.x) * (x - VOLCANO.x) + (z - VOLCANO.z) * (z - VOLCANO.z));
  // 세계를 넓히며 새로 생긴 땅(바깥 섬, 모래톱 길)인지
  const outer = (x, z) => x * x + z * z > MAIN_R * MAIN_R || world.addedAt(x, z);
  // 본섬의 귀환석만 (본섬의 배치 판단에는 예전과 같은 목록을 쓴다)
  const mainStones = stones.slice(0, stoneDefs.length);

  // ---- 일반 야영지 ----
  const CAMP_COMP = [
    ['goblin', 'goblin', 'goblin', 'thrower'],
    ['goblin', 'goblin', 'goblin', 'thrower', 'thrower'],
    ['yeti', 'wolf', 'wolf', 'wolf'],
    ['goblin', 'goblin', 'scorpion', 'scorpion', 'thrower'],
    ['goblin', 'goblin', 'thrower', 'thrower', 'slime', 'slime'],
    ['imp', 'imp', 'imp', 'imp'],
    ['goblin', 'goblin', 'wolf', 'wolf', 'thrower'],
    ['goblin', 'goblin', 'wolf', 'wolf', 'thrower', 'thrower'],
    ['slime', 'slime', 'slime', 'imp', 'imp', 'thrower'],
    ['yeti', 'yeti', 'wolf', 'wolf', 'imp'],
    ['imp', 'imp', 'imp', 'yeti', 'wolf', 'wolf'],
  ];
  const CSTEP = 150;
  // pass 0: 본섬 (예전과 같은 칸, 같은 순서), pass 1: 바깥 섬
  const placeCamps = (pass) => {
    const g0 = pass ? -3 : 0;
    const g1 = pass ? 14 : 11;
    for (let gz = g0; gz < g1; gz++) {
      for (let gx = g0; gx < g1; gx++) {
        if (rand2(gx, gz, seed + 301) > (pass ? 0.75 : 0.6)) continue;
        const ax = -O + (gx + 0.2 + 0.6 * rand2(gx, gz, seed + 302)) * CSTEP - 25;
        const az = -O + (gz + 0.2 + 0.6 * rand2(gx, gz, seed + 303)) * CSTEP - 25;
        const spot = findSpot(ax, az, 34, 'flat', 2.5);
        if (!spot || spot.rough > 3.2) continue;
        if (outer(spot.x, spot.z) !== !!pass) continue;
        if (distVillage(spot.x, spot.z) < 170) continue;
        if (distVolcano(spot.x, spot.z) < 75) continue;
        if (!far(spot.x, spot.z, shards, 90) || !far(spot.x, spot.z, pass ? stones : mainStones, 60) || !far(spot.x, spot.z, camps, pass ? 130 : 150)) continue;
        const b = world.biomeAt(spot.x, spot.z);
        const lvl = BIOME_INFO[b].level;
        const id = camps.length;
        flatten(spot.x, spot.z, 8, 8, spot.h);
        camps.push({ id, x: spot.x, z: spot.z, biome: b });
        CAMP_COMP[b].forEach((type, k) => {
          const dir = RING[(k * 2 + id * 3) % 16];
          // 바깥 섬의 야영지는 우두머리가 이끈다
          addSpawn(type, lvl, spot.x + dir[0] * 6.5, spot.z + dir[1] * 6.5, { camp: id, elite: pass && k === 0 ? 1 : 0 });
        });
        chests.push({ id: chests.length, x: spot.x + 2.8, z: spot.z - 2.4, tier: Math.min(4, 1 + Math.floor(lvl / 3)), kind: 'camp' });
      }
    }
  };

  // ---- 들판의 보물상자 ----
  const XSTEP = 100;
  const placeChests = (pass) => {
    const g0 = pass ? -4 : 0;
    const g1 = pass ? 20 : 16;
    for (let gz = g0; gz < g1; gz++) {
      for (let gx = g0; gx < g1; gx++) {
        if (rand2(gx, gz, seed + 311) > (pass ? 0.46 : 0.36)) continue;
        const x = -O + (gx + 0.1 + 0.8 * rand2(gx, gz, seed + 312)) * XSTEP;
        const z = -O + (gz + 0.1 + 0.8 * rand2(gx, gz, seed + 313)) * XSTEP;
        if (outer(x, z) !== !!pass) continue;
        const h = world.heightAt(x, z);
        if (h < (pass ? 2.4 : 1.3) || world.slopeAt(x, z) > 0.45) continue;
        if (distVillage(x, z) < 110 || distVolcano(x, z) < 60) continue;
        if (!far(x, z, shards, 25) || !far(x, z, pass ? stones : mainStones, 15) || !far(x, z, camps, 25)) continue;
        const lvl = BIOME_INFO[world.biomeAt(x, z)].level;
        chests.push({ id: chests.length, x: Math.round(x * 10) / 10, z: Math.round(z * 10) / 10, tier: Math.min(4, 1 + Math.floor(lvl / 3)), kind: 'wild' });
      }
    }
  };

  // ---- 회복 열매 덤불 ----
  const bushes = [];
  const BSTEP = 52;
  const BG = Math.floor((2 * O) / BSTEP);
  const placeBushes = (pass) => {
    const g0 = pass ? -8 : 0;
    const g1 = pass ? BG + 8 : BG;
    for (let gz = g0; gz < g1; gz++) {
      for (let gx = g0; gx < g1; gx++) {
        if (rand2(gx, gz, seed + 321) > 0.34) continue;
        const x = -O + (gx + 0.1 + 0.8 * rand2(gx, gz, seed + 322)) * BSTEP;
        const z = -O + (gz + 0.1 + 0.8 * rand2(gx, gz, seed + 323)) * BSTEP;
        if (outer(x, z) !== !!pass) continue;
        const h = world.heightAt(x, z);
        if (h < (pass ? 2.4 : 1.2) || world.slopeAt(x, z) > 0.5) continue;
        const b = world.biomeAt(x, z);
        if (b === BIOME.VOLCANO || b === BIOME.SNOW || b === BIOME.SHADOW || b === BIOME.CRYSTAL) {
          if (rand2(gx, gz, seed + 324) > 0.3) continue;
        }
        if (distVillage(x, z) < 50) continue;
        if (!far(x, z, shards, 10) || !far(x, z, pass ? stones : mainStones, 6) || !far(x, z, camps, 10)) continue;
        bushes.push({ id: bushes.length, x: Math.round(x * 10) / 10, z: Math.round(z * 10) / 10 });
      }
    }
  };

  // ---- 들판의 몬스터 ----
  const TABLE = {
    [BIOME.MEADOW]: [['slime', 0.62, 1, 3], ['goblin', 0.28, 1, 2], ['thrower', 0.1, 1, 1]],
    [BIOME.FOREST]: [['wolf', 0.38, 2, 3], ['goblin', 0.3, 1, 2], ['thrower', 0.14, 1, 1], ['slime', 0.18, 2, 3]],
    [BIOME.AUTUMN]: [['wolf', 0.36, 2, 3], ['goblin', 0.36, 1, 3], ['thrower', 0.14, 1, 2], ['slime', 0.14, 2, 3]],
    [BIOME.DESERT]: [['scorpion', 0.52, 1, 2], ['goblin', 0.26, 1, 2], ['thrower', 0.22, 1, 2]],
    [BIOME.SWAMP]: [['slime', 0.5, 2, 4], ['thrower', 0.2, 1, 2], ['goblin', 0.3, 1, 2]],
    [BIOME.SNOW]: [['wolf', 0.45, 2, 3], ['yeti', 0.25, 1, 1], ['slime', 0.3, 2, 3]],
    [BIOME.VOLCANO]: [['imp', 0.5, 1, 2], ['slime', 0.3, 2, 3], ['goblin', 0.2, 1, 2]],
    [BIOME.BLOSSOM]: [['wolf', 0.3, 2, 3], ['goblin', 0.3, 2, 3], ['thrower', 0.2, 1, 2], ['slime', 0.2, 2, 4]],
    [BIOME.MUSHROOM]: [['slime', 0.4, 3, 5], ['imp', 0.3, 1, 3], ['scorpion', 0.3, 1, 2]],
    [BIOME.CRYSTAL]: [['yeti', 0.3, 1, 2], ['wolf', 0.35, 2, 4], ['imp', 0.35, 2, 3]],
    [BIOME.SHADOW]: [['imp', 0.35, 2, 4], ['wolf', 0.3, 3, 4], ['yeti', 0.2, 1, 2], ['goblin', 0.15, 2, 3]],
  };
  const SSTEP = 56;
  const SG = Math.floor((2 * O) / SSTEP);
  const placeMobs = (pass) => {
    const g0 = pass ? -8 : 0;
    const g1 = pass ? SG + 8 : SG;
    for (let gz = g0; gz < g1; gz++) {
      for (let gx = g0; gx < g1; gx++) {
        if (rand2(gx, gz, seed + 331) > 0.5) continue;
        const x = -O + (gx + 0.15 + 0.7 * rand2(gx, gz, seed + 332)) * SSTEP;
        const z = -O + (gz + 0.15 + 0.7 * rand2(gx, gz, seed + 333)) * SSTEP;
        if (outer(x, z) !== !!pass) continue;
        const h = world.heightAt(x, z);
        const b = world.biomeAt(x, z);
        // 바깥 섬으로 가는 모래톱 길(낮은 모래밭)에는 몬스터를 두지 않는다
        if (h < (pass ? 2.6 : b === BIOME.SWAMP ? 0.5 : 1.2) || world.slopeAt(x, z) > 0.6) continue;
        const dv = distVillage(x, z);
        if (dv < 100 || distVolcano(x, z) < 62) continue;
        if (!far(x, z, shards, 34) || !far(x, z, pass ? stones : mainStones, 30) || !far(x, z, camps, 36)) continue;
        const table = TABLE[b];
        let pick = rand2(gx, gz, seed + 334);
        let entry = table[0];
        for (const e of table) {
          if (pick < e[1]) { entry = e; break; }
          pick -= e[1];
        }
        let type = entry[0];
        let lvl = BIOME_INFO[b].level + (rand2(gx, gz, seed + 335) < 0.35 ? 1 : 0);
        if (b === BIOME.MEADOW && dv < 230) { type = 'slime'; lvl = 1; }
        const cnt = entry[2] + Math.floor(rand2(gx, gz, seed + 336) * (entry[3] - entry[2] + 1));
        // 바깥 섬에서는 가끔 우두머리가 무리를 이끈다
        const lead = pass && rand2(gx, gz, seed + 337) < 0.14;
        for (let k = 0; k < cnt; k++) {
          const dir = RING[(((k * 5 + gx + gz * 3) % 16) + 16) % 16];
          const rr = k === 0 ? 0 : 3.2;
          const sx = x + dir[0] * rr;
          const sz = z + dir[1] * rr;
          if (world.heightAt(sx, sz) < 0.5) continue;
          addSpawn(type, lvl, sx, sz, lead && k === 0 ? { elite: 1 } : {});
        }
      }
    }
  };

  // 본섬을 먼저 예전과 같은 순서로 다 채운 다음에 바깥 섬을 채운다 (본섬의 번호가 바뀌지 않도록)
  for (let pass = 0; pass < 2; pass++) {
    placeCamps(pass);
    placeChests(pass);
    placeBushes(pass);
    placeMobs(pass);
  }

  // ---- 바깥 섬의 수호자 (별조각과 상관없이 섬 가운데를 지킨다) ----
  ISLES.forEach((q) => {
    const spot = findSpot(q.x, q.z, 70, 'flat', 4) || { x: q.x, z: q.z, h: 8 };
    flatten(spot.x, spot.z, 10, 9, spot.h);
    addSpawn('golem', BIOME_INFO[q.b].level + 2, spot.x, spot.z, { name: GOLEM_NAMES[q.b] });
    chests.push({ id: chests.length, x: spot.x - 4.5, z: spot.z + 4, tier: 4, kind: 'camp' });
  });

  // ---- 시련장과 던전의 입구 ----
  // 시련장은 눈에 띄는 곳에, 던전은 외진 곳에 숨겨 둔다 (주변의 돌등을 모두 밝혀야 문이 드러난다)
  const zones = [];
  const used = [];
  const farFrom = (list, x, z, r) => {
    for (const o of list) {
      const dx = o.x - x;
      const dz = o.z - z;
      if (dx * dx + dz * dz < r * r) return false;
    }
    return true;
  };
  // 다른 시설과 겹치지 않는지
  const clearOf = (x, z, pad) =>
    farFrom(shards, x, z, 18 + pad) && farFrom(stones, x, z, 10 + pad) && farFrom(camps, x, z, 15 + pad) && farFrom(chests, x, z, 4 + pad) &&
    farFrom(bushes, x, z, 2.5 + pad) && farFrom(used, x, z, 9 + pad) && farFrom([VILLAGE], x, z, 56 + pad) && farFrom([VOLCANO], x, z, VOLCANO.arenaR + 12 + pad);
  // 기준점 둘레에서 평평하고 물에 잠기지 않으며 다른 시설과 겹치지 않는 자리
  function findClear(ax, az, radius, minH, maxRough, pad, biome = -1) {
    const i0 = Math.max(3, Math.floor((ax - radius + W.HALF) / W.CELL));
    const i1 = Math.min(W.GRID - 3, Math.ceil((ax + radius + W.HALF) / W.CELL));
    const j0 = Math.max(3, Math.floor((az - radius + W.HALF) / W.CELL));
    const j1 = Math.min(W.GRID - 3, Math.ceil((az + radius + W.HALF) / W.CELL));
    let best = null;
    let bestScore = -1e9;
    for (let j = j0; j <= j1; j++) {
      for (let i = i0; i <= i1; i++) {
        const x = vx(i);
        const z = vx(j);
        const d = Math.hypot(x - ax, z - az);
        if (d > radius) continue;
        const h = H[j * N + i];
        if (h < minH || (biome >= 0 && world.biome[j * N + i] !== biome)) continue;
        const ro = rough(i, j, 2);
        if (ro > maxRough || !clearOf(x, z, pad)) continue;
        const score = -ro * 2 - d * 0.02;
        if (score > bestScore) {
          bestScore = score;
          best = { x, z, h };
        }
      }
    }
    return best;
  }
  for (const zd of ZONES) {
    const [ax, az] = zd.anchor;
    const trial = zd.kind === 'trial';
    // 되도록 그 지역 안의 평평한 곳에 놓는다 (산처럼 험한 곳은 조금 더 넓게, 덜 까다롭게 찾는다)
    const spot =
      findClear(ax, az, trial ? 50 : 70, 3, 2.5, 4, zd.theme) || findClear(ax, az, 90, 3, 5, 3, zd.theme) || findClear(ax, az, 140, 2.5, 7, 2, zd.theme) ||
      findClear(ax, az, 160, 2.5, 7, 2) || { x: ax, z: az, h: Math.max(3, world.heightAt(ax, az)) };
    flatten(spot.x, spot.z, 6, 7, spot.h);
    used.push({ x: spot.x, z: spot.z });
    const lamps = [];
    for (let k = 0; k < zd.lamps; k++) {
      // 입구 둘레 28~56m 에 흩어 놓는다. 물이나 비탈이면 방향과 거리를 조금씩 바꿔 가며 다시 찾는다.
      const base = Math.floor((k * 16) / zd.lamps) + (zd.id % 2);
      const rr = 30 + ((k * 37 + zd.id * 11) % 26);
      let ls = null;
      for (let t = 0; t < 30 && !ls; t++) {
        const dir = RING[(((base + [0, 1, -1, 2, -2][t % 5]) % 16) + 16) % 16];
        const r2 = [rr, 36, 46, 30, 54, 40][Math.floor(t / 5)];
        const c = findClear(spot.x + dir[0] * r2, spot.z + dir[1] * r2, 9, 2, t < 15 ? 2.2 : 5, 1);
        if (c && Math.hypot(c.x - spot.x, c.z - spot.z) > 24 && farFrom(lamps, c.x, c.z, 16)) ls = c;
      }
      if (!ls) {
        const lx = spot.x + RING[base % 16][0] * rr;
        const lz = spot.z + RING[base % 16][1] * rr;
        ls = { x: lx, z: lz, h: Math.max(2.5, world.heightAt(lx, lz)) };
      }
      flatten(ls.x, ls.z, 2.2, 3, ls.h);
      lamps.push({ x: ls.x, z: ls.z });
      used.push({ x: ls.x, z: ls.z });
    }
    zones.push({ id: zd.id, x: spot.x, z: spot.z, lamps });
    // 구역 안의 몬스터 (관문 무리)
    for (const sp of zd.spawns) {
      addSpawn(sp.type, sp.level, sp.x, sp.z, { biome: zd.theme, zone: zd.id, group: sp.group, elite: sp.elite, boss: sp.boss && zd.kind === 'dungeon' ? 1 : 0, minion: sp.minion });
    }
  }

  // ---- NPC ----
  const npcs = [];
  for (const kind of Object.keys(NPC_DEFS)) {
    const d = NPC_DEFS[kind];
    npcs.push({ id: npcs.length, kind, name: d.name, x: VILLAGE.x + d.x, z: VILLAGE.z + d.z, yaw: d.yaw });
  }
  // 각 귀환석 옆의 길잡이
  const GUIDE_NAMES = ['', '나무꾼 솔', '상인 모래', '약초꾼 이끼', '산지기 눈솔', '탐험가 불씨', '사냥꾼 단풍', '꽃지기 나래', '버섯꾼 포자', '세공사 유리', '방랑자 그늘'];
  for (let i = 1; i < stones.length; i++) {
    npcs.push({ id: npcs.length, kind: 'guide', name: GUIDE_NAMES[i], x: stones[i].x + 3.2, z: stones[i].z + 1.5, yaw: 4.2, stone: i });
  }

  // 보스와 소환수 (평소에는 잠들어 있다)
  const boss = addSpawn('lord', 14, VOLCANO.x, VOLCANO.z - 8, { boss: 1 });
  const minions = [];
  for (let k = 0; k < 6; k++) {
    const dir = RING[(k * 3) % 16];
    minions.push(addSpawn(k % 2 ? 'imp' : 'slime', 12, VOLCANO.x + dir[0] * 14, VOLCANO.z + dir[1] * 14, { minion: 1 }).id);
  }

  return {
    village: { x: VILLAGE.x, z: VILLAGE.z },
    arena: { x: VOLCANO.x, z: VOLCANO.z, r: VOLCANO.arenaR },
    patches,
    shards,
    stones,
    camps,
    chests,
    bushes,
    spawns,
    npcs,
    zones,
    bossId: boss.id,
    minionIds: minions,
  };
}

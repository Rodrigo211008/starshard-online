// 키보드·마우스·터치 입력
export class Input {
  constructor(canvas) {
    this.canvas = canvas;
    // 휴대폰·태블릿이면 터치 조작, 그 외에는 키보드·마우스 (터치가 들어오면 그때 전환)
    this.isTouch = matchMedia('(pointer: coarse)').matches || (navigator.maxTouchPoints > 0 && /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent));
    this.onTouchMode = null;
    this.moveX = 0;
    this.moveY = 0;
    this.sprint = false;
    this.sprintToggle = false;
    this.jumpHeld = false;
    this.lookDX = 0;
    this.lookDY = 0;
    this.zoom = 0;
    this.pressed = new Set();
    this.keys = new Set();
    this.locked = false;
    this.enabled = false; // 게임 플레이 중일 때만 입력을 받는다
    this.blocked = () => false; // UI 패널이 열려 있으면 true
    this.sens = 1;
    this.onKey = null;

    this._bindKeyboard();
    this._bindMouse();
    this._bindTouch();
  }

  consume(name) {
    if (this.pressed.has(name)) {
      this.pressed.delete(name);
      return true;
    }
    return false;
  }

  _press(name) {
    if (this.enabled) this.pressed.add(name);
  }

  _bindKeyboard() {
    const map = {
      Space: 'jump', KeyE: 'interact', KeyF: 'interact', KeyQ: 'heal', KeyR: 'bow', KeyJ: 'attack', KeyK: 'bow',
      KeyM: 'map', Enter: 'chat', KeyB: 'bag', KeyC: 'bag', Tab: 'players', Digit1: 'emote1', Digit2: 'emote2', Digit3: 'emote3', Escape: 'escape', KeyH: 'help',
    };
    window.addEventListener('keydown', (e) => {
      const typing = document.activeElement && /INPUT|TEXTAREA/.test(document.activeElement.tagName);
      if (typing) {
        if (e.code === 'Escape') this._press('escape');
        return;
      }
      if (e.code === 'Tab' || e.code === 'Space') e.preventDefault();
      if (e.repeat) return;
      this.keys.add(e.code);
      if (map[e.code]) this._press(map[e.code]);
    });
    window.addEventListener('keyup', (e) => this.keys.delete(e.code));
    window.addEventListener('blur', () => {
      this.keys.clear();
      this.jumpHeld = false;
    });
  }

  _bindMouse() {
    const c = this.canvas;
    c.addEventListener('mousedown', (e) => {
      if (this.isTouch || !this.enabled || this.blocked()) return;
      if (!this.locked) {
        if (c.requestPointerLock) {
          try {
            const p = c.requestPointerLock();
            if (p && p.catch) p.catch(() => {});
          } catch {
            /* 마우스 고정을 쓸 수 없는 환경 */
          }
        }
        this._drag = true;
        this._downAt = performance.now();
        this._moved = 0;
        this._downBtn = e.button;
        return;
      }
      if (e.button === 0) this._press('attack');
      else if (e.button === 2) this._press('bow');
    });
    window.addEventListener('mouseup', () => {
      // 마우스 고정이 안 되는 환경에서는 "드래그 = 시점, 짧은 클릭 = 공격"
      if (this._drag && !this.locked && this._lockTried && this._moved < 6 && performance.now() - this._downAt < 260) {
        this._press(this._downBtn === 2 ? 'bow' : 'attack');
      }
      if (this._drag && !this.locked) this._lockTried = true;
      this._drag = false;
    });
    c.addEventListener('contextmenu', (e) => e.preventDefault());
    document.addEventListener('pointerlockchange', () => {
      this.locked = document.pointerLockElement === c;
    });
    window.addEventListener('mousemove', (e) => {
      if (this.isTouch || !this.enabled) return;
      if (this.locked || this._drag) {
        this._moved = (this._moved || 0) + Math.abs(e.movementX) + Math.abs(e.movementY);
        this.lookDX += e.movementX * 0.0024 * this.sens;
        this.lookDY += e.movementY * 0.0024 * this.sens;
      }
    });
    c.addEventListener('wheel', (e) => {
      this.zoom += Math.sign(e.deltaY);
      e.preventDefault();
    }, { passive: false });
  }

  unlock() {
    if (this.locked && document.exitPointerLock) document.exitPointerLock();
  }

  _bindTouch() {
    const joy = document.getElementById('joy');
    const knob = document.getElementById('joy-knob');
    const zone = document.getElementById('touch-zone');
    if (!zone) return;
    let joyId = null;
    let joyX = 0;
    let joyY = 0;
    const looks = new Map();
    const R = 56;

    const setKnob = (dx, dy) => {
      knob.style.transform = `translate(${dx}px, ${dy}px)`;
    };
    // 터치스크린 노트북 등: 처음 화면을 터치하면 터치 조작으로 전환
    window.addEventListener('touchstart', () => {
      if (this.isTouch) return;
      this.isTouch = true;
      this.unlock();
      if (this.onTouchMode) this.onTouchMode();
    }, { passive: true });
    zone.addEventListener('touchstart', (e) => {
      if (!this.enabled) return;
      e.preventDefault();
      for (const t of e.changedTouches) {
        const leftSide = t.clientX < window.innerWidth * 0.42 && t.clientY > window.innerHeight * 0.25;
        if (leftSide && joyId === null) {
          joyId = t.identifier;
          joyX = t.clientX;
          joyY = t.clientY;
          joy.style.left = joyX + 'px';
          joy.style.top = joyY + 'px';
          joy.classList.add('on');
          setKnob(0, 0);
        } else {
          looks.set(t.identifier, { x: t.clientX, y: t.clientY });
        }
      }
    }, { passive: false });
    zone.addEventListener('touchmove', (e) => {
      e.preventDefault();
      for (const t of e.changedTouches) {
        if (t.identifier === joyId) {
          let dx = t.clientX - joyX;
          let dy = t.clientY - joyY;
          const d = Math.hypot(dx, dy);
          if (d > R) {
            dx = (dx / d) * R;
            dy = (dy / d) * R;
          }
          setKnob(dx, dy);
          const mag = Math.min(1, d / R);
          const dead = 0.14;
          if (mag < dead) {
            this.moveX = 0;
            this.moveY = 0;
          } else {
            this.moveX = dx / R;
            this.moveY = -dy / R;
          }
        } else if (looks.has(t.identifier)) {
          const l = looks.get(t.identifier);
          this.lookDX += (t.clientX - l.x) * 0.0052 * this.sens;
          this.lookDY += (t.clientY - l.y) * 0.0042 * this.sens;
          l.x = t.clientX;
          l.y = t.clientY;
        }
      }
    }, { passive: false });
    const end = (e) => {
      for (const t of e.changedTouches) {
        if (t.identifier === joyId) {
          joyId = null;
          this.moveX = 0;
          this.moveY = 0;
          joy.classList.remove('on');
        }
        looks.delete(t.identifier);
      }
    };
    zone.addEventListener('touchend', end);
    zone.addEventListener('touchcancel', end);

    // 액션 버튼
    for (const btn of document.querySelectorAll('.abtn')) {
      const act = btn.dataset.act;
      const down = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!this.enabled) return;
        btn.classList.add('down');
        if (act === 'sprint') {
          this.sprintToggle = !this.sprintToggle;
          btn.classList.toggle('active', this.sprintToggle);
          return;
        }
        if (act === 'jump') this.jumpHeld = true;
        this._press(act);
      };
      const up = (e) => {
        e.preventDefault();
        btn.classList.remove('down');
        if (act === 'jump') this.jumpHeld = false;
      };
      btn.addEventListener('touchstart', down, { passive: false });
      btn.addEventListener('touchend', up, { passive: false });
      btn.addEventListener('touchcancel', up, { passive: false });
      btn.addEventListener('mousedown', (e) => {
        if (!this.isTouch) down(e);
      });
      btn.addEventListener('mouseup', (e) => {
        if (!this.isTouch) up(e);
      });
    }
  }

  // 매 프레임 호출: 키보드 상태를 이동 값으로 변환
  update() {
    if (!this.isTouch || this.keys.size) {
      const k = this.keys;
      let x = 0;
      let y = 0;
      if (k.has('KeyW') || k.has('ArrowUp')) y += 1;
      if (k.has('KeyS') || k.has('ArrowDown')) y -= 1;
      if (k.has('KeyD') || k.has('ArrowRight')) x += 1;
      if (k.has('KeyA') || k.has('ArrowLeft')) x -= 1;
      if (!this.isTouch || x || y) {
        const d = Math.hypot(x, y) || 1;
        this.moveX = x / d;
        this.moveY = y / d;
      }
      this.sprint = k.has('ShiftLeft') || k.has('ShiftRight');
      if (!this.isTouch) this.jumpHeld = k.has('Space');
    }
    if (this.isTouch) this.sprint = this.sprintToggle || this.keys.has('ShiftLeft');
    if (!this.enabled || this.blocked()) {
      this.moveX = this.isTouch ? this.moveX : 0;
      if (this.blocked()) {
        this.moveX = 0;
        this.moveY = 0;
        this.lookDX = 0;
        this.lookDY = 0;
      }
    }
  }
}

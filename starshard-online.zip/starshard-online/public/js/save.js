// 캐릭터 진행 상황을 브라우저(localStorage)에 저장한다.
const KEY = 'starshard-save-v1';

export function defaultSave() {
  return {
    name: '',
    tunic: Math.floor(Math.random() * 8),
    hair: Math.floor(Math.random() * 6),
    level: 1,
    xp: 0,
    gold: 0,
    hp: 6,
    sword: 0,
    armor: 0,
    bow: 0,
    berries: 2,
    arrows: 15,
    glider: false,
    talkedElder: false,
    stones: [0],
    lastStone: 0,
    chestKey: '',
    chests: [],
    bushes: {},
    world: null,
    kills: 0,
    settings: { quality: '', sound: true, music: true, sens: 1 },
  };
}

export function loadSave() {
  const base = defaultSave();
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return base;
    const d = JSON.parse(raw);
    if (!d || typeof d !== 'object') return base;
    const s = { ...base, ...d };
    s.settings = { ...base.settings, ...(d.settings || {}) };
    if (!Array.isArray(s.stones) || !s.stones.includes(0)) s.stones = [0];
    if (!Array.isArray(s.chests)) s.chests = [];
    if (!s.bushes || typeof s.bushes !== 'object') s.bushes = {};
    for (const k of ['level', 'xp', 'gold', 'hp', 'sword', 'armor', 'bow', 'berries', 'arrows', 'lastStone', 'kills']) {
      s[k] = Number.isFinite(+s[k]) ? Math.max(0, Math.floor(+s[k])) : base[k];
    }
    s.level = Math.max(1, Math.min(30, s.level));
    s.sword = Math.min(3, s.sword);
    s.armor = Math.min(2, s.armor);
    s.bow = Math.min(2, s.bow);
    return s;
  } catch {
    return base;
  }
}

let pending = null;
export function storeSave(save) {
  if (pending) return;
  pending = setTimeout(() => {
    pending = null;
    try {
      localStorage.setItem(KEY, JSON.stringify(save));
    } catch {
      /* 저장 공간을 쓸 수 없으면 무시 */
    }
  }, 400);
}

export function storeSaveNow(save) {
  try {
    localStorage.setItem(KEY, JSON.stringify(save));
  } catch {
    /* 무시 */
  }
}

// 화면 UI: 시작 화면, HUD, 지도, 대화, 상점, 채팅, 설정
import { TUNIC_COLORS, HAIR_COLORS, SWORDS, ARMORS, BOWS, SHOP, xpNeed, SHARD_COUNT, MAX_LEVEL, MON } from '/shared/defs.js';
import { W, BIOME_INFO, BIOME_CENTERS, VOLCANO } from '/shared/world.js';

const $ = (id) => document.getElementById(id);
const hex = (n) => '#' + n.toString(16).padStart(6, '0');
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const HEART = 'M11 19 C4 13 1 9.5 1 6.2 C1 3.2 3.3 1 6.1 1 C8.2 1 10 2.2 11 4 C12 2.2 13.8 1 15.9 1 C18.7 1 21 3.2 21 6.2 C21 9.5 18 13 11 19 Z';
const heartSvg = (kind) =>
  `<svg viewBox="0 0 22 20"><path d="${HEART}" fill="${kind === 2 ? '#ff4d5e' : kind === 1 ? 'url(#half-heart)' : '#2a1826'}" stroke="#fff6df" stroke-width="1.6" stroke-linejoin="round"/></svg>`;

const KID_TIPS = [
  '달리면 초록색 기력 막대가 줄어들어. 다 떨어지면 잠깐 쉬어야 해!',
  '모닥불 옆이나 마을 안에 있으면 하트가 조금씩 차올라.',
  '빨간 열매가 달린 덤불을 지나가면 회복 열매를 딸 수 있어!',
  '가파른 절벽도 기력만 있으면 오를 수 있대. 기력이 떨어지면 주르륵 미끄러져!',
  '귀환석을 깨워 두면 지도에서 눌러서 바로 날아갈 수 있어.',
  '몬스터가 바닥에 빨간 표시를 그리면 얼른 밖으로 피해야 해!',
  '높은 데서 뛰어내린 다음 점프를 한 번 더 누르면 활공 천이 펴져. 진짜 신나!',
  '친구랑 같이 싸우면 경험치랑 골드를 둘 다 받을 수 있어. 뺏기는 게 아니야!',
];
const GUIDE_TIPS = [
  '',
  '이 숲 동쪽 끝 깊은 곳에 오래된 제단이 있어요. 커다란 바위 수호자가 지키고 있으니 단단히 준비하세요.',
  '남쪽 사막에서 가장 높은 붉은 탁상지 꼭대기에 무언가 반짝여요. 더 남쪽 유적에도 수호자가 있다더군요.',
  '늪 깊은 곳과 남쪽 말랑이 둥지에 별조각이 있다는 소문이에요. 물이 깊은 곳에서는 기력이 닳으니 조심하세요.',
  '서리봉 정상에 별조각이 있어요. 기력을 아껴 가며 완만한 길을 찾아 오르세요. 서쪽에는 설인들의 야영지가 있답니다.',
  '이 협곡을 따라가면 분화구예요. 별조각 열두 개가 모두 모이면 그곳에서 그림자 군주가 깨어난대요…',
  '고원 서쪽 늑대 언덕에 별조각이 있어요. 우두머리 늑대가 무리를 이끌고 있으니 친구와 함께 가세요.',
];

export class UI {
  constructor(game) {
    this.game = game;
    this.dirty = true;
    this.cache = {};
    this.mapCanvas = null;
    this.mmCtx = $('minimap').getContext('2d');
    this.mapOpen = false;
    this.dialogQueue = null;
    this.mmT = 0;
    this.panels = ['panel-map', 'panel-bag', 'panel-settings', 'panel-help', 'panel-shop'];

    // 반쪽 하트용 그라데이션
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    defs.setAttribute('width', '0');
    defs.setAttribute('height', '0');
    defs.style.position = 'absolute';
    defs.innerHTML = '<defs><linearGradient id="half-heart"><stop offset="50%" stop-color="#ff4d5e"/><stop offset="50%" stop-color="#2a1826"/></linearGradient></defs>';
    document.body.appendChild(defs);

    this._bindTitle();
    this._bindHud();
    this._bindPanels();
    this._bindChat();
  }

  // ================= 시작 화면 =================
  _bindTitle() {
    const save = this.game.save;
    const name = $('name-input');
    name.value = save.name || '';
    const mk = (wrap, colors, key) => {
      wrap.innerHTML = '';
      colors.forEach((c, i) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.style.background = hex(c);
        b.setAttribute('aria-label', `색 ${i + 1}`);
        if (save[key] === i) b.classList.add('on');
        b.addEventListener('click', () => {
          save[key] = i;
          for (const q of wrap.children) q.classList.remove('on');
          b.classList.add('on');
          this.game.audio.click();
        });
        wrap.appendChild(b);
      });
    };
    mk($('tunic-swatches'), TUNIC_COLORS, 'tunic');
    mk($('hair-swatches'), HAIR_COLORS, 'hair');
    const go = () => {
      if ($('start-btn').disabled) return;
      save.name = name.value.trim().slice(0, 12) || '모험가';
      this.game.startPlay();
    };
    $('start-btn').addEventListener('click', go);
    $('title-invite').addEventListener('click', () => this.invite());
    name.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') go();
    });
  }

  titleStatus(text, ready) {
    $('title-status').textContent = text;
    const b = $('start-btn');
    if (ready !== undefined) {
      b.disabled = !ready;
      b.textContent = ready ? '모험 시작' : '세계를 만드는 중…';
    }
  }

  showGame() {
    $('title').classList.add('hidden');
    $('hud').classList.remove('hidden');
    this.checkRotate();
  }

  checkRotate() {
    const g = this.game;
    const portrait = window.innerHeight > window.innerWidth * 1.15;
    $('rotate-hint').classList.toggle('hidden', !(g.input.isTouch && portrait && g.playing && !this.rotateOk));
  }

  // ================= HUD =================
  _bindHud() {
    for (const b of document.querySelectorAll('#menu-btns button')) {
      b.addEventListener('click', () => {
        this.game.audio.click();
        const k = b.dataset.ui;
        if (k === 'chat') this.openChat();
        else this.open('panel-' + k);
      });
    }
    $('prompt').addEventListener('click', () => this.game.interact());
    $('prompt').addEventListener('touchstart', (e) => {
      e.preventDefault();
      this.game.interact();
    }, { passive: false });
    $('rotate-ok').addEventListener('click', () => {
      this.rotateOk = true;
      $('rotate-hint').classList.add('hidden');
    });
  }

  set(id, key, value, fn) {
    if (this.cache[key] === value) return;
    this.cache[key] = value;
    fn($(id), value);
  }

  update(dt) {
    const g = this.game;
    const p = g.player;
    const s = g.save;
    if (!p) return;

    this.set('hearts', 'hearts', p.hp * 100 + p.maxHp, (el) => {
      let h = '';
      const n = Math.ceil(p.maxHp / 2);
      for (let i = 0; i < n; i++) h += heartSvg(p.hp >= (i + 1) * 2 ? 2 : p.hp === i * 2 + 1 ? 1 : 0);
      el.innerHTML = h;
    });
    const st = Math.round((p.stamina / p.maxStamina) * 100);
    this.set('stamina-fill', 'st', st, (el, v) => (el.style.width = v + '%'));
    this.set('stamina', 'stc', (st < 100 ? 1 : 0) + (p.exhausted ? 4 : st < 30 ? 2 : 0), (el) => {
      el.classList.toggle('show', st < 100);
      el.classList.toggle('low', st < 30 && !p.exhausted);
      el.classList.toggle('out', p.exhausted);
      el.style.width = Math.round(p.maxStamina * 1.5) + 'px';
    });
    this.set('lvl', 'lvl', s.level, (el, v) => (el.textContent = 'Lv.' + v));
    const need = xpNeed(s.level);
    this.set('xp-fill', 'xp', s.level >= MAX_LEVEL ? 100 : Math.round((s.xp / need) * 100), (el, v) => (el.style.width = v + '%'));
    this.set('res-gold', 'gold', s.gold, (el, v) => (el.textContent = v));
    this.set('res-berry', 'berry', s.berries, (el, v) => (el.textContent = v));
    this.set('res-arrow', 'arrow', s.arrows, (el, v) => (el.textContent = v));
    this.set('res-shard', 'shard', g.shards.size, (el, v) => (el.textContent = `${v}/${SHARD_COUNT}`));

    // 목표
    let q;
    if (!s.talkedElder) q = '촌장 한울과 이야기하기<small>마을 한가운데 제단 옆에 있어요</small>';
    else if (g.bossState === 'dead') q = '승리! 섬에 빛이 돌아왔습니다<small>곧 더 강한 새 순환이 시작됩니다</small>';
    else if (g.bossState === 'awake') q = '그림자 군주 쓰러뜨리기<small>화산 협곡을 지나 분화구로</small>';
    else q = `별조각 모으기 (${g.shards.size}/${SHARD_COUNT})<small>지도에서 ★ 위치를 확인하세요</small>`;
    this.set('quest', 'quest', q, (el, v) => (el.innerHTML = v));

    const b = BIOME_INFO[g.world.biomeAt(p.pos.x, p.pos.z)];
    const inVillage = Math.hypot(p.pos.x, p.pos.z) < 44;
    this.set('region', 'region', inVillage ? '새벽 마을' : `${b.name} · Lv.${b.level}`, (el, v) => (el.textContent = v));
    const friends = g.ents.players.size;
    this.set('friends', 'friends', friends, (el, v) => {
      el.classList.toggle('hidden', v === 0);
      el.textContent = `함께하는 친구 ${v}명`;
    });
    this.set('rest', 'rest', p.resting && p.hp < p.maxHp, (el, v) => el.classList.toggle('hidden', !v));
    this.set('vignette', 'low', p.hp > 0 && p.hp <= 2 && p.state !== 'dead', (el, v) => el.classList.toggle('low', v));
    this.set('death', 'dead', p.state === 'dead', (el, v) => el.classList.toggle('hidden', !v));
    this.set('b-heal', 'healbtn', s.berries, (el, v) => (el.firstElementChild.textContent = `열매 ${v}`));

    // 대상 정보
    const t = g.ents.target;
    if (t && !t.info.boss) {
      const frac = Math.max(0, Math.min(1, t.hp / t.maxHp));
      this.set('target', 'tshow', true, (el) => el.classList.remove('hidden'));
      this.set('target-name', 'tname', `${t.info.name} Lv.${t.info.level}`, (el, v) => (el.textContent = v));
      this.set('target-fill', 'tfill', Math.round(frac * 100), (el, v) => (el.style.width = v + '%'));
    } else this.set('target', 'tshow', false, (el) => el.classList.add('hidden'));
    // 보스 체력
    const boss = g.ents.monsters.get(g.pois.bossId);
    if (boss && !boss.dying) {
      this.set('boss', 'bshow', true, (el) => el.classList.remove('hidden'));
      this.set('boss-name', 'bname', MON.lord.name, (el, v) => (el.textContent = v));
      this.set('boss-fill', 'bfill', Math.round((boss.hp5 / 31) * 100), (el, v) => (el.style.width = v + '%'));
    } else this.set('boss', 'bshow', false, (el) => el.classList.add('hidden'));

    // 상호작용 안내
    const it = g.currentInteract;
    const label = it ? it.label() : '';
    this.set('prompt', 'prompt', label, (el, v) => {
      el.classList.toggle('hidden', !v);
      if (v) el.innerHTML = `<kbd>E</kbd>${esc(v)}`;
      el.classList.toggle('locked', v.startsWith('봉인'));
    });

    this.mmT -= dt;
    if (this.mmT <= 0) {
      this.mmT = 0.066;
      this.drawMinimap();
      if (this.mapOpen) this.drawMap();
    }
  }

  hurtFlash() {
    const v = $('vignette');
    v.classList.add('hit');
    clearTimeout(this._hv);
    this._hv = setTimeout(() => v.classList.remove('hit'), 90);
  }

  toast(text, good) {
    const wrap = $('toasts');
    // 같은 문구가 연달아 뜨지 않게
    if (this._lastToast === text && Date.now() - this._lastToastAt < 1800) return;
    this._lastToast = text;
    this._lastToastAt = Date.now();
    const el = document.createElement('div');
    el.className = 'toast' + (good ? ' good' : '');
    el.textContent = text;
    wrap.appendChild(el);
    while (wrap.children.length > 4) wrap.removeChild(wrap.firstChild);
    setTimeout(() => el.remove(), 3300);
  }

  banner(title, sub = '') {
    const el = $('banner');
    $('banner-title').textContent = title;
    $('banner-sub').textContent = sub;
    el.classList.remove('hidden');
    el.style.animation = 'none';
    void el.offsetWidth;
    el.style.animation = '';
    clearTimeout(this._bn);
    this._bn = setTimeout(() => el.classList.add('hidden'), 3700);
  }

  netStatus(text) {
    const el = $('net');
    el.textContent = text || '';
    el.classList.toggle('hidden', !text);
  }

  // ================= 채팅 =================
  _bindChat() {
    const quick = ['안녕!', '이리 와!', '도와줘!', '고마워!', '같이 가자', '잠깐만', '좋았어!', 'ㅋㅋㅋ'];
    const qw = $('chat-quick');
    for (const q of quick) {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = q;
      b.addEventListener('click', () => {
        this.game.net.send({ t: 'chat', text: q });
        this.closeChat();
      });
      qw.appendChild(b);
    }
    $('chat-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const inp = $('chat-input');
      const text = inp.value.trim();
      if (text) this.game.net.send({ t: 'chat', text });
      inp.value = '';
      this.closeChat();
    });
    $('chat-close').addEventListener('click', () => this.closeChat());
  }

  openChat() {
    this.closeAll();
    $('chat-row').classList.remove('hidden');
    this.game.input.unlock();
    setTimeout(() => $('chat-input').focus(), 30);
  }

  closeChat() {
    $('chat-row').classList.add('hidden');
    $('chat-input').blur();
  }

  chatAdd(name, text, cls = '') {
    const log = $('chat-log');
    const el = document.createElement('div');
    el.className = 'chat-line ' + cls;
    el.innerHTML = name ? `<b>${esc(name)}</b>${esc(text)}` : esc(text);
    log.appendChild(el);
    while (log.children.length > 6) log.removeChild(log.firstChild);
    setTimeout(() => el.remove(), 12500);
  }

  // ================= 패널 =================
  _bindPanels() {
    for (const b of document.querySelectorAll('[data-close]')) b.addEventListener('click', () => this.closeAll());
    for (const id of this.panels) {
      $(id).addEventListener('click', (e) => {
        if (e.target === $(id)) this.closeAll();
      });
    }
    const g = this.game;
    for (const b of document.querySelectorAll('#set-quality button')) {
      b.addEventListener('click', () => {
        g.setQuality(b.dataset.q);
        this.refreshSettings();
      });
    }
    $('set-sound').addEventListener('click', () => {
      g.save.settings.sound = !g.save.settings.sound;
      g.audio.setSound(g.save.settings.sound);
      this.refreshSettings();
    });
    $('set-music').addEventListener('click', () => {
      g.save.settings.music = !g.save.settings.music;
      g.audio.setMusic(g.save.settings.music);
      this.refreshSettings();
    });
    $('set-sens').addEventListener('input', (e) => {
      g.save.settings.sens = +e.target.value;
      g.input.sens = g.save.settings.sens;
    });
    $('set-full').addEventListener('click', () => {
      const d = document;
      if (d.fullscreenElement) d.exitFullscreen();
      else if (d.documentElement.requestFullscreen) d.documentElement.requestFullscreen().catch(() => this.toast('이 기기에서는 전체 화면을 쓸 수 없어요.'));
      else this.toast('브라우저 메뉴의 "홈 화면에 추가"를 쓰면 전체 화면으로 즐길 수 있어요.');
    });
    $('set-help').addEventListener('click', () => this.open('panel-help'));
    $('set-invite').addEventListener('click', () => this.invite());
    $('set-reset').addEventListener('click', () => {
      const b = $('set-reset');
      if (b.dataset.sure) g.resetCharacter();
      else {
        b.dataset.sure = '1';
        b.textContent = '정말요? 한 번 더';
        setTimeout(() => {
          delete b.dataset.sure;
          b.textContent = '처음부터';
        }, 3000);
      }
    });
    $('map').addEventListener('click', (e) => this._mapClick(e));
  }

  // 친구 초대: 휴대폰에서는 공유 창(카카오톡 등), PC 에서는 주소 복사
  async invite() {
    const url = location.origin + '/';
    if (navigator.share) {
      try {
        await navigator.share({ title: '별조각 원정대', text: '같이 모험하자! 링크를 누르면 바로 같은 세계에서 만날 수 있어.', url });
        return;
      } catch (err) {
        if (err && err.name === 'AbortError') return;
      }
    }
    try {
      await navigator.clipboard.writeText(url);
      this.toast('주소를 복사했어요. 친구에게 보내 주세요!', true);
    } catch {
      this.toast(url);
    }
  }

  anyOpen() {
    if (!$('chat-row').classList.contains('hidden') || !$('dialog').classList.contains('hidden')) return true;
    for (const id of this.panels) if (!$(id).classList.contains('hidden')) return true;
    return false;
  }

  open(id) {
    this.closeAll();
    this.game.input.unlock();
    $(id).classList.remove('hidden');
    if (id === 'panel-map') {
      this.mapOpen = true;
      this.drawMap();
    } else if (id === 'panel-bag') this.refreshBag();
    else if (id === 'panel-settings') this.refreshSettings();
    else if (id === 'panel-help') this.refreshHelp();
  }

  toggle(id) {
    if ($(id).classList.contains('hidden')) this.open(id);
    else this.closeAll();
  }

  closeAll() {
    for (const id of this.panels) $(id).classList.add('hidden');
    $('dialog').classList.add('hidden');
    this.closeChat();
    this.mapOpen = false;
    this.dialogQueue = null;
  }

  refreshSettings() {
    const g = this.game;
    for (const b of document.querySelectorAll('#set-quality button')) b.classList.toggle('on', b.dataset.q === g.gfx.qualityName);
    const s = g.save.settings;
    $('set-sound').textContent = s.sound ? '켜짐' : '꺼짐';
    $('set-sound').classList.toggle('on', s.sound);
    $('set-music').textContent = s.music ? '켜짐' : '꺼짐';
    $('set-music').classList.toggle('on', s.music);
    $('set-sens').value = s.sens;
  }

  refreshHelp() {
    const touch = this.game.input.isTouch;
    const rows = touch
      ? [['왼쪽 화면 드래그', '이동'], ['오른쪽 화면 드래그', '시점 회전'], ['공격', '검 휘두르기 (연타하면 3연속 공격)'], ['점프', '뛰기 · 공중에서 한 번 더 누르면 활공'], ['활', '가까운 적에게 화살 쏘기'], ['열매', '회복 열매 먹기 (하트 3칸)'], ['달리기', '켜 두면 빠르게 달림 (기력 소모)'], ['화면 가운데 버튼', '대화 · 상자 열기 · 별조각 얻기']]
      : [['W A S D', '이동'], ['마우스', '시점 회전 (화면을 클릭하면 고정, Esc 로 해제)'], ['왼쪽 클릭', '검 휘두르기 (연타하면 3연속 공격)'], ['오른쪽 클릭 / R', '활 쏘기'], ['Space', '점프 · 공중에서 한 번 더 누르면 활공'], ['Shift', '달리기 (기력 소모)'], ['E', '대화 · 상자 열기 · 별조각 얻기'], ['Q', '회복 열매 먹기'], ['M / B', '지도 / 가방'], ['Enter', '채팅'], ['1 2 3', '손 흔들기 · 환호 · 앉기']];
    $('help-body').innerHTML =
      `<div class="help-grid">${rows.map(([k, v]) => `<kbd>${esc(k)}</kbd><span>${esc(v)}</span>`).join('')}</div>` +
      '<div class="sec">알아 두면 좋은 것</div><div style="font-size:13.5px;opacity:.9">가파른 절벽은 기력으로 오를 수 있고, 깊은 물에서는 헤엄칩니다. 기력이 바닥나면 미끄러지거나 물가로 떠밀려 가요. 진행 상황은 이 기기에 자동으로 저장됩니다.</div>';
  }

  refreshBag() {
    const g = this.game;
    const s = g.save;
    const p = g.player;
    let h = '<div class="stat-grid">';
    h += `<div>이름<b>${esc(s.name)}</b></div><div>레벨<b>${s.level}${s.level >= MAX_LEVEL ? ' (최대)' : ''}</b></div>`;
    h += `<div>공격력<b>${p.atk}</b></div><div>방어력<b>${p.def}</b></div>`;
    h += `<div>검<b>${SWORDS[s.sword].name}</b></div><div>갑옷<b>${ARMORS[s.armor].name}</b></div>`;
    h += `<div>활<b>${BOWS[s.bow].name}</b></div><div>활 공격력<b>${p.bowAtk}</b></div>`;
    h += `<div>골드<b>${s.gold}</b></div><div>처치한 몬스터<b>${s.kills}</b></div>`;
    h += `<div>활공 천<b>${s.glider ? '보유' : '없음'}</b></div><div>세계 순환<b>${g.cycle + 1}회차</b></div>`;
    h += '</div>';
    h += '<div class="sec">감정 표현</div><div class="row-btns"><button data-em="emote1">손 흔들기</button><button data-em="emote2">환호</button><button data-em="emote3">앉기</button></div>';
    h += `<div class="sec">함께하는 모험가 (${g.ents.players.size + 1}명)</div><div class="plist"><div><span>${esc(s.name)} (나)</span><b>Lv.${s.level}</b></div>`;
    for (const e of g.ents.players.values()) h += `<div><span>${esc(e.prof.name)}</span><b>Lv.${e.prof.lvl}</b></div>`;
    h += '</div>';
    $('bag-body').innerHTML = h;
    for (const b of document.querySelectorAll('#bag-body [data-em]')) {
      b.addEventListener('click', () => {
        this.closeAll();
        g.input.pressed.add(b.dataset.em);
      });
    }
  }

  // ================= 대화 / 상점 =================
  // lines: 문자열 배열, 마지막 줄에서 buttons [{text, primary, fn}] 표시
  dialog(name, lines, buttons, onDone) {
    this.closeAll();
    this.game.input.unlock();
    this.dialogQueue = { name, lines: lines.slice(), buttons, onDone };
    $('dialog').classList.remove('hidden');
    this._dialogNext();
  }

  _dialogNext() {
    const q = this.dialogQueue;
    if (!q) return;
    const line = q.lines.shift();
    $('dialog-name').textContent = q.name;
    $('dialog-text').textContent = line;
    const wrap = $('dialog-btns');
    wrap.innerHTML = '';
    const add = (text, primary, fn) => {
      const b = document.createElement('button');
      b.textContent = text;
      if (primary) b.className = 'primary';
      b.addEventListener('click', () => {
        this.game.audio.click();
        fn();
      });
      wrap.appendChild(b);
    };
    if (q.lines.length) add('다음', true, () => this._dialogNext());
    else {
      for (const bt of q.buttons || []) add(bt.text, bt.primary, bt.fn);
      add(q.buttons && q.buttons.length ? '닫기' : '확인', !(q.buttons && q.buttons.length), () => {
        const done = q.onDone;
        this.closeAll();
        if (done) done();
      });
    }
  }

  // Enter/E/Space 로 대화 넘기기
  dialogKey() {
    if ($('dialog').classList.contains('hidden')) return false;
    const b = $('dialog-btns').querySelector('button.primary') || $('dialog-btns').querySelector('button');
    if (b) b.click();
    return true;
  }

  talk(npc) {
    const g = this.game;
    const s = g.save;
    const n = npc.def;
    npc.talkT = 1.6;
    if (n.kind === 'elder') {
      if (!s.talkedElder) {
        this.dialog(n.name, [
          '어서 오게, 젊은 모험가여. 나는 이 새벽 마을의 촌장 한울이라네.',
          '오래전 하늘의 별이 부서져 열두 개의 별조각이 섬 곳곳에 흩어졌지. 그 뒤로 화산 깊은 곳의 「그림자 군주」가 섬을 어둠으로 물들이고 있다네.',
          '별조각 열두 개를 모두 모아 이 제단을 밝히면 군주에게 맞설 길이 열릴 걸세. 별조각이 있을 만한 곳을 자네 지도에 표시해 두었네.',
          '이 활공 천을 가져가게. 높은 곳에서 뛰어내린 뒤 점프를 한 번 더 누르면 하늘을 날 수 있지. 친구들과 힘을 모으게나!',
        ], null, () => g.onElderIntro());
      } else {
        const left = SHARD_COUNT - g.shards.size;
        let lines;
        if (g.bossState === 'dead') lines = ['자네들 덕분에 섬에 빛이 돌아왔네! 하지만 어둠은 언젠가 더 강해져서 돌아오는 법… 그때도 부탁하네.'];
        else if (g.bossState === 'awake') lines = ['별조각이 모두 모였네! 제단이 이렇게 밝게 빛나다니…', '북동쪽 잿불 화산의 협곡을 지나 분화구로 가게. 그림자 군주가 깨어났다네. 혼자는 벅찰 테니 친구들과 함께 가게나.'];
        else lines = [`지금까지 별조각 ${g.shards.size}개를 밝혔군. 아직 ${left}개가 남았네.`, '초원부터 차근차근 돌아보게. 먼 곳일수록 몬스터가 강하니 대장간에서 장비를 갖추는 것도 잊지 말게.'];
        this.dialog(n.name, lines);
      }
    } else if (n.kind === 'merchant') {
      this.dialog(n.name, ['어서 오세요! 모험에 필요한 건 다 있답니다.'], [{ text: '물건 보기', primary: true, fn: () => this.openShop('merchant') }]);
    } else if (n.kind === 'smith') {
      this.dialog(n.name, ['쓸 만한 무기가 필요한가? 좋은 쇠는 거짓말을 안 하지.'], [{ text: '장비 보기', primary: true, fn: () => this.openShop('smith') }]);
    } else if (n.kind === 'kid') {
      this._kidTip = ((this._kidTip ?? -1) + 1) % KID_TIPS.length;
      this.dialog(n.name, [KID_TIPS[this._kidTip]]);
    } else {
      this.dialog(n.name, [GUIDE_TIPS[n.stone] || '조심해서 다니세요!']);
    }
  }

  openShop(kind) {
    this.closeAll();
    this.game.input.unlock();
    this.shopKind = kind;
    $('panel-shop').classList.remove('hidden');
    $('shop-title').textContent = kind === 'merchant' ? '상인 보리의 가게' : '무쇠의 대장간';
    this.refreshShop();
  }

  refreshShop() {
    const g = this.game;
    const s = g.save;
    $('shop-gold').textContent = `${s.gold} 골드`;
    const items = [];
    if (this.shopKind === 'merchant') {
      items.push({ name: SHOP.berry.name, desc: `${SHOP.berry.desc} · 보유 ${s.berries}개`, price: SHOP.berry.price, buy: () => s.berries++ });
      items.push({ name: SHOP.arrows.name, desc: `${SHOP.arrows.desc} · 보유 ${s.arrows}개`, price: SHOP.arrows.price, buy: () => (s.arrows += 10) });
      if (s.bow < BOWS.length - 1) {
        const b = BOWS[s.bow + 1];
        items.push({ name: b.name, desc: `활 공격력 ${BOWS[s.bow].dmg} → ${b.dmg}`, price: b.price, buy: () => s.bow++, equip: true });
      } else items.push({ name: BOWS[s.bow].name, desc: '가장 좋은 활을 갖고 있어요', price: 0, done: true });
    } else {
      if (s.sword < SWORDS.length - 1) {
        const w = SWORDS[s.sword + 1];
        items.push({ name: w.name, desc: `검 공격력 ${SWORDS[s.sword].dmg} → ${w.dmg}`, price: w.price, buy: () => s.sword++, equip: true });
      } else items.push({ name: SWORDS[s.sword].name, desc: '가장 좋은 검을 갖고 있어요', price: 0, done: true });
      if (s.armor < ARMORS.length - 1) {
        const a = ARMORS[s.armor + 1];
        items.push({ name: a.name, desc: `받는 피해 -${a.def} (하트 반 칸 단위)`, price: a.price, buy: () => s.armor++, equip: true });
      } else items.push({ name: ARMORS[s.armor].name, desc: '가장 좋은 갑옷을 입고 있어요', price: 0, done: true });
    }
    const body = $('shop-body');
    body.innerHTML = '';
    for (const it of items) {
      const row = document.createElement('div');
      row.className = 'shop-item';
      row.innerHTML = `<div class="info"><b>${esc(it.name)}</b><small>${esc(it.desc)}</small></div>`;
      const b = document.createElement('button');
      if (it.done) {
        b.textContent = '완료';
        b.disabled = true;
      } else {
        b.textContent = `${it.price} 골드`;
        b.disabled = s.gold < it.price;
        b.addEventListener('click', () => {
          if (s.gold < it.price) return;
          s.gold -= it.price;
          it.buy();
          g.audio.coin();
          if (it.equip) g.onEquipChanged();
          g.saveSoon();
          this.refreshShop();
        });
      }
      row.appendChild(b);
      body.appendChild(row);
    }
  }

  // ================= 지도 =================
  buildMapCanvas(pixels) {
    const c = document.createElement('canvas');
    c.width = W.VERTS;
    c.height = W.VERTS;
    c.getContext('2d').putImageData(new ImageData(pixels, W.VERTS, W.VERTS), 0, 0);
    this.mapCanvas = c;
  }

  drawMinimap() {
    const g = this.game;
    const ctx = this.mmCtx;
    const S = 280;
    const p = g.player;
    const RANGE = 120; // 지도에 보이는 반경 (월드 단위)
    const scale = S / (RANGE * 2);
    ctx.fillStyle = '#123154';
    ctx.fillRect(0, 0, S, S);
    if (this.mapCanvas) {
      const src = (RANGE * 2) / W.CELL;
      const sx = (p.pos.x + W.HALF) / W.CELL - src / 2;
      const sy = (p.pos.z + W.HALF) / W.CELL - src / 2;
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(this.mapCanvas, sx, sy, src, src, 0, 0, S, S);
    }
    const toX = (x) => (x - p.pos.x) * scale + S / 2;
    const toY = (z) => (z - p.pos.z) * scale + S / 2;
    const inside = (x, z) => Math.hypot(x - p.pos.x, z - p.pos.z) < RANGE - 6;

    // 목표 방향 화살표
    const goal = g.questGoal();
    if (goal && !inside(goal.x, goal.z)) {
      const a = Math.atan2(goal.z - p.pos.z, goal.x - p.pos.x);
      ctx.save();
      ctx.translate(S / 2 + Math.cos(a) * (S / 2 - 16), S / 2 + Math.sin(a) * (S / 2 - 16));
      ctx.rotate(a);
      ctx.fillStyle = '#ffd35a';
      ctx.strokeStyle = '#3a2a08';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(12, 0);
      ctx.lineTo(-8, -9);
      ctx.lineTo(-8, 9);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
    for (const st of g.objects.stones) {
      if (!inside(st.x, st.z)) continue;
      this._diamond(ctx, toX(st.x), toY(st.z), 8, st.active ? '#5fe0ff' : '#8a94a8');
    }
    if (g.save.talkedElder) {
      for (const sh of g.objects.shards) {
        if (sh.collected || !inside(sh.x, sh.z)) continue;
        this._star(ctx, toX(sh.x), toY(sh.z), 11, sh.sealed ? '#d08aff' : '#ffd35a');
      }
    }
    for (const n of g.objects.npcs) {
      if (!inside(n.x, n.z)) continue;
      ctx.fillStyle = '#ffe9a8';
      ctx.beginPath();
      ctx.arc(toX(n.x), toY(n.z), 4, 0, 6.3);
      ctx.fill();
    }
    ctx.fillStyle = '#ff5a5f';
    for (const e of g.ents.monsters.values()) {
      if (e.dying || !e.shown || !inside(e.x, e.z)) continue;
      ctx.beginPath();
      ctx.arc(toX(e.x), toY(e.z), e.info.elite || e.info.type === 'golem' || e.info.boss ? 6 : 3.5, 0, 6.3);
      ctx.fill();
    }
    for (const e of g.ents.players.values()) {
      if (!e.seen) continue;
      let x = toX(e.x);
      let y = toY(e.z);
      const d = Math.hypot(x - S / 2, y - S / 2);
      const lim = S / 2 - 10;
      if (d > lim) {
        x = S / 2 + ((x - S / 2) / d) * lim;
        y = S / 2 + ((y - S / 2) / d) * lim;
      }
      ctx.fillStyle = '#7fe08a';
      ctx.strokeStyle = '#0c2a12';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, y, 6, 0, 6.3);
      ctx.fill();
      ctx.stroke();
    }
    // 나
    ctx.save();
    ctx.translate(S / 2, S / 2);
    ctx.rotate(-p.yaw);
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#1f5fd0';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, 13);
    ctx.lineTo(-9, -9);
    ctx.lineTo(0, -4);
    ctx.lineTo(9, -9);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
    ctx.restore();
    // 북쪽 표시
    ctx.fillStyle = '#fff6df';
    ctx.font = '700 22px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('N', S / 2, 26);
  }

  _diamond(ctx, x, y, r, color) {
    ctx.fillStyle = color;
    ctx.strokeStyle = '#0b1222';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, y - r);
    ctx.lineTo(x + r, y);
    ctx.lineTo(x, y + r);
    ctx.lineTo(x - r, y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  _star(ctx, x, y, r, color) {
    ctx.fillStyle = color;
    ctx.strokeStyle = '#3a2a08';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + (i * Math.PI) / 5;
      const rr = i % 2 ? r * 0.45 : r;
      ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  drawMap() {
    const g = this.game;
    const cv = $('map');
    const ctx = cv.getContext('2d');
    const S = cv.width;
    const k = S / W.SIZE;
    const X = (x) => (x + W.HALF) * k;
    const Y = (z) => (z + W.HALF) * k;
    // 작은 화면에서도 글자와 표시가 읽히도록 크기를 키운다
    const disp = cv.getBoundingClientRect().width || 640;
    const f = Math.max(1, Math.min(2.4, 640 / disp));
    const small = disp < 430;
    ctx.imageSmoothingEnabled = true;
    if (this.mapCanvas) ctx.drawImage(this.mapCanvas, 0, 0, S, S);
    ctx.textAlign = 'center';
    ctx.lineJoin = 'round';
    const text = (str, x, y, size, color) => {
      ctx.font = `800 ${Math.round(size * f)}px "Pretendard", "Apple SD Gothic Neo", "Noto Sans KR", "Malgun Gothic", sans-serif`;
      ctx.lineWidth = 5 * f;
      ctx.strokeStyle = 'rgba(10,16,30,0.85)';
      ctx.strokeText(str, x, y);
      ctx.fillStyle = color;
      ctx.fillText(str, x, y);
    };
    BIOME_CENTERS.forEach(([x, z], i) => {
      if (i === 0) return;
      ctx.globalAlpha = 0.62;
      text(BIOME_INFO[i].name, X(x * 0.9), Y(z * 0.9) - 30 * f, 22, '#fff6df');
      ctx.globalAlpha = 1;
    });
    if (g.bossState === 'awake') {
      ctx.fillStyle = 'rgba(255,90,208,0.9)';
      ctx.beginPath();
      ctx.arc(X(VOLCANO.x), Y(VOLCANO.z), (13 + Math.sin(g.time * 5) * 3) * f, 0, 6.3);
      ctx.fill();
      text('그림자 군주', X(VOLCANO.x), Y(VOLCANO.z) - 20 * f, 17, '#ffb8f0');
    }
    for (const st of g.objects.stones) {
      this._diamond(ctx, X(st.x), Y(st.z), 11 * f, st.active ? '#5fe0ff' : '#7a8498');
      if (st.active && !small) text(st.def.name, X(st.x), Y(st.z) - 17 * f, 14, '#c8f6ff');
    }
    if (g.save.talkedElder) {
      for (const sh of g.objects.shards) {
        if (sh.collected) {
          ctx.globalAlpha = 0.5;
          this._star(ctx, X(sh.x), Y(sh.z), 9 * f, '#b8b8b8');
          ctx.globalAlpha = 1;
        } else {
          this._star(ctx, X(sh.x), Y(sh.z), 14 * f, sh.sealed ? '#d08aff' : '#ffd35a');
          if (!small) text(sh.def.name, X(sh.x), Y(sh.z) + 30 * f, 13, '#fff3c0');
        }
      }
    }
    for (const e of g.ents.players.values()) {
      if (!e.seen) continue;
      ctx.fillStyle = '#7fe08a';
      ctx.strokeStyle = '#0c2a12';
      ctx.lineWidth = 3 * f;
      ctx.beginPath();
      ctx.arc(X(e.x), Y(e.z), 8 * f, 0, 6.3);
      ctx.fill();
      ctx.stroke();
      text(e.prof.name, X(e.x), Y(e.z) - 14 * f, 14, '#c8ffd0');
    }
    const p = g.player;
    ctx.save();
    ctx.translate(X(p.pos.x), Y(p.pos.z));
    ctx.rotate(-p.yaw);
    ctx.scale(f, f);
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#1f5fd0';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(0, 16);
    ctx.lineTo(-11, -11);
    ctx.lineTo(0, -5);
    ctx.lineTo(11, -11);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
    ctx.restore();
  }

  _mapClick(e) {
    const g = this.game;
    const cv = $('map');
    const r = cv.getBoundingClientRect();
    const wx = ((e.clientX - r.left) / r.width) * W.SIZE - W.HALF;
    const wz = ((e.clientY - r.top) / r.height) * W.SIZE - W.HALF;
    let best = null;
    let bd = 46;
    for (const st of g.objects.stones) {
      const d = Math.hypot(st.x - wx, st.z - wz);
      if (d < bd) {
        bd = d;
        best = st;
      }
    }
    if (!best) return;
    if (!best.active) {
      this.toast('아직 깨우지 않은 귀환석입니다. 직접 찾아가서 깨워야 해요.');
      return;
    }
    this.closeAll();
    g.fastTravel(best);
  }
}

// 별의 시련장과 숨겨진 던전: 바깥의 입구, 실내 모습, 관문, 퍼즐, 함정, 보상
import * as THREE from '/vendor/three/three.module.js';
import { ZONES, TRIAL_COUNT, DUNGEON_COUNT, TABLET_SEALS, TILE, WALL_H, ZONE_FLOOR, TORCH_R, zoneAt, tileSolid, flameState } from '/shared/zones.js';
import { MON, MSTATE, POTION_KEYS, UNIQUES, rollItem, makeUnique } from '/shared/defs.js';
import { VILLAGE } from '/shared/world.js';
import { Geo, M, lin } from './geo.js';

const F = ZONE_FLOOR;
const TAU = Math.PI * 2;

// 지역(theme)마다 다른 돌 빛깔과 불빛. wall: [아래, 위], floor: [두 가지 타일], fog: 어둠의 빛깔, sky/ground: 은은한 주변광, key: 위에서 내리는 빛
const THEME = [
  { wall: [0x6b6252, 0x9a8f78], floor: [0x7d745f, 0x8b826b], trim: 0xb8ad90, fog: 0x15140f, sky: 0xb9b49a, ground: 0x4a4636, key: 0xffe2b0, glow: 0xffd65a, fire: 0xffa24a }, // 0 초원: 따뜻한 사암
  { wall: [0x46523c, 0x6d7d58], floor: [0x566247, 0x616e50], trim: 0x8fa070, fog: 0x0f150e, sky: 0x9fb894, ground: 0x34402c, key: 0xd8ffc0, glow: 0x9dff7a, fire: 0xc8ff6a }, // 1 숲: 이끼 낀 돌
  { wall: [0x6f8298, 0xb4c6d8], floor: [0x8696aa, 0x93a4b8], trim: 0xdfeaf5, fog: 0x101823, sky: 0xbfd6f0, ground: 0x4a5a70, key: 0xdff0ff, glow: 0x8fdcff, fire: 0x8fdcff }, // 2 설산: 얼음 돌
  { wall: [0x9a7a48, 0xd0ab6a], floor: [0xb08f58, 0xbd9c62], trim: 0xe8cf94, fog: 0x1c150a, sky: 0xe0c890, ground: 0x6a5230, key: 0xffe0a0, glow: 0xffb84a, fire: 0xffb84a }, // 3 사막: 누런 사암
  { wall: [0x3d5450, 0x5f7f78], floor: [0x4a625c, 0x546e66], trim: 0x86a89c, fog: 0x0b1614, sky: 0x8fc0b0, ground: 0x2c403a, key: 0xc8ffe8, glow: 0x6affc8, fire: 0x7affc0 }, // 4 늪: 물때 낀 돌
  { wall: [0x3a2a2a, 0x5e4444], floor: [0x4a3636, 0x543e3e], trim: 0x8a5a4a, fog: 0x180b08, sky: 0xc09080, ground: 0x3a201a, key: 0xffb080, glow: 0xff6a2a, fire: 0xff7a2a }, // 5 화산: 그을린 현무암
  { wall: [0x6e4a36, 0xa3704e], floor: [0x80583f, 0x8c6246], trim: 0xc99468, fog: 0x1a100a, sky: 0xd8a888, ground: 0x4a3020, key: 0xffd0a0, glow: 0xff9a3a, fire: 0xff9a3a }, // 6 고원: 붉은 벽돌
  { wall: [0x8a6878, 0xc9a2b4], floor: [0xa07a8c, 0xad8698], trim: 0xf0c8d8, fog: 0x1c1118, sky: 0xf0c0d8, ground: 0x5a3a4a, key: 0xffe0f0, glow: 0xff8ac8, fire: 0xff9ad0 }, // 7 벚꽃: 분홍빛 대리석
  { wall: [0x4c4070, 0x7868a8], floor: [0x5a4c82, 0x65568e], trim: 0xa894e0, fog: 0x100c1e, sky: 0xa898e0, ground: 0x30284a, key: 0xd8c8ff, glow: 0x7fffe0, fire: 0x7fffe0 }, // 8 버섯: 보랏빛 돌
  { wall: [0x4a7088, 0x86b8d0], floor: [0x5a8298, 0x668ea4], trim: 0xc0ecff, fog: 0x0c1a24, sky: 0xa0d8f0, ground: 0x2c485a, key: 0xd0f4ff, glow: 0xb9a8ff, fire: 0xb9c8ff }, // 9 수정: 푸른 수정
  { wall: [0x453c5e, 0x6f6296], floor: [0x574c74, 0x625680], trim: 0x9a7ad8, fog: 0x120e1e, sky: 0xc0b0f0, ground: 0x4a4068, key: 0xe0d0ff, glow: 0xb06aff, fire: 0xc08aff }, // 10 그림자: 보랏빛 흑요석
  { wall: [0x8a4a30, 0xc8845a], floor: [0x9a5a3c, 0xa86646], trim: 0xf0c070, fog: 0x1c0f08, sky: 0xe8b890, ground: 0x5a3020, key: 0xffd8a8, glow: 0xffc45a, fire: 0xffb04a }, // 11 바람 협곡: 붉은 사암
  { wall: [0x5f94b8, 0xc4e6f8], floor: [0x78a8c8, 0x86b6d4], trim: 0xeaf8ff, fog: 0x0c1822, sky: 0xc8ecff, ground: 0x3c6078, key: 0xe8f8ff, glow: 0x9ae8ff, fire: 0x9ae8ff }, // 12 얼음 호수: 맑은 얼음
  { wall: [0x7a7458, 0xb0a880], floor: [0x8a8464, 0x96906e], trim: 0xb8d86a, fog: 0x14140c, sky: 0xd0d8a0, ground: 0x4a4a30, key: 0xf0f4c0, glow: 0xb8ff7a, fire: 0xc8f06a }, // 13 거인의 계단: 이끼 낀 층층돌
  { wall: [0xb86a62, 0xf0b0a4], floor: [0xc8807a, 0xd48c84], trim: 0x7ff0e0, fog: 0x1c0e10, sky: 0xffd0c8, ground: 0x6a3a3c, key: 0xffe8e0, glow: 0x7ffff0, fire: 0x5fe8d8 }, // 14 산호 군도: 산홋빛 돌
  { wall: [0x566a5a, 0x92a894], floor: [0x667a6a, 0x728674], trim: 0xd8ffb0, fog: 0x0e1410, sky: 0xc0d8c0, ground: 0x34443a, key: 0xe8ffe0, glow: 0xd8ffb0, fire: 0xb8f0a0 }, // 15 하늘 기둥: 구름 낀 청록 돌
  { wall: [0x23264a, 0x444a88], floor: [0x2e3260, 0x383c6e], trim: 0x7a9aff, fog: 0x080914, sky: 0x9aa8ff, ground: 0x1c1e40, key: 0xc8d4ff, glow: 0x9ab8ff, fire: 0x7a9aff }, // 16 별똥 분지: 밤하늘빛 운석
  { wall: [0x1a1c3a, 0x3a3f7c], floor: [0x25284e, 0x2d315c], trim: 0xffe27a, fog: 0x06070f, sky: 0xb0b8ff, ground: 0x23264a, key: 0xfff2c8, glow: 0xffe27a, fire: 0xffd35a }, // 17 잠든 별의 심장 (레이드): 금빛 테를 두른 밤하늘
];
// 시련장 문의 빛깔: 아직 깨지 못한 곳(보라) / 인장을 받은 곳(민트) / 던전(진홍) / 레이드(금빛)
const C_OPEN = 0xc98aff;
const C_DONE = 0x7dffd0;
const C_DUNGEON = 0xff4a5a;
const C_RAID = 0xffd35a;
// 순서 퍼즐 발판의 빛깔
const PLATE_COL = [0x5ab8ff, 0xffd35a, 0xff7ab0, 0x7dff8a, 0xff9a3a, 0xb98aff, 0xf2f2f2, 0x3fe0d0, 0xff5a4a];

function hash2(a, b) {
  let h = Math.imul(a | 0, 374761393) ^ Math.imul(b | 0, 668265263);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}
// 색을 밝거나 어둡게 (지오메트리 색으로 바로 쓸 수 있는 배열)
function shade(hexColor, k) {
  const c = lin(hexColor);
  return [c[0] * k, c[1] * k, c[2] * k];
}
const css = (hexColor) => '#' + hexColor.toString(16).padStart(6, '0');

// 다섯 갈래 별 (시련장 문 위와 제단 위에 뜬다)
function starGeo(c1, c2, s = 1) {
  const g = new Geo();
  g.ico(0.34 * s, 0, null, c2);
  for (let k = 0; k < 5; k++) {
    const a = (k / 5) * TAU;
    g.cone(0.24 * s, 0.75 * s, 4, M(-Math.sin(a) * 0.55 * s, Math.cos(a) * 0.55 * s, 0, 0, 0, a), c1, c2);
  }
  return g.build(false);
}

export class ZoneManager {
  constructor(game) {
    this.game = game;
    const { gfx, world, pois, objects, save } = game;
    this.cur = null; // 지금 들어가 있는 구역
    this.busy = false; // 드나드는 중 (화면이 어두워져 있다)
    this.group = new THREE.Group(); // 바깥의 입구와 돌등
    objects.group.add(this.group);
    this.flameCue = 0;
    this.moteT = 0;

    const add = (hexColor, opacity) => new THREE.MeshBasicMaterial({ color: hexColor, transparent: true, opacity, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
    this.matPortal = { open: add(C_OPEN, 0.5), done: add(C_DONE, 0.42), dungeon: add(C_DUNGEON, 0.5), raid: add(C_RAID, 0.5) };
    this.matRaidBeam = add(C_RAID, 0.2);
    this.matChain = add(0xffe27a, 0.45);
    this.chainGeo = new THREE.CylinderGeometry(0.055, 0.055, 1, 5, 1, true);
    this.chainGeo.rotateX(Math.PI / 2);
    this.chainGeo.translate(0, 0, 0.5);
    this.chains = [];
    this.raid = null; // 레이드 싸움의 진행 (별 삼키기, 남은 시간)
    this.matBeam = add(C_OPEN, 0.16);
    this.matSigil = add(0x9fe8ff, 0.4);
    this.portalGeo = new THREE.PlaneGeometry(2.5, 4.4);
    this.beamGeo = new THREE.CylinderGeometry(0.55, 0.25, 70, 6, 1, true);
    this.beamGeo.translate(0, 35, 0);
    this.sigilGeo = new THREE.RingGeometry(0.8, 1.15, 28);
    this.sigilGeo.rotateX(-Math.PI / 2);
    this.starOpen = starGeo(0xb06aff, 0xf0c8ff);
    this.starDone = starGeo(0x3fd0a0, 0xd8fff0);
    this.starSeal = starGeo(0xffb02a, 0xfff2a8, 1.15);
    const dg = new Geo();
    dg.cone(0.2, 0.34, 4, M(0, 0.17, 0), 0xc8f6ff);
    dg.cone(0.2, 0.34, 4, M(0, -0.17, 0, Math.PI, 0, 0), 0x5fe0ff);
    this.diamondGeo = dg.build(false);
    // 불기둥(함정)과 화로의 불꽃
    const jg = new Geo();
    jg.cone(0.62, 2.9, 6, M(0, 1.45, 0), 0xff4a12, 0xffd35a);
    jg.cone(0.38, 2.1, 5, M(0.12, 1.05, 0.08, 0, 1, 0), 0xffa028, 0xfff3b0);
    this.jetGeo = jg.build(false);
    this.fireGeo = new Map();

    this.list = ZONES.map((def) => {
      const ent = pois.zones[def.id - 1];
      const zs = {
        def, id: def.id, trial: def.kind === 'trial', raid: def.kind === 'raid', theme: THEME[def.look] || THEME[0],
        x: ent.x, z: ent.z, y: world.heightAt(ent.x, ent.z),
        // 레이드의 문은 처음부터 드러나 있다
        lamps: [], found: def.kind === 'raid' || save.zfound.includes(def.id), cleared: save.trials.includes(def.id),
        open: 0, epoch: 0, grp: null, gates: [], flames: [], plates: [], solids: [], fires: [],
        puzzle: null, rise: -1, bossIntro: false, mapCv: null, mapOpen: -1,
      };
      ent.lamps.forEach((l, k) => zs.lamps.push({ zs, k, x: l.x, z: l.z, y: world.heightAt(l.x, l.z), lit: !!(((save.lamps[def.id] || 0) >> k) & 1), core: null }));
      return zs;
    });
    this._buildEntrances();
    this._buildTablet();
    this._interactables();
  }

  // ================= 바깥: 입구와 돌등 =================
  _buildEntrances() {
    const { gfx, objects } = this.game;
    const st = new Geo();
    for (const zs of this.list) {
      const { x, y, z } = zs;
      if (zs.trial) {
        // 별의 문: 둥근 단 위에 안쪽으로 기운 두 돌기둥, 그 위에 별이 뜬다
        st.cyl(3.4, 3.8, 0.4, 10, M(x, y + 0.12, z), 0x7c7a8c, 0xa9a6bc);
        st.cyl(2.5, 2.5, 0.1, 10, M(x, y + 0.36, z), 0x5a5870);
        for (const sx of [-1, 1]) {
          st.taperBox(1.05, 5.6, 1.05, 0.5, M(x + sx * 2.15, y + 3.0, z, 0, 0, sx * 0.15), 0x46445c, 0x7c79a0);
          st.box(1.3, 0.4, 1.3, M(x + sx * 2.45, y + 0.5, z), 0x5a5870, 0x86839e);
          objects.colliders.push({ x: x + sx * 2.3, z, r: 0.75 });
        }
        st.box(3.9, 0.5, 1.0, M(x, y + 5.75, z), 0x5a5870, 0x8c89a8);
        st.cone(0.5, 0.6, 4, M(x, y + 6.3, z, 0, Math.PI / 4, 0), 0x6c6a84, 0xa9a6bc);
        const mk = (geo) => {
          const m = new THREE.Mesh(geo, gfx.matGlow);
          m.position.set(x, y + 7.6, z);
          this.group.add(m);
          return m;
        };
        zs.starA = mk(this.starOpen);
        zs.starB = mk(this.starDone);
        zs.portal = new THREE.Mesh(this.portalGeo, this.matPortal.open);
        zs.portal.position.set(x, y + 2.75, z);
        zs.portal.renderOrder = 6;
        this.group.add(zs.portal);
        zs.beam = new THREE.Mesh(this.beamGeo, this.matBeam);
        zs.beam.position.set(x, y + 8, z);
        zs.beam.renderOrder = 6;
        this.group.add(zs.beam);
        zs.light = { x, y: y + 3, z: z + 1.5, color: C_OPEN, power: 18, zoneGate: zs };
        objects.lightSrc.push(zs.light);
      } else if (zs.raid) {
        // 레이드의 문: 둥근 단 위에 선 커다란 금빛 테의 문. 둘레에 선돌 여섯이 서 있고, 하늘로 금빛 기둥이 선다
        const T = zs.theme;
        st.cyl(6.2, 6.8, 0.5, 14, M(x, y + 0.12, z), 0x34386a, 0x5a60a8);
        st.cyl(4.6, 4.6, 0.12, 14, M(x, y + 0.42, z), 0x23264a);
        for (let k = 0; k < 6; k++) {
          const a = (k / 6) * TAU + Math.PI / 6;
          const sx = x + Math.sin(a) * 5.6;
          const sz = z + Math.cos(a) * 5.6 - 0.6;
          if (Math.abs(Math.sin(a)) < 0.3 && Math.cos(a) > 0) continue; // 들어가는 쪽은 비워 둔다
          st.taperBox(0.9, 3.6 + (k % 2) * 0.8, 0.9, 0.55, M(sx, y + 2.1 + (k % 2) * 0.4, sz, 0, a, 0), T.wall[0], T.wall[1]);
          objects.colliders.push({ x: sx, z: sz, r: 0.7 });
        }
        for (const sx of [-1, 1]) {
          st.taperBox(1.5, 7.4, 1.6, 0.6, M(x + sx * 3.0, y + 4.0, z, 0, 0, sx * 0.1), T.wall[0], T.wall[1]);
          st.box(1.9, 0.5, 2.0, M(x + sx * 3.2, y + 0.6, z), 0x3a3f7c, T.trim);
          objects.colliders.push({ x: x + sx * 3.1, z, r: 1.0 });
        }
        st.box(7.6, 0.8, 1.6, M(x, y + 7.7, z), T.wall[1], T.trim);
        st.box(3.4, 5.6, 0.3, M(x, y + 3.2, z - 0.5), 0x06070f);
        const gg = new Geo();
        gg.box(7.8, 0.14, 1.7, M(x, y + 8.2, z), 0xffe27a);
        for (const sx of [-1, 1]) gg.box(0.14, 6.8, 0.2, M(x + sx * 2.05, y + 3.8, z + 0.75), 0xffe27a);
        const gm = new THREE.Mesh(gg.build(false), gfx.matGlow);
        gm.frustumCulled = false;
        this.group.add(gm);
        const mk = (geo) => {
          const m = new THREE.Mesh(geo, gfx.matGlow);
          m.position.set(x, y + 10.2, z);
          m.scale.setScalar(1.7);
          this.group.add(m);
          return m;
        };
        zs.starA = mk(this.starSeal);
        zs.portal = new THREE.Mesh(this.portalGeo, this.matPortal.raid);
        zs.portal.position.set(x, y + 3.3, z - 0.3);
        zs.portal.scale.set(1.36, 1.3, 1);
        zs.portal.renderOrder = 6;
        this.group.add(zs.portal);
        zs.beam = new THREE.Mesh(this.beamGeo, this.matRaidBeam);
        zs.beam.position.set(x, y + 10, z);
        zs.beam.scale.set(1.6, 1.3, 1.6);
        zs.beam.renderOrder = 6;
        this.group.add(zs.beam);
        objects.lightSrc.push({ x, y: y + 4, z: z + 2, color: C_RAID, power: 34, fire: true, zoneGate: zs });
      } else {
        // 숨겨진 던전: 평소에는 이끼 낀 돌 몇 개가 둥글게 놓여 있을 뿐이다
        st.cyl(2.7, 2.9, 0.14, 9, M(x, y + 0.03, z), 0x5c6258, 0x777d70);
        for (let k = 0; k < 7; k++) {
          const a = (k / 7) * TAU + zs.id;
          st.ico(0.42 + (k % 3) * 0.12, 0, M(x + Math.cos(a) * 3.2, y + 0.16, z + Math.sin(a) * 3.2, 0, k, 0, 1, 0.7, 1), 0x5c6654, 0x8a917c, 0.35, k + zs.id);
        }
        // 돌등을 모두 밝히면 땅에서 솟아오르는 문
        const g = new Geo();
        const T = zs.theme;
        for (const sx of [-1, 1]) {
          g.box(1.3, 4.0, 1.6, M(sx * 2.0, 2.0, 0), shade(T.wall[0], 0.8), T.wall[1]);
          g.box(1.5, 0.4, 1.8, M(sx * 2.0, 0.2, 0), T.wall[0]);
          g.cyl(0.42, 0.3, 0.8, 6, M(sx * 3.3, 0.4, 1.1), 0x3a3a44, 0x5c5c6a);
        }
        g.box(5.6, 1.0, 1.8, M(0, 4.5, 0), shade(T.wall[0], 0.9), T.trim);
        g.box(2.8, 4.0, 0.3, M(0, 2.0, -0.6), 0x08080c);
        g.cone(0.55, 0.9, 4, M(0, 5.4, 0, 0, Math.PI / 4, 0), T.wall[1], T.trim);
        const door = new THREE.Group();
        const dm = new THREE.Mesh(g.build(false), gfx.matChar);
        dm.castShadow = true;
        door.add(dm);
        const gg = new Geo();
        gg.cone(0.3, 0.5, 4, M(0, 4.5, 0.95), 0xff9aa0);
        gg.cone(0.3, 0.5, 4, M(0, 4.0, 0.95, Math.PI, 0, 0), 0xff4a5a);
        for (const sx of [-1, 1]) {
          gg.cone(0.3, 0.9, 5, M(sx * 3.3, 1.25, 1.1), T.fire, 0xffffff);
        }
        door.add(new THREE.Mesh(gg.build(false), gfx.matGlow));
        const portal = new THREE.Mesh(this.portalGeo, this.matPortal.dungeon);
        portal.position.set(0, 2.1, -0.4);
        portal.scale.set(1.08, 0.9, 1);
        portal.renderOrder = 6;
        door.add(portal);
        door.position.set(x, zs.found ? y : y - 6.2, z);
        door.visible = zs.found;
        this.group.add(door);
        zs.door = door;
        zs.portal = portal;
        objects.lightSrc.push({ x, y: y + 2.5, z: z + 1.8, color: C_DUNGEON, power: 26, fire: true, zoneGate: zs });
        // 돌등
        for (const l of zs.lamps) {
          const lx = l.x;
          const ly = l.y;
          const lz = l.z;
          const rot = hash2(l.k, zs.id) * 1.5;
          st.box(0.95, 0.3, 0.95, M(lx, ly + 0.12, lz, 0, rot, 0), 0x586056, 0x7a8272);
          st.box(0.42, 1.15, 0.42, M(lx, ly + 0.82, lz, 0, rot, 0), 0x5e665a, 0x868e7c);
          st.box(0.9, 0.16, 0.9, M(lx, ly + 1.46, lz, 0, rot, 0), 0x6a7264);
          for (const [dx, dz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) st.box(0.14, 0.6, 0.14, M(lx + (dx * Math.cos(rot) + dz * Math.sin(rot)) * 0.36, ly + 1.84, lz + (dz * Math.cos(rot) - dx * Math.sin(rot)) * 0.36, 0, rot, 0), 0x5e665a);
          st.cone(0.82, 0.55, 4, M(lx, ly + 2.4, lz, 0, rot + Math.PI / 4, 0), 0x4e564a, 0x7a8272);
          st.ico(0.2, 0, M(lx, ly + 2.76, lz), 0x6a7264);
          const cg = new Geo();
          cg.box(0.5, 0.5, 0.5, M(0, 0, 0, 0, rot, 0), T.fire, 0xffffff);
          const core = new THREE.Mesh(cg.build(false), gfx.matGlow);
          core.position.set(lx, ly + 1.84, lz);
          core.visible = l.lit;
          this.group.add(core);
          l.core = core;
          objects.colliders.push({ x: lx, z: lz, r: 0.6 });
          objects.lightSrc.push({ x: lx, y: ly + 1.9, z: lz, color: T.fire, power: 24, fire: true, lamp: l });
        }
      }
      this._refreshEntrance(zs);
    }
    const sm = new THREE.Mesh(st.build(false), gfx.matChar);
    sm.castShadow = true;
    sm.receiveShadow = true;
    sm.frustumCulled = false;
    this.group.add(sm);
  }

  // 마을의 「별의 석판」: 받은 인장만큼 별 자리가 밝혀지고, 열두 개가 모두 차면 여명의 대검을 내어 준다
  _buildTablet() {
    const g = this.game;
    const { gfx, objects, world } = g;
    // 마을 북서쪽 (북동쪽의 귀환석과 제단을 사이에 두고 마주 본다)
    const x = VILLAGE.x - 9;
    const z = VILLAGE.z - 18;
    const y = world.heightAt(x, z);
    const grp = new THREE.Group();
    grp.position.set(x, y, z);
    grp.rotation.y = Math.atan2(9, 18); // 마을 한가운데의 제단을 바라본다
    const st = new Geo();
    st.cyl(2.1, 2.4, 0.3, 8, M(0, 0.1, 0), 0x7c7a8c, 0xa9a6bc);
    st.box(3.1, 0.42, 1.2, M(0, 0.44, 0), 0x5a5870, 0x86839e);
    st.taperBox(2.7, 3.5, 0.62, 0.84, M(0, 2.4, 0), 0x3c3a52, 0x76739a);
    st.box(2.5, 0.3, 0.8, M(0, 4.25, 0), 0x5a5870, 0x8c89a8);
    st.cone(0.5, 0.6, 4, M(0, 4.7, 0, 0, Math.PI / 4, 0), 0x6c6a84, 0xa9a6bc);
    // 별 자리 열두 개 (아직 비어 있는 자리는 어두운 홈)
    const R = 0.92;
    const cy = 2.5;
    const spot = (k) => {
      const a = (k / TABLET_SEALS) * TAU;
      return [Math.sin(a) * R, cy + Math.cos(a) * R];
    };
    for (let k = 0; k < TABLET_SEALS; k++) {
      const [sx, sy] = spot(k);
      st.cyl(0.15, 0.15, 0.06, 6, M(sx, sy, 0.31, Math.PI / 2, 0, 0), 0x1c1b2a);
    }
    const sm = new THREE.Mesh(st.build(false), gfx.matChar);
    sm.castShadow = true;
    sm.receiveShadow = true;
    grp.add(sm);
    const gems = [];
    const gg = new Geo();
    gg.cone(0.13, 0.2, 4, M(0, 0.1, 0), 0xd8fff0);
    gg.cone(0.13, 0.2, 4, M(0, -0.1, 0, Math.PI, 0, 0), 0x3fd0a0);
    const gemGeo = gg.build(false);
    for (let k = 0; k < TABLET_SEALS; k++) {
      const [sx, sy] = spot(k);
      const m = new THREE.Mesh(gemGeo, gfx.matGlow);
      m.position.set(sx, sy, 0.4);
      grp.add(m);
      gems.push(m);
    }
    const star = new THREE.Mesh(this.starSeal, gfx.matGlow);
    star.position.set(0, cy, 0.55);
    star.scale.setScalar(0.62);
    grp.add(star);
    this.group.add(grp);
    const light = { x, y: y + 2.6, z, color: C_DONE, power: 0 };
    objects.lightSrc.push(light);
    objects.colliders.push({ x, z, r: 1.5 });
    this.tablet = { x, y, z, grp, gems, star, light };
    objects.interactables.push({
      kind: 'ztablet', ref: null, x, z, r: 3.6,
      active: () => !this.cur,
      label: () => {
        const n = g.save.trials.length;
        return g.save.tablet ? '별의 석판 살펴보기' : n >= TABLET_SEALS ? '별의 석판 — 여명의 대검 받기' : `별의 석판 살펴보기 (별의 인장 ${n}/${TABLET_SEALS})`;
      },
    });
    this._refreshTablet();
  }

  _refreshTablet() {
    const t = this.tablet;
    const s = this.game.save;
    const n = s.trials.length;
    t.gems.forEach((m, k) => (m.visible = k < n));
    t.star.visible = n >= TABLET_SEALS && !s.tablet;
    t.light.power = n ? 6 + n * 1.5 : 0;
    t.light.color = t.star.visible ? 0xffb02a : C_DONE;
  }

  useTablet() {
    const g = this.game;
    const { save, ui, audio, fx } = g;
    const t = this.tablet;
    const n = save.trials.length;
    if (save.tablet) {
      ui.toast(n >= TRIAL_COUNT ? '별의 석판은 고요하다. 열여덟 인장을 모두 모은 이름이 석판에 새겨져 있다.' : `별의 석판은 고요하다. 여명의 대검은 이미 주인을 찾았다. (별의 인장 ${n}/${TRIAL_COUNT} — 먼바다 너머에도 시련장이 있다)`);
      audio.click();
    } else if (n < TABLET_SEALS) {
      ui.toast(`별의 석판 — 별의 인장 ${n}/${TABLET_SEALS}. 열두 인장을 모으면 석판 속에 잠든 「${UNIQUES.dawn.name}」이 깨어난다고 한다.`);
      audio.click();
    } else {
      save.tablet = true;
      audio.seal();
      fx.ring(t.x, t.y + 0.4, t.z, 0xffe27a, 7, 1);
      fx.burst(t.x, t.y + 2.6, t.z, 0xffe27a, 60, 8, { size: 0.42, life: 1.3, grav: 2, glow: 2.6 });
      const a = t.grp.rotation.y;
      g.loot.dropItem(makeUnique('dawn', Math.max(save.level, 20) + 3 * g.cycle), t.x + Math.sin(a) * 2.2, t.y + 1.4, t.z + Math.cos(a) * 2.2);
      this._refreshTablet();
      g.saveSoon();
    }
  }

  _refreshEntrance(zs) {
    if (!zs.trial) return;
    zs.starA.visible = !zs.cleared;
    zs.starB.visible = zs.cleared;
    zs.light.color = zs.cleared ? C_DONE : C_OPEN;
    zs.beam.visible = !zs.cleared;
    zs.portal.material = zs.cleared ? this.matPortal.done : this.matPortal.open;
  }

  _interactables() {
    const g = this.game;
    const I = g.objects.interactables;
    for (const zs of this.list) {
      const d = zs.def;
      I.push({
        kind: 'zenter', ref: zs, x: zs.x, z: zs.z + 0.8, r: 3.6,
        active: () => !this.cur && !this.busy && (zs.trial || (zs.found && zs.rise < 0)),
        label: () => `${d.name} 들어가기${zs.raid ? ' — 레이드 (친구와 함께)' : zs.trial ? (zs.cleared ? ' (인장 획득)' : '') : ` — 권장 Lv.${d.level}`}`,
      });
      for (const l of zs.lamps) {
        I.push({ kind: 'zlamp', ref: l, x: l.x, z: l.z, r: 2.7, active: () => !l.lit, label: () => '오래된 돌등에 불 밝히기' });
      }
      I.push({ kind: 'zexit', ref: zs, x: d.start.x, z: d.start.z, r: 2.1, active: () => this.cur === zs && !this.busy, label: () => '밖으로 나가기' });
      if (d.altar) {
        I.push({ kind: 'zaltar', ref: zs, x: d.altar.x, z: d.altar.z, r: 3.0, active: () => this.cur === zs && !zs.cleared, label: () => '별의 인장 받기' });
        I.push({ kind: 'zexit', ref: zs, x: d.altar.x, z: d.altar.z - TILE, r: 1.9, active: () => this.cur === zs && zs.cleared && !this.busy, label: () => '밖으로 나가기' });
      }
      for (const c of d.chests) {
        // 레이드의 보물은 그 싸움에 함께한 사람만 연다 (끝난 뒤에 들어온 사람은 열 수 없다)
        I.push({ kind: 'zchest', ref: zs, x: c.x, z: c.z, r: 2.8, active: () => this.cur === zs && zs.epoch > 0 && g.save.zchest[zs.id] !== zs.epoch && (!zs.raid || g.save.rkill === zs.epoch), label: () => (zs.raid ? '별의 보물상자 열기' : '던전의 보물상자 열기') });
      }
      if (d.exit) I.push({ kind: 'zexit', ref: zs, x: d.exit.x, z: d.exit.z, r: 2.1, active: () => this.cur === zs && !this.busy, label: () => '밖으로 나가기' });
    }
  }

  // ================= 실내 만들기 (처음 들어갈 때 한 번) =================
  _fire(color) {
    let geo = this.fireGeo.get(color);
    if (!geo) {
      const g = new Geo();
      g.cone(0.36, 1.05, 5, M(0, 0.52, 0), color, 0xffffff);
      g.cone(0.2, 0.7, 5, M(0.1, 0.4, 0.05, 0, 1, 0), 0xffffff, 0xffffff);
      geo = g.build(false);
      this.fireGeo.set(color, geo);
    }
    return geo;
  }

  _buildInterior(zs) {
    const { gfx, objects } = this.game;
    const def = zs.def;
    const T = zs.theme;
    const grp = new THREE.Group();
    const st = new Geo();
    const gl = new Geo();
    const rows = def.rows;
    const wall = (c, r) => c < 0 || r < 0 || c >= def.tileW || r >= def.tileH || rows[r][c] === '#' || rows[r][c] === ' ';
    const half = TILE / 2;
    for (let r = 0; r < def.tileH; r++) {
      for (let c = 0; c < def.tileW; c++) {
        const ch = rows[r][c];
        if (ch === ' ') continue;
        const x = def.ox + (c + 0.5) * TILE;
        const z = def.oz + (r + 0.5) * TILE;
        const h = hash2(c + def.id * 31, r);
        if (ch === '#') {
          const k = 0.88 + h * 0.24;
          st.box(TILE, WALL_H - 0.3, TILE, M(x, F + (WALL_H - 0.3) / 2, z), shade(T.wall[0], k), shade(T.wall[1], k));
          st.box(TILE, 0.3, TILE, M(x, F + WALL_H - 0.15, z), shade(T.trim, 0.8 + h * 0.25));
          // 바닥과 맞닿은 면에는 아랫단을 두르고, 군데군데 기둥을 세운다
          for (const [dc, dr] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            if (wall(c + dc, r + dr)) continue;
            const bx = x + dc * (half + 0.06);
            const bz = z + dr * (half + 0.06);
            st.box(dc ? 0.14 : TILE, 0.5, dc ? TILE : 0.14, M(bx, F + 0.25, bz), shade(T.wall[0], 0.62), shade(T.wall[0], 0.8));
            if ((c * 3 + r * 5 + def.id) % 4 === 0) {
              st.box(dc ? 0.3 : 0.8, WALL_H - 0.3, dc ? 0.8 : 0.3, M(x + dc * (half + 0.14), F + (WALL_H - 0.3) / 2, z + dr * (half + 0.14)), shade(T.wall[0], 0.95), shade(T.trim, 0.9));
              st.box(dc ? 0.42 : 1.0, 0.3, dc ? 1.0 : 0.42, M(x + dc * (half + 0.16), F + WALL_H - 0.5, z + dr * (half + 0.16)), shade(T.trim, 0.95));
            }
          }
          continue;
        }
        // 바닥 (벽 가까이는 조금 어둡게 해서 깊이감을 준다)
        const edge = wall(c - 1, r) || wall(c + 1, r) || wall(c, r - 1) || wall(c, r + 1);
        const fc = shade(T.floor[(c + r) % 2], (edge ? 0.8 : 0.94) + h * 0.14);
        st.quad([x - half, F, z + half], [x + half, F, z + half], [x + half, F, z - half], [x - half, F, z - half], fc);
        // 벽 모퉁이에 굴러다니는 돌 부스러기 (던전은 더 낡았다)
        if (ch === '.' && edge && h < (zs.trial ? 0.1 : 0.24)) {
          const sx = wall(c - 1, r) ? -1 : wall(c + 1, r) ? 1 : 0;
          const sz = wall(c, r - 1) ? -1 : wall(c, r + 1) ? 1 : 0;
          const n = 1 + Math.floor(h * 30) % 3;
          for (let q = 0; q < n; q++) {
            const hh = hash2(c * 7 + q, r * 13 + def.id);
            st.ico(0.16 + hh * 0.22, 0, M(x + sx * (0.95 - hh * 0.5) + (q - 1) * 0.35 * (sz ? 1 : 0), F + 0.1, z + sz * (0.95 - hh * 0.5) + (q - 1) * 0.35 * (sx ? 1 : 0), 0, hh * 6, 0, 1, 0.7, 1), shade(T.wall[0], 0.8), shade(T.wall[1], 0.9), 0.4, q + c);
          }
        }
        if (ch === 'o') {
          // 화로
          st.cyl(0.5, 0.36, 0.95, 6, M(x, F + 0.47, z), 0x3a3a44, 0x62626e);
          st.cyl(0.62, 0.5, 0.16, 6, M(x, F + 0.98, z), 0x4a4a56, 0x74747e);
          const fl = new THREE.Mesh(this._fire(T.fire), gfx.matGlow);
          fl.position.set(x, F + 1.0, z);
          grp.add(fl);
          zs.fires.push(fl);
          zs.solids.push({ x, z, r: TORCH_R });
          objects.lightSrc.push({ x, y: F + 1.9, z, color: T.fire, power: 64, fire: true, always: true });
        } else if (ch === 'f' || ch === 'F') {
          st.cyl(0.56, 0.66, 0.12, 8, M(x, F + 0.05, z), 0x2c2c34, 0x4a4a54);
          gl.cyl(0.26, 0.26, 0.04, 8, M(x, F + 0.12, z), 0xff6a2a);
        } else if (ch === 'p') {
          st.box(2.1, 0.1, 2.1, M(x, F + 0.04, z), 0x33333c, 0x55555f);
        } else if (ch === 'S' || ch === 'E') {
          st.cyl(1.5, 1.6, 0.08, 12, M(x, F + 0.03, z), shade(T.trim, 0.55), shade(T.trim, 0.8));
        } else if (ch === 'R') {
          // 제단
          st.cyl(1.5, 1.7, 0.3, 8, M(x, F + 0.15, z), shade(T.trim, 0.6), shade(T.trim, 0.85));
          st.cyl(0.7, 0.9, 1.0, 8, M(x, F + 0.8, z), shade(T.trim, 0.7), T.trim);
          st.cyl(0.95, 0.75, 0.18, 8, M(x, F + 1.38, z), T.trim);
          zs.solids.push({ x, z, r: 0.95 });
          objects.lightSrc.push({ x, y: F + 2.6, z, color: 0xffe9a0, power: 34, always: true, altar: zs });
        } else if (ch === 'C') {
          zs.solids.push({ x, z, r: 0.85 });
          objects.lightSrc.push({ x, y: F + 1.6, z: z - 1, color: 0xffd65a, power: 30, always: true });
        }
      }
    }
    const sm = new THREE.Mesh(st.build(false), gfx.matChar);
    sm.castShadow = true;
    sm.receiveShadow = true;
    sm.frustumCulled = false;
    grp.add(sm);
    if (gl.vertCount) {
      const gm = new THREE.Mesh(gl.build(false), gfx.matGlow);
      gm.frustumCulled = false;
      grp.add(gm);
    }

    // 관문: 쇠창살. 열리면 바닥으로 내려간다
    for (const gate of def.gates) {
      const len = gate.tiles.length * TILE;
      const puzzle = def.puzzle && def.puzzle.gate === gate.n;
      const col = puzzle ? 0x5ab8ff : (def.kind === 'dungeon' && gate.n === 4) || def.kind === 'raid' ? 0xffd65a : 0xff4a3a;
      const g = new Geo();
      const n = Math.round(len / 0.5);
      for (let k = 0; k < n; k++) g.box(0.17, 3.9, 0.17, M(-len / 2 + 0.25 + k * 0.5, 1.95, 0), 0x25252e, 0x55556a);
      g.box(len, 0.24, 0.3, M(0, 3.9, 0), 0x3a3a48, 0x5e5e74);
      g.box(len, 0.2, 0.26, M(0, 1.7, 0), 0x3a3a48);
      g.box(len, 0.2, 0.3, M(0, 0.12, 0), 0x2c2c36);
      const e = new Geo();
      for (const side of [1, -1]) {
        e.cone(0.36, 0.56, 4, M(0, 2.78, 0.2 * side), col, 0xffffff);
        e.cone(0.36, 0.56, 4, M(0, 2.22, 0.2 * side, Math.PI, 0, 0), col);
      }
      const gg = new THREE.Group();
      const bars = new THREE.Mesh(g.build(false), gfx.matChar);
      bars.castShadow = true;
      gg.add(bars, new THREE.Mesh(e.build(false), gfx.matGlow));
      gg.position.set(gate.x, F, gate.z);
      gg.rotation.y = gate.horiz ? 0 : Math.PI / 2;
      grp.add(gg);
      zs.gates.push({ def: gate, grp: gg, y: 0, bit: 1 << gate.n, puzzle, col });
    }

    // 불기둥 함정
    for (const f of def.flames) {
      const m = new THREE.Mesh(this.jetGeo, gfx.matGlow);
      m.position.set(f.x, F + 0.1, f.z);
      m.visible = false;
      grp.add(m);
      zs.flames.push({ def: f, m, on: 0 });
    }

    // 순서 퍼즐 발판
    for (const p of def.plates) {
      const mat = new THREE.MeshBasicMaterial({ color: PLATE_COL[p.i % PLATE_COL.length], fog: false });
      const m = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.08, 1.8), mat);
      m.position.set(p.x, F + 0.12, p.z);
      grp.add(m);
      zs.plates.push({ def: p, m, mat, base: new THREE.Color(PLATE_COL[p.i % PLATE_COL.length]), glow: 0, flash: 0, bad: 0 });
    }

    // 드나드는 문양 (시작 지점, 던전 끝, 시련장 제단 앞)
    zs.sigils = [];
    const sigil = (x, z, when) => {
      const ring = new THREE.Mesh(this.sigilGeo, this.matSigil);
      ring.position.set(x, F + 0.1, z);
      ring.renderOrder = 6;
      const gem = new THREE.Mesh(this.diamondGeo, gfx.matGlow);
      gem.position.set(x, F + 1.5, z);
      grp.add(ring, gem);
      zs.sigils.push({ ring, gem, when, x, z });
    };
    sigil(def.start.x, def.start.z, () => true);
    if (def.exit) sigil(def.exit.x, def.exit.z, () => true);
    if (def.altar) {
      sigil(def.altar.x, def.altar.z - TILE, () => zs.cleared);
      const seal = new THREE.Mesh(this.starSeal, gfx.matGlow);
      seal.position.set(def.altar.x, F + 2.5, def.altar.z);
      grp.add(seal);
      zs.seal = seal;
    }

    // 던전의 보물상자
    zs.chests = [];
    for (const c of def.chests) {
      const base = new Geo();
      base.box(1.5, 0.8, 1.0, M(0, 0.4, 0), 0x3a2a5a, 0x6a4a9a);
      base.box(1.56, 0.1, 1.06, M(0, 0.75, 0), 0xffd65a);
      for (const sx of [-0.55, 0, 0.55]) base.box(0.12, 0.82, 1.06, M(sx, 0.41, 0), 0xffd65a);
      const lid = new Geo();
      lid.box(1.5, 0.36, 1.0, M(0, 0.18, 0.5), 0x4a367a, 0x7a5ab0);
      for (const sx of [-0.55, 0, 0.55]) lid.box(0.12, 0.38, 1.06, M(sx, 0.18, 0.5), 0xffd65a);
      lid.box(0.26, 0.3, 0.08, M(0, 0.04, 1.03), 0xfff2a8);
      const cg = new THREE.Group();
      cg.position.set(c.x, F, c.z);
      const bm = new THREE.Mesh(base.build(false), gfx.matChar);
      bm.castShadow = true;
      const lm = new THREE.Mesh(lid.build(false), gfx.matChar);
      lm.position.set(0, 0.8, -0.5);
      cg.add(bm, lm);
      grp.add(cg);
      zs.chests.push({ x: c.x, z: c.z, lid: lm });
    }

    grp.visible = false;
    gfx.scene.add(grp);
    zs.grp = grp;
  }

  // ================= 드나들기 =================
  enter(zs) {
    const g = this.game;
    if (this.busy || this.cur || g.player.state === 'dead') return;
    this.busy = true;
    g.player.invuln = Math.max(g.player.invuln, 1.6);
    g.audio.portal();
    g.fx.ring(zs.x, zs.y + 0.4, zs.z, zs.raid ? C_RAID : zs.trial ? C_OPEN : C_DUNGEON, 4, 0.5);
    g.ui.fade(true);
    setTimeout(() => {
      if (!zs.grp) this._buildInterior(zs);
      const d = zs.def;
      g.player.teleport(d.start.x, d.start.z + 2.7, 0);
      g.player.camPitch = Math.max(g.player.camPitch, 0.62);
      this._setMode(zs);
      g.ui.fade(false);
      g.ui.banner(d.name, zs.raid ? '레이드 · 친구들과 함께 (2~6명 권장)' : zs.trial ? `별의 시련장 · ${d.sub} · Lv.${d.level}` : `숨겨진 던전 · 권장 Lv.${d.level}`);
      this.busy = false;
      if (zs.raid) {
        g.tip('z-raid', '레이드에서는 레벨과 상관없이 누구나 함께 싸울 수 있어요. 받는 피해는 내 체력의 비율이고, 주는 피해는 누구의 한 방이든 같은 무게입니다. 보스의 체력은 모인 사람 수에 맞춰져요.');
        if (g.ents.players.size === 0) g.ui.toast('혼자서는 몹시 벅찬 상대입니다. 친구를 불러 함께 도전해 보세요!');
      } else if (d.tough) g.tip('z-far', '먼바다 너머의 시련장과 던전은 본섬보다 훨씬 험합니다. 권장 레벨에 맞는 장비와 물약을 챙기세요.');
      if (d.type === 'order') g.tip('z-order', '발판이 빛나는 순서를 기억했다가, 같은 순서로 밟으면 문이 열립니다.');
      else if (d.type === 'trap') g.tip('z-trap', '불기둥은 박자에 맞춰 꺼졌다 켜집니다. 꺼진 틈에 지나가거나, 구르기로 빠져나가세요.');
      else if (d.type === 'combat') g.tip('z-combat', '방 안의 몬스터를 모두 쓰러뜨리면 쇠창살 문이 열립니다.');
      else if (!zs.raid) g.tip('z-dungeon', '던전에서 쓰러지면 입구로 돌아갑니다. 모두 나가면 잠시 뒤 던전이 처음 상태로 되돌아가요.');
    }, 330);
  }

  leave() {
    const g = this.game;
    const zs = this.cur;
    if (this.busy || !zs) return;
    this.busy = true;
    g.audio.portal();
    g.ui.fade(true);
    setTimeout(() => {
      this.toEntrance(zs);
      this._setMode(null);
      g.ui.fade(false);
      this.busy = false;
    }, 330);
  }

  // 입구 앞에, 문을 바라보게 세운다
  toEntrance(zs) {
    this.game.player.teleport(zs.x, zs.z + 5, Math.PI);
  }

  // 지금 있는 곳에 맞춰 화면을 바꾼다 (실내/바깥)
  _setMode(zs) {
    const g = this.game;
    if (zs && !zs.grp) this._buildInterior(zs);
    const prev = this.cur;
    if (prev && prev.grp) prev.grp.visible = false;
    this._hideRaidHud();
    this.raid = null;
    document.body.classList.toggle('in-raid', !!(zs && zs.raid));
    this.cur = zs;
    g.zone = zs;
    g.terrain.group.visible = !zs;
    g.objects.group.visible = !zs;
    g.ents.clearMonsters();
    g.player.lock = null;
    if (zs) {
      const T = zs.theme;
      const dungeon = !zs.trial;
      zs.grp.visible = true;
      g.gfx.setIndoor({ fog: T.fog, sky: T.sky, ground: T.ground, key: T.key, far: zs.raid ? 130 : dungeon ? 66 : 80, amb: zs.raid ? 1.5 : dungeon ? 1.15 : 1.4, keyPower: zs.raid ? 1.3 : dungeon ? 1.0 : 1.25 });
      g.net.send({ t: 'zone', id: zs.id });
      zs.sync = true; // 서버가 알려 주는 지금 상태를 처음 받을 때는 조용히 맞춘다
      zs.bossIntro = false;
      if (zs.def.puzzle && !((zs.open >> zs.def.puzzle.gate) & 1)) this._newPuzzle(zs);
      for (const gt of zs.gates) {
        // 이미 열려 있던 문은 바로 내려가 있다
        gt.y = zs.open & gt.bit ? 1 : 0;
      }
      this._applyChests(zs);
    } else g.gfx.setIndoor(null);
    g.ui.dirty = true;
  }

  _applyChests(zs) {
    const opened = this.game.save.zchest[zs.id] === zs.epoch && zs.epoch > 0;
    for (const c of zs.chests || []) c.lid.rotation.x = opened ? -1.9 : 0;
  }

  // ================= 서버에서 온 소식 =================
  onState(m) {
    const zs = this.list[m.id - 1];
    if (!zs) return;
    const g = this.game;
    const before = zs.open;
    const reset = zs.epoch && m.epoch !== zs.epoch;
    zs.open = m.open;
    zs.epoch = m.epoch;
    if (this.cur !== zs) return;
    if (reset) this._applyChests(zs);
    const d = zs.def;
    if (zs.sync) {
      // 막 들어왔을 때: 먼저 온 친구가 열어 둔 문은 이미 내려가 있다
      zs.sync = false;
      for (const gt of zs.gates) gt.y = m.open & gt.bit ? 1 : 0;
      this._applyChests(zs);
      if (d.puzzle) {
        if ((m.open >> d.puzzle.gate) & 1) {
          if (zs.puzzle) zs.puzzle.mode = 'done';
        } else if (!zs.puzzle || zs.puzzle.mode === 'done') this._newPuzzle(zs);
      }
      return;
    }
    const opened = m.open & ~before;
    if (!opened) return;
    g.audio.gate();
    g.player.shake = Math.max(g.player.shake, 0.25);
    if (d.puzzle && opened & (1 << d.puzzle.gate)) {
      if (zs.puzzle) zs.puzzle.mode = 'done';
      g.ui.toast(m.by && m.by !== g.myId ? '친구가 퍼즐을 풀었습니다! 문이 열립니다.' : '퍼즐을 풀었습니다! 문이 열립니다.', true);
    } else if (zs.raid) {
      // 별 포식자를 쓰러뜨렸다
      this.raid = null;
      g.audio.victory();
      g.ui.banner('레이드 성공!', '별 포식자가 쓰러졌습니다 — 보물 방의 문이 열렸어요');
    } else if (!zs.trial && opened & 8) {
      const boss = d.spawns.find((s) => s.boss);
      g.ui.banner('깊은 곳의 문이 열렸다', boss ? `${MON[boss.type].name}이(가) 기다리고 있습니다` : '');
    } else if (!zs.trial && opened & 16) g.ui.toast('보물 방의 문이 열렸습니다!', true);
    else g.ui.toast(zs.trial && d.gates.every((q) => m.open & (1 << q.n)) ? '마지막 문이 열렸습니다! 제단으로 가세요.' : '쇠창살 문이 열렸습니다!', true);
  }

  onLamp(m) {
    const zs = this.list[m.z - 1];
    const l = zs && zs.lamps[m.k];
    if (!l || l.lit) return;
    const who = this.game.ents.players.get(m.by);
    this.lightLamp(l, true);
    if (who) this.game.ui.chatAdd('', `${who.prof.name} 님이 돌등을 밝혔습니다.`, 'sys');
  }

  // ================= 상호작용 =================
  interact(it) {
    const g = this.game;
    const zs = it.kind === 'zlamp' ? it.ref.zs : it.ref;
    if (it.kind === 'zenter') this.enter(zs);
    else if (it.kind === 'zexit') this.leave();
    else if (it.kind === 'zlamp') this.lightLamp(it.ref, false);
    else if (it.kind === 'zaltar') this.claimSeal(zs);
    else if (it.kind === 'zchest') this.openChest(zs);
    else if (it.kind === 'ztablet') this.useTablet();
    g.ui.dirty = true;
  }

  lightLamp(l, remote) {
    const g = this.game;
    const zs = l.zs;
    if (l.lit) return;
    if (!remote && zs.def.night && g.gfx.night < 0.6) {
      g.ui.toast('불이 붙지 않는다… 별빛이 있어야 할 것 같다. 밤에 다시 와 보자.');
      g.audio.deny();
      return;
    }
    l.lit = true;
    l.core.visible = true;
    g.save.lamps[zs.id] = (g.save.lamps[zs.id] || 0) | (1 << l.k);
    g.audio.lamp();
    g.fx.burst(l.x, l.y + 1.9, l.z, zs.theme.fire, 18, 3.5, { size: 0.3, life: 0.8, grav: -1, glow: 2.4 });
    g.fx.ring(l.x, l.y + 0.3, l.z, zs.theme.fire, 3, 0.6);
    if (!remote) g.net.send({ t: 'lamp', z: zs.id, k: l.k });
    const n = zs.lamps.filter((q) => q.lit).length;
    if (n >= zs.lamps.length) {
      if (!zs.found) this.reveal(zs);
    } else g.ui.toast(`돌등에 불이 붙었다 (${n}/${zs.lamps.length}) — 근처에 돌등이 더 있다. 불빛이 흘러가는 쪽을 살펴보자.`, true);
    g.saveSoon();
  }

  // 숨겨진 던전의 문이 땅에서 솟아오른다
  reveal(zs) {
    const g = this.game;
    zs.found = true;
    zs.rise = 0;
    zs.door.visible = true;
    if (!g.save.zfound.includes(zs.id)) g.save.zfound.push(zs.id);
    g.audio.reveal();
    g.ui.banner('숨겨진 던전 발견!', `${zs.def.name} · 권장 Lv.${zs.def.level}`);
    g.ui.chatAdd('', `숨겨진 던전 「${zs.def.name}」의 문이 드러났습니다! 지도에 표시됩니다.`, 'sys');
    this.announce(`숨겨진 던전 「${zs.def.name}」의 문을 찾아냈습니다!`);
    g.saveSoon();
  }

  // 함께 있는 친구들에게 채팅으로 소식을 알린다
  announce(text) {
    this.game.net.send({ t: 'chat', text: '★ ' + text });
  }

  claimSeal(zs) {
    const g = this.game;
    const { save, fx, ui, audio, player } = g;
    if (zs.cleared || save.trials.includes(zs.id)) return;
    zs.cleared = true;
    save.trials.push(zs.id);
    const n = save.trials.length;
    const heart = n % 2 === 1;
    // 인장 하나마다 번갈아 체력 20(안에서는 2) 또는 기력 10
    save.bonusHp = Math.ceil(n / 2) * 2;
    save.bonusSta = Math.floor(n / 2) * 10;
    player.refreshStats();
    player.hp = player.maxHp;
    player.stamina = player.maxStamina;
    g.net.send({ t: 'prof', prof: player.profile() });
    const a = zs.def.altar;
    audio.seal();
    fx.ring(a.x, F + 0.4, a.z, 0xfff2a8, 6, 0.9);
    fx.burst(a.x, F + 2.5, a.z, 0xfff2a8, 46, 7, { size: 0.42, life: 1.2, grav: 2, glow: 2.4 });
    fx.burst(player.pos.x, player.pos.y + 1, player.pos.z, heart ? 0xff6a7a : 0x7dff8a, 24, 4, { size: 0.36, life: 1, grav: -1.5 });
    ui.banner(`별의 인장 획득! ${n}/${TRIAL_COUNT}`, heart ? '최대 체력이 20 늘어났습니다' : '최대 기력이 10 늘어났습니다');
    this.announce(`「${zs.def.name}」을(를) 통과했습니다! (별의 인장 ${n}/${TRIAL_COUNT})`);
    // 덤: 장비 하나와 별가루
    const lvl = zs.def.level + 3 * g.cycle;
    const lz = a.z - 2.2;
    const far = !!zs.def.tough; // 먼바다 너머의 시련장: 영웅 등급 이상의 장비와 별의 핵
    let gift = rollItem(far ? 'dungeon' : 'trial', lvl);
    for (let k = 0; far && k < 30 && gift.r < 3; k++) gift = rollItem('dungeon', lvl);
    g.loot.dropItem(gift, a.x, F + 1.2, lz);
    g.loot.dropMat('dust', (far ? 5 : 2) + (Math.random() < 0.5 ? 1 : 0), a.x, F + 1.2, lz);
    if (far || Math.random() < 0.35) g.loot.dropMat('core', far ? 2 : 1, a.x, F + 1.2, lz);
    if (far) g.loot.dropMat('apple', 1, a.x, F + 1.2, lz);
    g.loot.dropMat('pot:hp', 1, a.x, F + 1.2, lz);
    g.loot.dropMat('pot:' + POTION_KEYS[1 + Math.floor(Math.random() * (POTION_KEYS.length - 1))], 1, a.x, F + 1.2, lz);
    if (n % 3 === 0) g.loot.dropMat('apple', 1, a.x, F + 1.2, lz);
    save.gold += 20 + zs.def.level * 6;
    this._refreshEntrance(zs);
    this._refreshTablet();
    if (n === TABLET_SEALS && !save.tablet) ui.chatAdd('', '별의 인장 열두 개를 모았습니다. 대단해요! 마을의 별의 석판이 빛나기 시작했습니다…', 'sys');
    if (n >= TRIAL_COUNT) {
      // 열여덟 인장을 모두 모았다: 전설 등급의 장비 하나
      let it = rollItem('dboss', lvl + 2);
      for (let k = 0; k < 60 && it.r < 4; k++) it = rollItem('dboss', lvl + 2);
      g.loot.dropItem(it, a.x + 2.2, F + 1.2, lz);
      ui.chatAdd('', '모든 별의 시련장을 통과했습니다! 열여덟 인장의 주인에게 전설의 장비가 내려졌습니다.', 'sys');
      this.announce('별의 인장 열여덟 개를 모두 모았습니다!');
      audio.victory();
    }
    g.saveSoon();
  }

  openChest(zs) {
    const g = this.game;
    const { save, fx, ui, audio } = g;
    if (!zs.epoch || save.zchest[zs.id] === zs.epoch) return;
    save.zchest[zs.id] = zs.epoch;
    g.quests.on('chest');
    const c = zs.def.chests[0];
    if (zs.raid) return this._openRaidChest(zs, c);
    const lvl = zs.def.level + 3 * g.cycle;
    const gold = 120 + zs.def.level * 14;
    save.gold += gold;
    save.berries += 2;
    audio.chest();
    fx.burst(c.x, F + 1, c.z, 0xffd65a, 40, 6, { size: 0.4, life: 1, grav: 3, glow: 2 });
    this._applyChests(zs);
    // 상자 양옆으로 쏟아진다
    const dz = c.z;
    g.loot.dropItem(rollItem('dungeon', lvl), c.x - 2.6, F + 1, dz);
    g.loot.dropItem(rollItem('dungeon', lvl), c.x + 2.6, F + 1, dz);
    g.loot.dropMat('dust', 5 + Math.floor(Math.random() * 3), c.x - 2.6, F + 1, dz);
    g.loot.dropMat('core', 2, c.x + 2.6, F + 1, dz);
    for (let k = 0; k < 2; k++) g.loot.dropMat('pot:' + POTION_KEYS[Math.floor(Math.random() * POTION_KEYS.length)], 1, c.x - 2.6, F + 1, dz);
    const first = !save.dclear.includes(zs.id);
    g.loot.dropMat('apple', first ? 3 : 1, c.x + 2.6, F + 1, dz);
    if (first) {
      // 처음 정복했을 때는 영웅 등급 이상이 하나 더 나온다
      save.dclear.push(zs.id);
      let it = rollItem('dboss', lvl);
      for (let k = 0; k < 30 && it.r < 3; k++) it = rollItem('dboss', lvl);
      g.loot.dropItem(it, c.x + 2.6, F + 1, dz);
      ui.banner('던전 정복!', `${zs.def.name} — 처음 정복한 보상으로 귀한 장비를 얻었습니다`);
      this.announce(`숨겨진 던전 「${zs.def.name}」을(를) 정복했습니다!`);
      audio.victory();
    } else ui.toast(`던전의 보물상자: 골드 +${gold}, 열매 +2`, true);
    g.saveSoon();
  }

  // 레이드의 보물: 저마다 자기 레벨에 맞는 영웅·전설 장비를 받는다
  _openRaidChest(zs, c) {
    const g = this.game;
    const { save, fx, ui, audio } = g;
    const lvl = save.level + 2 + 3 * g.cycle;
    const gold = 300 + save.level * 22;
    save.gold += gold;
    save.berries += 3;
    save.raidWins = (save.raidWins || 0) + 1;
    audio.chest();
    fx.burst(c.x, F + 1, c.z, 0xffe27a, 60, 7, { size: 0.42, life: 1.1, grav: 3, glow: 2.4 });
    this._applyChests(zs);
    const dz = c.z;
    g.loot.dropItem(rollItem('raid', lvl), c.x - 2.8, F + 1, dz);
    g.loot.dropItem(rollItem('raid', lvl), c.x + 2.8, F + 1, dz);
    g.loot.dropMat('dust', 12, c.x - 2.8, F + 1, dz);
    g.loot.dropMat('core', 6, c.x + 2.8, F + 1, dz);
    g.loot.dropMat('apple', 2, c.x + 2.8, F + 1, dz);
    for (let k = 0; k < 3; k++) g.loot.dropMat('pot:' + POTION_KEYS[Math.floor(Math.random() * POTION_KEYS.length)], 1, c.x - 2.8, F + 1, dz);
    if (save.raidWins === 1) {
      // 처음 이겼을 때는 전설 등급이 하나 더 나온다
      let it = rollItem('raid', lvl);
      for (let k = 0; k < 60 && it.r < 4; k++) it = rollItem('raid', lvl);
      g.loot.dropItem(it, c.x, F + 1, dz - 2.2);
      ui.banner('레이드 정복!', '처음 이긴 보상으로 전설의 장비를 얻었습니다 — 이름 옆에 별이 붙어요');
      audio.victory();
    } else ui.toast(`별의 보물상자: 골드 +${gold}, 열매 +3 (레이드 승리 ${save.raidWins}번째)`, true);
    this.announce(`레이드 「${zs.def.name}」에서 별 포식자를 쓰러뜨렸습니다! (${save.raidWins}번째)`);
    g.net.send({ t: 'prof', prof: g.player.profile() });
    g.saveSoon();
  }

  // ================= 레이드: 화면에 띄우는 것들 =================
  // 별 삼키기를 외기 시작했다 (msg.d: 걸리는 시간, msg.n: 사슬 기둥의 수 — 0 이면 막을 수 없다)
  onRaidCast(msg) {
    const g = this.game;
    this.raid = this.raid || {};
    this.raid.cast = { at: performance.now(), dur: msg.d, n: msg.n };
    g.audio.roar();
    g.player.shake = Math.max(g.player.shake, 0.5);
    if (msg.n > 0) {
      g.ui.banner('별 삼키기!', msg.n > 1 ? `사슬 기둥 ${msg.n}개를 거의 동시에 부숴야 합니다 — 흩어지세요!` : '사슬 기둥을 부숴 주문을 끊으세요!');
      g.tip('raid-cast', '금빛 사슬이 이어진 기둥을 모두 부수면 주문이 끊깁니다. 기둥이 여럿이면 저마다 하나씩 맡아 거의 동시에 부숴야 해요 — 먼저 부순 기둥은 되살아납니다.');
    } else g.ui.banner('모든 빛을 삼킨다…', '시간이 다 됐습니다');
  }

  onRaidSplit(msg) {
    const g = this.game;
    const mine = msg.pid === g.myId;
    const who = g.ents.players.get(msg.pid);
    g.ui.toast(mine ? '별똥이 나를 노립니다! 친구들 곁으로 가서 함께 맞으세요!' : `별똥이 ${who ? who.prof.name : '친구'} 님을 노립니다! 금빛 원 안으로 모이세요!`, true);
    g.audio.flame();
    g.tip('raid-split', '금빛 원은 「별똥 나누기」입니다. 원 안에 선 사람들이 피해를 나눠 받아요. 혼자 맞으면 거의 쓰러집니다.');
  }

  // 별 포식자가 쓰러질 때 함께 싸우고 있었다: 이번 회차의 보물상자를 열 수 있다
  onRaidKill(zoneId) {
    const zs = this.list[zoneId - 1];
    if (!zs) return;
    this.game.save.rkill = zs.epoch;
    this.game.saveSoon();
  }

  onRaidWipe() {
    const g = this.game;
    if (this.raid) this.raid.cast = null;
    g.player.shake = Math.max(g.player.shake, 1);
    g.audio.thud();
    const p = g.player.pos;
    g.fx.ring(p.x, F + 0.3, p.z, 0xffe27a, 40, 1.2);
  }

  // 서버가 알려 주는 레이드 소식 (msg.k: start 시작 / break 사슬이 끊김 / regrow 기둥이 되살아남 / reset 처음으로)
  onRaid(msg) {
    const g = this.game;
    const zs = this.cur;
    if (!zs || !zs.raid) return;
    if (msg.k === 'start') {
      this.raid = { endAt: performance.now() + msg.left, cast: this.raid ? this.raid.cast : null };
      if (msg.late) g.ui.toast('싸움이 한창입니다! 어서 친구들을 도우세요.', true);
      else g.ui.toast(`별 포식자가 깨어났습니다! ${Math.round(msg.left / 60000)}분 안에 쓰러뜨려야 합니다.`, true);
    } else if (msg.k === 'break') {
      if (this.raid) this.raid.cast = null;
      g.ents.cancelStrikes(msg.id);
      g.audio.puzzleOk();
      g.audio.gate();
      g.player.shake = Math.max(g.player.shake, 0.6);
      g.ui.banner('사슬이 끊어졌다!', '별 포식자가 쓰러졌습니다 — 지금 몰아치세요!');
      const b = this.boss();
      if (b) g.fx.burst(b.x, F + 4, b.z, 0xffe27a, 50, 9, { size: 0.5, life: 0.9, grav: 4, glow: 2.6 });
    } else if (msg.k === 'regrow') {
      g.ui.toast('사슬이 다시 이어졌습니다! 기둥을 거의 동시에 부숴야 해요.', true);
      g.audio.deny();
    } else if (msg.k === 'reset') this.raid = null;
  }

  // 별 삼키기 막대와 남은 시간, 기둥과 보스를 잇는 사슬
  _updateRaid(zs, dt, time) {
    const g = this.game;
    const r = this.raid;
    const boss = this.boss();
    const now = performance.now();
    const cast = r && r.cast && boss ? r.cast : null;
    const el = document.getElementById('raid-cast');
    if (cast) {
      const k = Math.max(0, 1 - (now - cast.at) / cast.dur);
      el.classList.remove('hidden');
      document.getElementById('raid-cast-fill').style.width = (k * 100).toFixed(1) + '%';
      document.getElementById('raid-cast-label').textContent = cast.n > 0 ? `별 삼키기 — 사슬 기둥을 부숴라! ${Math.ceil((cast.dur * k) / 1000)}초` : `모든 빛을 삼킨다… ${Math.ceil((cast.dur * k) / 1000)}초`;
      if (k <= 0) r.cast = null;
    } else el.classList.add('hidden');
    const tm = document.getElementById('raid-timer');
    if (r && r.endAt && boss) {
      const left = Math.max(0, r.endAt - now);
      tm.classList.remove('hidden');
      tm.classList.toggle('low', left < 60000);
      tm.textContent = `남은 시간 ${Math.floor(left / 60000)}:${String(Math.floor((left % 60000) / 1000)).padStart(2, '0')}`;
    } else tm.classList.add('hidden');
    // 사슬: 살아 있는 기둥마다 보스의 가슴으로 금빛 줄이 이어진다
    let n = 0;
    if (boss) {
      for (const e of g.ents.monsters.values()) {
        if (e.info.type !== 'pylon' || !e.shown || e.dying) continue;
        let m = this.chains[n];
        if (!m) {
          m = new THREE.Mesh(this.chainGeo, this.matChain);
          m.renderOrder = 6;
          m.frustumCulled = false;
          g.gfx.scene.add(m);
          this.chains[n] = m;
        }
        n++;
        const by = F + boss.info.def.height * 0.55;
        m.position.set(e.x, F + 3.2, e.z);
        m.lookAt(boss.x, by, boss.z);
        const len = Math.hypot(boss.x - e.x, by - (F + 3.2), boss.z - e.z);
        const w = 1 + Math.sin(time * 9 + n) * 0.35;
        m.scale.set(w, w, len);
        m.visible = true;
        if (Math.random() < dt * 14) {
          const t = Math.random();
          g.fx.spawn(e.x + (boss.x - e.x) * t, F + 3.2 + (by - F - 3.2) * t, e.z + (boss.z - e.z) * t, 0, 0.6, 0, 0xffe27a, 0.14, 0.5, -0.4, 1, 2.6);
        }
      }
    }
    this.matChain.opacity = 0.34 + Math.sin(time * 7) * 0.12;
    for (let i = n; i < this.chains.length; i++) this.chains[i].visible = false;
  }

  _hideRaidHud() {
    for (const id of ['raid-cast', 'raid-timer']) {
      const el = document.getElementById(id);
      if (el) el.classList.add('hidden');
    }
    for (const m of this.chains) m.visible = false;
  }

  // ================= 순서 퍼즐 =================
  _newPuzzle(zs) {
    const n = zs.plates.length;
    const len = zs.def.puzzle.len;
    const seq = [];
    while (seq.length < len) {
      const k = Math.floor(Math.random() * n);
      if (seq.length && seq[seq.length - 1] === k) continue;
      seq.push(k);
    }
    // 모든 발판이 적어도 한 번은 나오게 한다 (길이가 넉넉할 때)
    if (len >= n) {
      const order = [...Array(n).keys()].sort(() => Math.random() - 0.5);
      for (let i = 0; i < n; i++) seq[i] = order[i];
      for (let i = n; i < len; i++) {
        let k = Math.floor(Math.random() * n);
        if (k === seq[i - 1]) k = (k + 1) % n;
        seq[i] = k;
      }
    }
    zs.puzzle = { seq, step: 0, mode: 'demo', t: -1.2, idle: 0, on: -1, shown: -1 };
  }

  _updatePuzzle(zs, dt) {
    const g = this.game;
    const pz = zs.puzzle;
    const p = g.player;
    for (const pl of zs.plates) {
      pl.glow = Math.max(0, pl.glow - dt * 2.4);
      pl.flash = Math.max(0, pl.flash - dt * 2.2);
      pl.bad = Math.max(0, pl.bad - dt * 2.2);
    }
    if (pz && pz.mode !== 'done') {
      // 지금 밟고 있는 발판
      let on = -1;
      if (p.state === 'ground') {
        for (const pl of zs.plates) {
          if (Math.abs(p.pos.x - pl.def.x) < 1.05 && Math.abs(p.pos.z - pl.def.z) < 1.05) on = pl.def.i;
        }
      }
      const stepped = on >= 0 && on !== pz.on;
      pz.on = on;
      if (pz.mode === 'demo') {
        // 순서 보여 주기: 하나씩 차례로 빛난다
        pz.t += dt;
        const SLOT = zs.def.puzzle.slot || 0.7;
        const i = Math.floor(pz.t / SLOT);
        if (pz.t >= 0 && i < pz.seq.length) {
          if (i !== pz.shown) {
            pz.shown = i;
            g.audio.plate(pz.seq[i]);
          }
          if (pz.t - i * SLOT < SLOT * 0.72) zs.plates[pz.seq[i]].glow = 1;
        } else if (i >= pz.seq.length) {
          pz.mode = 'input';
          pz.idle = 0;
        }
        if (stepped) {
          // 보는 도중에 밟으면 바로 입력으로 넘어간다
          pz.mode = 'input';
          pz.idle = 0;
        }
      }
      if (pz.mode === 'input') {
        pz.idle += dt;
        if (stepped) {
          pz.idle = 0;
          const pl = zs.plates[on];
          if (on === pz.seq[pz.step]) {
            pz.step++;
            pl.flash = 1;
            g.audio.plate(on);
            g.fx.text(pl.def.x, F + 1.6, pl.def.z, `${pz.step}/${pz.seq.length}`, 'heal');
            if (pz.step >= pz.seq.length) {
              pz.mode = 'done';
              g.audio.puzzleOk();
              zs.open |= 1 << zs.def.puzzle.gate;
              g.net.send({ t: 'zopen', gate: zs.def.puzzle.gate });
              for (const q of zs.plates) q.flash = 1.4;
              g.audio.gate();
              g.ui.toast('퍼즐을 풀었습니다! 문이 열립니다.', true);
            }
          } else {
            // 틀렸다: 발판에서 불꽃이 튀어 데고, 순서가 새로 바뀐다
            pl.bad = 1;
            g.audio.puzzleFail();
            g.fx.text(pl.def.x, F + 1.6, pl.def.z, '틀렸다!', 'hurt');
            g.fx.burst(pl.def.x, F + 0.6, pl.def.z, 0xff6a3a, 16, 4, { size: 0.3, life: 0.5, grav: 4, glow: 2 });
            p.damage(Math.max(2, Math.round(p.maxHp * 0.15)), pl.def.x, pl.def.z, { raw: true, noKnock: true, force: true });
            const bad = on;
            this._newPuzzle(zs);
            zs.puzzle.t = -1.5;
            zs.puzzle.on = bad; // 밟고 서 있는 발판은 다시 밟은 것으로 치지 않는다
            if (!this._puzzleTold) {
              this._puzzleTold = true;
              g.ui.toast('틀리면 순서가 새로 바뀝니다. 끝까지 잘 보고 밟으세요!');
            }
          }
        } else if (pz.idle > 7 && pz.step === 0) {
          // 가만히 있으면 순서를 다시 보여 준다
          pz.mode = 'demo';
          pz.t = -0.4;
          pz.shown = -1;
        }
      }
    }
    for (const pl of zs.plates) {
      const k = 0.2 + pl.glow * 2.6 + pl.flash * 1.6;
      if (pl.bad > 0) pl.mat.color.setRGB(2.2 * pl.bad + 0.15, 0.1, 0.1);
      else if (pl.flash > 0 && pl.glow <= 0) pl.mat.color.setRGB(0.3 + pl.flash, 0.5 + pl.flash * 2, 0.4 + pl.flash);
      else pl.mat.color.copy(pl.base).multiplyScalar(k);
      pl.m.position.y = F + 0.12 - (pz && pz.on === pl.def.i ? 0.05 : 0);
    }
  }

  // ================= 매 프레임 =================
  update(dt, time) {
    const g = this.game;
    const p = g.player.pos;
    // 서 있는 곳으로 판단한다 (지도 이동이나 되살아나기로 옮겨져도 맞춰진다)
    const def = this.busy ? (this.cur ? this.cur.def : null) : zoneAt(p.x, p.z);
    const now = def ? this.list[def.id - 1] : null;
    if (now !== this.cur) this._setMode(now);
    if (this.cur) this._updateInside(this.cur, dt, time);
    else this._updateOutside(dt, time);
  }

  _updateOutside(dt, time) {
    const g = this.game;
    const { fx, save, ui } = g;
    const p = g.player.pos;
    const pulse = 0.75 + Math.sin(time * 2.2) * 0.25;
    this.matPortal.open.opacity = 0.42 * pulse + 0.12;
    this.matPortal.done.opacity = 0.3 * pulse + 0.12;
    this.matPortal.dungeon.opacity = 0.4 * pulse + 0.14;
    this.matPortal.raid.opacity = 0.42 * pulse + 0.16;
    const tb = this.tablet;
    if (tb.star.visible) {
      tb.star.rotation.z += dt * 0.9;
      const k = 0.62 + Math.sin(time * 2.4) * 0.05;
      tb.star.scale.setScalar(k);
      if (Math.random() < dt * 8 && Math.hypot(tb.x - p.x, tb.z - p.z) < 60) fx.spawn(tb.x + (Math.random() - 0.5) * 2.4, tb.y + 1 + Math.random() * 3.6, tb.z + (Math.random() - 0.5) * 1.2, 0, 0.5 + Math.random() * 0.6, 0, 0xffe27a, 0.12, 1.4, -0.2, 0.9, 2.8, 0.4, 0.2);
    }
    for (const zs of this.list) {
      const d = Math.hypot(zs.x - p.x, zs.z - p.z);
      if (d > 260) continue;
      if (zs.trial) {
        const star = zs.cleared ? zs.starB : zs.starA;
        star.rotation.y += dt * 1.3;
        star.position.y = zs.y + 7.6 + Math.sin(time * 1.7 + zs.id) * 0.22;
        if (!zs.found && d < 46) {
          zs.found = true;
          save.zfound.push(zs.id);
          ui.region('별의 시련장 발견', `${zs.def.name} · ${zs.def.sub} · Lv.${zs.def.level}`);
          ui.chatAdd('', `별의 시련장 「${zs.def.name}」을(를) 발견했습니다. 지도에 표시됩니다.`, 'sys');
          g.tip('z-trial', '별의 시련장을 통과하면 별의 인장을 얻어 체력이나 기력이 늘어납니다.');
          g.saveSoon();
        }
        if (d < 40 && Math.random() < dt * 6) {
          const a = Math.random() * TAU;
          fx.spawn(zs.x + Math.cos(a) * 1.1, zs.y + 0.6 + Math.random() * 4, zs.z + 0.1, 0, 0.5 + Math.random() * 0.5, 0, zs.cleared ? C_DONE : C_OPEN, 0.1, 1.4, -0.2, 0.9, 2.6, 0.4, 0.2);
        }
        continue;
      }
      if (zs.raid) {
        zs.starA.rotation.y += dt * 0.9;
        zs.starA.position.y = zs.y + 10.2 + Math.sin(time * 1.3) * 0.3;
        if (d < 60 && Math.random() < dt * 9) {
          const a = Math.random() * TAU;
          fx.spawn(zs.x + Math.cos(a) * 1.6, zs.y + 0.6 + Math.random() * 6, zs.z + 0.1, 0, 0.6 + Math.random() * 0.6, 0, C_RAID, 0.12, 1.5, -0.2, 0.9, 2.8, 0.4, 0.2);
        }
        if (d < 30) g.tip('z-raidgate', '금빛 문은 「레이드」로 들어가는 문입니다. 친구들과 함께 들어가 커다란 보스와 싸우는 곳이에요.');
        continue;
      }
      // 던전: 솟아오르는 문
      if (zs.rise >= 0) {
        zs.rise += dt / 2.6;
        const k = Math.min(1, zs.rise);
        const e = 1 - (1 - k) * (1 - k);
        zs.door.position.y = zs.y - 6.2 * (1 - e);
        if (d < 60) g.player.shake = Math.max(g.player.shake, 0.22 * (1 - k));
        if (Math.random() < dt * 30) fx.dust(zs.x + (Math.random() - 0.5) * 6, zs.y, zs.z + (Math.random() - 0.5) * 3, 2);
        if (k >= 1) {
          zs.rise = -1;
          fx.ring(zs.x, zs.y + 0.3, zs.z, C_DUNGEON, 7, 0.8);
        }
      }
      if (zs.found) {
        if (d < 40 && Math.random() < dt * 5) fx.spawn(zs.x + (Math.random() - 0.5) * 2.2, zs.y + 0.4 + Math.random() * 3.4, zs.z + 0.2, 0, 0.4, 0.3, C_DUNGEON, 0.1, 1.3, -0.2, 0.9, 2.6, 0.4, 0.2);
      } else if (d < 13) g.tip('z-hidden' + zs.id, '둥글게 놓인 돌들… 이 아래에 무언가 숨겨져 있는 것 같다. 근처의 오래된 돌등을 찾아 불을 밝혀 보자.');
      for (const l of zs.lamps) {
        const dl = Math.hypot(l.x - p.x, l.z - p.z);
        if (dl > 90) continue;
        if (!l.lit) {
          if (dl < 9) g.tip('z-lamp', '이끼 낀 오래된 돌등이다. 불을 밝힐 수 있을 것 같다.');
          continue;
        }
        const k = 1 + Math.sin(time * 9 + l.k * 2) * 0.12;
        l.core.scale.set(k, k, k);
        // 불빛이 입구 쪽으로 흘러간다 (길잡이)
        if (dl < 60 && Math.random() < dt * 7) {
          const dx = zs.x - l.x;
          const dz = zs.z - l.z;
          const dd = Math.hypot(dx, dz) || 1;
          fx.spawn(l.x, l.y + 1.9, l.z, (dx / dd) * 5, 0.5 + Math.random() * 0.4, (dz / dd) * 5, zs.theme.fire, 0.14, 2.2, 0.15, 1, 3, 0.3, 0.1);
        }
      }
    }
  }

  _updateInside(zs, dt, time) {
    const g = this.game;
    const { fx, player } = g;
    const p = player.pos;
    const def = zs.def;
    const T = zs.theme;

    // 관문: 열리면 바닥으로 내려간다
    for (const gt of zs.gates) {
      const want = zs.open & gt.bit ? 1 : 0;
      if (gt.y !== want) {
        gt.y = Math.max(0, Math.min(1, gt.y + (want ? dt / 0.9 : -dt / 0.4)));
        if (want && Math.random() < dt * 40) fx.dust(gt.def.x + (Math.random() - 0.5) * gt.def.tiles.length * TILE * (gt.def.horiz ? 1 : 0), F, gt.def.z + (Math.random() - 0.5) * gt.def.tiles.length * TILE * (gt.def.horiz ? 0 : 1), 2);
      }
      gt.grp.position.y = F - gt.y * (WALL_H + 0.4);
      gt.grp.visible = gt.y < 1;
    }

    // 화로 불꽃
    for (let i = 0; i < zs.fires.length; i++) {
      const f = zs.fires[i];
      const k = 1 + Math.sin(time * 11 + i) * 0.14 + Math.sin(time * 17 + i * 2) * 0.08;
      f.scale.set(1 + (k - 1) * 0.5, k, 1 + (k - 1) * 0.5);
      f.rotation.y = time * 2 + i;
      if (Math.random() < dt * 1.6) {
        const dx = f.position.x - p.x;
        const dz = f.position.z - p.z;
        if (dx * dx + dz * dz < 900) fx.spawn(f.position.x + (Math.random() - 0.5) * 0.4, F + 1.7, f.position.z + (Math.random() - 0.5) * 0.4, (Math.random() - 0.5) * 0.5, 1.2 + Math.random(), (Math.random() - 0.5) * 0.5, T.fire, 0.13, 1.1, -0.5, 0.9, 3, 0.5);
      }
    }

    // 불기둥 함정: 서버 시계에 맞춰 모두에게 똑같이 켜지고 꺼진다
    if (zs.flames.length) {
      const ts = g.net.serverNow() / 1000;
      // 갑옷과 상관없이 아프다: 적어도 최대 체력의 18% (damage 가 방어력을 빼므로 그만큼 더해 둔다)
      const dmg = Math.max(3 + Math.floor(def.level / 4), Math.round(player.maxHp * 0.18)) + player.def;
      let cue = false;
      for (const f of zs.flames) {
        const dx = f.def.x - p.x;
        const dz = f.def.z - p.z;
        const d2 = dx * dx + dz * dz;
        if (d2 > 70 * 70) {
          f.m.visible = false;
          continue;
        }
        const s = flameState(f.def, ts);
        const m = f.m;
        if (s >= 1) {
          if (f.on < 1 && d2 < 30 * 30) cue = true;
          const k = 1 + Math.sin(time * 23 + f.def.x) * 0.1;
          m.visible = true;
          m.scale.set(1.05, k, 1.05);
          m.rotation.y = time * 5 + f.def.x;
          if (d2 < 40 * 40 && Math.random() < dt * 9) fx.spawn(f.def.x + (Math.random() - 0.5) * 0.7, F + 0.4 + Math.random() * 2.2, f.def.z + (Math.random() - 0.5) * 0.7, (Math.random() - 0.5) * 1.2, 2 + Math.random() * 2, (Math.random() - 0.5) * 1.2, Math.random() < 0.3 ? 0xffd35a : 0xff6a1a, 0.16, 0.5, -1, 1, 3, 0.4);
          // 닿으면 덴다 (구르는 동안에는 피할 수 있다)
          if (Math.abs(dx) < 1.12 && Math.abs(dz) < 1.12 && p.y < F + 2.7 && player.state !== 'dead') player.damage(dmg, f.def.x, f.def.z, { knock: 5 });
        } else if (s > 0) {
          // 곧 켜진다: 작은 불씨가 인다
          m.visible = true;
          m.scale.set(0.3, 0.1 + s * 0.16, 0.3);
          if (d2 < 30 * 30 && Math.random() < dt * 14 * s) fx.spawn(f.def.x + (Math.random() - 0.5) * 0.5, F + 0.2, f.def.z + (Math.random() - 0.5) * 0.5, 0, 1.5 + Math.random(), 0, 0xffb040, 0.1, 0.35, -0.5, 1, 3);
        } else m.visible = false;
        f.on = s;
      }
      this.flameCue -= dt;
      if (cue && this.flameCue <= 0) {
        this.flameCue = 0.5;
        g.audio.flame();
      }
    }

    if (zs.plates.length) this._updatePuzzle(zs, dt);

    // 문양과 보상
    for (const s of zs.sigils) {
      const show = s.when();
      s.ring.visible = s.gem.visible = show;
      if (!show) continue;
      s.ring.rotation.y += dt * 0.8;
      s.gem.rotation.y -= dt * 1.6;
      s.gem.position.y = F + 1.5 + Math.sin(time * 2 + s.x) * 0.15;
    }
    if (zs.seal) {
      zs.seal.visible = !zs.cleared;
      zs.seal.rotation.y += dt * 1.4;
      zs.seal.position.y = F + 2.5 + Math.sin(time * 1.8) * 0.16;
      if (!zs.cleared && Math.random() < dt * 5) fx.spawn(def.altar.x + (Math.random() - 0.5) * 1.4, F + 1.6 + Math.random() * 1.6, def.altar.z + (Math.random() - 0.5) * 1.4, 0, 0.6, 0, 0xfff2a8, 0.12, 1.1, -0.2, 1, 2.8);
    }
    const looted = g.save.zchest[zs.id] === zs.epoch && zs.epoch > 0;
    if (zs.raid && !looted && g.save.rkill !== zs.epoch && zs.open & 2) {
      const c = def.chests[0];
      if (Math.hypot(p.x - c.x, p.z - c.z) < 4) g.tip('raid-late', '이 보물상자는 별 포식자와 함께 싸운 사람만 열 수 있습니다. 다음 싸움에 함께하세요!');
    }
    for (const c of zs.chests) {
      if (looted && c.lid.rotation.x > -1.9) c.lid.rotation.x = Math.max(-1.9, c.lid.rotation.x - dt * 5);
      if (!looted && Math.random() < dt * 4) fx.spawn(c.x + (Math.random() - 0.5) * 1.4, F + 0.9 + Math.random() * 0.6, c.z + (Math.random() - 0.5) * 0.9, 0, 0.7, 0, 0xffe27a, 0.2, 0.9, -0.2, 1, 2.6);
    }

    // 떠다니는 먼지와 불티
    this.moteT -= dt;
    if (this.moteT <= 0 && g.gfx.quality.ambient > 0) {
      this.moteT = 0.09 / g.gfx.quality.ambient;
      const a = Math.random() * TAU;
      const r = 2 + Math.random() * 16;
      fx.spawn(p.x + Math.cos(a) * r, F + 0.4 + Math.random() * 4, p.z + Math.sin(a) * r, (Math.random() - 0.5) * 0.3, 0.08 + Math.random() * 0.2, (Math.random() - 0.5) * 0.3, Math.random() < 0.3 ? T.glow : 0xd8d0c0, 0.05 + Math.random() * 0.05, 4 + Math.random() * 3, 0, 0.5, Math.random() < 0.3 ? 2.6 : 1, 0.5, 1);
    }

    if (zs.raid) this._updateRaid(zs, dt, time);
    // 던전 보스가 덤벼들기 시작하면 알린다
    if (!zs.trial && !zs.bossIntro) {
      const b = this.boss();
      if (b && (b.lastState === MSTATE.CHASE || b.lastState === MSTATE.WINDUP)) {
        zs.bossIntro = true;
        g.audio.roar();
        g.ui.banner(b.info.name, zs.raid ? '잠든 별을 삼킨 거인' : `${def.name}의 주인`);
      }
    }
  }

  // 지금 있는 던전의 보스 (화면에 나타나 있을 때만)
  boss() {
    const zs = this.cur;
    if (!zs || zs.trial) return null;
    for (const e of this.game.ents.monsters.values()) {
      if (e.info.boss && e.info.zone === zs.id && e.shown && !e.dying) return e;
    }
    return null;
  }

  // ================= 플레이어 충돌 =================
  // 벽·닫힌 관문·화로 바깥으로 밀어낸다. R: 몸의 반지름, (fromX, fromZ): 이번에 움직이기 전의 자리
  // 한 번에 멀리 움직였을 때(구르기, 느린 기기)는 잘게 나눠 따라가며 막는다. 벽을 뚫고 들어가는 일이 없도록.
  collide(p, R, fromX, fromZ) {
    const zs = this.cur;
    if (!zs) return;
    if (fromX === undefined || !Number.isFinite(fromX)) return this._pushOut(zs, p, R, p.x, p.z);
    const dx = p.x - fromX;
    const dz = p.z - fromZ;
    const dist = Math.hypot(dx, dz);
    if (dist > 6) return this._pushOut(zs, p, R, p.x, p.z); // 순간 이동
    const n = Math.max(1, Math.ceil(dist / 0.28));
    let sx = fromX;
    let sz = fromZ;
    for (let i = 1; i <= n; i++) {
      p.x = sx + dx / n;
      p.z = sz + dz / n;
      this._pushOut(zs, p, R, sx, sz);
      sx = p.x;
      sz = p.z;
    }
  }

  // (backX, backZ): 벽 속에 완전히 갇혔을 때 되돌아갈 자리
  _pushOut(zs, p, R, backX, backZ) {
    const def = zs.def;
    for (let pass = 0; pass < 2; pass++) {
      const c0 = Math.floor((p.x - R - def.ox) / TILE);
      const c1 = Math.floor((p.x + R - def.ox) / TILE);
      const r0 = Math.floor((p.z - R - def.oz) / TILE);
      const r1 = Math.floor((p.z + R - def.oz) / TILE);
      for (let r = r0; r <= r1; r++) {
        for (let c = c0; c <= c1; c++) {
          if (!tileSolid(def, c, r, zs.open)) continue;
          const x0 = def.ox + c * TILE;
          const z0 = def.oz + r * TILE;
          const qx = Math.max(x0, Math.min(p.x, x0 + TILE));
          const qz = Math.max(z0, Math.min(p.z, z0 + TILE));
          const dx = p.x - qx;
          const dz = p.z - qz;
          const d2 = dx * dx + dz * dz;
          if (d2 >= R * R) continue;
          if (d2 > 1e-8) {
            const d = Math.sqrt(d2);
            p.x = qx + (dx / d) * R;
            p.z = qz + (dz / d) * R;
          } else {
            // 칸 안쪽에 들어와 버렸다: 가장 가까운, 비어 있는 쪽으로 내보낸다
            const opts = [
              [p.x - x0, -1, 0], [x0 + TILE - p.x, 1, 0], [p.z - z0, 0, -1], [z0 + TILE - p.z, 0, 1],
            ].filter(([, sx, sz]) => !tileSolid(def, c + sx, r + sz, zs.open)).sort((a, b) => a[0] - b[0]);
            if (opts.length) {
              const [dist, sx, sz] = opts[0];
              p.x += sx * (dist + R);
              p.z += sz * (dist + R);
            } else if (!tileSolid(def, Math.floor((backX - def.ox) / TILE), Math.floor((backZ - def.oz) / TILE), zs.open)) {
              p.x = backX;
              p.z = backZ;
            }
          }
        }
      }
    }
    for (const s of zs.solids) {
      const dx = p.x - s.x;
      const dz = p.z - s.z;
      const rr = s.r + R;
      const d2 = dx * dx + dz * dz;
      if (d2 >= rr * rr) continue;
      const d = Math.sqrt(d2) || 1e-3;
      p.x = s.x + (dx / d) * rr;
      p.z = s.z + (dz / d) * rr;
    }
  }

  // ================= 지도 =================
  // 작은 지도에 깔리는 실내 평면도 (관문이 열릴 때만 다시 그린다)
  mapCanvas(zs) {
    if (zs.mapCv && zs.mapOpen === zs.open && zs.mapDone === zs.cleared) return zs.mapCv;
    const def = zs.def;
    const K = 8;
    const cv = zs.mapCv || document.createElement('canvas');
    cv.width = def.tileW * K;
    cv.height = def.tileH * K;
    const ctx = cv.getContext('2d');
    ctx.clearRect(0, 0, cv.width, cv.height);
    const T = zs.theme;
    for (let r = 0; r < def.tileH; r++) {
      for (let c = 0; c < def.tileW; c++) {
        const ch = def.rows[r][c];
        if (ch === ' ') continue;
        if (ch === '#') {
          ctx.fillStyle = css(T.wall[0]);
          ctx.fillRect(c * K, r * K, K, K);
          continue;
        }
        ctx.fillStyle = (c + r) % 2 ? '#39425a' : '#343c52';
        ctx.fillRect(c * K, r * K, K, K);
        if (ch >= '1' && ch <= '9') {
          if (!((zs.open >> +ch) & 1)) {
            ctx.fillStyle = def.puzzle && def.puzzle.gate === +ch ? '#5ab8ff' : '#ff5a4a';
            ctx.fillRect(c * K, r * K + 2, K, K - 4);
          }
        } else if (ch === 'f' || ch === 'F') {
          ctx.fillStyle = '#ff8a3a';
          ctx.fillRect(c * K + 2, r * K + 2, K - 4, K - 4);
        } else if (ch === 'p') {
          ctx.fillStyle = '#5ab8ff';
          ctx.fillRect(c * K + 1, r * K + 1, K - 2, K - 2);
        } else if (ch === 'S' || ch === 'E') {
          ctx.fillStyle = '#9fe8ff';
          ctx.beginPath();
          ctx.arc(c * K + K / 2, r * K + K / 2, K * 0.42, 0, 6.3);
          ctx.fill();
        } else if (ch === 'R' || ch === 'C') {
          ctx.fillStyle = ch === 'R' && zs.cleared ? '#8a94a8' : '#ffd35a';
          ctx.beginPath();
          ctx.arc(c * K + K / 2, r * K + K / 2, K * 0.5, 0, 6.3);
          ctx.fill();
        }
      }
    }
    zs.mapCv = cv;
    zs.mapOpen = zs.open;
    zs.mapDone = zs.cleared;
    return cv;
  }

  // 지도와 기록에 쓰는 요약
  summary() {
    const s = this.game.save;
    return {
      seals: s.trials.length, trials: TRIAL_COUNT,
      found: this.list.filter((z) => !z.trial && !z.raid && z.found).length,
      cleared: s.dclear.length,
      dungeons: DUNGEON_COUNT,
      raidWins: s.raidWins || 0,
    };
  }
}

// 움직이는 것들: 다른 플레이어, 몬스터, 화살·투사체, 몬스터 공격 판정
import * as THREE from '/vendor/three/three.module.js';
import { ANIM, MON, MON_TYPES, MSTATE, ELITE_NAMES, GOLEM_NAMES, TUNIC_COLORS, WEAPONS, MOUNT_KEYS, HP_SHOW, RAID, isRiding, monStats, cycleScale } from '/shared/defs.js';
import { readSnap } from '/shared/proto.js';
import { ZONES, ZONE_FLOOR, WALL_H, zoneIdAt, zoneSolid, zoneClearLine, zoneTough } from '/shared/zones.js';
import { Geo, M } from './geo.js';
import { makeHumanoid, animateHumanoid, makeMonster, animateMonster, playerLook, makeHorse, animateHorse, attackProgress, slopePitch, seatRider } from './models.js';
import { makeLabel } from './objects.js';

const INTERP_MS = 200; // 이만큼 과거의 모습을 그려서 끊김 없이 보간한다
const TAU = Math.PI * 2;

function angDiff(a, b) {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}

// 시간순 상태 버퍼에서 보간
function sample(buf, t, out) {
  const n = buf.length;
  if (n === 0) return false;
  if (t <= buf[0].t || n === 1) {
    Object.assign(out, buf[0]);
    out.k = 0;
    return true;
  }
  for (let i = n - 1; i >= 1; i--) {
    const a = buf[i - 1];
    const b = buf[i];
    if (t >= a.t) {
      if (t >= b.t) {
        Object.assign(out, b);
        return true;
      }
      // 멀리 순간 이동했으면(귀환석, 시련장 드나들기) 사이를 잇지 않는다
      if (Math.abs(b.x - a.x) + Math.abs(b.z - a.z) > 60) {
        Object.assign(out, b);
        return true;
      }
      const k = (t - a.t) / (b.t - a.t || 1);
      out.x = a.x + (b.x - a.x) * k;
      out.y = a.y + (b.y - a.y) * k;
      out.z = a.z + (b.z - a.z) * k;
      out.yaw = a.yaw + angDiff(a.yaw, b.yaw) * k;
      out.anim = b.anim;
      out.state = b.state;
      out.hp = b.hp;
      out.maxHp = b.maxHp;
      return true;
    }
  }
  Object.assign(out, buf[n - 1]);
  return true;
}
const _s = { t: 0, x: 0, y: 0, z: 0, yaw: 0, anim: 0, state: 0, hp: 0, maxHp: 0 };

export class Entities {
  constructor(game) {
    this.game = game;
    this.scene = game.gfx.scene;
    this.players = new Map();
    this.monsters = new Map();
    this.spawnInfo = [];
    this.rigPool = new Map();
    this.snapSeq = 0;
    this.clockOff = null;
    this.projectiles = [];
    this.strikes = [];
    this.colliders = [];
    this.objects = null;
    this.myId = 0;
    this.target = null; // 최근에 때린/가까운 몬스터 (상단 정보창용)
    this.targetT = 0;

    // 체력 막대
    this.barGeo = new THREE.PlaneGeometry(1, 1);
    this.barBg = new THREE.MeshBasicMaterial({ color: 0x1a1a22, transparent: true, opacity: 0.7, depthWrite: false, fog: false });
    this.barFg = new THREE.MeshBasicMaterial({ color: 0xff4a4a, depthWrite: false, fog: false });
    this.barElite = new THREE.MeshBasicMaterial({ color: 0xffb02a, depthWrite: false, fog: false });

    // 투사체 모델
    const ag = new Geo();
    ag.box(0.05, 0.05, 1.0, M(0, 0, 0), 0x8a623c, 0xc9a05a);
    ag.cone(0.09, 0.22, 4, M(0, 0, 0.6, Math.PI / 2, 0, 0), 0xdfe7ee);
    ag.box(0.2, 0.02, 0.22, M(0, 0, -0.42), 0xf2f2f2);
    ag.box(0.02, 0.2, 0.22, M(0, 0, -0.42), 0xf2f2f2);
    this.arrowGeo = ag.build(false);
    const rg = new Geo();
    rg.ico(0.26, 0, null, 0x7f848c, 0xb0b5bd, 0.4, 3);
    this.rockGeo = rg.build(false);
    const fg = new Geo();
    fg.ico(0.34, 0, null, 0xff7a1a, 0xffd35a, 0.3, 5);
    this.fireGeo = fg.build(false);
    const mg = new Geo();
    mg.ico(0.9, 0, null, 0x7a2a8a, 0xff5ad0, 0.4, 7);
    this.meteorGeo = mg.build(false);
  }

  setSpawns(list, cycle) {
    this.cycle = cycle;
    this.spawnInfo = list.map((s, id) => {
      const type = MON_TYPES[s[0]];
      const elite = !!(s[5] & 1);
      const def = MON[type];
      let name = def.name;
      if (elite) name = ELITE_NAMES[type] || name;
      if (type === 'golem') name = GOLEM_NAMES[s[4]] || name;
      // 시련장·던전 안의 몬스터 (던전의 몬스터는 더 좋은 것을 떨어뜨린다)
      const zone = s[7] || 0;
      const dungeon = zone > 0 && ZONES[zone - 1].kind === 'dungeon';
      const raid = zone > 0 && ZONES[zone - 1].kind === 'raid';
      return { id, type, level: s[1], x: s[2], z: s[3], biome: s[4], elite, boss: !!(s[5] & 2), minion: !!(s[5] & 4), shard: s[6], zone, dungeon, raid, def, name, radius: def.radius * (elite ? 1.45 : 1) };
    });
  }

  maxHpOf(info) {
    // 레이드에서 불려 나오는 것들의 체력은 레벨과 상관없이 정해져 있다 (보스의 체력은 사람 수에 달렸으므로 한 사람 몫을 어림으로 쓴다)
    if (info.raid) return RAID.unit * (info.def.fixed ? RAID.pylonHits : info.boss ? RAID.hpHits : RAID.addHits);
    return Math.round(monStats(info.type, info.level, info.elite, info.zone > 0).hp * zoneTough(info.zone, info.boss)[0] * cycleScale(this.cycle));
  }

  // ---------------- 다른 플레이어 ----------------
  addPlayer(p) {
    this.removePlayer(p.id);
    const rig = makeHumanoid(playerLook(p));
    this.scene.add(rig.root);
    // 결투 모드를 켠 사람은 이름이 붉게, 칼 표시와 함께 보인다
    // 레이드를 이긴 적이 있으면 이름 앞에 별이 붙는다
    const label = makeLabel((p.pv ? '⚔ ' : '') + (p.rw ? '★ ' : '') + p.name, p.pv ? '#ff9a8a' : p.rw ? '#ffe9a0' : '#ffffff', `Lv.${p.lvl}`);
    this.scene.add(label);
    const blob = this.game.fx.makeBlob(0.55);
    this.scene.add(blob);
    rig.root.visible = false;
    label.visible = false;
    blob.visible = false;
    const wk = p.eq && p.eq.weapon && WEAPONS[p.eq.weapon.t] ? p.eq.weapon.t : 'sword';
    const e = { id: p.id, prof: p, rig, label, blob, horse: null, wk, buf: [], x: 0, y: 0, z: 0, yaw: 0, anim: 0, hp: 6, maxHp: 6, atkT: 0, lastAnim: 0, seen: false, px: 0, pz: 0 };
    this.players.set(p.id, e);
    return e;
  }

  updatePlayerProfile(p) {
    const old = this.players.get(p.id);
    const e = this.addPlayer(p);
    if (old) {
      e.buf = old.buf;
      e.seen = old.seen;
    }
  }

  removePlayer(id) {
    const e = this.players.get(id);
    if (!e) return;
    this.scene.remove(e.rig.root, e.label, e.blob);
    disposeTree(e.rig.root);
    if (e.horse) {
      this.scene.remove(e.horse.root);
      disposeTree(e.horse.root);
    }
    e.label.material.map.dispose();
    e.label.material.dispose();
    this.players.delete(id);
  }

  clearPlayers() {
    for (const id of [...this.players.keys()]) this.removePlayer(id);
  }

  // ---------------- 몬스터 ----------------
  _getRig(info) {
    const key = `${info.type}|${info.biome}|${info.elite ? 1 : 0}|${info.minion ? 1 : 0}`;
    const pool = this.rigPool.get(key);
    if (pool && pool.length) return pool.pop();
    const rig = makeMonster(info.type, info.biome, info.elite, info.minion);
    rig.poolKey = key;
    return rig;
  }

  _addMonster(id) {
    const info = this.spawnInfo[id];
    if (!info) return null;
    const rig = this._getRig(info);
    rig.root.visible = false;
    this.scene.add(rig.root);
    const bar = new THREE.Group();
    const w = info.boss || info.type === 'golem' ? 3.2 : info.elite ? 2.2 : 1.5;
    const bg = new THREE.Mesh(this.barGeo, this.barBg);
    bg.scale.set(w + 0.1, 0.24, 1);
    const fg = new THREE.Mesh(this.barGeo, info.elite || info.type === 'golem' || info.boss ? this.barElite : this.barFg);
    fg.scale.set(w, 0.15, 1);
    fg.position.z = 0.01;
    fg.renderOrder = 12;
    bg.renderOrder = 11;
    bar.add(bg, fg);
    bar.visible = false;
    this.scene.add(bar);
    const blob = this.game.fx.makeBlob(info.radius * 1.05);
    this.scene.add(blob);
    const e = {
      id, info, rig, bar, barFg: fg, barW: w, blob, buf: [], seq: 0, lastSeen: performance.now(),
      x: info.x, z: info.z, y: 0, yaw: 0, state: 0, hp5: 31, hp: this.maxHpOf(info), maxHp: this.maxHpOf(info),
      pattern: null, strikeT: 9, flash: 0, speed: 0, px: info.x, pz: info.z, shown: false, lastState: 0,
    };
    this.monsters.set(id, e);
    return e;
  }

  _removeMonster(e) {
    this.scene.remove(e.rig.root, e.bar, e.blob);
    e.rig.root.scale.setScalar(e.rig.root.userData.baseScale || e.rig.root.scale.x);
    let pool = this.rigPool.get(e.rig.poolKey);
    if (!pool) this.rigPool.set(e.rig.poolKey, (pool = []));
    if (pool.length < 6) pool.push(e.rig);
    else disposeTree(e.rig.root);
    this.monsters.delete(e.id);
    if (this.target === e) this.target = null;
  }

  clearMonsters() {
    for (const e of [...this.monsters.values()]) this._removeMonster(e);
  }

  // ---------------- 스냅샷 수신 ----------------
  onSnapshot(dv) {
    const net = this.game.net;
    const t = net.expandTime(dv.getUint32(1));
    const seq = ++this.snapSeq;
    const nowMs = performance.now();
    // 스냅샷 도착 시각으로 서버 시계를 추정한다 (가장 빨리 도착한 패킷 기준, 천천히 보정)
    const d = t - Date.now();
    if (this.clockOff === null || Math.abs(d - this.clockOff) > 2000) this.clockOff = d;
    else this.clockOff = Math.max(d, this.clockOff - 0.4);
    readSnap(
      dv,
      (id, x, y, z, yaw, anim, hp, maxHp) => {
        const e = this.players.get(id);
        if (!e) return;
        e.buf.push({ t, x, y, z, yaw, anim, hp, maxHp, state: 0 });
        if (e.buf.length > 12) e.buf.shift();
      },
      (id, x, z, yaw, sb) => {
        let e = this.monsters.get(id);
        if (!e) e = this._addMonster(id);
        if (!e || e.dying) return;
        e.seq = seq;
        e.lastSeen = nowMs;
        e.buf.push({ t, x, y: 0, z, yaw, state: sb & 7, hp: sb >> 3, anim: 0, maxHp: 31 });
        if (e.buf.length > 12) e.buf.shift();
      }
    );
    // 한동안 스냅샷에 없으면 시야 밖으로 나간 것 (가만히 있는 몬스터는 0.5초마다 온다)
    for (const e of this.monsters.values()) {
      if (e.seq !== seq && !e.dying && nowMs - e.lastSeen > 1400) this._removeMonster(e);
    }
  }

  // ---------------- 이벤트 ----------------
  onHit(msg) {
    const e = this.monsters.get(msg.id);
    if (!e) return;
    if (msg.x === 'guard') {
      // 방패에 막혔다
      const gy = e.y + e.info.def.height * 0.6;
      this.game.fx.text(e.x + (Math.random() - 0.5) * 2, gy, e.z, '막힘', 'dmg other');
      this.game.fx.burst(e.x, gy, e.z, 0x9ab8ff, 6, 5, { size: 0.3, life: 0.3, glow: 2.4 });
      if (msg.by === this.myId) this.game.tip('raid-guard', '별 포식자가 방패를 둘렀습니다. 방 모퉁이의 사슬 기둥을 부숴야 해요!');
      return;
    }
    e.hp = msg.hp;
    e.flash = Math.max(e.flash, 0.16);
    e.hitShow = 4;
    this.target = e;
    this.targetT = 5;
    const g = this.game;
    const mine = msg.by === this.myId;
    const y = e.y + e.info.def.height * (e.info.elite ? 1.45 : 1) * 0.8;
    // 히든 무기의 효과: 독(초록 숫자), 번개, 얼림, 빛의 파동
    if (msg.x === 'poison') {
      g.fx.text(e.x + (Math.random() - 0.5), y + 0.2, e.z, String(msg.d), 'heal');
      g.fx.burst(e.x, y - 0.5, e.z, 0x7dff8a, 4, 1.6, { size: 0.2, life: 0.5, grav: -1 });
      return;
    }
    if (msg.x === 'bolt') {
      g.fx.impact(e.x, y - 0.3, e.z, 0xfff06a, 1.5);
      g.fx.burst(e.x, y - 0.3, e.z, 0xfff9c0, 10, 6, { size: 0.24, life: 0.3, grav: 4, glow: 2.6 });
    } else if (msg.x === 'frost') {
      e.slowT = 3;
      g.fx.burst(e.x, y - 0.4, e.z, 0xbfe9ff, 8, 3, { size: 0.24, life: 0.6, grav: 2, glow: 2 });
    } else if (msg.x === 'wave') g.fx.impact(e.x, y - 0.3, e.z, 0xffe27a, 1.4);
    else if (mine) g.player.onLeechHit(e.x, y, e.z);
    g.fx.text(e.x, y + 0.4, e.z, msg.c ? `${msg.d}!` : String(msg.d), msg.c ? 'crit' : mine ? 'dmg' : 'dmg other');
    if (msg.c) {
      // 치명타: 금빛 섬광
      g.fx.impact(e.x, y - 0.3, e.z, 0xffe27a, 1.7);
      g.fx.burst(e.x, y - 0.3, e.z, 0xffe27a, 14, 6, { size: 0.26, life: 0.35, grav: 9, glow: 2.4 });
      if (mine) {
        g.hitStop = Math.max(g.hitStop || 0, 0.07);
        g.player.shake = Math.max(g.player.shake, 0.3);
        g.audio.crit();
      }
    } else if (!mine) g.fx.burst(e.x, y - 0.3, e.z, 0xffffff, 6, 4, { size: 0.26, life: 0.3, grav: 9 });
    if (!mine) g.audio.hit(0.4);
    if (msg.s) this.cancelStrikes(msg.id);
  }

  // 내 공격이 닿은 순간의 반응 (서버 응답을 기다리지 않고 바로 보여 준다): 섬광, 불꽃, 움찔하며 밀려남
  localHit(id, px, pz, h, color) {
    const e = this.monsters.get(id);
    if (!e) return;
    const g = this.game;
    const info = e.info;
    let dx = e.x - px;
    let dz = e.z - pz;
    const d = Math.hypot(dx, dz) || 1;
    dx /= d;
    dz /= d;
    e.flash = 0.2;
    const heavy = info.boss || info.type === 'golem' ? 0.2 : info.elite || info.type === 'yeti' ? 0.5 : 1;
    const pw = Math.min(1.1, h.kb * 0.07) * heavy;
    e.sx = dx * pw;
    e.sz = dz * pw;
    const hy = e.y + info.def.height * (info.elite ? 1.45 : 1) * 0.55;
    const ix = e.x - dx * info.radius * 0.7;
    const iz = e.z - dz * info.radius * 0.7;
    g.fx.impact(ix, hy, iz, color, 0.75 + h.shake * 1.7);
    const n = 5 + Math.round(h.shake * 16);
    for (let i = 0; i < n; i++) {
      // 맞은 방향으로 튀는 불꽃
      const sp = 4 + Math.random() * 7;
      g.fx.spawn(ix, hy, iz, dx * sp * (0.3 + Math.random() * 0.7) + (Math.random() - 0.5) * 5, 1 + Math.random() * 4.5, dz * sp * (0.3 + Math.random() * 0.7) + (Math.random() - 0.5) * 5, i % 3 ? 0xffffff : color, 0.14 + Math.random() * 0.1, 0.22 + Math.random() * 0.2, 13, 1, 2.6);
    }
  }

  onMonsterDead(msg) {
    const e = this.monsters.get(msg.id);
    const g = this.game;
    this.cancelStrikes(msg.id);
    if (!e) return null;
    const info = e.info;
    const col = info.type === 'slime' ? 0x9fe89a : info.type === 'golem' ? 0xb0b5bd : info.boss ? 0xff5ad0 : 0xfff0c0;
    const h = info.def.height * 0.5;
    g.fx.burst(e.x, e.y + h, e.z, col, info.boss ? 60 : 18, info.boss ? 9 : 5, { size: info.boss ? 0.7 : 0.4, life: 0.8, grav: 5 });
    g.fx.ring(e.x, e.y + 0.3, e.z, col, info.radius * 3 + 1, 0.45);
    g.audio.pop(info.boss || info.type === 'golem');
    e.dying = 0.28;
    e.bar.visible = false;
    return e;
  }

  // 몬스터 공격 예고 -> 바닥 표시 + 내 캐릭터 피격 판정 예약
  onMonsterAttack(msg) {
    const g = this.game;
    const e = this.monsters.get(msg.id);
    if (e) {
      e.pattern = msg.k;
      e.windupUntil = performance.now() + msg.d;
      e.strikeT = -msg.d / 1000;
      e.atkYaw = msg.yaw;
    }
    const now = performance.now();
    const add = (shape, delay, opts = {}) => {
      const tele = opts.noTele ? null : g.fx.telegraph(shape, msg.d, delay, opts.color || (msg.k === 'meteor' ? 0xc04aff : 0xff3a2a));
      const s = { id: msg.id, at: now + msg.d + delay, shape, dmg: msg.dmg, pct: msg.pct || 0, tele, kind: msg.k, ...opts };
      this.strikes.push(s);
      return s;
    };
    const big = e && (e.info.boss || e.info.type === 'golem' || e.info.type === 'yeti');
    if (msg.k === 'arc') add({ kind: 'arc', x: msg.x, z: msg.z, yaw: msg.yaw, r: msg.r, half: msg.half }, 0, { knock: big ? 11 : 7 });
    else if (msg.k === 'slam') add({ kind: 'circle', x: msg.x, z: msg.z, r: msg.r }, 0, { knock: 11, jumpable: true, big: true });
    else if (msg.k === 'lunge') add({ kind: 'line', x: msg.x, z: msg.z, yaw: msg.yaw, len: msg.dash + msg.r * 0.6, w: msg.r }, 0, { knock: big ? 12 : 7 });
    else if (msg.k === 'meteor') {
      for (const p of msg.pts) add({ kind: 'circle', x: p[0], z: p[1], r: msg.r }, p[2], { knock: 8, jumpable: false, big: true, meteor: true });
      g.audio.roar();
    } else if (msg.k === 'roar') g.audio.roar();
    else if (msg.k === 'nova') {
      // 고리 충격파: 안쪽에 바짝 붙거나 바깥으로 벗어난다 (뛰어넘을 수도 있다)
      add({ kind: 'ring', x: msg.x, z: msg.z, r0: msg.r0, r1: msg.r1 }, 0, { knock: 10, jumpable: true, big: true });
      g.tip('atk-nova', '붉은 고리는 충격파입니다. 보스에게 바짝 붙거나 고리 밖으로 벗어나세요. 때맞춰 뛰어넘거나 구르기로도 피할 수 있어요.');
    } else if (msg.k === 'cross') {
      g.tip('atk-cross', '보스에게서 여러 갈래로 뻗는 붉은 줄은 「십자 가르기」입니다. 줄과 줄 사이에 서세요.');
      // 십자 가르기: 보스에게서 뻗어 나가는 여러 갈래의 줄
      for (let i = 0; i < msg.n; i++) add({ kind: 'line', x: msg.x, z: msg.z, yaw: msg.a + (i / msg.n) * TAU, len: msg.len, w: msg.w }, 0, { knock: 10, big: i === 0, burst: true });
    } else if (msg.k === 'split') {
      // 별똥 나누기: 한 사람을 따라다니는 원. 그 안에 모인 사람들이 피해를 나눠 받는다
      const s = add({ kind: 'circle', x: msg.x, z: msg.z, r: msg.r }, 0, { knock: 6, big: true, split: msg.pid, color: 0xffd35a });
      const who = this._bodyOf(msg.pid);
      if (who) {
        s.shape.x = who.x;
        s.shape.z = who.z;
        g.fx.cancelTelegraph(s.tele);
        s.tele = g.fx.telegraph(s.shape, msg.d, 0, 0xffd35a);
        s.ox = who.x;
        s.oz = who.z;
      }
      g.zones.onRaidSplit(msg);
    } else if (msg.k === 'wipe') {
      // 별 삼키기: 끝까지 외우면 방 안의 모두가 쓰러진다 (사슬 기둥을 모두 부수면 끊긴다). 예고 무늬는 없고 화면에 남은 시간이 뜬다
      add({ kind: 'circle', x: msg.x, z: msg.z, r: 400 }, 400, { noTele: true, wipe: true, noKnock: true });
      g.zones.onRaidCast(msg);
    }
  }

  // 플레이어 번호 -> 지금 서 있는 자리 (나 또는 다른 모험가)
  _bodyOf(pid) {
    if (pid === this.myId) return this.game.player.pos;
    const e = this.players.get(pid);
    return e && e.seen ? e : null;
  }

  cancelStrikes(id) {
    for (const s of this.strikes) {
      if (s.id === id && !s.meteor) {
        s.dead = true;
        this.game.fx.cancelTelegraph(s.tele);
      }
    }
    const e = this.monsters.get(id);
    if (e) e.pattern = null;
  }

  _inShape(shape, px, pz) {
    const dx = px - shape.x;
    const dz = pz - shape.z;
    if (shape.kind === 'circle') return dx * dx + dz * dz <= (shape.r + 0.3) * (shape.r + 0.3);
    if (shape.kind === 'ring') {
      const d2 = dx * dx + dz * dz;
      return d2 >= (shape.r0 - 0.2) * (shape.r0 - 0.2) && d2 <= (shape.r1 + 0.3) * (shape.r1 + 0.3);
    }
    if (shape.kind === 'arc') {
      const d = Math.hypot(dx, dz);
      if (d > shape.r + 0.3) return false;
      if (d < 1.0) return true;
      return Math.abs(angDiff(shape.yaw, Math.atan2(dx, dz))) <= shape.half + 0.1;
    }
    // line: yaw 방향으로 len, 폭 w
    const fx = Math.sin(shape.yaw);
    const fz = Math.cos(shape.yaw);
    const along = dx * fx + dz * fz;
    const side = Math.abs(dx * fz - dz * fx);
    return along >= -0.6 && along <= shape.len + 0.4 && side <= shape.w + 0.3;
  }

  _resolveStrike(s) {
    const g = this.game;
    const pl = g.player;
    const sx = s.shape.x;
    const sz = s.shape.z;
    const gy = Math.max(g.world.heightAt(sx, sz), 0);
    if (s.wipe) {
      // 별 삼키기가 끝났다: 온 방이 빛을 잃는다
      g.zones.onRaidWipe();
      if (pl.state !== 'dead' && g.zone) pl.damage(Math.ceil(pl.maxHp * s.pct), sx, sz, { raw: true, noKnock: true, force: true });
      return;
    }
    if (s.big) {
      g.fx.ring(sx, gy + 0.2, sz, s.meteor ? 0xc04aff : s.split ? 0xffd35a : 0xffc08a, (s.shape.r1 || s.shape.r || 3) * 1.1, 0.4);
      g.fx.dust(sx, gy, sz, 10);
      const d = Math.hypot(pl.pos.x - sx, pl.pos.z - sz);
      if (d < 40) {
        pl.shake = Math.max(pl.shake, 0.5 * (1 - d / 40));
        g.audio.thud();
      }
    }
    if (s.burst) {
      // 줄을 따라 흙먼지가 솟는다
      const fx = Math.sin(s.shape.yaw);
      const fz = Math.cos(s.shape.yaw);
      for (let d = 3; d < s.shape.len; d += 5) g.fx.dust(sx + fx * d, gy, sz + fz * d, 3);
    }
    if (pl.state === 'dead') return;
    if (Math.abs(pl.pos.y - gy) > 5) return;
    if (s.jumpable && pl.pos.y - pl.groundH > 1.2) return;
    if (!this._inShape(s.shape, pl.pos.x, pl.pos.z)) return;
    const e = this.monsters.get(s.id);
    let amount = s.pct ? Math.ceil(pl.maxHp * s.pct) : s.dmg;
    if (s.split) {
      // 원 안에 함께 선 사람 수만큼 나눈다
      let n = 1;
      for (const q of this.players.values()) {
        if (q.seen && q.zone === (g.zone ? g.zone.id : 0) && q.anim !== ANIM.DEAD && q.hp > 0 && this._inShape(s.shape, q.x, q.z)) n++;
      }
      amount = Math.ceil(amount / n);
      g.fx.text(pl.pos.x, pl.pos.y + 2.6, pl.pos.z, n > 1 ? `${n}명이 나눠 받았다!` : '혼자 받았다!', n > 1 ? 'heal' : 'hurt');
    }
    pl.damage(amount, e ? e.x : sx, e ? e.z : sz, { knock: s.knock, pct: !!s.pct, noKnock: !!s.noKnock });
  }

  onProjectile(msg) {
    const geo = msg.k === 'fire' ? this.fireGeo : this.rockGeo;
    const m = new THREE.Mesh(geo, msg.k === 'fire' ? this.game.gfx.matGlow : this.game.gfx.matChar);
    m.position.set(msg.x, msg.y, msg.z);
    this.scene.add(m);
    this.projectiles.push({ m, kind: msg.k, vx: msg.vx, vy: msg.vy, vz: msg.vz, g: msg.g, dmg: msg.dmg, pct: msg.pct || 0, life: 4, hostile: true, fromX: msg.x, fromZ: msg.z });
    this.game.audio.throwSound();
  }

  spawnArrow(x, y, z, dx, dy, dz, mine) {
    const m = new THREE.Mesh(this.arrowGeo, this.game.gfx.matChar);
    m.position.set(x, y, z);
    this.scene.add(m);
    const sp = 55;
    this.projectiles.push({ m, kind: 'arrow', vx: dx * sp, vy: dy * sp, vz: dz * sp, g: 9, life: 2.6, hostile: false, mine });
  }

  // ---------------- 플레이어 전투 보조 ----------------
  // 가까운 몬스터 (정면 기준 각도 제한)
  nearestMonster(x, z, range, yaw, halfAngle) {
    let best = null;
    let bs = Infinity;
    for (const e of this.monsters.values()) {
      if (e.dying || !e.shown) continue;
      const dx = e.x - x;
      const dz = e.z - z;
      const d = Math.hypot(dx, dz) - e.info.radius;
      if (d > range) continue;
      const a = Math.abs(angDiff(yaw, Math.atan2(dx, dz)));
      if (a > halfAngle && d > 1.2) continue;
      const score = d + a * 1.5;
      if (score < bs) {
        bs = score;
        best = { x: e.x, z: e.z, dist: Math.max(0, d), e };
      }
    }
    return best;
  }

  // 주목(대상 고정)할 몬스터 고르기: 시점 정면에 있고 가까운 것이 우선
  pickLockTarget(x, z, yaw, range) {
    let best = null;
    let bs = Infinity;
    const zs = this.game.zone;
    for (const e of this.monsters.values()) {
      if (e.dying || !e.shown) continue;
      const dx = e.x - x;
      const dz = e.z - z;
      const d = Math.hypot(dx, dz);
      if (d > range) continue;
      if (zs && !zoneClearLine(zs.def, x, z, e.x, e.z, zs.open)) continue;
      const a = Math.abs(angDiff(yaw, Math.atan2(dx, dz)));
      const score = d + a * 9;
      if (score < bs) {
        bs = score;
        best = e;
      }
    }
    return best;
  }

  // 앞으로 곧게 뻗은 띠 안의 몬스터 (빛의 파동)
  // ---------------- 결투 (PvP) ----------------
  // 지금 내가 공격할 수 있는 다른 모험가: 결투 모드를 켰고, 눈에 보이고, 살아 있다
  *rivals() {
    if (!this.game.duel()) return;
    for (const e of this.players.values()) {
      if (e.prof.pv && e.seen && e.rig.root.visible && e.anim !== ANIM.DEAD && e.hp > 0) yield e;
    }
  }

  playersInArc(x, y, z, yaw, reach, halfAngle) {
    const ids = [];
    for (const e of this.rivals()) {
      const dx = e.x - x;
      const dz = e.z - z;
      const d = Math.hypot(dx, dz);
      if (d > reach + 0.6 || Math.abs(e.y - y) > 3.2) continue;
      if (d > 1.4 && Math.abs(angDiff(yaw, Math.atan2(dx, dz))) > halfAngle) continue;
      ids.push(e.id);
    }
    return ids;
  }

  playersInLine(x, z, yaw, len, halfW) {
    const ids = [];
    const sx = Math.sin(yaw);
    const sz = Math.cos(yaw);
    for (const e of this.rivals()) {
      const dx = e.x - x;
      const dz = e.z - z;
      const along = dx * sx + dz * sz;
      if (along < 0 || along > len + 0.6 || Math.abs(dx * sz - dz * sx) > halfW + 0.6) continue;
      ids.push(e.id);
    }
    return ids;
  }

  // 휘두를 때 저절로 향할 결투 상대 (몬스터가 없을 때)
  nearestRival(x, z, range, yaw, halfAngle) {
    let best = null;
    let bs = Infinity;
    for (const e of this.rivals()) {
      const dx = e.x - x;
      const dz = e.z - z;
      const d = Math.hypot(dx, dz) - 0.5;
      if (d > range) continue;
      const a = Math.abs(angDiff(yaw, Math.atan2(dx, dz)));
      if (a > halfAngle && d > 1.2) continue;
      const score = d + a * 1.5;
      if (score < bs) {
        bs = score;
        best = { x: e.x, z: e.z, dist: Math.max(0, d), e };
      }
    }
    return best;
  }

  // 내 공격이 결투 상대에게 닿은 순간 (서버의 답을 기다리지 않고 바로 보여 준다)
  localHitPlayer(id, color) {
    const e = this.players.get(id);
    if (!e) return;
    this.game.fx.impact(e.x, e.y + 1.1, e.z, color, 1.2);
    this.game.fx.burst(e.x, e.y + 1.1, e.z, 0xffffff, 8, 4.5, { size: 0.26, life: 0.3, grav: 9 });
  }

  // 결투의 결과 (맞은 사람이 실제로 입은 피해). 내가 맞은 것은 이미 내 화면에서 처리했다
  onPvpHit(msg) {
    const g = this.game;
    const e = this.players.get(msg.id);
    if (!e) return;
    const y = e.y + 2.0;
    const mine = msg.by === this.myId;
    if (!msg.d) {
      g.fx.text(e.x, y + 0.3, e.z, '회피!', 'heal');
      return;
    }
    g.fx.text(e.x, y + 0.3, e.z, msg.c ? `${msg.d * HP_SHOW}!` : `${msg.d * HP_SHOW}`, msg.c ? 'crit' : mine ? 'dmg' : 'dmg other');
    g.fx.burst(e.x, y - 0.8, e.z, msg.x === 'dot' ? 0x7dff8a : 0xff5a5f, 8, 3.5, { size: 0.28, life: 0.4 });
    if (mine && msg.x !== 'dot') {
      g.player.onLeechHit(e.x, y, e.z);
      if (msg.c) g.audio.crit();
    } else if (!mine) g.audio.hit(0.4);
  }

  monstersInLine(x, z, yaw, len, halfW) {
    const ids = [];
    const sx = Math.sin(yaw);
    const sz = Math.cos(yaw);
    const zs = this.game.zone;
    for (const e of this.monsters.values()) {
      if (e.dying || !e.shown) continue;
      const dx = e.x - x;
      const dz = e.z - z;
      const along = dx * sx + dz * sz;
      if (along < 0 || along > len + e.info.radius) continue;
      if (Math.abs(dx * sz - dz * sx) > halfW + e.info.radius) continue;
      if (zs && !zoneClearLine(zs.def, x, z, e.x, e.z, zs.open)) continue;
      ids.push(e.id);
    }
    return ids;
  }

  monstersInArc(x, y, z, yaw, reach, halfAngle) {
    const ids = [];
    const zs = this.game.zone;
    for (const e of this.monsters.values()) {
      if (e.dying || !e.shown) continue;
      const dx = e.x - x;
      const dz = e.z - z;
      const d = Math.hypot(dx, dz);
      if (d > reach + e.info.radius) continue;
      if (Math.abs(e.y - y) > 3.5 + e.info.def.height) continue;
      if (d > e.info.radius + 0.9 && Math.abs(angDiff(yaw, Math.atan2(dx, dz))) > halfAngle) continue;
      if (zs && d > e.info.radius + 1.6 && !zoneClearLine(zs.def, x, z, e.x, e.z, zs.open)) continue;
      ids.push(e.id);
    }
    return ids;
  }

  aimTarget(pos, yaw, maxAngle, range) {
    let best = null;
    let bs = Infinity;
    const zs = this.game.zone;
    for (const e of this.monsters.values()) {
      if (e.dying || !e.shown) continue;
      const dx = e.x - pos.x;
      const dz = e.z - pos.z;
      const d = Math.hypot(dx, dz);
      if (d > range || d < 0.5) continue;
      const a = Math.abs(angDiff(yaw, Math.atan2(dx, dz)));
      if (a > maxAngle) continue;
      if (zs && !zoneClearLine(zs.def, pos.x, pos.z, e.x, e.z, zs.open)) continue;
      const score = a + d * 0.006;
      if (score < bs) {
        bs = score;
        best = { x: e.x, y: e.y + e.info.def.height * (e.info.elite ? 1.45 : 1) * 0.55, z: e.z, e };
      }
    }
    // 결투 상대도 겨냥을 도와준다
    for (const e of this.rivals()) {
      const dx = e.x - pos.x;
      const dz = e.z - pos.z;
      const d = Math.hypot(dx, dz);
      if (d > range || d < 0.5) continue;
      const a = Math.abs(angDiff(yaw, Math.atan2(dx, dz)));
      if (a > maxAngle) continue;
      const score = a + d * 0.006;
      if (score < bs) {
        bs = score;
        best = { x: e.x, y: e.y + 1.0, z: e.z, rival: e };
      }
    }
    return best;
  }

  flashMonster(id) {
    const e = this.monsters.get(id);
    if (e) e.flash = 0.12;
  }

  nearRest(x, z) {
    return this.objects ? this.objects.nearRest(x, z) : false;
  }

  // ---------------- 매 프레임 ----------------
  update(dt, time) {
    const g = this.game;
    const net = g.net;
    const rt = (this.clockOff === null ? net.serverNow() : Date.now() + this.clockOff) - INTERP_MS;
    const cam = g.gfx.camera;
    const pl = g.player;
    const blobs = !g.gfx.quality.shadows;
    const world = g.world;
    const zs = g.zone;
    const myZone = zs ? zs.id : 0;

    // 다른 플레이어
    for (const e of this.players.values()) {
      if (!sample(e.buf, rt, _s)) {
        continue;
      }
      const moved = Math.hypot(_s.x - e.x, _s.z - e.z);
      const speed = e.seen ? moved / Math.max(dt, 1e-3) : 0;
      e.x = _s.x;
      e.y = _s.y;
      e.z = _s.z;
      e.yaw = _s.yaw;
      e.hp = _s.hp;
      e.maxHp = _s.maxHp;
      const anim = _s.anim;
      if (anim !== e.lastAnim) {
        e.lastAnim = anim;
        e.atkT = 0;
      }
      e.atkT += dt;
      e.anim = anim;
      const riding = isRiding(anim);
      const dxp = e.x - pl.pos.x;
      const dzp = e.z - pl.pos.z;
      const d2 = dxp * dxp + dzp * dzp;
      // 시련장·던전 안에 있는 친구는 같은 곳에 있을 때만 보인다
      e.zone = zoneIdAt(e.x, e.z);
      const vis = d2 < 260 * 260 && e.zone === myZone;
      e.rig.root.visible = vis;
      e.label.visible = vis && d2 < 90 * 90;
      e.blob.visible = vis && blobs;
      e.seen = true;
      if (e.horse) e.horse.root.visible = vis && riding;
      if (!vis) continue;
      e.rig.root.position.set(e.x, e.y, e.z);
      e.rig.root.rotation.y = e.yaw;
      e.rig.root.rotation.x = 0;
      const prog = anim === ANIM.ROLL ? Math.min(1, e.atkT / 0.46) : (anim >= ANIM.ATK1 && anim <= ANIM.ATK3) || anim === ANIM.THRUST || anim === ANIM.RIDEATK ? attackProgress(e.wk, anim, e.atkT) : 0;
      animateHumanoid(e.rig, anim, dt, Math.min(20, speed), prog);
      if (riding) {
        // 탈것을 탄 친구: 말을 만들어 그 위에 앉힌다
        if (!e.horse) {
          e.horse = makeHorse(e.prof.mc || 0, TUNIC_COLORS[e.prof.tunic % TUNIC_COLORS.length], MOUNT_KEYS[e.prof.mk | 0] || 'horse');
          this.scene.add(e.horse.root);
        }
        const h = e.horse;
        animateHorse(h, dt, Math.min(28, speed));
        // 땅에 붙어 달릴 때는 비탈의 기울기를 따라 기운다
        const onGround = e.y - Math.max(world.heightAt(e.x, e.z), -0.12) < 0.6;
        e.mPitch = (e.mPitch || 0) + ((onGround ? slopePitch(world, e.x, e.z, e.yaw) : 0) - (e.mPitch || 0)) * Math.min(1, 9 * dt);
        seatRider(h, e.rig, e.x, e.y, e.z, e.yaw, e.mPitch);
      }
      e.label.position.set(e.x, e.y + (riding ? 3.4 : 2.35), e.z);
      if (blobs) {
        const gh = Math.max(world.heightAt(e.x, e.z), 0);
        e.blob.position.set(e.x, gh + 0.06, e.z);
      }
    }

    // 몬스터
    this.targetT -= dt;
    if (this.targetT <= 0) this.target = null;
    const bodyX = pl.pos.x;
    const bodyZ = pl.pos.z;
    for (const e of this.monsters.values()) {
      if (e.dying) {
        e.dying -= dt;
        const k = Math.max(0.01, e.dying / 0.28);
        e.rig.root.scale.setScalar((e.rig.root.userData.baseScale || 1) * k);
        if (e.dying <= 0) this._removeMonster(e);
        continue;
      }
      if (!sample(e.buf, rt, _s)) continue;
      if (!e.shown) {
        e.shown = true;
        e.rig.root.visible = true;
        if (e.rig.root.userData.baseScale === undefined) e.rig.root.userData.baseScale = e.rig.root.scale.x;
        e.rig.root.scale.setScalar(e.rig.root.userData.baseScale);
        e.px = _s.x;
        e.pz = _s.z;
      }
      e.x = _s.x;
      e.z = _s.z;
      e.yaw = _s.yaw;
      e.y = Math.max(world.heightAt(e.x, e.z), -0.4);
      const st = _s.state;
      e.hp5 = _s.hp;
      const frac = Math.min(1, Math.max(e.hp5 / 31, 0));
      const moved = Math.hypot(e.x - e.px, e.z - e.pz);
      e.speed += (moved / Math.max(dt, 1e-3) - e.speed) * Math.min(1, dt * 8);
      e.px = e.x;
      e.pz = e.z;
      if (st !== e.lastState) {
        if (st === MSTATE.RECOVER) e.strikeT = 0;
        e.lastState = st;
      }
      e.strikeT += dt;
      let as = 'idle';
      if (st === MSTATE.WALK) as = 'walk';
      else if (st === MSTATE.CHASE || st === MSTATE.RETURN) as = e.speed > 0.4 ? 'run' : 'idle';
      else if (st === MSTATE.WINDUP) as = 'windup';
      else if (st === MSTATE.RECOVER) as = 'strike';
      else if (st === MSTATE.STAGGER) as = 'stagger';
      animateMonster(e.rig, as, e.pattern || e.info.def.atk.kind, dt, e.speed, Math.min(1, e.strikeT / 0.3));
      // 맞은 직후에는 그 방향으로 살짝 밀려나 보인다
      if (e.sx || e.sz) {
        const dk = Math.exp(-dt * 11);
        e.sx *= dk;
        e.sz *= dk;
        if (Math.abs(e.sx) + Math.abs(e.sz) < 0.01) e.sx = e.sz = 0;
      }
      e.rig.root.position.set(e.x + (e.sx || 0), e.y, e.z + (e.sz || 0));
      e.rig.root.rotation.y = e.yaw;
      if (e.slowT > 0) {
        // 얼어붙어 느려진 동안 서리가 날린다
        e.slowT -= dt;
        if (Math.random() < dt * 9) g.fx.spawn(e.x + (Math.random() - 0.5) * e.info.radius * 1.6, e.y + Math.random() * e.info.def.height * 0.9, e.z + (Math.random() - 0.5) * e.info.radius * 1.6, 0, 0.4, 0, Math.random() < 0.5 ? 0xbfe9ff : 0xffffff, 0.13, 0.7, 0.3, 1, 2.4);
      }
      if (e.flash > 0 || e.flashed) {
        // 맞으면 납작하게 눌렸다가 돌아온다
        e.flash -= dt;
        const base = e.rig.root.userData.baseScale || 1;
        const f = Math.max(0, e.flash);
        e.rig.root.scale.set(base * (1 + f * 1.3), base * (1 - f * 0.9), base * (1 + f * 1.3));
        e.flashed = f > 0;
      }
      // 체력 막대
      e.hitShow = (e.hitShow || 0) - dt;
      const showBar = frac < 0.999 || e.hitShow > 0;
      e.bar.visible = showBar && !(e.info.boss);
      if (e.bar.visible) {
        e.bar.position.set(e.x, e.y + e.rig.height + 0.6, e.z);
        e.bar.quaternion.copy(cam.quaternion);
        e.barFg.scale.x = Math.max(0.001, e.barW * frac);
        e.barFg.position.x = -(e.barW * (1 - frac)) / 2;
      }
      e.blob.visible = blobs;
      if (blobs) e.blob.position.set(e.x, Math.max(e.y, 0) + 0.06, e.z);

      // 몸으로 밀어내기
      const dx = pl.pos.x - e.x;
      const dz = pl.pos.z - e.z;
      const rr = e.info.radius * 0.8 + 0.35;
      const d2 = dx * dx + dz * dz;
      if (d2 < rr * rr && d2 > 1e-4 && pl.state === 'ground') {
        const d = Math.sqrt(d2);
        const push = (rr - d) * 0.5;
        pl.pos.x += (dx / d) * push;
        pl.pos.z += (dz / d) * push;
      }
    }

    // 몬스터에게 떠밀려 벽 속으로 들어가지 않게 한다
    if (zs && (pl.pos.x !== bodyX || pl.pos.z !== bodyZ)) g.zones.collide(pl.pos, 0.42, bodyX, bodyZ);

    // 몬스터 공격 판정
    if (this.strikes.length) {
      const now = performance.now();
      for (let i = this.strikes.length - 1; i >= 0; i--) {
        const s = this.strikes[i];
        if (s.dead) {
          this.strikes.splice(i, 1);
          continue;
        }
        if (s.split) {
          // 표적이 된 사람을 따라다닌다
          const who = this._bodyOf(s.split);
          if (who && s.tele) {
            s.shape.x = who.x;
            s.shape.z = who.z;
            s.tele.m.position.set(who.x - s.ox, 0, who.z - s.oz);
          }
        }
        if (now >= s.at) {
          this.strikes.splice(i, 1);
          this._resolveStrike(s);
        }
      }
    }

    // 투사체
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= dt;
      const m = p.m;
      const ox = m.position.x;
      const oy = m.position.y;
      const oz = m.position.z;
      p.vy -= p.g * dt;
      m.position.x += p.vx * dt;
      m.position.y += p.vy * dt;
      m.position.z += p.vz * dt;
      let done = p.life <= 0;
      if (p.kind === 'arrow') {
        m.lookAt(m.position.x + p.vx, m.position.y + p.vy, m.position.z + p.vz);
        if (p.mine && !done) {
          // 선분-구 충돌 (빠른 화살이 몬스터를 통과하지 않도록)
          const sx = m.position.x - ox;
          const sy = m.position.y - oy;
          const sz = m.position.z - oz;
          const sl2 = sx * sx + sy * sy + sz * sz || 1;
          for (const e of this.monsters.values()) {
            if (e.dying || !e.shown) continue;
            const hgt = e.info.def.height * (e.info.elite ? 1.45 : 1);
            const cx = e.x;
            const cy = e.y + hgt * 0.5;
            const cz = e.z;
            let t = ((cx - ox) * sx + (cy - oy) * sy + (cz - oz) * sz) / sl2;
            t = t < 0 ? 0 : t > 1 ? 1 : t;
            const qx = ox + sx * t - cx;
            const qy = (oy + sy * t - cy) * (e.info.radius / Math.max(hgt * 0.55, e.info.radius));
            const qz = oz + sz * t - cz;
            const rr = e.info.radius + 0.35;
            if (qx * qx + qy * qy + qz * qz < rr * rr) {
              net.send({ t: 'ar', id: e.id });
              g.fx.burst(ox + sx * t, oy + sy * t, oz + sz * t, 0xffffff, 6, 3, { size: 0.24, life: 0.25 });
              e.flash = 0.12;
              done = true;
              break;
            }
          }
          // 결투 상대
          if (!done) {
            for (const e of this.rivals()) {
              const cx = e.x;
              const cy = e.y + 1.0;
              const cz = e.z;
              let t = ((cx - ox) * sx + (cy - oy) * sy + (cz - oz) * sz) / sl2;
              t = t < 0 ? 0 : t > 1 ? 1 : t;
              const qx = ox + sx * t - cx;
              const qy = (oy + sy * t - cy) * 0.6;
              const qz = oz + sz * t - cz;
              if (qx * qx + qy * qy + qz * qz < 0.75 * 0.75) {
                net.send({ t: 'ar', pid: e.id });
                this.localHitPlayer(e.id, 0xffffff);
                done = true;
                break;
              }
            }
          }
        }
      } else {
        m.rotation.x += dt * 9;
        m.rotation.y += dt * 7;
        if (p.kind === 'fire' && Math.random() < 0.6) g.fx.spawn(m.position.x, m.position.y, m.position.z, 0, 0.5, 0, 0xff9a3a, 0.4, 0.35, -1, 0.8);
        // 내 캐릭터에 맞았는지
        if (p.hostile && pl.state !== 'dead') {
          const dx = m.position.x - pl.pos.x;
          const dy = m.position.y - (pl.pos.y + 0.95);
          const dz = m.position.z - pl.pos.z;
          if (dx * dx + dz * dz < 0.75 * 0.75 && Math.abs(dy) < 1.15) {
            pl.damage(p.pct ? Math.ceil(pl.maxHp * p.pct) : p.dmg, p.fromX, p.fromZ, { knock: 5, pct: !!p.pct });
            g.fx.burst(m.position.x, m.position.y, m.position.z, p.kind === 'fire' ? 0xff9a3a : 0xb0b5bd, 10, 4, { size: 0.3, life: 0.35 });
            done = true;
          }
        }
      }
      if (!done && zs && m.position.y < ZONE_FLOOR + WALL_H && zoneSolid(zs.def, m.position.x, m.position.z, zs.open)) {
        // 실내에서는 벽과 닫힌 문에 막힌다
        g.fx.burst(ox, oy, oz, p.kind === 'fire' ? 0xff9a3a : 0xd8cfb8, 5, 2.5, { size: 0.24, life: 0.25 });
        done = true;
      }
      if (!done && m.position.y < Math.max(world.heightAt(m.position.x, m.position.z), 0) + 0.05) {
        g.fx.burst(m.position.x, m.position.y + 0.1, m.position.z, p.kind === 'fire' ? 0xff9a3a : 0xd8cfb8, 6, 2.5, { size: 0.28, life: 0.3 });
        done = true;
      }
      if (done) {
        this.scene.remove(m);
        this.projectiles.splice(i, 1);
      }
    }
  }
}

export function disposeTree(root) {
  root.traverse((o) => {
    if (o.geometry) o.geometry.dispose();
  });
}

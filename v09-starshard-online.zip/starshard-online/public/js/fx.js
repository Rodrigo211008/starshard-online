// 시각 효과: 파티클, 베기 궤적, 바닥 공격 예고, 떠오르는 숫자
import * as THREE from '/vendor/three/three.module.js';
import { BIOME } from '/shared/world.js';

const MAXP = 1500;
const _c = new THREE.Color();
const _v = new THREE.Vector3();

export class Fx {
  constructor(gfx, world) {
    this.gfx = gfx;
    this.world = world;
    this.scene = gfx.scene;

    // ---- 파티클 ----
    this.pPos = new Float32Array(MAXP * 3);
    this.pCol = new Float32Array(MAXP * 4);
    this.pSize = new Float32Array(MAXP);
    this.pVel = new Float32Array(MAXP * 3);
    this.pLife = new Float32Array(MAXP);
    this.pMax = new Float32Array(MAXP);
    this.pGrav = new Float32Array(MAXP);
    this.pBase = new Float32Array(MAXP);
    this.pWob = new Float32Array(MAXP); // 좌우로 나풀거리는 정도
    this.pIn = new Float32Array(MAXP); // 서서히 나타나는 시간
    this.pNext = 0;
    this.ambAcc = 0;
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(this.pPos, 3));
    geo.setAttribute('pcolor', new THREE.BufferAttribute(this.pCol, 4));
    geo.setAttribute('psize', new THREE.BufferAttribute(this.pSize, 1));
    this.pMat = new THREE.ShaderMaterial({
      uniforms: { uScale: { value: 600 } },
      transparent: true,
      depthWrite: false,
      vertexShader: `
        attribute vec4 pcolor; attribute float psize; varying vec4 vColor; uniform float uScale;
        void main() {
          vColor = pcolor;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_PointSize = psize * uScale / max(0.1, -mv.z);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        varying vec4 vColor;
        void main() {
          vec2 c = gl_PointCoord - 0.5;
          float d = dot(c, c);
          if (d > 0.25 || vColor.a <= 0.0) discard;
          gl_FragColor = vec4(vColor.rgb, vColor.a * (1.0 - d * 2.4));
          #include <colorspace_fragment>
        }`,
    });
    this.points = new THREE.Points(geo, this.pMat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 8;
    this.scene.add(this.points);

    // ---- 베기 궤적 ----
    this.slashes = [];
    const sg = new THREE.RingGeometry(1.5, 3.1, 14, 1, -1.0, 2.0);
    sg.rotateX(-Math.PI / 2);
    for (let i = 0; i < 4; i++) {
      const m = new THREE.Mesh(sg, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }));
      m.visible = false;
      m.renderOrder = 9;
      this.scene.add(m);
      this.slashes.push({ m, t: 0, dur: 0.2, yaw: 0, k: 0 });
    }
    this.slashNext = 0;

    // ---- 찌르기 궤적 (앞으로 뻗는 가느다란 빛) ----
    this.stabs = [];
    const tg = new THREE.BufferGeometry();
    tg.setAttribute('position', new THREE.BufferAttribute(new Float32Array([0, 0, 0, 0.2, 0, 0.55, 0, 0, 1, -0.2, 0, 0.55, 0, 0.12, 0.55, 0, -0.12, 0.55]), 3));
    tg.setIndex([0, 1, 2, 0, 2, 3, 0, 4, 2, 0, 2, 5]);
    for (let i = 0; i < 3; i++) {
      const m = new THREE.Mesh(tg, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }));
      m.visible = false;
      m.renderOrder = 9;
      this.scene.add(m);
      this.stabs.push({ m, t: 0, dur: 0.16, len: 5 });
    }
    this.stabNext = 0;

    // ---- 타격 섬광 (네 갈래 별 모양, 늘 카메라를 본다) ----
    this.sparks = [];
    const ig = new THREE.BufferGeometry();
    ig.setAttribute('position', new THREE.BufferAttribute(new Float32Array([1, 0, 0, 0, 0.13, 0, -1, 0, 0, 0, -0.13, 0, 0, 1, 0, 0.13, 0, 0, 0, -1, 0, -0.13, 0, 0]), 3));
    ig.setIndex([0, 1, 2, 0, 2, 3, 4, 5, 6, 4, 6, 7]);
    for (let i = 0; i < 8; i++) {
      const m = new THREE.Mesh(ig, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending, fog: false }));
      m.visible = false;
      m.renderOrder = 13;
      this.scene.add(m);
      this.sparks.push({ m, t: 0, dur: 0.14, size: 1, roll: 0 });
    }
    this.sparkNext = 0;

    // ---- 퍼지는 고리 ----
    this.rings = [];
    const rg = new THREE.RingGeometry(0.82, 1.0, 28);
    rg.rotateX(-Math.PI / 2);
    for (let i = 0; i < 6; i++) {
      const m = new THREE.Mesh(rg, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }));
      m.visible = false;
      m.renderOrder = 9;
      this.scene.add(m);
      this.rings.push({ m, t: 0, dur: 0.5, r: 3 });
    }
    this.ringNext = 0;

    // ---- 바닥 예고 표시 ----
    this.tele = [];
    this.teleMat = new THREE.MeshBasicMaterial({ color: 0xff3a2a, transparent: true, opacity: 0.3, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -6, fog: false });

    // ---- 그림자 방울 ----
    this.blobGeo = new THREE.CircleGeometry(1, 14);
    this.blobGeo.rotateX(-Math.PI / 2);
    this.blobMat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.26, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -4 });

    // ---- 떠오르는 글자 (DOM) ----
    this.layer = document.getElementById('floaters');
    this.texts = [];
    this.resize();
  }

  resize() {
    const h = this.gfx.renderer.domElement.height || window.innerHeight;
    const fov = (this.gfx.camera.fov * Math.PI) / 180;
    this.pMat.uniforms.uScale.value = h / (2 * Math.tan(fov / 2));
  }

  makeBlob(r) {
    const m = new THREE.Mesh(this.blobGeo, this.blobMat);
    m.scale.setScalar(r);
    m.renderOrder = 2;
    return m;
  }

  // glow: 1 보다 크면 빛 번짐이 생긴다, wob: 나풀거림, fadeIn: 서서히 나타나는 시간(초)
  spawn(x, y, z, vx, vy, vz, hex, size, life, grav = 0, alpha = 1, glow = 1, wob = 0, fadeIn = 0) {
    const i = this.pNext;
    this.pNext = (i + 1) % MAXP;
    this.pPos[i * 3] = x;
    this.pPos[i * 3 + 1] = y;
    this.pPos[i * 3 + 2] = z;
    this.pVel[i * 3] = vx;
    this.pVel[i * 3 + 1] = vy;
    this.pVel[i * 3 + 2] = vz;
    _c.setHex(hex);
    this.pCol[i * 4] = _c.r * glow;
    this.pCol[i * 4 + 1] = _c.g * glow;
    this.pCol[i * 4 + 2] = _c.b * glow;
    this.pCol[i * 4 + 3] = fadeIn > 0 ? 0 : alpha;
    this.pBase[i] = alpha;
    this.pWob[i] = wob;
    this.pIn[i] = fadeIn;
    this.pSize[i] = size;
    this.pLife[i] = life;
    this.pMax[i] = life;
    this.pGrav[i] = grav;
  }

  burst(x, y, z, hex, count = 10, speed = 3, opts = {}) {
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const u = Math.random() * 2 - 1;
      const r = Math.sqrt(1 - u * u);
      const s = speed * (0.4 + Math.random() * 0.8);
      this.spawn(x, y, z, Math.cos(a) * r * s, (opts.up ?? 1) * Math.abs(u) * s + (opts.lift || 0), Math.sin(a) * r * s, hex, opts.size || 0.3, (opts.life || 0.6) * (0.6 + Math.random() * 0.7), opts.grav ?? 6, opts.alpha ?? 1, opts.glow ?? 1.5);
    }
  }

  dust(x, y, z, count = 7) {
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      this.spawn(x + Math.cos(a) * 0.3, y + 0.15, z + Math.sin(a) * 0.3, Math.cos(a) * 1.4, 0.8 + Math.random(), Math.sin(a) * 1.4, 0xd8cfb8, 0.5, 0.5 + Math.random() * 0.3, 1.5, 0.55);
    }
  }

  splash(x, z) {
    for (let i = 0; i < 16; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = 1 + Math.random() * 2.5;
      this.spawn(x, 0.1, z, Math.cos(a) * s, 2.5 + Math.random() * 3, Math.sin(a) * s, 0xdff4ff, 0.32, 0.7, 12, 0.9);
    }
    this.ring(x, 0.12, z, 0xdff4ff, 2.2, 0.6);
  }

  ring(x, y, z, hex, radius = 3, dur = 0.5) {
    const r = this.rings[this.ringNext];
    this.ringNext = (this.ringNext + 1) % this.rings.length;
    r.m.position.set(x, y, z);
    r.m.material.color.setHex(hex);
    r.t = 0;
    r.dur = dur;
    r.r = radius;
    r.m.visible = true;
  }

  // anim: 0 가로 베기, 1 반대로 베기, 2 내려찍기, 3 찌르기. scale: 무기 길이에 따른 크기, half: 휘두르는 폭
  slash(x, y, z, yaw, anim, color = 0xffffff, scale = 1, half = 1.5) {
    if (anim === 3) {
      const st = this.stabs[this.stabNext];
      this.stabNext = (this.stabNext + 1) % this.stabs.length;
      st.t = 0;
      st.len = 3.1 * scale;
      st.m.material.color.setHex(color);
      st.m.position.set(x + Math.sin(yaw) * 0.5, y + 0.15, z + Math.cos(yaw) * 0.5);
      st.m.rotation.set(0, yaw, 0);
      st.m.scale.set(1, 1, 0.1);
      st.m.visible = true;
      return;
    }
    const s = this.slashes[this.slashNext];
    this.slashNext = (this.slashNext + 1) % this.slashes.length;
    s.t = 0;
    s.dur = anim === 2 ? 0.24 : 0.18;
    s.k = anim;
    s.yaw = yaw;
    s.wide = Math.min(2.4, half / 1.5);
    s.m.material.color.setHex(color);
    s.m.position.set(x, y, z);
    s.m.scale.setScalar(scale * (anim === 2 ? 1.2 : 1));
    s.m.visible = true;
    this._poseSlash(s, 0);
  }

  _poseSlash(s, p) {
    // RingGeometry 의 호는 +x 방향을 중심으로 펼쳐져 있다 -> 캐릭터 정면(+z)으로 돌린다
    const m = s.m;
    if (s.k === 2) {
      // 세로 베기: 고리를 세워서 위에서 아래로
      m.rotation.order = 'YZX';
      m.rotation.set(-Math.PI / 2, s.yaw - Math.PI / 2, 1.15 - p * 1.6);
    } else {
      m.rotation.order = 'YXZ';
      const sweep = (p - 0.5) * 1.4 * (s.wide || 1) * (s.k === 0 ? 1 : -1);
      m.rotation.set(0, s.yaw - Math.PI / 2 + sweep, s.k === 0 ? 0.18 : -0.18);
    }
  }

  // 타격 지점의 섬광과 불꽃
  // 여명의 대검: 빛의 파동이 앞으로 뻗어 나간다
  lightWave(x, y, z, yaw, len, color = 0xffe27a) {
    const sx = Math.sin(yaw);
    const sz = Math.cos(yaw);
    for (let i = 0; i < 3; i++) this.slash(x + sx * (2 + i * 4.5), y, z + sz * (2 + i * 4.5), yaw, 0, color, 1.5 + i * 0.25, 1.9);
    for (let d = 1.5; d < len; d += 1.1) {
      const px = x + sx * d;
      const pz = z + sz * d;
      for (let k = 0; k < 3; k++) {
        const side = (Math.random() - 0.5) * 4.4;
        this.spawn(px + sz * side, y - 0.6 + Math.random() * 1.6, pz - sx * side, sx * (6 + Math.random() * 6), 0.6 + Math.random() * 1.6, sz * (6 + Math.random() * 6), Math.random() < 0.35 ? 0xffffff : color, 0.22, 0.28 + d * 0.022, -0.5, 1, 3, 0.5);
      }
    }
    this.ring(x + sx * 2, y - 0.9, z + sz * 2, color, 4, 0.4);
  }

  // 천둥 망치: 적에서 적으로 튀는 번개. pts: [[x, z], ...], y: 높이를 돌려주는 함수
  bolt(pts, heightAt) {
    for (let i = 0; i + 1 < pts.length; i++) {
      const [x0, z0] = pts[i];
      const [x1, z1] = pts[i + 1];
      const y0 = heightAt(x0, z0) + 1.2;
      const y1 = heightAt(x1, z1) + 1.2;
      const n = Math.max(6, Math.ceil(Math.hypot(x1 - x0, z1 - z0) / 0.45));
      let jx = 0;
      let jy = 0;
      let jz = 0;
      for (let k = 0; k <= n; k++) {
        const t = k / n;
        // 들쭉날쭉한 번개 줄기
        if (k % 3 === 0) {
          const amp = Math.sin(t * Math.PI) * 0.9;
          jx = (Math.random() - 0.5) * amp;
          jy = (Math.random() - 0.5) * amp;
          jz = (Math.random() - 0.5) * amp;
        }
        this.spawn(x0 + (x1 - x0) * t + jx, y0 + (y1 - y0) * t + jy, z0 + (z1 - z0) * t + jz, 0, 0, 0, k % 2 ? 0xffffff : 0xfff06a, 0.2, 0.16 + Math.random() * 0.12, 0, 1, 3.2);
      }
      this.impact(x1, y1, z1, 0xfff9c0, 1.6);
    }
  }

  impact(x, y, z, color = 0xffffff, size = 1) {
    const sp = this.sparks[this.sparkNext];
    this.sparkNext = (this.sparkNext + 1) % this.sparks.length;
    sp.t = 0;
    sp.dur = 0.11 + size * 0.05;
    sp.size = size;
    sp.roll = Math.random() * Math.PI;
    sp.m.material.color.setHex(color);
    sp.m.position.set(x, y, z);
    sp.m.visible = true;
    sp.m.scale.setScalar(0.3 * size);
  }

  // 땅을 내려찍었을 때: 퍼지는 고리 + 먼지 + 튀는 돌조각
  quake(x, y, z, radius, color = 0xffffff) {
    this.ring(x, y + 0.18, z, color, radius, 0.42);
    this.ring(x, y + 0.14, z, 0xe8dcc0, radius * 0.72, 0.3);
    const n = Math.round(10 + radius * 3);
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + Math.random() * 0.3;
      const r = radius * (0.25 + Math.random() * 0.6);
      const px = x + Math.cos(a) * r;
      const pz = z + Math.sin(a) * r;
      this.spawn(px, y + 0.15, pz, Math.cos(a) * 2.2, 1.2 + Math.random() * 1.6, Math.sin(a) * 2.2, 0xd8cfb8, 0.55, 0.5 + Math.random() * 0.35, 1.5, 0.5);
      if (i % 2 === 0) this.spawn(px, y + 0.2, pz, Math.cos(a) * 3, 4 + Math.random() * 4, Math.sin(a) * 3, 0x8a7a66, 0.16, 0.6, 16, 1, 1);
    }
  }

  // 떠오르는 글자
  text(x, y, z, str, cls = 'dmg') {
    if (!this.layer) return;
    let t = this.texts.find((q) => q.life <= 0);
    if (!t) {
      if (this.texts.length >= 28) return;
      const el = document.createElement('div');
      this.layer.appendChild(el);
      t = { el, life: 0, x: 0, y: 0, z: 0, ox: 0 };
      this.texts.push(t);
    }
    t.el.className = 'floater ' + cls;
    t.el.textContent = str;
    t.el.style.display = 'block';
    t.x = x;
    t.y = y;
    t.z = z;
    t.ox = (Math.random() - 0.5) * 36;
    t.life = 0.95;
  }

  // ---- 바닥 예고: 원 ----
  _fan(cx, cz, r, a0, a1, segs) {
    const world = this.world;
    const pos = [];
    const idx = [];
    const h0 = Math.max(world.heightAt(cx, cz), 0) + 0.14;
    pos.push(cx, h0, cz);
    const rings = 2;
    for (let k = 1; k <= rings; k++) {
      const rr = (r * k) / rings;
      for (let i = 0; i <= segs; i++) {
        const a = a0 + ((a1 - a0) * i) / segs;
        const x = cx + Math.sin(a) * rr;
        const z = cz + Math.cos(a) * rr;
        pos.push(x, Math.max(world.heightAt(x, z), 0) + 0.14, z);
      }
    }
    const n = segs + 1;
    for (let i = 0; i < segs; i++) {
      idx.push(0, 1 + i, 2 + i);
      const a = 1 + i;
      const b = 1 + n + i;
      idx.push(a, b, a + 1, a + 1, b, b + 1);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pos), 3));
    g.setIndex(idx);
    return g;
  }

  // 고리 (안쪽 반지름 r0 ~ 바깥 반지름 r1)
  _ring(cx, cz, r0, r1, segs) {
    const world = this.world;
    const pos = [];
    const idx = [];
    const rings = 3;
    for (let k = 0; k <= rings; k++) {
      const rr = r0 + ((r1 - r0) * k) / rings;
      for (let i = 0; i <= segs; i++) {
        const a = (i / segs) * Math.PI * 2;
        const x = cx + Math.sin(a) * rr;
        const z = cz + Math.cos(a) * rr;
        pos.push(x, Math.max(world.heightAt(x, z), 0) + 0.14, z);
      }
    }
    const n = segs + 1;
    for (let k = 0; k < rings; k++) {
      for (let i = 0; i < segs; i++) {
        const a = k * n + i;
        const b = a + n;
        idx.push(a, b, a + 1, a + 1, b, b + 1);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pos), 3));
    g.setIndex(idx);
    return g;
  }

  _strip(cx, cz, yaw, len, halfW) {
    const world = this.world;
    const pos = [];
    const idx = [];
    const segs = Math.max(2, Math.ceil(len / 2));
    const fx = Math.sin(yaw);
    const fz = Math.cos(yaw);
    const rx = fz;
    const rz = -fx;
    for (let i = 0; i <= segs; i++) {
      const d = (len * i) / segs;
      for (const s of [-1, 1]) {
        const x = cx + fx * d + rx * halfW * s;
        const z = cz + fz * d + rz * halfW * s;
        pos.push(x, Math.max(world.heightAt(x, z), 0) + 0.14, z);
      }
    }
    for (let i = 0; i < segs; i++) {
      const a = i * 2;
      idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pos), 3));
    g.setIndex(idx);
    return g;
  }

  // shape: {kind:'circle',x,z,r} | {kind:'ring',x,z,r0,r1} | {kind:'arc',x,z,yaw,r,half} | {kind:'line',x,z,yaw,len,w}
  telegraph(shape, durMs, delayMs = 0, hex = 0xff3a2a) {
    let geo;
    if (shape.kind === 'circle') geo = this._fan(shape.x, shape.z, shape.r, 0, Math.PI * 2, 26);
    else if (shape.kind === 'ring') geo = this._ring(shape.x, shape.z, shape.r0, shape.r1, 36);
    else if (shape.kind === 'arc') geo = this._fan(shape.x, shape.z, shape.r, shape.yaw - shape.half, shape.yaw + shape.half, 14);
    else geo = this._strip(shape.x, shape.z, shape.yaw, shape.len, shape.w);
    const mat = this.teleMat.clone();
    mat.color.setHex(hex);
    const m = new THREE.Mesh(geo, mat);
    m.renderOrder = 3;
    m.frustumCulled = false;
    m.visible = delayMs <= 0;
    this.scene.add(m);
    const t = { m, t: -delayMs / 1000, dur: durMs / 1000, cancelled: false };
    this.tele.push(t);
    return t;
  }

  cancelTelegraph(t) {
    if (t) t.cancelled = true;
  }

  // 주변 분위기 입자: 지역에 따라 꽃가루·낙엽·눈·모래바람·불티·반딧불이가 날린다
  ambient(dt, time, px, py, pz, night, amount) {
    if (amount <= 0) return;
    this.ambAcc += dt * 40 * amount;
    const world = this.world;
    let guard = 0;
    while (this.ambAcc >= 1 && guard++ < 12) {
      this.ambAcc -= 1;
      const a = Math.random() * Math.PI * 2;
      const r = 2.5 + Math.sqrt(Math.random()) * 24;
      const x = px + Math.cos(a) * r;
      const z = pz + Math.sin(a) * r;
      const ground = world.heightAt(x, z);
      const g = Math.max(ground, 0);
      if (Math.abs(g - py) > 14) continue;
      const b = world.biomeAt(x, z);
      const rnd = Math.random();
      const R = Math.random;
      const dark = night > 0.6;
      if (b === BIOME.SNOW) {
        // 눈송이
        this.spawn(x, g + 3 + R() * 9, z, 0.7 + R() * 0.6, -1.3 - R() * 0.8, 0.4 + R() * 0.4, 0xffffff, 0.09 + R() * 0.08, 5 + R() * 2, 0, 0.9, 1.2, 0.5, 0.4);
        if (rnd < 0.5) this.spawn(x + 2, g + 2 + R() * 8, z - 1, 0.9, -1.6, 0.5, 0xeaf4ff, 0.08, 5, 0, 0.8, 1.2, 0.4, 0.4);
      } else if (b === BIOME.DESERT) {
        // 모래바람
        if (rnd < 0.75) this.spawn(x, g + 0.1 + R() * 1.5, z, 4 + R() * 2.5, 0.15 + R() * 0.3, 2.3 + R() * 1.5, 0xf2dca0, 0.06 + R() * 0.05, 1.8 + R() * 1.4, 0.1, 0.55, 1, 0.3, 0.4);
      } else if (b === BIOME.VOLCANO) {
        // 불티와 재
        if (rnd < 0.6) this.spawn(x, g + R() * 2.5, z, (R() - 0.5) * 0.8, 1.0 + R() * 1.8, (R() - 0.5) * 0.8, rnd < 0.2 ? 0xffc85a : 0xff7a2a, 0.07 + R() * 0.07, 2.5 + R() * 2.5, -0.15, 1, 3.4, 0.7, 0.3);
        else if (rnd < 0.9) this.spawn(x, g + 2 + R() * 8, z, 0.3, -0.5 - R() * 0.4, 0.2, 0x4a4446, 0.1 + R() * 0.08, 6, 0, 0.6, 1, 0.5, 0.5);
      } else if (b === BIOME.BLOSSOM) {
        // 벚꽃잎이 흩날린다
        if (ground > 0.5 && rnd < 0.85) this.spawn(x, g + 2.5 + R() * 6, z, 0.7 + R() * 0.6, -0.5 - R() * 0.4, 0.4 + R() * 0.4, rnd < 0.3 ? 0xffffff : rnd < 0.6 ? 0xffc8e0 : 0xff9ac8, 0.09 + R() * 0.06, 6 + R() * 2, 0, 0.95, 1.1, 1.2, 0.5);
      } else if (b === BIOME.MUSHROOM) {
        // 빛나는 포자 (밤에 더 밝다)
        if (ground > 0.3 && rnd < 0.7) this.spawn(x, g + 0.3 + R() * 3.5, z, (R() - 0.5) * 0.3, 0.12 + R() * 0.25, (R() - 0.5) * 0.3, rnd < 0.35 ? 0x7fffe0 : 0xc09aff, 0.08 + R() * 0.05, 5 + R() * 4, 0, 0.9, dark ? 3.6 : 1.6, 0.7, 1.0);
      } else if (b === BIOME.CRYSTAL) {
        // 수정 가루가 반짝인다
        if (ground > 0.5 && rnd < 0.55) this.spawn(x, g + 0.4 + R() * 5, z, 0.25, -0.1 + R() * 0.15, 0.15, rnd < 0.25 ? 0xb9a8ff : 0xffffff, 0.05 + R() * 0.05, 3 + R() * 3, 0, 0.9, 2.6, 0.35, 0.8);
      } else if (b === BIOME.SHADOW) {
        // 검은 재와 보랏빛 불티
        if (rnd < 0.4) this.spawn(x, g + R() * 2.5, z, (R() - 0.5) * 0.6, 0.8 + R() * 1.4, (R() - 0.5) * 0.6, 0xb06aff, 0.07 + R() * 0.06, 2.5 + R() * 2.5, -0.1, 1, 3.0, 0.7, 0.3);
        else if (rnd < 0.85) this.spawn(x, g + 2 + R() * 8, z, 0.3, -0.5 - R() * 0.4, 0.2, 0x2a2434, 0.1 + R() * 0.08, 6, 0, 0.6, 1, 0.5, 0.5);
      } else if (b === BIOME.CANYON) {
        // 깊은 골짜기에서는 바람이 위로 솟구친다 (활공 천을 펴면 떠오른다)
        if (ground < 10 && rnd < 0.5) this.spawn(x, g + R() * 16, z, 0.4, 7 + R() * 5, 0.2, rnd < 0.2 ? 0xffffff : 0xfff0d8, 0.05 + R() * 0.04, 1.0 + R() * 0.8, 0, 0.55, 1.4, 0.25, 0.25);
        // 협곡을 훑고 지나가는 붉은 흙바람
        else if (rnd < 0.7) this.spawn(x, g + 0.2 + R() * 3.5, z, 6 + R() * 4.5, 0.3 + R() * 0.7, 1.6 + R() * 2.2, rnd < 0.18 ? 0xffdcae : 0xe8a070, 0.06 + R() * 0.06, 1.5 + R() * 1.2, 0.1, 0.5, 1, 0.3, 0.35);
      } else if (b === BIOME.GLACIER) {
        // 반짝이는 얼음 가루와 드문드문 내리는 눈
        if (rnd < 0.45) this.spawn(x, g + 0.2 + R() * 4, z, 0.3, -0.05 + R() * 0.1, 0.2, rnd < 0.15 ? 0xbfe9ff : 0xffffff, 0.05 + R() * 0.04, 2.5 + R() * 2.5, 0, 0.9, 2.8, 0.3, 0.7);
        else if (rnd < 0.75) this.spawn(x, g + 3 + R() * 9, z, 1.0 + R() * 0.6, -1.2 - R() * 0.7, 0.5 + R() * 0.4, 0xffffff, 0.08 + R() * 0.07, 5 + R() * 2, 0, 0.9, 1.2, 0.5, 0.4);
      } else if (b === BIOME.TERRACE) {
        // 낮에는 꽃잎과 민들레 씨, 밤에는 반딧불이
        if (ground > 0.5) {
          if (dark) {
            if (rnd < 0.32) this.spawn(x, g + 0.4 + R() * 2.4, z, (R() - 0.5) * 0.4, (R() - 0.5) * 0.2, (R() - 0.5) * 0.4, 0xe6ff7a, 0.1, 4 + R() * 4, 0, 1, 3.6, 0.9, 1.0);
          } else if (rnd < 0.35) this.spawn(x, g + 2 + R() * 5, z, 0.6 + R() * 0.5, -0.45 - R() * 0.35, 0.3 + R() * 0.3, rnd < 0.1 ? 0xffffff : rnd < 0.22 ? 0xffd34f : 0xff9ab8, 0.09 + R() * 0.05, 6 + R() * 2, 0, 0.95, 1.1, 1.2, 0.5);
          else if (rnd < 0.7) this.spawn(x, g + 0.3 + R() * 2.5, z, 0.5 + R() * 0.4, 0.15 + R() * 0.25, 0.25 + R() * 0.25, 0xffffff, 0.06 + R() * 0.04, 5 + R() * 3, 0, 0.75, 1.3, 0.6, 1.0);
        }
      } else if (b === BIOME.REEF) {
        if (ground < 0.15) {
          // 얕은 바다: 낮에는 물비늘이 반짝이고, 밤에는 바다가 푸르게 빛난다
          if (dark) {
            if (rnd < 0.6) this.spawn(x, 0.07, z, (R() - 0.5) * 0.3, 0, (R() - 0.5) * 0.3, rnd < 0.15 ? 0xa8fff0 : 0x4fd8ff, 0.09 + R() * 0.06, 2.5 + R() * 3, 0, 0.9, 3.4, 0.15, 0.8);
          } else if (rnd < 0.55) this.spawn(x, 0.08, z, 0.12, 0, 0.08, 0xffffff, 0.05 + R() * 0.05, 0.7 + R() * 0.8, 0, 0.9, 2.6, 0, 0.25);
        } else if (dark) {
          if (rnd < 0.2) this.spawn(x, g + 0.4 + R() * 2.2, z, (R() - 0.5) * 0.4, (R() - 0.5) * 0.2, (R() - 0.5) * 0.4, 0x9afff0, 0.1, 4 + R() * 4, 0, 1, 3.4, 0.9, 1.0);
        } else if (rnd < 0.3) this.spawn(x, g + 0.3 + R() * 3, z, 0.8 + R() * 0.5, 0.05 + R() * 0.1, 0.4 + R() * 0.3, 0xfffbe0, 0.05 + R() * 0.04, 4 + R() * 3, 0, 0.6, 1.3, 0.4, 1.0);
      } else if (b === BIOME.PILLARS) {
        // 바닥을 천천히 흐르는 안개 자락, 밤에는 반딧불이
        if (rnd < 0.42) this.spawn(x, g + 0.6 + R() * 4.5, z, 0.45 + R() * 0.4, 0.02, 0.22 + R() * 0.2, 0xeaf4ee, 1.3 + R() * 1.4, 6 + R() * 4, 0, 0.07, 1, 0.15, 2.2);
        else if (dark) {
          if (rnd < 0.62) this.spawn(x, g + 0.4 + R() * 2.4, z, (R() - 0.5) * 0.4, (R() - 0.5) * 0.2, (R() - 0.5) * 0.4, 0xd8ffb0, 0.1, 4 + R() * 4, 0, 1, 3.4, 0.9, 1.0);
        } else if (rnd < 0.62 && ground > 0.5) this.spawn(x, g + 3 + R() * 5, z, 0.4 + R() * 0.4, -0.5 - R() * 0.4, 0.25 + R() * 0.25, rnd < 0.5 ? 0x5fae48 : 0x9ccc5a, 0.09 + R() * 0.05, 6 + R() * 2, 0, 0.9, 1, 1.0, 0.5);
      } else if (b === BIOME.CRATER) {
        // 땅에서 떠오르는 별빛 알갱이, 그리고 이따금 떨어지는 별똥
        if (rnd < 0.6) this.spawn(x, g + 0.2 + R() * 3, z, (R() - 0.5) * 0.3, 0.25 + R() * 0.5, (R() - 0.5) * 0.3, rnd < 0.14 ? 0xfff2c0 : 0x8fb4ff, 0.06 + R() * 0.06, 4 + R() * 4, 0, 0.95, 3.2, 0.5, 0.8);
        else if (rnd < 0.625) {
          const sy = g + 24 + R() * 12;
          const vx = 9 + R() * 5;
          const vy = -19 - R() * 6;
          const vz = (R() - 0.5) * 8;
          const col = R() < 0.3 ? 0xfff2c0 : 0xbfd4ff;
          // 꼬리를 끌며 떨어진다 (알갱이 여러 개를 줄지어 뿌린다)
          for (let k = 0; k < 7; k++) this.spawn(x - vx * k * 0.035, sy - vy * k * 0.035, z - vz * k * 0.035, vx, vy, vz, col, 0.3 - k * 0.035, 1.25 - k * 0.04, 0, 1 - k * 0.11, 4.2, 0, 0.08);
        }
      } else if (b === BIOME.SWAMP) {
        if (dark) {
          if (rnd < 0.4) this.spawn(x, g + 0.5 + R() * 2.5, z, (R() - 0.5) * 0.4, (R() - 0.5) * 0.2, (R() - 0.5) * 0.4, 0xb8ff6a, 0.1, 4 + R() * 4, 0, 1, 3.6, 0.9, 1.0);
        } else if (rnd < 0.4) this.spawn(x, g + 0.2 + R() * 2, z, 0.1, 0.15 + R() * 0.2, 0.05, 0xcfe8a8, 0.08 + R() * 0.06, 5 + R() * 3, 0, 0.5, 1, 0.5, 1.0);
      } else if (b === BIOME.AUTUMN || b === BIOME.FOREST) {
        if (dark && ground > 0.5) {
          if (rnd < 0.28) this.spawn(x, g + 0.5 + R() * 2.5, z, (R() - 0.5) * 0.4, (R() - 0.5) * 0.2, (R() - 0.5) * 0.4, 0xe6ff7a, 0.1, 4 + R() * 4, 0, 1, 3.6, 0.9, 1.0);
        } else if (ground > 0.5) {
          // 낙엽과 빛 알갱이
          const autumn = b === BIOME.AUTUMN;
          const cols = autumn ? [0xe2603a, 0xf2a63a, 0xf7e05c, 0xc9541f] : [0x7cc653, 0xa8d65a, 0xd6d65a, 0x5fae48];
          if (rnd < (autumn ? 0.6 : 0.28)) this.spawn(x, g + 3 + R() * 5, z, 0.5 + R() * 0.5, -0.6 - R() * 0.5, 0.3 + R() * 0.3, cols[(R() * cols.length) | 0], 0.11 + R() * 0.07, 6 + R() * 2, 0, 0.95, 1, 1.1, 0.5);
          else if (rnd < 0.8) this.spawn(x, g + 0.5 + R() * 4, z, 0.15, 0.05, 0.1, 0xfff3c0, 0.05 + R() * 0.04, 4 + R() * 3, 0, 0.5, 1.6, 0.4, 1.2);
        }
      } else if (ground > 0.5) {
        // 초원: 낮에는 꽃가루, 밤에는 반딧불이
        if (dark) {
          if (rnd < 0.22) this.spawn(x, g + 0.4 + R() * 2.2, z, (R() - 0.5) * 0.4, (R() - 0.5) * 0.2, (R() - 0.5) * 0.4, 0xe6ff7a, 0.1, 4 + R() * 4, 0, 1, 3.6, 0.9, 1.0);
        } else if (rnd < 0.4) this.spawn(x, g + 0.3 + R() * 3.5, z, 0.45 + R() * 0.4, 0.05 + R() * 0.12, 0.28 + R() * 0.25, rnd < 0.12 ? 0xfff0a0 : 0xffffff, 0.06 + R() * 0.05, 5 + R() * 3, 0, 0.7, 1.25, 0.45, 1.0);
      }
    }
  }

  update(dt, time) {
    // 파티클
    const n = MAXP;
    for (let i = 0; i < n; i++) {
      if (this.pLife[i] <= 0) continue;
      this.pLife[i] -= dt;
      if (this.pLife[i] <= 0) {
        this.pCol[i * 4 + 3] = 0;
        this.pSize[i] = 0;
        continue;
      }
      this.pVel[i * 3 + 1] -= this.pGrav[i] * dt;
      this.pPos[i * 3] += this.pVel[i * 3] * dt;
      this.pPos[i * 3 + 1] += this.pVel[i * 3 + 1] * dt;
      this.pPos[i * 3 + 2] += this.pVel[i * 3 + 2] * dt;
      const wob = this.pWob[i];
      if (wob) {
        this.pPos[i * 3] += Math.sin(time * 2.3 + i * 1.7) * wob * dt;
        this.pPos[i * 3 + 1] += Math.sin(time * 3.1 + i * 2.9) * wob * 0.35 * dt;
        this.pPos[i * 3 + 2] += Math.cos(time * 1.9 + i * 1.3) * wob * dt;
      }
      let a = this.pBase[i] * Math.min(1, (this.pLife[i] / this.pMax[i]) * 1.8);
      const fi = this.pIn[i];
      if (fi > 0) a *= Math.min(1, (this.pMax[i] - this.pLife[i]) / fi);
      this.pCol[i * 4 + 3] = a;
    }
    const g = this.points.geometry;
    g.attributes.position.needsUpdate = true;
    g.attributes.pcolor.needsUpdate = true;
    g.attributes.psize.needsUpdate = true;

    for (const s of this.slashes) {
      if (!s.m.visible) continue;
      s.t += dt;
      const p = s.t / s.dur;
      if (p >= 1) {
        s.m.visible = false;
        continue;
      }
      this._poseSlash(s, p);
      s.m.material.opacity = (s.wide > 1.15 ? 0.5 : 0.75) * (1 - p) * Math.min(1, p * 6);
    }
    for (const st of this.stabs) {
      if (!st.m.visible) continue;
      st.t += dt;
      const p = st.t / st.dur;
      if (p >= 1) {
        st.m.visible = false;
        continue;
      }
      st.m.scale.set(1 + p * 0.6, 1, st.len * Math.min(1, 0.25 + p * 1.6));
      st.m.material.opacity = 0.85 * (1 - p);
    }
    if (this.sparks.some((q) => q.m.visible)) {
      const cq = this.gfx.camera.quaternion;
      for (const sp of this.sparks) {
        if (!sp.m.visible) continue;
        sp.t += dt;
        const p = sp.t / sp.dur;
        if (p >= 1) {
          sp.m.visible = false;
          continue;
        }
        sp.m.quaternion.copy(cq);
        sp.m.rotateZ(sp.roll + p * 0.5);
        sp.m.scale.setScalar(sp.size * (0.35 + 1.1 * (1 - (1 - p) * (1 - p))));
        sp.m.material.opacity = 1 - p * p;
      }
    }
    for (const r of this.rings) {
      if (!r.m.visible) continue;
      r.t += dt;
      const p = r.t / r.dur;
      if (p >= 1) {
        r.m.visible = false;
        continue;
      }
      const e = 1 - (1 - p) * (1 - p);
      r.m.scale.setScalar(0.3 + r.r * e);
      r.m.material.opacity = 0.8 * (1 - p);
    }
    for (let i = this.tele.length - 1; i >= 0; i--) {
      const t = this.tele[i];
      t.t += dt;
      if (t.t < 0) continue;
      t.m.visible = true;
      const p = t.t / t.dur;
      if (p >= 1.12 || t.cancelled) {
        this.scene.remove(t.m);
        t.m.geometry.dispose();
        t.m.material.dispose();
        this.tele.splice(i, 1);
        continue;
      }
      t.m.material.opacity = p < 1 ? 0.14 + 0.36 * p * p + Math.sin(time * 22) * 0.03 : 0.75 * (1 - (p - 1) / 0.12);
    }

    // 떠오르는 글자 위치 갱신
    if (this.texts.length) {
      const cam = this.gfx.camera;
      const w = window.innerWidth;
      const h = window.innerHeight;
      for (const t of this.texts) {
        if (t.life <= 0) continue;
        t.life -= dt;
        if (t.life <= 0) {
          t.el.style.display = 'none';
          continue;
        }
        const p = 1 - t.life / 0.95;
        _v.set(t.x, t.y + p * 1.1, t.z).project(cam);
        if (_v.z > 1 || _v.z < -1) {
          t.el.style.opacity = '0';
          continue;
        }
        const sx = (_v.x * 0.5 + 0.5) * w + t.ox;
        const sy = (-_v.y * 0.5 + 0.5) * h;
        t.el.style.transform = `translate(${sx.toFixed(1)}px, ${sy.toFixed(1)}px) translate(-50%, -50%) scale(${(1 + Math.max(0, 0.25 - p) * 2).toFixed(2)})`;
        t.el.style.opacity = String(Math.min(1, t.life * 3));
      }
    }
  }
}

// 화면 UI: 시작 화면, 게임 화면(HUD), 메뉴(지도·모험가·설정·조작법), 대화, 상점, 채팅
// 모든 화면은 키보드만으로도, 터치만으로도 조작할 수 있다.
import { Vector3 } from '/vendor/three/three.module.js';
import {
  TUNIC_COLORS, HAIR_COLORS, RARITY, SLOTS, SLOT_NAME, TYPE_NAME, WEAPONS, xpNeed, SHARD_COUNT, MAX_LEVEL, MON, itemName, itemStatText,
  POTIONS, POTION_KEYS, MOUNTS, MOUNT_KEYS, UNIQUES, UNIQUE_KEYS, PERKS, HP_SHOW,
} from '/shared/defs.js';
import { W, BIOME_INFO, BIOME_CENTERS, VOLCANO } from '/shared/world.js';
import { TILE } from '/shared/zones.js';
import { $, hex, esc, ICONS, icon } from './dom.js';
import { installItemsUI } from './ui-items.js';
import { QUESTS, rewardText } from './quests.js';

const _v = new Vector3();

// 기력도 100 을 넘으면 길어지는 대신 색이 바뀐다 (초록 → 하늘 → 보라 → 흰색)
const STAMINA_COLORS = ['linear-gradient(90deg, #58d86a, #c6f76a)', '#5fe0ff', '#c79bff', '#ffffff'];
const BUFF_NAME = { sta: '기력', power: '힘', guard: '수호', swift: '신속' };

// 방향 입력 (방향키와 WASD 모두)
const DIRS = {
  ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0],
  KeyW: [0, -1], KeyS: [0, 1], KeyA: [-1, 0], KeyD: [1, 0],
};
const CONFIRM = new Set(['Enter', 'NumpadEnter', 'Space', 'KeyF', 'KeyJ']);
const TABS = ['panel-map', 'panel-inv', 'panel-bag', 'panel-quest', 'panel-settings', 'panel-help'];
// 메뉴를 바로 여는 키
const TAB_KEYS = { KeyM: 'panel-map', KeyB: 'panel-inv', KeyP: 'panel-bag', KeyU: 'panel-quest', KeyH: 'panel-help' };

const KID_TIPS = [
  '달리면 초록색 기력 막대가 줄어들어. 다 떨어지면 잠깐 쉬어야 해!',
  '모닥불 옆이나 마을 안에 있으면 체력이 조금씩 차올라.',
  '빨간 열매가 달린 덤불을 지나가면 회복 열매를 딸 수 있어!',
  '가파른 절벽도 기력만 있으면 오를 수 있대. 기력이 떨어지면 주르륵 미끄러져!',
  '귀환석을 깨워 두면 지도에서 눌러서 바로 날아갈 수 있어.',
  '몬스터가 바닥에 빨간 표시를 그리면 얼른 밖으로 피해야 해!',
  '높은 데서 뛰어내린 다음 점프를 한 번 더 누르면 활공 천이 펴져. 진짜 신나!',
  '친구랑 같이 싸우면 경험치랑 골드를 둘 다 받을 수 있어. 뺏기는 게 아니야!',
  '섬 여기저기에 별이 떠 있는 돌문이 있대. 「별의 시련장」이라는데, 끝까지 가면 체력이나 기력이 늘어난대! 마을 남서쪽이랑 북동쪽에도 하나씩 있어.',
  '본섬 네 모퉁이에서 모랫길을 따라가면 다른 섬이 나온대. 엄청 센 몬스터가 산다던데… 나도 크면 가 볼 거야!',
  '어른들이 그러는데, 이끼 낀 돌등에 전부 불을 밝히면 땅에서 숨겨진 문이 올라온대. 진짜일까?',
  '마을 북서쪽에 서 있는 커다란 석판 봤어? 별의 인장을 받을 때마다 별이 하나씩 켜진대. 열두 개가 다 켜지면… 무슨 일이 생길까?',
  '화산 기슭에 불꽃 갈기를 가진 빨간 말이 산대! 황금 사과를 엄청 좋아한다던데. 설산에는 하얀 말, 그림자 섬에는 밤에만 나오는 까만 말도 있대.',
  '근데 그 말들, 사과만 준다고 따라오는 게 아니래. 등에 올라타서 마구 날뛰는 걸 끝까지 버텨 내야 한대! 그리고 겁이 많아서 달려가면 도망가니까 살금살금 걸어가야 해.',
  '말을 타고 달리면서 칼을 휘두르면 「돌격!」이 된대. 엄청 세다던데… 나도 말 타고 싶다!',
  '본섬 동서남북 끝에서 아주 긴 모랫길을 따라가면 먼바다 너머의 땅이 나온대. 협곡이랑 얼음 호수, 거인의 계단, 산호 군도… 그 너머에도 땅이 더 있다던데!',
  '보리 아저씨가 물약을 팔기 시작했어. 마시면 힘이 세지는 물약도 있대!',
  '마을 북쪽 풀밭에 반짝반짝하는 바람 정령이 산대! 이름은 하늬. 술래잡기에서 다섯 번 잡으면 친구가 돼서 하늘 높이 띄워 준대. 난 세 번밖에 못 잡았어…',
  '마을 남동쪽에 금빛 문 봤어? 「레이드」래. 친구들이랑 같이 들어가서 엄청 큰 거인이랑 싸우는 데야. 혼자서는 절대 못 이긴다던데!',
  '먼바다 너머 땅에도 별의 시련장이 생겼대. 어른들도 벌벌 떤다던데… 하늘 기둥의 시련장은 돌기둥 꼭대기에 있어서 바람 정령이 없으면 올라가기도 힘들대.',
];
const GUIDE_TIPS = [
  [],
  ['이 숲 동쪽 끝 깊은 곳에 오래된 제단이 있어요. 커다란 바위 수호자가 지키고 있으니 단단히 준비하세요.', '여기서 남쪽으로 조금 가면 별이 떠 있는 돌문, 「속삭임의 시련장」이 있어요. 힘이 아니라 눈썰미를 시험한다더군요.', '숲을 지나 남동쪽 끝 모랫길을 건너면 벚꽃이 흩날리는 섬이 나온답니다.'],
  ['남쪽 사막에서 가장 높은 붉은 탁상지 꼭대기에 무언가 반짝여요. 더 남쪽 유적에도 수호자가 있다더군요.', '남동쪽 모래 언덕 너머에는 「모래의 시련장」이 서 있어요. 전갈 떼가 지키는 힘의 시련이랍니다.', '본섬 남서쪽 끝에서 모랫길을 건너면 커다란 버섯이 자라는 섬이 나온다더군요.'],
  ['늪 깊은 곳과 남쪽 말랑이 둥지에 별조각이 있다는 소문이에요. 물이 깊은 곳에서는 기력이 닳으니 조심하세요.', '남동쪽 물가에 「안개의 시련장」이 있어요. 그리고… 이건 옛이야기인데요.', '늪 서쪽 끝의 외진 물가에 이끼 낀 돌등 셋이 서 있대요. 셋 모두에 불을 밝히면 땅 밑에서 「잊힌 수로」의 문이 올라온다는군요. 들어갔다 돌아온 사람은 드물어요.'],
  ['서리봉 정상에 별조각이 있어요. 기력을 아껴 가며 완만한 길을 찾아 오르세요. 서쪽에는 설인들의 야영지가 있답니다.', '여기서 서쪽 비탈에는 「서리의 시련장」이 있어요. 불기둥 사이를 지나는 용기의 시련이지요.', '설산을 넘어 북동쪽 비탈로 내려가면 눈에 반쯤 묻힌 돌등 넷이 있다더군요. 옛사람들이 금고를 숨겨 둔 자리래요. 넷을 모두 밝혀야 문이 드러난답니다. 단단히 준비하고 가세요.', '아, 그리고 설산의 가장 외진 눈밭에서 발굽이 닿는 물이 얼어붙는 하얀 말을 봤다는 사람이 있어요. 황금 사과 다섯 개를 들고 걸어서 다가가 등에 올라타세요. 날뛰는 등 위에서 끝까지 버텨 내야 따라온대요. 달려가면 놀라 달아난답니다.'],
  ['이 협곡을 따라가면 분화구예요. 별조각 열두 개가 모두 모이면 그곳에서 그림자 군주가 깨어난대요…', '남서쪽 잿더미 벌판에 「잿불의 시련장」이 있어요. 불도깨비들이 득실거린다니 조심하세요.', '화산 북동쪽 끝에서 모랫길을 건너면 그림자가 드리운 섬이 나와요. 이 섬에서 가장 위험한 곳이랍니다.', '화산 기슭의 외진 곳에는 불꽃 갈기를 지닌 붉은 말이 산답니다. 절벽도 달려 오른대요. 황금 사과 다섯 개를 들고 등에 올라타, 날뛰는 걸 버텨 내야 길든다더군요. 겁이 많으니 달리지 말고 걸어서 다가가세요.'],
  ['고원 서쪽 늑대 언덕에 별조각이 있어요. 우두머리 늑대가 무리를 이끌고 있으니 친구와 함께 가세요.', '남서쪽으로 내려가면 「단풍의 시련장」이 있어요. 불기둥이 켜졌다 꺼지는 박자를 잘 보세요.', '고원 북서쪽 끝 모랫길 너머에는 수정이 자라는 섬이 있답니다.'],
  ['어서 와요, 벚꽃 언덕이에요. 꽃잎은 고와도 이곳 몬스터는 사나워요. 언덕 한가운데는 꽃잎 수호자가 지키고 있답니다.', '동쪽으로 조금 가면 「꽃잎의 시련장」이 있어요. 늑대 떼가 기다리는 힘의 시련이에요.'],
  ['버섯 숲에 온 걸 환영해요. 밤이 되면 포자가 반딧불처럼 빛나서 참 예쁘답니다. 하지만 버섯 사이에 숨은 녀석들은 조심하세요.', '남쪽 깊은 곳에 「포자의 시련장」이 있어요. 발판이 일곱 번이나 빛난다니 잘 기억해야 해요.'],
  ['수정 고원이에요. 수정에 비친 자기 모습에 한눈팔다가는 큰일 나요. 고원 가운데의 수정 수호자는 어지간해서는 쓰러지지 않아요.', '서쪽 끝에 「수정의 시련장」이 있어요. 불기둥이 세 줄씩 늘어서 있다더군요.'],
  ['…여기까지 오다니 제법이군. 그림자 황무지는 이 세계에서 가장 험한 곳이야. 북쪽에 「그림자의 시련장」이 있지.', '그리고 이 섬 북동쪽 끝자락에 돌등 다섯이 있는데, 낮에는 아무리 해도 불이 붙지 않아. 별이 뜬 밤에만 불이 붙지.', '다섯을 모두 밝히면 「별무덤」의 문이 열린다더군. 공허의 기사가 지킨다는데… 살아 돌아온 이는 아직 못 봤어.', '밤이 되면 이 섬 동쪽 끝에 검은 말이 나타나. 어떤 공격에도 주인을 떨어뜨리지 않는 전투마지. 황금 사과 여덟 개는 있어야 눈길이라도 줄 거야. 올라탄 다음이 진짜 시작이지. 그 녀석만큼 사납게 날뛰는 말은 없거든.'],
  // ---- 먼바다 너머의 여섯 땅 ----
  ['어서 오세요, 바람 협곡입니다. 위에서 보면 판판한 고원이지만 발밑은 미로처럼 갈라진 깊은 협곡이에요.', '협곡 바닥에는 맑은 물이 흐르고 야자가 자란답니다. 길을 잃으면 물길을 따라가세요. 고원 위로 올라갈 때는 절벽을 타거나, 골짜기 바닥에서 뛰어올라 활공 천을 펴 보세요. 솟구치는 바람이 고원 위까지 띄워 준답니다.', '협곡 한가운데쯤에는 협곡 수호자가 버티고 있어요. 붉은 전갈 떼도 사나우니 조심하세요.', '고원 위 동남쪽에 「돌개바람의 시련장」이 생겼어요. 불기둥 사이에서 싸워야 한답니다. 그리고 동쪽 끝 고원에 이끼 낀 돌등 다섯이 흩어져 있다는데… 모두 밝히면 「울부짖는 바람굴」의 문이 솟는대요. 금빛 전갈 여제가 산다던데요.'],
  ['여긴 얼음 호수야. 호수가 통째로 꽁꽁 얼어붙어서 그 위를 걸어 다닐 수 있지. 다만 얼음판은 미끄러워서 발이 죽죽 밀리니까 조심해!', '호수 위로 솟은 얼음 송곳 봤어? 꼭대기에 오르면 호수가 한눈에 들어와. 설인들이 얼음판 위를 어슬렁거리니 한눈팔지는 말고.', '호수 한가운데쯤에는 얼음 수호자가 있어. 웬만한 장비로는 흠집도 안 날걸.', '귀환석에서 서쪽 물가로 조금 가면 「살얼음의 시련장」이 있어. 발판이 아홉 개나 되는 지혜의 시련이라더라. 순서가 엄청 길다니까 친구랑 같이 외워!'],
  ['거인의 계단에 잘 왔네. 옛날 거인들이 밟고 다니던 계단이라는데, 한 층이 사람 키의 일곱 배는 된다네.', '층과 층 사이는 깎아지른 절벽이지만, 잘 찾아보면 걸어서 오를 수 있는 비탈이 군데군데 있지. 대나무 숲도 구경하고 가게.', '맨 꼭대기 가까이에 계단 수호자가 산다는데, 나는 무서워서 한 번도 못 올라가 봤네.', '서쪽 위층에 「층층의 시련장」이 섰다네. 불길이 끝도 없이 이어지는 용기의 시련이라지. 쉬는 틈마다 도깨비들이 돌을 던진다니 구르기를 아끼게.'],
  ['산호 군도에 온 걸 환영해요! 이곳 바다는 얕아서 섬과 섬 사이를 걸어서 건널 수 있어요. 물빛이 짙은 곳만 깊으니 돌아서 가세요.', '밤이 되면 바다가 온통 푸르게 빛난답니다. 꼭 한번 보고 가세요.', '군도 한가운데 섬에는 산호 수호자가 살아요. 알록달록하다고 얕보면 큰코다쳐요.', '남동쪽 섬에 「물거품의 시련장」이 있어요. 그리고 남서쪽 먼 섬에 돌등 다섯이 있는데, 모두 밝히면 「가라앉은 신전」이 떠오른대요. 밀물의 군주가 일으키는 물결은 안에서 밖으로, 밖에서 안으로 번갈아 밀려온다니 발을 잘 맞추세요.'],
  ['하늘 기둥이야. 안개 낀 분지 위로 돌기둥이 수십 개나 솟아 있지. 높은 건 까마득해서 꼭대기가 안 보일 정도야.', '기둥 꼭대기는 판판해서 소나무가 자라. 기력을 넉넉히 챙겨서 올라가 봐. 꼭대기에서 꼭대기로 활공하면 기분이 끝내준다고!', '안개 속에서는 발소리에 귀를 기울여. 분지 한가운데쯤에는 돌기둥 수호자가 서 있어.', '북쪽 돌기둥 꼭대기에 「구름기둥의 시련장」이 있어. 까마득해서 기어오르다간 기력이 바닥나기 십상이야. 바람 정령을 데리고 있으면 바람 기둥을 타고 금방 오를 수 있다던데!'],
  ['…별똥 분지에 온 걸 환영하네. 아주 오래전 커다란 별이 떨어져 생긴 구덩이지. 지금도 밤낮없이 별똥이 떨어진다네.', '둘레 산을 넘어 들어가면 바닥에 물결 같은 둔덕이 겹겹이 둘러 있고, 한가운데에는 「별의 심장」이라 부르는 봉우리가 빛나고 있지.', '이곳 몬스터는 이 세계에서 가장 강하네. 별똥 수호자는 더 말할 것도 없고. 부디 살아서 돌아가게.', '서남쪽에 「별똥의 시련장」이 있네. 이 세계에서 가장 험한 시련일세. 그리고 분지 남서쪽 끝에 돌등 여섯이 있는데 별이 뜬 밤에만 불이 붙지. 그 아래 「별똥 구덩이」에는 떨어진 별의 화신이 잠들어 있다네.'],
];

export class UI {
  constructor(game) {
    this.game = game;
    this.dirty = true;
    this.cache = {};
    this.mapCanvas = null;
    this.mmCtx = $('minimap').getContext('2d');
    this.mapOpen = false;
    this.mapView = { z: 2, x: 0, y: 0 }; // 지도 확대 배율(1·2·4)과 화면 가운데의 세계 좌표
    this.mapSel = null;
    this.dialogQueue = null;
    this.type = null; // 대사를 한 글자씩 보여 주는 중이면 { full, n }
    this.mmT = 0;
    this.focusEl = null;
    this.lastTab = 'panel-map';
    this.panels = [...TABS, 'panel-shop', 'panel-trade'];
    this.bagDirty = false; // 가방 내용이 바뀌어 화면을 다시 그려야 하는지
    this.invSel = null;
    this.trade = null; // 진행 중인 교환
    this.tradeReq = null; // 받은 교환 신청

    for (const el of document.querySelectorAll('.slot-ic[data-ic]')) el.innerHTML = ICONS[el.dataset.ic];

    this._bindTitle();
    this._bindHud();
    this._bindPanels();
    this._bindChat();
    this._bindTouchEdit();
    this._bindTrade();
    // 마우스나 터치를 쓰면 키보드 선택 표시를 숨긴다
    window.addEventListener('pointerdown', () => document.body.classList.remove('kb'));
  }

  // ================= 키보드로 고르기 (공통) =================
  _focusables(root) {
    return [...root.querySelectorAll('button, input, [data-nav]')].filter((el) => !el.disabled && !el.classList.contains('x') && !el.hasAttribute('data-nonav') && el.offsetParent !== null);
  }

  setFocus(el, scroll = true) {
    if (this.focusEl && this.focusEl !== el) this.focusEl.classList.remove('kf');
    this.focusEl = el || null;
    if (el) {
      el.classList.add('kf');
      // 키보드로 고르는 중일 때만 그 항목이 보이도록 스크롤한다
      if (scroll && el.scrollIntoView && document.body.classList.contains('kb')) el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      if (el._onFocus) el._onFocus();
    }
  }

  // 누른 방향에서 가장 가까운 항목으로 옮긴다
  navMove(root, dx, dy) {
    const list = this._focusables(root);
    if (!list.length) return false;
    const cur = this.focusEl && list.includes(this.focusEl) ? this.focusEl : null;
    if (!cur) {
      this.setFocus(list[0]);
      return true;
    }
    const a = cur.getBoundingClientRect();
    const ax = a.left + a.width / 2;
    const ay = a.top + a.height / 2;
    const cands = [];
    for (const el of list) {
      if (el === cur) continue;
      const r = el.getBoundingClientRect();
      const ddx = r.left + r.width / 2 - ax;
      const ddy = r.top + r.height / 2 - ay;
      const along = dx ? ddx * dx : ddy * dy;
      if (along < 4) continue;
      cands.push({ el, along, across: dx ? Math.abs(ddy) : Math.abs(ddx), size: dx ? Math.max(a.height, r.height) : 0 });
    }
    let best = null;
    if (dy) {
      // 위아래: 가장 가까운 줄로 가서, 그 줄에서 가로로 가장 가까운 것
      let near = Infinity;
      for (const c of cands) near = Math.min(near, c.along);
      let bs = Infinity;
      for (const c of cands) {
        if (c.along <= near + 14 && c.across < bs) {
          bs = c.across;
          best = c.el;
        }
      }
    } else {
      // 좌우: 같은 줄에서 가장 가까운 것
      let bs = Infinity;
      for (const c of cands) {
        if (c.across < c.size * 0.6 && c.along < bs) {
          bs = c.along;
          best = c.el;
        }
      }
    }
    if (best) {
      this.setFocus(best);
      this.game.audio.click();
    }
    return !!best;
  }

  activate(el) {
    if (!el) return;
    if (el.tagName === 'INPUT' && el.type !== 'range') el.focus();
    else (el._act || el).click();
  }

  // 시작 화면·메뉴·대화가 열려 있을 때의 키 처리. 처리했으면 true (게임 조작으로 넘어가지 않는다)
  handleKey(e, typing) {
    const g = this.game;
    const code = e.code;
    if (!g.input.enabled) {
      if ($('title').classList.contains('hidden')) return false;
      const used = this._titleKey(e, typing);
      if (used) document.body.classList.add('kb');
      return used;
    }
    if (!$('chat-row').classList.contains('hidden')) {
      if (code === 'Escape' || code === 'Tab') {
        this.closeChat();
        return true;
      }
      if (typing) return false;
      $('chat-input').focus();
      return true;
    }
    if (typing) return false;
    if (e.repeat && !DIRS[code]) return this.anyOpen();
    if (!$('dialog').classList.contains('hidden')) {
      document.body.classList.add('kb');
      const dir = DIRS[code];
      if (CONFIRM.has(code) || code === 'KeyE') this.dialogKey();
      else if (code === 'Escape' || code === 'Backspace') {
        const btns = $('dialog-btns').querySelectorAll('button');
        if (btns.length) btns[btns.length - 1].click();
      } else if (dir && dir[0] && !this.type) this.navMove($('dialog-btns'), dir[0], 0);
      return true;
    }
    const id = this.openPanel();
    if (id) {
      document.body.classList.add('kb');
      this._panelKey(e, id);
      return true;
    }
    // 아무것도 열려 있지 않을 때: 메뉴·채팅을 여는 키는 누른 즉시 처리한다
    if (e.repeat) return false;
    // 받은 교환 신청에 답하기
    if (this.tradeReq && (code === 'KeyY' || code === 'KeyN')) {
      this.answerTrade(code === 'KeyY');
      return true;
    }
    const direct = code === 'Tab' || code === 'Escape' ? this.lastTab : TAB_KEYS[code];
    if (direct) {
      document.body.classList.add('kb');
      this.open(direct);
      return true;
    }
    if (code === 'Enter' || code === 'NumpadEnter') {
      this.openChat();
      return true;
    }
    return false;
  }

  openPanel() {
    for (const id of this.panels) if (!$(id).classList.contains('hidden')) return id;
    return null;
  }

  _panelKey(e, id) {
    const code = e.code;
    const isTab = TABS.includes(id);
    if (code === 'Escape' || code === 'Tab' || code === 'Backspace') {
      this.closeAll();
      return;
    }
    if (isTab) {
      if (code === 'KeyQ' || code === 'BracketLeft') return this.tabStep(-1);
      if (code === 'KeyE' || code === 'BracketRight') return this.tabStep(1);
      const jump = TAB_KEYS[code];
      if (jump) return jump === id ? this.closeAll() : this.open(jump);
      if (code === 'KeyT') {
        // 메뉴를 보면서도 자동 달리기를 켜고 끌 수 있다
        if (!e.repeat && this.game.player.state !== 'dead') {
          this.game.input.autoRun = !this.game.input.autoRun;
          this.game.audio.click();
        }
        return;
      }
    }
    if (id === 'panel-shop') {
      // 사기 · 팔기 · 강화 전환
      if (code === 'KeyQ' || code === 'BracketLeft') return this.shopStep(-1);
      if (code === 'KeyE' || code === 'BracketRight') return this.shopStep(1);
    }
    if (id === 'panel-inv' && (code === 'KeyX' || code === 'Delete') && this.invSel) return this._invDiscard(this.invSel);
    const dir = DIRS[code];
    const confirm = CONFIRM.has(code);
    if (id === 'panel-map') {
      if (code === 'KeyZ' || code === 'Equal' || code === 'NumpadAdd') this.mapZoom(1);
      else if (code === 'KeyX' || code === 'Minus' || code === 'NumpadSubtract') this.mapZoom(-1);
      else if (code === 'KeyC') this.mapCenter();
      else if (dir) this.mapMove(dir[0], dir[1]);
      else if (confirm) this.mapGo();
      return;
    }
    const box = $(id).querySelector('.panel-box');
    const f = this.focusEl;
    if (dir) {
      // 슬라이더는 좌우 키로 값을 바꾼다
      if (dir[0] && f && f.tagName === 'INPUT' && f.type === 'range') {
        const step = +f.step || 1;
        f.value = Math.min(+f.max, Math.max(+f.min, +f.value + dir[0] * step));
        f.dispatchEvent(new Event('input', { bubbles: true }));
      } else if (!this.navMove(box, dir[0], dir[1]) && dir[1]) box.scrollTop += dir[1] * 80;
    } else if (confirm) this.activate(f && box.contains(f) ? f : this._focusables(box)[0]);
  }

  tabStep(d) {
    const i = TABS.indexOf(this.openPanel());
    this.open(TABS[(i + d + TABS.length) % TABS.length]);
    this.game.audio.click();
  }

  // ================= 시작 화면 =================
  _bindTitle() {
    const save = this.game.save;
    const name = $('name-input');
    name.value = save.name || '';
    const mk = (wrap, colors, key) => {
      wrap.innerHTML = '';
      colors.forEach((c, i) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.style.background = hex(c);
        b.setAttribute('aria-label', `색 ${i + 1}`);
        if (save[key] === i) b.classList.add('on');
        b.addEventListener('click', () => {
          save[key] = i;
          for (const q of wrap.children) q.classList.remove('on');
          b.classList.add('on');
          this.game.audio.click();
        });
        wrap.appendChild(b);
      });
    };
    mk($('tunic-swatches'), TUNIC_COLORS, 'tunic');
    mk($('hair-swatches'), HAIR_COLORS, 'hair');
    // 이름은 처음 한 번만 정한다. 다시 왔을 때는 인사만 하고 바로 이어서 할 수 있다.
    this.returning = !!save.name;
    const showFields = (v) => {
      $('title-new').classList.toggle('hidden', !v);
      $('title-back').classList.toggle('hidden', v);
    };
    showFields(!this.returning);
    $('title-hello').innerHTML = `<b>${esc(save.name || '')}</b> 님, 다시 오셨군요!`;
    $('title-edit').addEventListener('click', () => {
      showFields(true);
      this.setFocus(name);
      name.focus();
    });
    this._go = () => {
      if ($('start-btn').disabled) return;
      save.name = name.value.trim().slice(0, 12) || save.name || '모험가';
      this.game.startPlay();
    };
    $('start-btn').addEventListener('click', this._go);
    $('title-invite').addEventListener('click', () => this.invite());
    this.setFocus($('start-btn'));
    if (!this.returning && !this.game.input.isTouch) {
      this.setFocus(name);
      name.focus();
    }
  }

  _titleKey(e, typing) {
    const code = e.code;
    const box = $('title');
    const name = $('name-input');
    if (code === 'Enter' || code === 'NumpadEnter') {
      // 초대·모습 바꾸기 버튼 위에서는 그 버튼을, 그 밖에는 바로 시작
      if (!typing && (this.focusEl === $('title-invite') || this.focusEl === $('title-edit'))) this.focusEl.click();
      else this._go();
      return true;
    }
    if (typing) {
      // 이름을 쓰는 중: 아래 화살표나 Tab 으로 다음 항목으로 넘어간다
      if (code === 'ArrowDown' || code === 'Tab' || code === 'Escape') {
        name.blur();
        this.setFocus(name);
        if (code !== 'Escape') this.navMove(box, 0, 1);
        return true;
      }
      return false;
    }
    const dir = DIRS[code];
    if (dir && code.startsWith('Arrow')) {
      this.navMove(box, dir[0], dir[1]);
      // 색 고르기 줄에서는 좌우로 옮기는 즉시 그 색이 적용된다
      const f = this.focusEl;
      if (f && f.parentElement && f.parentElement.classList.contains('swatches')) f.click();
      if (f === name) name.focus();
      return true;
    }
    if (code === 'Tab') {
      this.navMove(box, 0, e.shiftKey ? -1 : 1);
      if (this.focusEl === name) name.focus();
      return true;
    }
    if (code === 'Space') {
      this.activate(this.focusEl);
      return true;
    }
    // 글자를 치기 시작하면 이름 칸으로 (이름 칸이 보일 때만)
    if (e.key && (e.key.length === 1 || e.key === 'Process' || e.keyCode === 229) && name.offsetParent !== null) {
      this.setFocus(name);
      name.focus();
    }
    return false;
  }

  titleStatus(text, ready) {
    $('title-status').textContent = text;
    const b = $('start-btn');
    if (ready !== undefined) {
      b.disabled = !ready;
      b.textContent = ready ? (this.returning ? '이어서 하기' : '모험 시작') : '세계를 만드는 중…';
      if (ready && (!this.focusEl || !$('title').contains(this.focusEl))) this.setFocus(b);
    }
  }

  showGame() {
    $('title').classList.add('hidden');
    $('hud').classList.remove('hidden');
    $('name-input').blur();
    this.setFocus(null);
    this.checkRotate();
  }

  checkRotate() {
    const g = this.game;
    const portrait = window.innerHeight > window.innerWidth * 1.15;
    $('rotate-hint').classList.toggle('hidden', !(g.input.isTouch && portrait && g.playing && !this.rotateOk));
  }

  // 조작 장치가 바뀌면(키보드 <-> 터치) 안내를 그에 맞게 바꾼다
  onInputMode() {
    this.cache = {};
    if (!$('panel-help').classList.contains('hidden')) this.refreshHelp();
    this.checkRotate();
  }

  // ================= 게임 화면 =================
  _bindHud() {
    const g = this.game;
    for (const b of document.querySelectorAll('#menu-btns button')) {
      b.addEventListener('click', () => {
        g.audio.click();
        if (b.dataset.ui === 'chat') this.openChat();
        else this.openMenu();
      });
    }
    // 키 안내는 눌러서도 쓸 수 있다 (마우스만 쓰는 경우)
    const hints = [['roll', 'X', '구르기'], ['lock', 'C', '주목'], ['mount', 'G', '탈것'], ['gust', 'Z', '솟구침'], ['autorun', 'T', '자동 달리기'], ['menu', 'Tab', '메뉴'], ['bag', 'B', '가방'], ['map', 'M', '지도'], ['chat', 'Enter', '채팅']];
    const kh = $('keyhints');
    for (const [act, key, label] of hints) {
      const b = document.createElement('button');
      b.innerHTML = `<kbd>${key}</kbd>${label}`;
      if (act === 'mount') b.className = 'mount-only';
      if (act === 'gust') b.className = 'gust-only';
      b.addEventListener('click', () => g.input.pressed.add(act));
      kh.appendChild(b);
    }
    $('prompt').addEventListener('click', () => g.interact());
    $('prompt').addEventListener('touchstart', (e) => {
      e.preventDefault();
      g.interact();
    }, { passive: false });
    $('rotate-ok').addEventListener('click', () => {
      this.rotateOk = true;
      $('rotate-hint').classList.add('hidden');
    });
  }

  set(id, key, value, fn) {
    if (this.cache[key] === value) return;
    this.cache[key] = value;
    fn($(id), value);
  }

  update(dt) {
    const g = this.game;
    const p = g.player;
    const s = g.save;
    if (!p) return;

    // 체력: 길이가 늘 같은 빨간 막대와 숫자 (체력이 4분의 1 아래로 내려가면 깜빡인다)
    this.set('hp-fill', 'hp', p.hp * 1000 + p.maxHp, (el) => {
      const hp = Math.max(0, Math.round(p.hp));
      el.style.width = `${Math.max(0, Math.min(1, hp / p.maxHp)) * 100}%`;
      $('hp-num').textContent = `${hp * HP_SHOW} / ${p.maxHp * HP_SHOW}`;
      $('hp-bar').classList.toggle('low', hp > 0 && hp <= p.maxHp * 0.25);
    });
    const st = Math.round((p.stamina / p.maxStamina) * 100);
    const stTier = Math.max(0, Math.min(3, Math.ceil(p.stamina / 100) - 1));
    const stIn = Math.round(Math.min(100, p.stamina - stTier * 100));
    this.set('stamina-fill', 'st', stIn + stTier * 1000, (el) => {
      el.style.width = stIn + '%';
      el.style.background = stTier ? STAMINA_COLORS[stTier] : '';
      el.parentNode.style.background = stTier ? STAMINA_COLORS[stTier - 1] : '';
    });
    this.set('stamina', 'stc', (st < 100 ? 1 : 0) + (p.exhausted ? 4 : st < 30 ? 2 : 0), (el) => {
      el.classList.toggle('show', st < 100);
      el.classList.toggle('low', st < 30 && !p.exhausted);
      el.classList.toggle('out', p.exhausted);
    });
    // 물약: 가진 것만 작게, 효과가 남아 있으면 테두리가 빛난다
    this.set('pots', 'pots', POTION_KEYS.map((k) => s.pots[k] * 2 + (p.buffs[k] > 0 ? 1 : 0)).join(), (el) => {
      el.innerHTML = POTION_KEYS.map((k, i) => (s.pots[k] > 0 ? `<div class="pot${p.buffs[k] > 0 ? ' on' : ''}" style="color:${POTIONS[k].css}">${icon('potion')}<b>${s.pots[k]}</b><kbd>${i + 1}</kbd></div>` : '')).join('');
      const total = POTION_KEYS.reduce((a, k) => a + s.pots[k], 0);
      document.body.classList.toggle('has-potion', total > 0);
      $('b-potion').firstElementChild.textContent = `물약 ${total}`;
      if (!$('pot-menu').classList.contains('hidden')) this.renderPotMenu();
    });
    const duel = s.settings.pvp ? (g.duel() ? 2 : 1) : 0;
    this.set('buffs', 'buffs', POTION_KEYS.map((k) => (p.buffs[k] > 0 ? Math.ceil(p.buffs[k]) : 0)).join() + duel + (p.chill > 0 ? 'c' : ''), (el) => {
      el.innerHTML =
        (duel ? `<span class="buff duel${duel === 2 ? ' on' : ''}">⚔ 결투 모드${duel === 2 ? '' : ' · 안전 구역'}</span>` : '') +
        (p.chill > 0 ? '<span class="buff" style="color:#bfe9ff">❄ 느려짐</span>' : '') +
        POTION_KEYS.map((k) => (p.buffs[k] > 0 ? `<span class="buff" style="color:${POTIONS[k].css}">${icon('potion')}${BUFF_NAME[k]} ${Math.ceil(p.buffs[k])}초</span>` : '')).join('');
    });
    this.set('lvl', 'lvl', s.level, (el, v) => (el.textContent = 'Lv.' + v));
    const need = xpNeed(s.level);
    this.set('xp-fill', 'xp', s.level >= MAX_LEVEL ? 100 : Math.round((s.xp / need) * 100), (el, v) => (el.style.width = v + '%'));
    this.set('res-gold', 'gold', s.gold, (el, v) => (el.textContent = v));
    this.set('res-berry', 'berry', s.berries, (el, v) => {
      el.textContent = v;
      $('slot-berry').classList.toggle('empty', v <= 0);
      $('b-heal').firstElementChild.textContent = `열매 ${v}`;
    });
    this.set('res-arrow', 'arrow', s.arrows, (el, v) => {
      el.textContent = v;
      $('slot-bow').classList.toggle('empty', v <= 0);
      $('b-bow').firstElementChild.textContent = `활 ${v}`;
    });
    // 가방 내용이 바뀌었으면 열려 있는 화면을 다시 그린다
    if (this.bagDirty) {
      this.bagDirty = false;
      if (!$('panel-inv').classList.contains('hidden')) this.refreshInv(this.invSel);
      else if (this.trade) this.refreshTrade(this._tradeFocus());
    }
    if (this.tradeReq) {
      this.tradeReq.t -= dt;
      if (this.tradeReq.t <= 0) this.answerTrade(false);
    }
    // 무기 칸은 지금 든 무기 종류를 보여 준다
    this.set('slot-sword', 'wkind', p.wkind + ':' + (s.eq.weapon ? s.eq.weapon.r : 0), (el) => {
      el.querySelector('.slot-ic').innerHTML = ICONS[p.wkind] || ICONS.sword;
      el.style.borderColor = s.eq.weapon && s.eq.weapon.r >= 1 ? RARITY[s.eq.weapon.r].css : '';
    });
    // 바람 정령의 바람 구슬 (친구가 된 뒤에만 보인다)
    const sp = g.sprite;
    this.set('res-gust', 'gust', s.sprite ? sp.charges : -1, (el, v) => {
      document.body.classList.toggle('has-gust', v >= 0);
      el.textContent = Math.max(0, v);
      $('slot-gust').classList.toggle('empty', v <= 0);
      $('b-gust').firstElementChild.textContent = `솟구침 ${Math.max(0, v)}`;
      $('b-gust').classList.toggle('off', v <= 0);
    });
    this.set('slot-gust', 'gustOn', sp.castT > 0, (el, v) => el.classList.toggle('on', v));
    this.set('b-mount', 'mount', (p.hasMount() ? 1 : 0) + (p.mounted ? 2 : 0), (el) => {
      document.body.classList.toggle('has-mount', p.hasMount());
      el.classList.toggle('active', p.mounted);
    });
    // 지금 쓰고 있는 장비 칸을 눌린 것처럼 보여 준다
    const act = p.action;
    this.set('slot-sword', 'swOn', !!(act && act.type === 'atk'), (el, v) => el.classList.toggle('on', v));
    this.set('slot-bow', 'bowOn', !!(act && act.type === 'bow'), (el, v) => el.classList.toggle('on', v));
    this.set('slot-berry', 'berOn', p.healCd > 0.5, (el, v) => el.classList.toggle('on', v));
    this.set('autorun', 'auto', g.input.autoRun, (el, v) => el.classList.toggle('hidden', !v));
    this.set('menu-run', 'menurun', g.input.autoRun && !!this.openPanel(), (el, v) => el.classList.toggle('hidden', !v));
    this.set('mm-time', 'night', g.gfx.night > 0.5, (el, v) => el.classList.toggle('night', v));

    // 목표
    let q;
    if (!s.talkedElder) q = '촌장 한울과 이야기하기<small>마을 한가운데 제단 옆에 있어요</small>';
    else if (g.bossState === 'dead') q = '승리! 섬에 빛이 돌아왔습니다<small>곧 더 강한 새 순환이 시작됩니다</small>';
    else if (g.bossState === 'awake') q = '그림자 군주 쓰러뜨리기<small>화산 협곡을 지나 분화구로</small>';
    else q = `별조각 모으기 ${g.shards.size}/${SHARD_COUNT}<small>지도에서 ★ 위치를 확인하세요</small>`;
    // 의뢰: 진행 상황이 바뀌면 화면의 목록과 머리 위 표시를 새로 그린다
    const Q = g.quests;
    this.questT = (this.questT || 0) - dt;
    if (Q.dirty || this.questT <= 0) {
      Q.dirty = false;
      this.questT = 1;
      this.questLines = Q.tracked().map((t) => `<span class="ql${t.rdy ? ' rdy' : ''}">${esc(t.text)}</span>`).join('');
      for (const n of g.objects.npcs) n.qm = Q.marker(n.key);
      if (this.openPanel() === 'panel-quest') this.refreshQuest();
    }
    this.set('quest', 'quest', q + (s.talkedElder ? this.questLines || '' : ''), (el, v) => (el.innerHTML = v));

    const zs = g.zone;
    const b = BIOME_INFO[g.world.biomeAt(p.pos.x, p.pos.z)];
    const inVillage = Math.hypot(p.pos.x, p.pos.z) < 44;
    this.set('region', 'region', zs ? (zs.raid ? `${zs.def.name} · 레이드` : `${zs.def.name} · Lv.${zs.def.level}`) : inVillage ? '새벽 마을' : `${b.name} · Lv.${b.level}`, (el, v) => (el.textContent = v));
    const friends = g.ents.players.size;
    this.set('friends', 'friends', friends, (el, v) => {
      el.classList.toggle('hidden', v === 0);
      el.textContent = `● 함께하는 친구 ${v}명`;
    });
    this.set('rest', 'rest', p.resting && p.hp < p.maxHp, (el, v) => el.classList.toggle('hidden', !v));
    this.set('vignette', 'low', p.hp > 0 && p.hp <= 2 && p.state !== 'dead', (el, v) => el.classList.toggle('low', v));
    this.set('death', 'dead', p.state === 'dead', (el, v) => el.classList.toggle('hidden', !v));

    // 대상 정보
    const t = g.ents.target;
    if (t && !t.info.boss) {
      const frac = Math.max(0, Math.min(1, t.hp / t.maxHp));
      this.set('target', 'tshow', true, (el) => el.classList.remove('hidden'));
      this.set('target-name', 'tname', `${t.info.name} Lv.${t.info.level}`, (el, v) => (el.textContent = v));
      this.set('target-fill', 'tfill', Math.round(frac * 100), (el, v) => (el.style.width = v + '%'));
    } else this.set('target', 'tshow', false, (el) => el.classList.add('hidden'));
    // 보스 체력
    let boss = g.ents.monsters.get(g.pois.bossId);
    if (zs) {
      // 던전의 주인: 싸움이 시작됐거나 다쳤을 때만 보여 준다
      boss = g.zones.boss();
      if (boss && boss.hp5 >= 31 && boss.lastState !== 2 && boss.lastState !== 3 && boss.lastState !== 4) boss = null;
    }
    if (boss && !boss.dying) {
      this.set('boss', 'bshow', true, (el) => el.classList.remove('hidden'));
      this.set('boss-name', 'bname', boss.info.name, (el, v) => (el.textContent = v));
      this.set('boss-fill', 'bfill', Math.round((boss.hp5 / 31) * 100), (el, v) => (el.style.width = v + '%'));
    } else this.set('boss', 'bshow', false, (el) => el.classList.add('hidden'));

    // 주목한 대상 위에 표시를 띄운다
    const lk = p.lock;
    let lockOn = false;
    if (lk) {
      _v.set(lk.x, lk.y + lk.info.def.height * (lk.info.elite ? 1.45 : 1) * 0.55, lk.z).project(g.gfx.camera);
      if (_v.z > -1 && _v.z < 1) {
        lockOn = true;
        $('lock').style.transform = `translate(${((_v.x * 0.5 + 0.5) * window.innerWidth).toFixed(1)}px, ${((-_v.y * 0.5 + 0.5) * window.innerHeight).toFixed(1)}px)`;
      }
    }
    this.set('lock', 'lock', lockOn, (el, v) => el.classList.toggle('hidden', !v));

    // 상호작용 안내
    const uiOpen = this.anyOpen();
    this.set('keyhints', 'uiopen', uiOpen, (el, v) => (el.style.visibility = v ? 'hidden' : ''));
    const it = g.currentInteract;
    const label = it && !uiOpen ? it.label() : '';
    this.set('prompt', 'prompt', label, (el, v) => {
      el.classList.toggle('hidden', !v);
      if (v) el.innerHTML = `<kbd>E</kbd><span>${esc(v)}</span>`;
      el.classList.toggle('locked', v.startsWith('봉인'));
    });

    // 대사를 한 글자씩
    const ty = this.type;
    if (ty) {
      ty.n += dt * 46;
      if (ty.n >= ty.full.length) this._typeDone();
      else $('dialog-text').textContent = ty.full.slice(0, Math.floor(ty.n));
    }

    this.mmT -= dt;
    if (this.mmT <= 0) {
      this.mmT = 0.066;
      this.drawMinimap();
      if (this.mapOpen) this.drawMap();
    }
  }

  // 물약 고르기 (터치 버튼을 누르면 열린다)
  togglePotMenu() {
    const el = $('pot-menu');
    if (!el.classList.contains('hidden')) {
      el.classList.add('hidden');
      return;
    }
    this.renderPotMenu();
    el.classList.remove('hidden');
  }

  renderPotMenu() {
    const g = this.game;
    const el = $('pot-menu');
    const s = g.save;
    el.innerHTML = '';
    for (const k of POTION_KEYS) {
      if (s.pots[k] <= 0) continue;
      const b = document.createElement('button');
      b.style.color = POTIONS[k].css;
      b.innerHTML = `${icon('potion')}<span style="color:var(--cream)">${POTIONS[k].name} <small>×${s.pots[k]}</small></span>`;
      const use = (e) => {
        e.preventDefault();
        e.stopPropagation();
        g.player.usePotion(k);
        el.classList.add('hidden');
      };
      b.addEventListener('touchstart', use, { passive: false });
      b.addEventListener('click', use);
      el.appendChild(b);
    }
    if (!el.children.length) el.innerHTML = '<p>물약이 없습니다. 상인에게서 살 수 있어요.</p>';
  }

  // 화면을 어둡게 했다가(on) 다시 밝힌다: 시련장·던전에 드나들 때
  fade(on) {
    $('fade').classList.toggle('on', on);
  }

  hurtFlash() {
    const v = $('vignette');
    v.classList.add('hit');
    clearTimeout(this._hv);
    this._hv = setTimeout(() => v.classList.remove('hit'), 90);
  }

  toast(text, good, cls = '') {
    const wrap = $('toasts');
    // 같은 문구가 연달아 뜨지 않게
    if (this._lastToast === text && Date.now() - this._lastToastAt < 1800) return;
    this._lastToast = text;
    this._lastToastAt = Date.now();
    const el = document.createElement('div');
    el.className = 'toast' + (good ? ' good' : '') + (cls ? ' ' + cls : '');
    el.textContent = text;
    wrap.appendChild(el);
    while (wrap.children.length > 4) wrap.removeChild(wrap.firstChild);
    setTimeout(() => el.remove(), 3300);
  }

  _replay(el, ms) {
    el.classList.remove('hidden');
    el.style.animation = 'none';
    void el.offsetWidth;
    el.style.animation = '';
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.add('hidden'), ms);
  }

  banner(title, sub = '') {
    $('banner-title').textContent = title;
    $('banner-sub').textContent = sub;
    $('region-card').classList.add('hidden');
    this._replay($('banner'), 3700);
  }

  // 새 지역에 들어섰을 때 뜨는 지역 이름
  region(title, sub = '', warn = false) {
    if (!$('banner').classList.contains('hidden')) return;
    $('region-title').textContent = title;
    $('region-sub').textContent = sub;
    $('region-card').classList.toggle('warn', warn);
    this._replay($('region-card'), 4300);
  }

  // ---- 길들이기 시험: 균형 막대 ----
  tameShow(name) {
    $('tame-name').textContent = `길들이기 — ${name}`;
    $('tame-hint').textContent = this.game.input.isTouch ? '조이스틱을 좌우로 움직여 표시를 가운데에 · 붉은 화살표 쪽으로 곧 쏠립니다' : 'A · D 로 표시를 가운데에 · 붉은 화살표 쪽으로 곧 쏠립니다';
    $('tame').classList.remove('hidden');
    this._tameZone = -1;
  }

  // bal: 균형(-1 ~ 1), zone: 가운데 범위, trust: 믿음(0 ~ 1), warn: 곧 쏠릴 방향(-1, 0, 1)
  tameUpdate(bal, zone, trust, warn, inside) {
    if (zone !== this._tameZone) {
      this._tameZone = zone;
      const z = $('tame-zone');
      z.style.left = `${50 - zone * 50}%`;
      z.style.width = `${zone * 100}%`;
    }
    const m = $('tame-mark');
    m.style.left = `${50 + Math.max(-1, Math.min(1, bal)) * 50}%`;
    m.classList.toggle('out', !inside);
    $('tame-fill').style.width = `${Math.max(0, Math.min(1, trust)) * 100}%`;
    $('tame-warn-l').classList.toggle('on', warn < 0);
    $('tame-warn-r').classList.toggle('on', warn > 0);
  }

  tameHide() {
    $('tame').classList.add('hidden');
  }

  netStatus(text) {
    const el = $('net');
    el.textContent = text || '';
    el.classList.toggle('hidden', !text);
  }

  // ================= 터치 버튼 배치 바꾸기 =================
  // 저장 형식: settings.touch = { opacity, btn: { attack: { r, b, w }, ... } }  (r·b: 오른쪽·아래에서의 거리, w: 지름)
  _bindTouchEdit() {
    const g = this.game;
    this.editing = false;
    this.editSel = null;
    const wrap = $('abtns');
    let drag = null;
    for (const btn of document.querySelectorAll('.abtn')) {
      btn.addEventListener('pointerdown', (e) => {
        if (!this.editing) return;
        e.preventDefault();
        this._editSelect(btn);
        const r = btn.getBoundingClientRect();
        drag = { btn, ox: e.clientX - (r.left + r.width / 2), oy: e.clientY - (r.top + r.height / 2), id: e.pointerId };
        if (btn.setPointerCapture) btn.setPointerCapture(e.pointerId);
      });
      btn.addEventListener('pointermove', (e) => {
        if (!drag || drag.btn !== btn || e.pointerId !== drag.id) return;
        // 화면 좌표 -> 버튼 묶음(#abtns) 기준의 오른쪽·아래 거리로 바꾼다 (작은 화면에서는 묶음이 축소돼 있다)
        const wr = wrap.getBoundingClientRect();
        const k = wr.width / wrap.offsetWidth || 1;
        const w = btn.offsetWidth;
        const cx = Math.min(window.innerWidth - 20, Math.max(20, e.clientX - drag.ox));
        const cy = Math.min(window.innerHeight - 20, Math.max(20, e.clientY - drag.oy));
        btn.style.right = Math.round((wr.right - cx) / k - w / 2) + 'px';
        btn.style.bottom = Math.round((wr.bottom - cy) / k - w / 2) + 'px';
      });
      const end = (e) => {
        if (drag && drag.btn === btn && e.pointerId === drag.id) drag = null;
      };
      btn.addEventListener('pointerup', end);
      btn.addEventListener('pointercancel', end);
    }
    for (const b of document.querySelectorAll('#touch-edit [data-te]')) {
      b.addEventListener('click', () => {
        const act = b.dataset.te;
        const sel = this.editSel;
        if (act === 'smaller' || act === 'bigger') {
          if (!sel) return this.toast('먼저 크기를 바꿀 버튼을 눌러 주세요.');
          const w = Math.min(150, Math.max(40, sel.offsetWidth + (act === 'bigger' ? 8 : -8)));
          // 가운데를 유지한 채 크기만 바꾼다
          const d = (w - sel.offsetWidth) / 2;
          const cs = getComputedStyle(sel);
          sel.style.right = Math.round(parseFloat(cs.right) - d) + 'px';
          sel.style.bottom = Math.round(parseFloat(cs.bottom) - d) + 'px';
          sel.style.width = sel.style.height = w + 'px';
          sel.style.fontSize = Math.round(Math.max(11, w * 0.19)) + 'px';
        } else if (act === 'fainter' || act === 'solid') {
          const o = Math.min(1, Math.max(0.25, (this._touchOpacity || 1) + (act === 'solid' ? 0.15 : -0.15)));
          this._touchOpacity = o;
          for (const q of document.querySelectorAll('.abtn')) q.style.opacity = o;
        } else if (act === 'reset') {
          delete g.save.settings.touch;
          this.applyTouchLayout();
          this._editSelect(null);
        } else if (act === 'done') this.endTouchEdit();
      });
    }
    this.applyTouchLayout();
  }

  _editSelect(btn) {
    if (this.editSel) this.editSel.classList.remove('sel');
    this.editSel = btn;
    if (btn) btn.classList.add('sel');
  }

  // 저장된 배치를 버튼에 적용한다 (없으면 기본 배치)
  applyTouchLayout() {
    const t = this.game.save.settings.touch;
    this._touchOpacity = (t && t.opacity) || 1;
    for (const btn of document.querySelectorAll('.abtn')) {
      let q = t && t.btn && t.btn[btn.dataset.act];
      if (q && !(q.w >= 30)) q = null;
      btn.style.right = q ? q.r + 'px' : '';
      btn.style.bottom = q ? q.b + 'px' : '';
      btn.style.width = btn.style.height = q ? q.w + 'px' : '';
      btn.style.fontSize = q ? Math.round(Math.max(11, q.w * 0.19)) + 'px' : '';
      btn.style.opacity = t && t.opacity ? t.opacity : '';
    }
  }

  startTouchEdit() {
    this.closeAll();
    this.editing = true;
    this.game.input.editing = true;
    document.body.classList.add('touch-edit');
    $('touch-edit').classList.remove('hidden');
    this._editSelect(null);
  }

  endTouchEdit() {
    const g = this.game;
    const btn = {};
    for (const b of document.querySelectorAll('.abtn')) {
      const cs = getComputedStyle(b);
      if (b.offsetWidth < 30) continue;
      btn[b.dataset.act] = { r: Math.round(parseFloat(cs.right)), b: Math.round(parseFloat(cs.bottom)), w: b.offsetWidth };
    }
    g.save.settings.touch = { opacity: this._touchOpacity || 1, btn };
    g.saveSoon();
    this.editing = false;
    g.input.editing = false;
    document.body.classList.remove('touch-edit');
    $('touch-edit').classList.add('hidden');
    this._editSelect(null);
    this.applyTouchLayout();
    this.toast('버튼 배치를 저장했습니다.', true);
  }

  // ================= 채팅 =================
  _bindChat() {
    const quick = ['안녕!', '이리 와!', '도와줘!', '고마워!', '같이 가자', '잠깐만', '좋았어!', 'ㅋㅋㅋ'];
    const qw = $('chat-quick');
    for (const q of quick) {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = q;
      b.addEventListener('click', () => {
        this.game.net.send({ t: 'chat', text: q });
        this.closeChat();
      });
      qw.appendChild(b);
    }
    $('chat-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const inp = $('chat-input');
      const text = inp.value.trim();
      if (text) this.game.net.send({ t: 'chat', text });
      inp.value = '';
      this.closeChat();
    });
    $('chat-close').addEventListener('click', () => this.closeChat());
  }

  openChat() {
    this.closeAll();
    $('chat-row').classList.remove('hidden');
    this.game.input.unlock();
    $('chat-input').placeholder = this.game.input.isTouch ? '메시지를 입력하세요' : '메시지 입력 · Enter 보내기 · Tab 닫기';
    $('chat-input').focus();
    setTimeout(() => $('chat-input').focus(), 30);
  }

  closeChat() {
    $('chat-row').classList.add('hidden');
    $('chat-input').blur();
  }

  chatAdd(name, text, cls = '') {
    const log = $('chat-log');
    const el = document.createElement('div');
    el.className = 'chat-line ' + cls;
    el.innerHTML = name ? `<b>${esc(name)}</b>${esc(text)}` : esc(text);
    log.appendChild(el);
    while (log.children.length > 6) log.removeChild(log.firstChild);
    setTimeout(() => el.remove(), 12500);
  }

  // ================= 메뉴 · 패널 =================
  _bindPanels() {
    for (const b of document.querySelectorAll('[data-close]')) b.addEventListener('click', () => this.closeAll());
    for (const b of document.querySelectorAll('#menu-tabs [data-tab]')) {
      b.addEventListener('click', () => {
        this.game.audio.click();
        this.open(b.dataset.tab);
      });
    }
    for (const id of this.panels) {
      $(id).addEventListener('click', (e) => {
        if (e.target === $(id)) this.closeAll();
      });
    }
    const g = this.game;
    for (const b of document.querySelectorAll('#set-quality button')) {
      b.addEventListener('click', () => {
        g.setQuality(b.dataset.q, true);
        this.refreshSettings();
      });
    }
    $('set-sound').addEventListener('click', () => {
      g.save.settings.sound = !g.save.settings.sound;
      g.audio.setSound(g.save.settings.sound);
      this.refreshSettings();
    });
    $('set-music').addEventListener('click', () => {
      g.save.settings.music = !g.save.settings.music;
      g.audio.setMusic(g.save.settings.music);
      this.refreshSettings();
    });
    $('set-follow').addEventListener('click', () => {
      g.save.settings.follow = !g.save.settings.follow;
      g.saveSoon();
      this.refreshSettings();
    });
    $('set-sens').addEventListener('input', (e) => {
      g.save.settings.sens = +e.target.value;
      g.input.sens = g.save.settings.sens;
      g.saveSoon();
    });
    $('set-full').addEventListener('click', () => {
      const d = document;
      if (d.fullscreenElement) d.exitFullscreen();
      else if (d.documentElement.requestFullscreen) d.documentElement.requestFullscreen().catch(() => this.toast('이 기기에서는 전체 화면을 쓸 수 없어요.'));
      else this.toast('브라우저 메뉴의 "홈 화면에 추가"를 쓰면 전체 화면으로 즐길 수 있어요.');
    });
    $('set-invite').addEventListener('click', () => this.invite());
    $('set-touch').addEventListener('click', () => this.startTouchEdit());
    $('set-reset').addEventListener('click', () => {
      const b = $('set-reset');
      if (b.dataset.sure) g.resetCharacter();
      else {
        b.dataset.sure = '1';
        b.textContent = '정말요? 한 번 더';
        setTimeout(() => {
          delete b.dataset.sure;
          b.textContent = '처음부터';
        }, 3000);
      }
    });
    const mc = $('map');
    mc.addEventListener('click', (e) => {
      // 끌어서 지도를 옮긴 직후의 누름은 무시한다
      if (this._mapDragged) this._mapDragged = false;
      else this._mapClick(e);
    });
    mc.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.mapZoom(e.deltaY < 0 ? 1 : -1, e);
    }, { passive: false });
    const pts = new Map();
    let pinch = 0;
    mc.addEventListener('pointerdown', (e) => {
      if (!pts.size) this._mapDragged = false;
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY });
      if (pts.size === 2) {
        const [a, b] = [...pts.values()];
        pinch = Math.hypot(a.x - b.x, a.y - b.y);
      }
    });
    mc.addEventListener('pointermove', (e) => {
      const q = pts.get(e.pointerId);
      if (!q) return;
      const dx = e.clientX - q.x;
      const dy = e.clientY - q.y;
      q.x = e.clientX;
      q.y = e.clientY;
      if (pts.size === 1) {
        if (!this._mapDragged && Math.hypot(q.x - q.sx, q.y - q.sy) < 8) return;
        this._mapDragged = true;
        const r = mc.getBoundingClientRect();
        const v = this.mapView;
        const span = W.SIZE / v.z;
        v.x -= (dx / r.width) * span;
        v.y -= (dy / r.height) * span;
        this._mapClamp();
        this.drawMap();
      } else if (pts.size === 2 && pinch > 0) {
        this._mapDragged = true;
        const [a, b] = [...pts.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d > pinch * 1.3 || d < pinch / 1.3) {
          this.mapZoom(d > pinch ? 1 : -1, { clientX: (a.x + b.x) / 2, clientY: (a.y + b.y) / 2 });
          pinch = d;
        }
      }
    });
    const up = (e) => {
      pts.delete(e.pointerId);
      if (pts.size < 2) pinch = 0;
    };
    mc.addEventListener('pointerup', up);
    mc.addEventListener('pointercancel', up);
    mc.addEventListener('pointerleave', up);
    for (const b of document.querySelectorAll('#map-zoom [data-mz]')) {
      b.addEventListener('click', () => (+b.dataset.mz ? this.mapZoom(+b.dataset.mz) : this.mapCenter()));
    }
  }

  // 친구 초대: 휴대폰에서는 공유 창(카카오톡 등), PC 에서는 주소 복사
  async invite() {
    const url = location.origin + '/';
    if (navigator.share) {
      try {
        await navigator.share({ title: '별조각 원정대', text: '같이 모험하자! 링크를 누르면 바로 같은 세계에서 만날 수 있어.', url });
        return;
      } catch (err) {
        if (err && err.name === 'AbortError') return;
      }
    }
    try {
      await navigator.clipboard.writeText(url);
      this.toast('주소를 복사했어요. 친구에게 보내 주세요!', true);
    } catch {
      this.toast(url);
    }
  }

  // 메뉴(지도 · 가방 · 모험가 · 설정 · 조작법)나 채팅을 열어 둔 동안에도 자동 달리기는 이어진다. 대화 · 상점 · 교환 중에는 멈춘다
  keepsRunning() {
    if (this.editing || !$('dialog').classList.contains('hidden')) return false;
    const id = this.openPanel();
    return id ? TABS.includes(id) : !$('chat-row').classList.contains('hidden');
  }

  anyOpen() {
    if (this.editing) return true;
    if (!$('chat-row').classList.contains('hidden') || !$('dialog').classList.contains('hidden')) return true;
    return !!this.openPanel();
  }

  openMenu() {
    this.open(this.lastTab);
  }

  // remember: 다음에 메뉴를 열 때 이 탭부터 보여 줄지 (처음 뜨는 조작법 안내는 기억하지 않는다)
  open(id, remember = true) {
    this.closeAll();
    const g = this.game;
    g.input.unlock();
    // 메뉴(지도 · 가방 · 모험가 · 설정 · 조작법)를 보는 동안에는 자동 달리기를 끄지 않는다. 상점처럼 그 자리에 있어야 하는 화면에서는 멈춘다
    if (!TABS.includes(id)) g.input.autoRun = false;
    $(id).classList.remove('hidden');
    const isTab = TABS.includes(id);
    $('menu-tabs').classList.toggle('hidden', !isTab);
    if (isTab) {
      if (remember) this.lastTab = id;
      for (const b of document.querySelectorAll('#menu-tabs [data-tab]')) b.classList.toggle('on', b.dataset.tab === id);
    }
    const foot = $('menu-foot');
    foot.classList.remove('hidden');
    const k = (keys, label) => `<span>${keys.map((x) => `<kbd>${x}</kbd>`).join('')}${label}</span>`;
    if (id === 'panel-map') foot.innerHTML = k(['↑', '↓', '←', '→'], '귀환석 고르기') + k(['Enter'], '이동') + k(['Z', 'X'], '확대 · 축소') + k(['C'], '내 위치') + k(['T'], '자동 달리기') + k(['Q', 'E'], '탭') + k(['Tab'], '닫기');
    else if (isTab) foot.innerHTML = k(['↑', '↓', '←', '→'], '고르기') + k(['Enter'], '선택') + k(['T'], '자동 달리기') + k(['Q', 'E'], '탭') + k(['Tab'], '닫기');
    else foot.innerHTML = k(['↑', '↓'], '고르기') + k(['Enter'], '사기') + k(['Tab'], '닫기');

    if (id === 'panel-map') {
      this.mapOpen = true;
      this._mapInitSel();
      this.mapCenter(true);
      this.drawMap();
    } else if (id === 'panel-bag') this.refreshBag();
    else if (id === 'panel-inv') {
      foot.innerHTML = k(['↑', '↓', '←', '→'], '고르기') + k(['Enter'], '착용 · 벗기') + k(['X'], '버리기') + k(['T'], '자동 달리기') + k(['Q', 'E'], '탭') + k(['Tab'], '닫기');
      this.bagDirty = false;
      this.refreshInv();
      return;
    } else if (id === 'panel-settings') this.refreshSettings();
    else if (id === 'panel-quest') this.refreshQuest();
    else if (id === 'panel-help') this.refreshHelp();
    if (id !== 'panel-map') {
      const box = $(id).querySelector('.panel-box');
      box.scrollTop = 0;
      this.setFocus(this._focusables(box)[0] || null, false);
    }
  }

  toggle(id) {
    if ($(id).classList.contains('hidden')) this.open(id);
    else this.closeAll();
  }

  closeAll() {
    // 교환 창을 닫으면 교환이 취소된다
    if (this.trade) {
      this.trade = null;
      this.game.net.send({ t: 'tr', a: 'cancel' });
    }
    for (const id of this.panels) $(id).classList.add('hidden');
    $('menu-tabs').classList.add('hidden');
    $('menu-foot').classList.add('hidden');
    $('dialog').classList.add('hidden');
    this.closeChat();
    this.mapOpen = false;
    this.dialogQueue = null;
    this.type = null;
    this.setFocus(null);
  }

  refreshSettings() {
    const g = this.game;
    for (const b of document.querySelectorAll('#set-quality button')) b.classList.toggle('on', b.dataset.q === g.gfx.qualityName);
    const s = g.save.settings;
    $('set-sound').textContent = s.sound ? '켜짐' : '꺼짐';
    $('set-sound').classList.toggle('on', s.sound);
    $('set-music').textContent = s.music ? '켜짐' : '꺼짐';
    $('set-music').classList.toggle('on', s.music);
    $('set-sens').value = s.sens;
    $('set-follow').textContent = s.follow ? '켜짐' : '꺼짐';
    $('set-follow').classList.toggle('on', !!s.follow);
  }

  refreshHelp() {
    const touch = this.game.input.isTouch;
    const K = (...keys) => keys.map((x) => (x === '/' ? '<em>또는</em>' : `<kbd>${esc(x)}</kbd>`)).join('');
    let rows;
    if (touch) {
      rows = [
        ['왼쪽 화면 드래그', '이동'], ['오른쪽 화면 드래그', '시점 돌리기'], ['공격', '검 휘두르기 (연타하면 3연속 공격)'],
        ['점프', '뛰기 · 공중에서 한 번 더 누르면 활공'], ['구르기', '구르는 동안은 공격에 맞지 않음 (기력 소모)'], ['활', '가까운 적에게 화살 쏘기'], ['열매', '회복 열매 먹기 (체력 60)'],
        ['달리기', '켜 두면 빠르게 달림 (기력 소모)'], ['탈것', '말을 타고 내리기 — 말 위에서도 공격과 활을 쓸 수 있어요'], ['솟구침', '바람 정령과 친구가 되면: 바람 기둥을 일으켜 높이 떠오르기'], ['물약', '가진 물약 가운데 골라 마시기'], ['화면 가운데 버튼', '대화 · 상자 열기 · 별조각 얻기'],
        ['오른쪽 위 ≡', '메뉴 (지도 · 가방 · 모험가 · 설정)'],
      ].map(([a, b]) => [esc(a), b]);
    } else {
      rows = [
        [K('W', 'A', 'S', 'D'), '이동'],
        [K('←', '→', '↑', '↓'), '시점 돌리기 (마우스로도 됩니다)'],
        [K('Space'), '점프 · 공중에서 한 번 더 누르면 활공'],
        [K('Shift'), '누르는 동안 달리기 (기력 소모)'],
        [K('T'), '자동 달리기 켜기/끄기 (S 를 누르면 꺼짐) — 지도 · 가방 같은 메뉴나 채팅을 열어도 계속 달립니다'],
        [K('F', '/', 'J'), '무기 휘두르기 (연타하면 연속 공격 · 무기마다 다름)'],
        [K('X', '/', 'I'), '구르기 — 구르는 동안은 공격에 맞지 않음 (기력 소모)'],
        [K('R', '/', 'K'), '활 쏘기'],
        [K('C', '/', 'L'), '주목 — 가까운 몬스터를 계속 바라보기 (다시 누르면 해제)'],
        [K('E'), '대화 · 상자 열기 · 별조각 얻기'],
        [K('Q'), '회복 열매 먹기'],
        [K('1', '2', '3', '4', '5'), '물약 마시기 (체력 · 기력 · 힘 · 수호 · 신속)'],
        [K('G'), '탈것 타고 내리기 — 말 위에서도 공격과 활을 쓸 수 있어요 (기마전)'],
        [K('Z'), '솟구침 — 바람 정령 하늬와 친구가 되면, 바람 기둥을 일으켜 높이 떠오릅니다'],
        [K('Tab'), '메뉴 열기/닫기 (Q · E 로 탭 넘기기, Esc 로도 닫힘)'],
        [K('B'), '가방 — 얻은 장비 보기 · 착용하기'],
        [K('M', 'P', 'U', 'H'), '지도 · 모험가 · 의뢰 · 조작법 바로 열기'],
        [K('Enter'), '채팅'],
        [K('7', '8', '9'), '손 흔들기 · 환호 · 앉기'],
        [K('−', '='), '시점 멀리 · 가까이'],
        [K('V'), '시점을 캐릭터 뒤쪽으로'],
      ];
    }
    $('help-body').innerHTML =
      `<div class="help-grid">${rows.map(([k, v]) => `<div class="keys">${k}</div><span>${esc(v)}</span>`).join('')}</div>` +
      '<div class="sec">장비와 강화</div><div class="help-note">몬스터를 쓰러뜨리거나 보물상자를 열면 장비(무기 · 활 · 갑옷 · 투구 · 부적)와 별가루가 나옵니다. 등급은 일반 → 고급 → 희귀 → 영웅 → 전설 순으로 좋아져요 (전설은 훨씬 강하고 치명타도 잘 터집니다). 가방에서 착용하고, 필요 없는 것은 상인에게 팔고, 대장장이에게 별가루를 주면 강화할 수 있습니다. 강화에 성공하면 무기의 모습도 달라져요.</div>' +
      '<div class="sec">결투 (모험가끼리 겨루기)</div><div class="help-note">메뉴의 「모험가」에서 <b>결투 모드</b>를 켜면, 똑같이 결투 모드를 켠 모험가(이름이 붉고 ⚔ 표시)와 서로 공격할 수 있습니다. 무기 · 활 · 말 위의 돌격 · 히든 무기의 힘이 모두 통하고, 구르기로 피할 수 있어요. 마을 근처와 시련장 · 던전 안은 안전 구역이고, 쓰러져도 잃는 것은 없습니다. 끄면 다시는 공격받지 않습니다.</div>' +
      '<div class="sec">의뢰와 현상금</div><div class="help-note">머리 위에 <b style="color:#ffd84a">!</b> 가 뜬 사람(촌장 · 상인 · 대장장이 · 꼬마, 귀환석 옆 길잡이)에게 말을 걸면 의뢰를 맡을 수 있습니다. 일을 마치면 <b style="color:#8dff9a">?</b> 가 뜨니 돌아가서 보상을 받으세요. 마을 게시판의 현상금은 어디서든 맡고 어디서든 보상을 받을 수 있고, 끝낼 때마다 새 현상금이 붙습니다. 진행 상황은 화면 왼쪽 위와 메뉴의 「의뢰」에서 볼 수 있어요.</div>' +
      '<div class="sec">레벨</div><div class="help-note">몬스터를 쓰러뜨리면 경험치를 얻어 레벨이 오릅니다(최고 Lv.50). 레벨이 오를 때마다 체력과 기력이 모두 차고, 공격력 · 체력 · 기력이 늘어납니다 — 레벨이 높을수록 같은 무기로도 더 큰 피해를 줍니다. 다섯 레벨마다 「레벨 능력」을 하나씩 얻어요(모험가 화면에서 볼 수 있습니다).</div>' +
      '<div class="sec">탈것과 기마전</div><div class="help-note">말을 탄 동안에는 기력이 닳지 않습니다. 말 위에서 무기를 휘두르면 양옆을 넓게 베고, 빨리 달릴수록 「돌격」 피해가 붙어요. 가볍게 맞아서는 떨어지지 않지만 크게 맞으면 떨어집니다. 섬 어딘가에는 절벽을 달려 오르는 붉은 말, 물 위를 달리는 하얀 말, 밤에만 나타나는 검은 전투마가 숨어 있습니다. 이 말들은 겁이 많아 달려가면 달아나므로 걸어서 다가가야 하고, 「황금 사과」를 들고 등에 올라탄 뒤 날뛰는 말 위에서 균형을 잃지 않고 버텨 내는 「길들이기 시험」을 통과해야 내 말이 됩니다. 떨어지면 사과 하나를 잃고 말은 한동안 달아나요. 황금 사과는 의뢰 보상 · 수호자 · 우두머리 · 던전에서만 얻을 수 있습니다.</div>' +
      '<div class="sec">물약과 히든 무기</div><div class="help-note">물약은 상인이 팔고, 강한 몬스터와 보물상자에서도 나옵니다. 전설보다 높은 「신화」 등급의 히든 무기가 종류마다 하나씩 있습니다. 저마다 고유한 힘(흡혈 · 빛의 파동 · 얼림 · 독 · 번개 · 세 갈래 화살)을 지녔고, 정해진 곳에서만 얻을 수 있어요. 실마리는 모험가 화면(P)의 「히든 무기」에 적혀 있습니다.</div>' +
      '<div class="sec">별의 시련장과 숨겨진 던전</div><div class="help-note">별이 떠 있는 돌문은 「별의 시련장」입니다. 힘 · 지혜 · 용기의 시련 가운데 하나를 통과하면 별의 인장을 얻어 체력이나 기력이 늘어나요 (본섬과 바깥 섬에 12곳, 먼바다 너머 여섯 땅에 훨씬 험한 6곳). 곳곳에는 아주 어려운 던전 여섯 곳이 숨겨져 있습니다. 근처의 이끼 낀 돌등에 모두 불을 밝히면 문이 솟아오릅니다. 던전 끝의 주인을 쓰러뜨리면 귀한 장비가 나오니 친구와 함께 도전하세요.</div>' +
      '<div class="sec">레이드 「잠든 별의 심장」</div><div class="help-note">마을 남동쪽의 금빛 문으로 들어가면 거대한 「별 포식자」가 기다립니다. <b>친구들과 함께</b> 싸우는 곳이에요(2~6명 권장). 레벨이 달라도 괜찮습니다 — 받는 피해는 저마다 자기 체력의 비율이고, 주는 피해는 레벨 · 장비와 상관없이 누구의 한 방이든 같은 무게이며(무기 종류와 치명타는 그대로), 보스의 체력은 모인 사람 수에 맞춰집니다. <b>별 삼키기</b>: 보스가 방패를 두르고 주문을 외면, 금빛 사슬이 이어진 기둥을 사람 수만큼 나눠 맡아 거의 동시에 부숴야 합니다(끝까지 외우면 모두 쓰러져요). <b>별똥 나누기</b>: 금빛 원이 한 사람을 따라다니면 그 안에 모여 피해를 나눠 받으세요. <b>고리 충격파</b>는 보스에게 바짝 붙거나 멀리 벗어나서, <b>십자 가르기</b>는 줄 사이로 피합니다. 7분 안에 쓰러뜨리면 보물 방이 열립니다.</div>' +
      '<div class="sec">바람 정령 하늬</div><div class="help-note">마을 북쪽 풀밭에서 맴도는 바람 정령에게 말을 걸면 술래잡기가 시작됩니다(걸어서 다섯 번 잡기). 친구가 되면 곁을 따라다니며, 부르면 발밑에서 <b>바람 기둥</b>이 솟아 하늘 높이 밀어 올려 줍니다. 꼭대기에서는 활공 천이 저절로 펴져요. 공중에서 다시 부르면 더 높이 오릅니다. 바람 구슬은 세 개까지 모이고 9초에 하나씩 다시 찹니다. 기둥은 잠깐 남아 있어서 <b>친구들도 뛰어들어 함께</b> 오를 수 있어요. 실내에서는 바람이 불지 않습니다.</div>' +
      '<div class="sec">알아 두면 좋은 것</div><div class="help-note">가파른 절벽은 기력으로 오를 수 있고, 깊은 물에서는 헤엄칩니다. 기력이 바닥나면 미끄러지거나 물가로 떠밀려 가요. 진행 상황은 이 기기에 자동으로 저장됩니다.</div>' +
      (touch ? '<div class="help-note" style="margin-top:6px">키보드를 연결해 아무 키나 누르면 키보드 조작으로 바뀝니다.</div>' : '');
  }

  refreshBag() {
    const g = this.game;
    const s = g.save;
    const p = g.player;
    const max = s.level >= MAX_LEVEL;
    const need = xpNeed(s.level);
    const zq = g.zones.summary();
    let h = `<div class="hero"><div class="hero-badge"><small>Lv</small><b>${s.level}</b></div><div class="hero-info"><h3>${esc(s.name)}</h3>`;
    h += `<div class="hero-xp"><div style="width:${max ? 100 : Math.round((s.xp / need) * 100)}%"></div></div><small>${max ? '최고 레벨입니다' : `다음 레벨까지 경험치 ${need - s.xp}`}</small></div></div>`;
    h += '<div class="sec">능력치</div><div class="stat-grid">';
    const stat = (label, v) => `<div><span>${label}</span><b>${v}</b></div>`;
    h += stat(`공격력 <em>${WEAPONS[p.wkind].name}</em>`, p.atk) + stat('활 공격력', p.bowAtk || '—') + stat('방어력', p.def) + stat('치명타', Math.round(p.crit * 100) + '%');
    h += stat('체력', p.maxHp * HP_SHOW) + stat('기력', p.maxStamina) + (p.swift ? stat('이동 속도', '+' + Math.round(p.swift * 100) + '%') : '') + (p.luck ? stat('장비 발견', '+' + Math.round(p.luck * 100) + '%') : '');
    h += '</div>';
    // 다섯 레벨마다 얻는 능력: 얻은 것은 밝게, 다음 것은 필요한 레벨과 함께
    const got = PERKS.filter((q) => s.level >= q.lv).length;
    h += `<div class="sec">레벨 능력 ${got}/${PERKS.length} <small style="font-weight:600;opacity:0.8">· 레벨이 오를 때마다 공격력 · 체력 · 기력이 늘고, 다섯 레벨마다 새 능력을 얻습니다</small></div><div class="uq-list perks">`;
    for (const q of PERKS) {
      const on = s.level >= q.lv;
      h += `<div${on ? '' : ' class="off"'}><b${on ? ' style="color:#ffd35a"' : ''}>${on ? '★' : '☆'} ${esc(q.name)} <small>Lv.${q.lv}</small></b><span>${esc(q.desc)}</span></div>`;
    }
    h += '</div><div class="sec">착용 장비</div><div class="gear-grid">';
    for (const slot of SLOTS) {
      const it = s.eq[slot];
      const ic = icon(it ? it.t : slot === 'weapon' ? 'sword' : slot);
      if (it) h += `<div class="gear">${ic}<div><b style="color:${RARITY[it.r].css}">${esc(itemName(it))}</b><small>${esc(itemStatText(it))}</small></div></div>`;
      else h += `<div class="gear none">${ic}<div><b>${SLOT_NAME[slot]} 없음</b><small>사냥이나 상자에서 얻을 수 있어요</small></div></div>`;
    }
    h += `<div class="gear${s.glider ? '' : ' none'}">${icon('glider')}<div><b>활공 천</b><small>${s.glider ? '공중에서 점프를 한 번 더' : '아직 없음 — 촌장에게'}</small></div></div>`;
    const mk = p.mountKind();
    h += `<div class="gear${p.hasMount() ? '' : ' none'}">${icon('horse')}<div><b>${p.hasMount() ? MOUNTS[mk].name : '탈것'}</b><small>${p.hasMount() ? (g.input.isTouch ? '탈것 버튼으로 타고 내리기' : 'G 키로 타고 내리기') : '아직 없음 — 상인의 말 피리'}</small></div></div>`;
    h += '</div><div class="row-btns" style="margin-top:10px"><button data-open="panel-inv" class="primary">가방 열기 · 장비 바꾸기</button></div>';
    // 탈것 고르기와 히든 탈것의 소문
    h += `<div class="sec">탈것 <small style="font-weight:600;opacity:0.8">· 황금 사과 ${s.apples}개</small></div><div class="row-btns">`;
    if (s.mount) h += `<button data-mount="horse"${mk === 'horse' ? ' class="primary"' : ''}>말</button>`;
    for (const k of s.mounts) h += `<button data-mount="${k}"${mk === k ? ' class="primary"' : ''}>${MOUNTS[k].name}</button>`;
    h += '</div>';
    if (p.hasMount()) h += `<p class="it-desc" style="margin:6px 2px 0">${esc(MOUNTS[mk].desc)}</p>`;
    h += '<div class="uq-list">';
    for (const k of MOUNT_KEYS) {
      if (k === 'horse' || s.mounts.includes(k)) continue;
      h += `<div><b>??? <small>황금 사과 ${MOUNTS[k].need}개 + 길들이기 시험</small></b><span>${esc(MOUNTS[k].hint)}</span></div>`;
    }
    h += '</div>';
    if (MOUNT_KEYS.some((k) => k !== 'horse' && !s.mounts.includes(k))) h += '<p class="it-desc" style="margin:6px 2px 0">걸어서 다가가 등에 올라탄 뒤, 날뛰는 말 위에서 끝까지 버텨야 길듭니다. 떨어지면 사과 하나를 잃어요. 황금 사과는 의뢰 · 수호자 · 던전에서 얻습니다.</p>';
    h += `<div class="sec">히든 무기 ${s.uqGot.length}/${UNIQUE_KEYS.length}</div><div class="uq-list">`;
    for (const k of UNIQUE_KEYS) {
      const u = UNIQUES[k];
      const got = s.uqGot.includes(k);
      h += `<div><b${got ? ' style="color:#ff5470"' : ''}>${got ? esc(u.name) : '???'} <small>${TYPE_NAME[u.t]}</small></b><span>${esc(got ? u.desc : u.hint)}</span></div>`;
    }
    h += '</div>';
    h += `<div class="sec">결투 <small style="font-weight:600;opacity:0.8">· 이긴 횟수 ${s.pvpWins}</small></div><p class="it-desc" style="margin:0 2px 8px">결투 모드를 켠 모험가끼리만 서로 공격할 수 있습니다. 마을과 시련장 · 던전 안은 안전하고, 쓰러져도 잃는 것은 없어요.</p><div class="row-btns"><button data-duel class="${s.settings.pvp ? 'primary' : ''}">⚔ 결투 모드: ${s.settings.pvp ? '켜짐 (누르면 끄기)' : '꺼짐 (누르면 켜기)'}</button></div>`;
    h += '<div class="sec">감정 표현</div><div class="row-btns"><button data-em="emote1">손 흔들기</button><button data-em="emote2">환호</button><button data-em="emote3">앉기</button></div>';
    h += `<div class="sec">함께하는 모험가 ${g.ents.players.size + 1}명</div><div class="plist"><div><span>${esc(s.name)} (나)</span><b>Lv.${s.level}</b></div>`;
    for (const e of g.ents.players.values()) h += `<div><span>${e.prof.pv ? '<em style="color:#ff9a8a;font-style:normal">⚔</em> ' : ''}${esc(e.prof.name)}</span><b>Lv.${e.prof.lvl}</b><button data-trade="${e.id}">교환 신청</button></div>`;
    if (!g.ents.players.size) h += '<p class="it-desc" style="margin:4px 2px 0">친구가 들어오면 여기서 장비와 골드를 교환할 수 있어요.</p>';
    h += `</div><div class="sec">기록</div><div class="plist"><div><span>처치한 몬스터</span><b>${s.kills}</b></div><div><span>결투 승리</span><b>${s.pvpWins}</b></div><div><span>별조각</span><b>${g.shards.size}/${SHARD_COUNT}</b></div><div><span>별의 인장 (시련장)</span><b>${zq.seals}/${zq.trials}</b></div><div><span>찾아낸 던전</span><b>${zq.found}/${zq.dungeons}</b></div><div><span>정복한 던전</span><b>${zq.cleared}/${zq.dungeons}</b></div><div><span>레이드 승리</span><b>${zq.raidWins}</b></div><div><span>세계 순환</span><b>${g.cycle + 1}회차</b></div></div>`;
    $('bag-body').innerHTML = h;
    for (const b of document.querySelectorAll('#bag-body [data-em]')) {
      b.addEventListener('click', () => {
        this.closeAll();
        g.input.pressed.add(b.dataset.em);
      });
    }
    for (const b of document.querySelectorAll('#bag-body [data-open]')) b.addEventListener('click', () => this.open(b.dataset.open));
    for (const b of document.querySelectorAll('#bag-body [data-duel]')) {
      b.addEventListener('click', () => {
        g.setDuel(!s.settings.pvp);
        this.refreshBag();
        this.setFocus(document.querySelector('#bag-body [data-duel]'), false);
      });
    }
    for (const b of document.querySelectorAll('#bag-body [data-mount]')) {
      b.addEventListener('click', () => {
        p.setMountKind(b.dataset.mount);
        g.audio.equip();
        this.toast(`탈것: ${MOUNTS[b.dataset.mount].name}`, true);
        this.refreshBag();
      });
    }
    for (const b of document.querySelectorAll('#bag-body [data-trade]')) b.addEventListener('click', () => this.requestTrade(+b.dataset.trade));
  }

  // ================= 대화 / 상점 =================
  // lines: 문자열 배열, 마지막 줄에서 buttons [{text, primary, fn}] 표시
  dialog(name, lines, buttons, onDone) {
    this.closeAll();
    const g = this.game;
    g.input.unlock();
    g.input.autoRun = false;
    this.dialogQueue = { name, lines: lines.slice(), buttons, onDone };
    $('dialog').classList.remove('hidden');
    $('dialog-hint').innerHTML = '<kbd>Enter</kbd>계속';
    this._dialogNext();
  }

  _dialogNext() {
    const q = this.dialogQueue;
    if (!q) return;
    const line = q.lines.shift();
    $('dialog-name').textContent = q.name;
    $('dialog-text').textContent = '';
    this.type = { full: line, n: 0 };
    const wrap = $('dialog-btns');
    wrap.innerHTML = '';
    const add = (text, primary, fn, cls = '') => {
      const b = document.createElement('button');
      b.textContent = text;
      b.className = (primary ? 'primary ' : '') + cls;
      b.addEventListener('click', () => {
        this.game.audio.click();
        // 글자가 아직 나오는 중이면 먼저 끝까지 보여 준다
        if (this.type) this._typeDone();
        else fn();
      });
      wrap.appendChild(b);
      return b;
    };
    let first;
    if (q.lines.length) first = add('다음', true, () => this._dialogNext(), 'next');
    else {
      for (const bt of q.buttons || []) {
        const b = add(bt.text, bt.primary, bt.fn);
        if (!first && bt.primary) first = b;
      }
      const close = add(q.buttons && q.buttons.length ? '닫기' : '확인', !(q.buttons && q.buttons.length), () => {
        const done = q.onDone;
        this.closeAll();
        if (done) done();
      });
      if (!first) first = close;
    }
    this.setFocus(first);
  }

  _typeDone() {
    if (!this.type) return;
    $('dialog-text').textContent = this.type.full;
    this.type = null;
  }

  // Enter/E/Space 로 대화 넘기기
  dialogKey() {
    if ($('dialog').classList.contains('hidden')) return false;
    const wrap = $('dialog-btns');
    const b = (this.focusEl && wrap.contains(this.focusEl) && this.focusEl) || wrap.querySelector('button.primary') || wrap.querySelector('button');
    if (b) b.click();
    return true;
  }

  // 의뢰와 얽힌 대화. 보고할 것이 있으면 보상을, 맡길 일이 있으면 그 일을 꺼낸다. 꺼낸 것이 있으면 true
  questTalk(npc) {
    const g = this.game;
    const Q = g.quests;
    const n = npc.def;
    const f = Q.forGiver(npc.key);
    const shop = n.kind === 'merchant' || n.kind === 'smith';
    if (f.ready.length) {
      const q = f.ready[0];
      this.dialog(n.name, [...(q.done || ['수고했어요!']), `「${q.name}」 완료! 보상: ${rewardText(q.reward)}`], [
        {
          text: '보상 받기', primary: true,
          fn: () => {
            this.closeAll();
            if (!Q.claim(q)) return;
            g.audio.seal();
            this.banner('의뢰 완료!', `${q.name} — ${rewardText(q.reward)}`);
            const p = g.player.pos;
            g.fx.burst(p.x, p.y + 1.2, p.z, 0xffd35a, 26, 4, { size: 0.34, life: 0.9, grav: -1.5, glow: 2 });
            // 이어지는 일이 있으면 바로 꺼낸다
            const nx = Q.forGiver(npc.key);
            if (nx.ready.length || nx.offer.length) setTimeout(() => !this.anyOpen() && this.questTalk(npc), 900);
          },
        },
      ]);
      return true;
    }
    if (f.offer.length) {
      const q = f.offer[0];
      this.dialog(n.name, [...q.intro, `의뢰 「${q.name}」 — ${q.short}. 보상: ${rewardText(q.reward)}`], [
        {
          text: '맡을게요', primary: true,
          fn: () => {
            this.closeAll();
            if (!Q.accept(q)) return;
            g.audio.stone();
            this.toast(`의뢰를 맡았습니다: 「${q.name}」 — ${q.short}`, true);
            Q.announce(); // 이미 조건을 채운 일이라면 바로 알려 준다
          },
        },
        { text: shop ? '가게 보기' : '다른 이야기', fn: () => this.talk(npc, true) },
      ]);
      return true;
    }
    return false;
  }

  // plain: 의뢰 이야기는 건너뛰고 평소 대화만
  talk(npc, plain = false) {
    const g = this.game;
    const s = g.save;
    const n = npc.def;
    npc.talkT = 1.6;
    if (!plain && (n.kind !== 'elder' || s.talkedElder) && this.questTalk(npc)) return;
    // 맡은 일이 아직 진행 중이면 한마디 덧붙인다
    const act = g.quests.forGiver(npc.key).active[0];
    const remind = act ? [`(맡은 의뢰 「${act.name}」 — ${act.short}: ${g.quests.progress(act)}/${act.goal.n})`] : [];
    if (n.kind === 'elder') {
      if (!s.talkedElder) {
        this.dialog(n.name, [
          '어서 오게, 젊은 모험가여. 나는 이 새벽 마을의 촌장 한울이라네.',
          '오래전 하늘의 별이 부서져 열두 개의 별조각이 섬 곳곳에 흩어졌지. 그 뒤로 화산 깊은 곳의 「그림자 군주」가 섬을 어둠으로 물들이고 있다네.',
          '별조각 열두 개를 모두 모아 이 제단을 밝히면 군주에게 맞설 길이 열릴 걸세. 별조각이 있을 만한 곳을 자네 지도에 표시해 두었네.',
          '이 활공 천을 가져가게. 높은 곳에서 뛰어내린 뒤 점프를 한 번 더 누르면 하늘을 날 수 있지. 친구들과 힘을 모으게나!',
        ], null, () => g.onElderIntro());
      } else {
        const left = SHARD_COUNT - g.shards.size;
        let lines;
        if (g.bossState === 'dead') lines = ['자네들 덕분에 섬에 빛이 돌아왔네! 하지만 어둠은 언젠가 더 강해져서 돌아오는 법… 그때도 부탁하네.'];
        else if (g.bossState === 'awake') lines = ['별조각이 모두 모였네! 제단이 이렇게 밝게 빛나다니…', '북동쪽 잿불 화산의 협곡을 지나 분화구로 가게. 그림자 군주가 깨어났다네. 혼자는 벅찰 테니 친구들과 함께 가게나.'];
        else lines = [`지금까지 별조각 ${g.shards.size}개를 밝혔군. 아직 ${left}개가 남았네.`, '초원부터 차근차근 돌아보게. 먼 곳일수록 몬스터가 강하니 대장간에서 장비를 갖추는 것도 잊지 말게.', '그리고 별이 떠 있는 돌문을 보거든 들어가 보게. 「별의 시련장」을 통과할 때마다 몸과 마음이 한층 단단해질 걸세.'];
        this.dialog(n.name, [...remind, ...lines]);
      }
    } else if (n.kind === 'merchant') {
      this.dialog(n.name, [...remind, '어서 오세요! 모험에 필요한 건 다 있답니다. 사냥해서 얻은 장비도 좋은 값에 사 드려요.'], [
        { text: '물건 사기', primary: true, fn: () => this.openShop('merchant', 'buy') },
        { text: '장비 팔기', fn: () => this.openShop('merchant', 'sell') },
      ]);
    } else if (n.kind === 'smith') {
      this.dialog(n.name, [...remind, '쓸 만한 무기가 필요한가? 검, 대검, 창, 쌍단검, 망치… 손에 맞는 걸 골라 보게. 별가루를 가져오면 강화도 해 주지.'], [
        { text: '장비 사기', primary: true, fn: () => this.openShop('smith', 'buy') },
        { text: '강화하기', fn: () => this.openShop('smith', 'enh') },
      ]);
    } else if (n.kind === 'kid') {
      this._kidTip = ((this._kidTip ?? -1) + 1) % KID_TIPS.length;
      this.dialog(n.name, [...remind, KID_TIPS[this._kidTip]]);
    } else {
      const tips = GUIDE_TIPS[n.stone];
      this.dialog(n.name, [...remind, ...(tips && tips.length ? tips : ['조심해서 다니세요!'])]);
    }
  }

  // ================= 의뢰 화면 =================
  refreshQuest() {
    const g = this.game;
    const Q = g.quests;
    const where = (q) => (q.giver.startsWith('guide') ? `${g.pois.stones[+q.giver.slice(5)].name} 귀환석 옆` : '새벽 마을');
    const bar = (n, need) => `<div class="q-bar"><div style="width:${Math.round((n / need) * 100)}%"></div></div>`;
    let h = '';
    if (!g.save.talkedElder) h += '<p class="it-desc">먼저 마을 한가운데의 촌장 한울과 이야기해 보세요.</p>';
    const act = Q.activeList();
    h += `<div class="sec">맡은 의뢰 ${act.length}</div><div class="q-list">`;
    for (const q of act) {
      const n = Q.progress(q);
      const rdy = Q.ready(q);
      h += `<div class="q-item${rdy ? ' rdy' : ''}"><span class="n">${n}/${q.goal.n}</span><b>${esc(q.name)}<small>${esc(Q.giverName(q))}</small></b><p>${esc(q.short)}</p>${bar(n, q.goal.n)}<span class="q-rew">보상: ${esc(rewardText(q.reward))}</span>`;
      if (rdy) h += `<span class="q-go">✔ ${esc(where(q))}의 ${esc(Q.giverName(q))}에게 돌아가 보고하세요</span>`;
      h += '</div>';
    }
    if (!act.length) h += '<p class="it-desc" style="margin:2px">맡은 의뢰가 없습니다. 머리 위에 <b style="color:#ffd84a">!</b> 가 뜬 사람에게 말을 걸어 보세요.</p>';
    h += '</div>';
    // 현상금: 어디서든 받고 어디서든 보상을 받는다. 끝내면 새 현상금이 붙는다
    h += '<div class="sec">현상금 <small style="font-weight:600;opacity:0.8">· 마을 게시판에 붙은 일. 끝내면 새 현상금이 붙습니다</small></div><div class="q-list">';
    for (const b of Q.state.b) {
      const rdy = b.acc && b.n >= b.need;
      h += `<div class="q-item${rdy ? ' rdy' : ''}">${b.acc ? `<span class="n">${b.n}/${b.need}</span>` : ''}<b>${esc(Q.bountyText(b))}</b>${b.acc ? bar(b.n, b.need) : ''}<span class="q-rew">보상: ${esc(rewardText(b.r))}</span>`;
      h += `<div class="row-btns">${rdy ? `<button class="primary" data-bclaim="${b.id}">보상 받기</button>` : b.acc ? '<button disabled>진행 중</button>' : `<button data-bacc="${b.id}">맡기</button>`}</div></div>`;
    }
    h += '</div>';
    const offer = Q.offerList();
    h += `<div class="sec">받을 수 있는 의뢰 ${offer.length}</div><div class="q-list">`;
    for (const q of offer.slice(0, 12)) h += `<div class="q-item"><b>${esc(q.name)}<small>${esc(Q.giverName(q))} · ${esc(where(q))}</small></b><p>${esc(q.short)}</p><span class="q-rew">보상: ${esc(rewardText(q.reward))}</span></div>`;
    if (offer.length > 12) h += `<p class="it-desc" style="margin:2px">… 그리고 ${offer.length - 12}가지 더</p>`;
    if (!offer.length) h += '<p class="it-desc" style="margin:2px">지금은 새로 받을 수 있는 의뢰가 없습니다.</p>';
    h += `</div><div class="sec">끝낸 의뢰 ${Q.state.done.length}/${QUESTS.length}</div>`;
    const body = $('quest-body');
    const keep = this.focusEl && body.contains(this.focusEl) ? this.focusEl.dataset.bacc || this.focusEl.dataset.bclaim : null;
    body.innerHTML = h;
    for (const el of body.querySelectorAll('[data-bacc]')) {
      el.addEventListener('click', () => {
        const b = Q.state.b.find((x) => x.id === +el.dataset.bacc);
        if (!b) return;
        Q.acceptBounty(b);
        g.audio.stone();
        this.toast(`현상금을 맡았습니다: ${Q.bountyText(b)}`, true);
        this.refreshQuest();
      });
    }
    for (const el of body.querySelectorAll('[data-bclaim]')) {
      el.addEventListener('click', () => {
        const b = Q.state.b.find((x) => x.id === +el.dataset.bclaim);
        if (!b) return;
        const text = rewardText(b.r);
        if (!Q.claimBounty(b)) return;
        g.audio.seal();
        this.toast(`현상금 보상: ${text}`, true);
        this.refreshQuest();
      });
    }
    // 키보드로 고르던 자리를 되찾는다
    if (document.body.classList.contains('kb')) {
      const again = keep && (body.querySelector(`[data-bacc="${keep}"]`) || body.querySelector(`[data-bclaim="${keep}"]`));
      this.setFocus(again || this._focusables(body)[0] || null, false);
    }
  }

  // ================= 지도 =================
  buildMapCanvas(pixels) {
    const c = document.createElement('canvas');
    c.width = W.VERTS;
    c.height = W.VERTS;
    c.getContext('2d').putImageData(new ImageData(pixels, W.VERTS, W.VERTS), 0, 0);
    this.mapCanvas = c;
  }

  drawMinimap() {
    const g = this.game;
    const ctx = this.mmCtx;
    const S = 280;
    const p = g.player;
    const zs = g.zone;
    const RANGE = zs ? 44 : 120; // 지도에 보이는 반경 (월드 단위). 실내에서는 더 크게 보여 준다
    const scale = S / (RANGE * 2);
    ctx.fillStyle = zs ? '#0a0d15' : '#123154';
    ctx.fillRect(0, 0, S, S);
    if (zs) {
      // 실내 평면도
      const d = zs.def;
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(g.zones.mapCanvas(zs), (d.ox - p.pos.x) * scale + S / 2, (d.oz - p.pos.z) * scale + S / 2, d.tileW * TILE * scale, d.tileH * TILE * scale);
    } else if (this.mapCanvas) {
      const src = (RANGE * 2) / W.CELL;
      const sx = (p.pos.x + W.HALF) / W.CELL - src / 2;
      const sy = (p.pos.z + W.HALF) / W.CELL - src / 2;
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(this.mapCanvas, sx, sy, src, src, 0, 0, S, S);
    }
    const toX = (x) => (x - p.pos.x) * scale + S / 2;
    const toY = (z) => (z - p.pos.z) * scale + S / 2;
    const inside = (x, z) => Math.hypot(x - p.pos.x, z - p.pos.z) < RANGE - 6;

    // 목표 방향 화살표
    const goal = g.questGoal();
    if (goal && !inside(goal.x, goal.z)) {
      const a = Math.atan2(goal.z - p.pos.z, goal.x - p.pos.x);
      ctx.save();
      ctx.translate(S / 2 + Math.cos(a) * (S / 2 - 16), S / 2 + Math.sin(a) * (S / 2 - 16));
      ctx.rotate(a);
      ctx.fillStyle = '#ffd35a';
      ctx.strokeStyle = '#3a2a08';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(12, 0);
      ctx.lineTo(-8, -9);
      ctx.lineTo(-8, 9);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
    for (const st of g.objects.stones) {
      if (!inside(st.x, st.z)) continue;
      this._diamond(ctx, toX(st.x), toY(st.z), 8, st.active ? '#5fe0ff' : '#8a94a8');
    }
    // 찾아낸 시련장·던전의 입구와 밝힌 돌등
    if (!zs) {
      for (const q of g.zones.list) {
        for (const l of q.lamps) {
          if (!l.lit || !inside(l.x, l.z)) continue;
          ctx.fillStyle = '#ffe9a0';
          ctx.beginPath();
          ctx.arc(toX(l.x), toY(l.z), 3.5, 0, 6.3);
          ctx.fill();
        }
        if (q.found && inside(q.x, q.z)) this._gate(ctx, toX(q.x), toY(q.z), q.raid ? 11 : 9, q.raid ? '#ffd35a' : q.trial ? (q.cleared ? '#7dffd0' : '#c98aff') : '#ff4a5a');
      }
    }
    if (g.save.talkedElder) {
      for (const sh of g.objects.shards) {
        if (sh.collected || !inside(sh.x, sh.z)) continue;
        this._star(ctx, toX(sh.x), toY(sh.z), 11, sh.sealed ? '#d08aff' : '#ffd35a');
      }
    }
    for (const n of g.objects.npcs) {
      if (!inside(n.x, n.z)) continue;
      ctx.fillStyle = '#ffe9a8';
      ctx.beginPath();
      ctx.arc(toX(n.x), toY(n.z), 4, 0, 6.3);
      ctx.fill();
    }
    const lock = p.lock;
    for (const e of g.ents.monsters.values()) {
      if (e.dying || !e.shown || !inside(e.x, e.z)) continue;
      ctx.fillStyle = e === lock ? '#ffd35a' : '#ff5a5f';
      ctx.beginPath();
      ctx.arc(toX(e.x), toY(e.z), e === lock ? 6 : e.info.elite || e.info.type === 'golem' || e.info.boss ? 6 : 3.5, 0, 6.3);
      ctx.fill();
    }
    const myZone = zs ? zs.id : 0;
    for (const e of g.ents.players.values()) {
      if (!e.seen) continue;
      // 시련장·던전 안팎이 다른 친구는 그 입구 자리에 표시한다
      const ez = e.zone || 0;
      if (zs && ez !== myZone) continue;
      const eq = ez && ez !== myZone ? g.zones.list[ez - 1] : e;
      let x = toX(eq.x);
      let y = toY(eq.z);
      const d = Math.hypot(x - S / 2, y - S / 2);
      const lim = S / 2 - 10;
      if (d > lim) {
        x = S / 2 + ((x - S / 2) / d) * lim;
        y = S / 2 + ((y - S / 2) / d) * lim;
      }
      ctx.fillStyle = '#7fe08a';
      ctx.strokeStyle = '#0c2a12';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, y, 6, 0, 6.3);
      ctx.fill();
      ctx.stroke();
    }
    // 시야 방향 (부채꼴)
    ctx.save();
    ctx.translate(S / 2, S / 2);
    ctx.rotate(-p.camYaw);
    const fan = ctx.createRadialGradient(0, 0, 4, 0, 0, 62);
    fan.addColorStop(0, 'rgba(255,255,255,0.34)');
    fan.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = fan;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, 62, Math.PI / 2 - 0.5, Math.PI / 2 + 0.5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    // 나
    ctx.save();
    ctx.translate(S / 2, S / 2);
    ctx.rotate(-p.yaw);
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#1f5fd0';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, 13);
    ctx.lineTo(-9, -9);
    ctx.lineTo(0, -4);
    ctx.lineTo(9, -9);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
    ctx.restore();
  }

  _diamond(ctx, x, y, r, color) {
    ctx.fillStyle = color;
    ctx.strokeStyle = '#0b1222';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, y - r);
    ctx.lineTo(x + r, y);
    ctx.lineTo(x, y + r);
    ctx.lineTo(x - r, y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  // 시련장·던전 입구 표시: 아치 모양의 문
  _gate(ctx, x, y, r, color) {
    ctx.fillStyle = color;
    ctx.strokeStyle = '#0b1222';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x - r * 0.8, y + r);
    ctx.lineTo(x - r * 0.8, y - r * 0.2);
    ctx.arc(x, y - r * 0.2, r * 0.8, Math.PI, 0);
    ctx.lineTo(x + r * 0.8, y + r);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#0b1222';
    ctx.fillRect(x - r * 0.28, y + r * 0.1, r * 0.56, r * 0.9);
  }

  _star(ctx, x, y, r, color) {
    ctx.fillStyle = color;
    ctx.strokeStyle = '#3a2a08';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + (i * Math.PI) / 5;
      const rr = i % 2 ? r * 0.45 : r;
      ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  drawMap() {
    const g = this.game;
    const cv = $('map');
    const ctx = cv.getContext('2d');
    const S = cv.width;
    // 보이는 범위: 가운데 (v.x, v.y), 한 변 span
    const v = this.mapView;
    const span = W.SIZE / v.z;
    const x0 = v.x - span / 2;
    const z0 = v.y - span / 2;
    const k = S / span;
    const X = (x) => (x - x0) * k;
    const Y = (z) => (z - z0) * k;
    const wide = v.z < 2; // 세계 전체를 볼 때는 글자를 줄이고 표시를 작게 그린다
    // 작은 화면에서도 글자와 표시가 읽히도록 크기를 키운다
    const disp = cv.getBoundingClientRect().width || 640;
    const f0 = Math.max(1, Math.min(2.4, 640 / disp));
    const f = f0 * (wide ? 0.72 : 1);
    const small = disp < 430 || wide;
    ctx.imageSmoothingEnabled = true;
    if (this.mapCanvas) ctx.drawImage(this.mapCanvas, (x0 + W.HALF) / W.CELL, (z0 + W.HALF) / W.CELL, span / W.CELL, span / W.CELL, 0, 0, S, S);
    ctx.textAlign = 'center';
    ctx.lineJoin = 'round';
    const text = (str, x, y, size, color) => {
      ctx.font = `800 ${Math.round(size * f)}px "Pretendard", "Apple SD Gothic Neo", "Noto Sans KR", "Malgun Gothic", sans-serif`;
      ctx.lineWidth = 5 * f;
      ctx.strokeStyle = 'rgba(10,16,30,0.85)';
      ctx.strokeText(str, x, y);
      ctx.fillStyle = color;
      ctx.fillText(str, x, y);
    };
    // 지역 이름과 권장 레벨 (내 레벨로 충분하면 초록, 조금 벅차면 노랑, 위험하면 빨강)
    const myLv = g.save.level;
    BIOME_CENTERS.forEach(([x, z], i) => {
      // 작은 화면에서 세계 전체를 볼 때는 본섬 안의 지역 이름을 적지 않는다 (글자가 겹쳐서 읽을 수 없다)
      if (wide && disp < 430 && i < 7) return;
      const lv = BIOME_INFO[i].level;
      const col = myLv >= lv ? '#a8ffb8' : myLv >= lv - 3 ? '#ffe27a' : '#ff9d9d';
      if (i === 0) {
        // 마을이 있는 초원은 마을 아래쪽에 작게 적는다
        ctx.globalAlpha = 0.9;
        text(wide ? `${BIOME_INFO[0].name} Lv.${lv}` : `${BIOME_INFO[0].name} · 권장 Lv.${lv}`, X(x), Y(z) + (wide ? 34 : 58) * f, wide ? 15 : 14, col);
        ctx.globalAlpha = 1;
        return;
      }
      const kk = i >= 7 ? 1 : 0.9; // 바깥 섬은 섬 한가운데 조금 위에 이름을 적는다 (가운데에는 귀환석이 있다)
      if (wide) {
        // 세계 전체: 이름과 권장 레벨을 한 줄씩 작게
        const up = (i >= 7 ? 30 : 12) * f;
        ctx.globalAlpha = 0.8;
        text(BIOME_INFO[i].name, X(x * kk), Y(z * kk) - up, i >= 7 ? 21 : 17, '#fff6df');
        ctx.globalAlpha = 0.95;
        text(`Lv.${lv}`, X(x * kk), Y(z * kk) - up + 20 * f, 16, col);
        ctx.globalAlpha = 1;
        return;
      }
      const up = (i >= 7 ? 56 : 30) * f;
      ctx.globalAlpha = 0.62;
      text(BIOME_INFO[i].name, X(x * kk), Y(z * kk) - up, 22, '#fff6df');
      ctx.globalAlpha = 0.95;
      text(`권장 Lv.${lv}`, X(x * kk), Y(z * kk) - up + 21 * f, 15.5, col);
      ctx.globalAlpha = 1;
    });
    // 찾아낸 시련장과 던전
    for (const q of g.zones.list) {
      if (!q.found) continue;
      this._gate(ctx, X(q.x), Y(q.z), (q.raid ? 13 : 10) * f, q.raid ? '#ffd35a' : q.trial ? (q.cleared ? '#7dffd0' : '#c98aff') : '#ff4a5a');
      if (q.raid) {
        if (!small || this.mapView.z > 1) text('레이드', X(q.x), Y(q.z) + 30 * f, 13, '#ffe9a0');
      } else if (!q.trial && !small) text(`${q.def.name} Lv.${q.def.level}`, X(q.x), Y(q.z) + 28 * f, 13, '#ffc0c8');
    }
    // 아직 친구가 되지 않은 바람 정령이 노니는 풀밭 (촌장에게서 이야기를 들은 뒤에 보인다)
    const spr = g.pois.sprite;
    if (spr && !g.save.sprite && g.save.talkedElder) {
      ctx.fillStyle = '#bff8ff';
      ctx.strokeStyle = '#0b1222';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(X(spr.x), Y(spr.z), (6 + Math.sin(g.time * 4) * 1.5) * f, 0, 6.3);
      ctx.fill();
      ctx.stroke();
      if (!small || this.mapView.z > 1) text('바람 정령', X(spr.x) + 34 * f, Y(spr.z) + 1 * f, 12.5, '#d8fbff');
    }
    if (g.bossState === 'awake') {
      ctx.fillStyle = 'rgba(255,90,208,0.9)';
      ctx.beginPath();
      ctx.arc(X(VOLCANO.x), Y(VOLCANO.z), (13 + Math.sin(g.time * 5) * 3) * f, 0, 6.3);
      ctx.fill();
      text('그림자 군주', X(VOLCANO.x), Y(VOLCANO.z) - 20 * f, 17, '#ffb8f0');
    }
    const sel = this.mapSel;
    for (const st of g.objects.stones) {
      this._diamond(ctx, X(st.x), Y(st.z), 11 * f, st.active ? '#5fe0ff' : '#7a8498');
      if (st.active && !small && st !== sel) text(st.def.name, X(st.x), Y(st.z) - 16 * f, 12.5, '#c8f6ff');
    }
    if (g.save.talkedElder) {
      for (const sh of g.objects.shards) {
        if (sh.collected) {
          ctx.globalAlpha = 0.5;
          this._star(ctx, X(sh.x), Y(sh.z), 9 * f, '#b8b8b8');
          ctx.globalAlpha = 1;
        } else {
          this._star(ctx, X(sh.x), Y(sh.z), 14 * f, sh.sealed ? '#d08aff' : '#ffd35a');
          if (!small) text(sh.def.name, X(sh.x), Y(sh.z) + 27 * f, 11.5, '#fff3c0');
        }
      }
    }
    // 의뢰: 맡길 일(!)이나 보고받을 일(?)이 있는 사람
    if (g.save.talkedElder) {
      let vm = '';
      for (const n of g.objects.npcs) {
        if (!n.qm) continue;
        if (n.def.kind !== 'guide') {
          if (n.qm === '?' || !vm) vm = n.qm; // 마을 사람들은 한데 모아 마을에 하나만 표시한다
          continue;
        }
        text(n.qm, X(n.x) + 13 * f, Y(n.z) + 6 * f, 19, n.qm === '?' ? '#8dff9a' : '#ffd84a');
      }
      if (vm) text(vm, X(0) - 15 * f, Y(0) + 7 * f, 21, vm === '?' ? '#8dff9a' : '#ffd84a');
    }
    for (const e of g.ents.players.values()) {
      if (!e.seen) continue;
      // 시련장·던전 안에 있는 친구는 그 입구 자리에 표시한다
      const eq = e.zone ? g.zones.list[e.zone - 1] : e;
      ctx.fillStyle = '#7fe08a';
      ctx.strokeStyle = '#0c2a12';
      ctx.lineWidth = 3 * f;
      ctx.beginPath();
      ctx.arc(X(eq.x), Y(eq.z), 8 * f, 0, 6.3);
      ctx.fill();
      ctx.stroke();
      text(e.prof.name, X(eq.x), Y(eq.z) - 14 * f, 14, '#c8ffd0');
    }
    // 고른 귀환석
    if (sel) {
      const pulse = 1 + Math.sin(g.time * 5) * 0.12;
      ctx.strokeStyle = sel.active ? '#ffd35a' : '#c8d0e0';
      ctx.lineWidth = 4 * f;
      ctx.beginPath();
      ctx.arc(X(sel.x), Y(sel.z), 21 * f * pulse, 0, 6.3);
      ctx.stroke();
      text(sel.def.name, X(sel.x), Y(sel.z) - 30 * f, wide ? 20 : 16, sel.active ? '#ffe9a8' : '#dfe4ee');
    }
    const p = g.player;
    // 실내에 있을 때는 그 입구 자리에 나를 표시한다
    const me = g.zone || p.pos;
    ctx.save();
    ctx.translate(X(me.x), Y(me.z));
    ctx.rotate(g.zone ? 0 : -p.yaw);
    ctx.scale(f0 * (wide ? 0.85 : 1), f0 * (wide ? 0.85 : 1));
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#1f5fd0';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(0, 16);
    ctx.lineTo(-11, -11);
    ctx.lineTo(0, -5);
    ctx.lineTo(11, -11);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
    ctx.restore();
  }

  _mapClamp() {
    const v = this.mapView;
    const h = W.SIZE / v.z / 2;
    v.x = Math.max(-W.HALF + h, Math.min(W.HALF - h, v.x));
    v.y = Math.max(-W.HALF + h, Math.min(W.HALF - h, v.y));
    for (const b of document.querySelectorAll('#map-zoom [data-mz]')) {
      const d = +b.dataset.mz;
      if (d) b.classList.toggle('off', d > 0 ? v.z >= 4 : v.z <= 1);
    }
  }

  // 지도 확대(+1)·축소(-1). e 가 있으면 그 자리를 붙잡고 확대한다
  mapZoom(dir, e) {
    const v = this.mapView;
    const LV = [1, 2, 4];
    const i = Math.max(0, Math.min(LV.length - 1, LV.indexOf(v.z) + dir));
    if (LV[i] === v.z) return;
    let fx = 0.5;
    let fy = 0.5;
    if (e) {
      const r = $('map').getBoundingClientRect();
      fx = (e.clientX - r.left) / r.width;
      fy = (e.clientY - r.top) / r.height;
    }
    const s0 = W.SIZE / v.z;
    const ax = v.x + (fx - 0.5) * s0;
    const ay = v.y + (fy - 0.5) * s0;
    v.z = LV[i];
    const s1 = W.SIZE / v.z;
    v.x = ax - (fx - 0.5) * s1;
    v.y = ay - (fy - 0.5) * s1;
    this._mapClamp();
    this.game.audio.click();
    if (this.mapOpen) this.drawMap();
  }

  // 내 위치가 지도 가운데에 오게 한다
  mapCenter(quiet = false) {
    const g = this.game;
    const me = g.zone || g.player.pos;
    this.mapView.x = me.x;
    this.mapView.y = me.z;
    this._mapClamp();
    if (!quiet) {
      g.audio.click();
      if (this.mapOpen) this.drawMap();
    }
  }

  // 고른 곳이 화면 밖이면 그쪽으로 지도를 옮긴다
  _mapReveal(x, z) {
    const v = this.mapView;
    const h = (W.SIZE / v.z / 2) * 0.84;
    if (Math.abs(x - v.x) > h || Math.abs(z - v.y) > h) {
      v.x = x;
      v.y = z;
      this._mapClamp();
    }
  }

  // 지도를 열면 가장 가까운(깨운) 귀환석이 골라져 있다
  _mapInitSel() {
    const g = this.game;
    const p = g.zone || g.player.pos;
    let best = null;
    let bd = Infinity;
    for (const st of g.objects.stones) {
      const d = Math.hypot(st.x - p.x, st.z - p.z) + (st.active ? 0 : 5000);
      if (d < bd) {
        bd = d;
        best = st;
      }
    }
    this.mapSel = best;
    this._mapSelInfo();
  }

  _mapSelInfo() {
    const g = this.game;
    const st = this.mapSel;
    const el = $('map-sel');
    const zq = g.zones.summary();
    let h = `<p>별조각 <b>${g.shards.size}/${SHARD_COUNT}</b> · 깨운 귀환석 <b>${g.objects.stones.filter((q) => q.active).length}/${g.objects.stones.length}</b> · 별의 인장 <b>${zq.seals}/${zq.trials}</b> · 찾아낸 던전 <b>${zq.found}/${zq.dungeons}</b></p>`;
    if (st) {
      const bi = BIOME_INFO[g.world.biomeAt(st.x, st.z)];
      h += `<h3>${esc(st.def.name)}</h3>`;
      if (st.def.id > 0) h += `<p class="lv-line">${esc(bi.name)} · 권장 <b style="color:${g.save.level >= bi.level ? '#a8ffb8' : g.save.level >= bi.level - 3 ? '#ffe27a' : '#ff9d9d'}">Lv.${bi.level}</b> (내 레벨 ${g.save.level})</p>`;
      h += st.active ? '<p>깨워 둔 귀환석입니다. 바로 이동할 수 있어요.</p>' : '<p>아직 깨우지 않은 귀환석입니다. 직접 찾아가서 깨워야 해요.</p>';
      h += `<button class="go${st.active ? '' : ' off'}" data-nonav><kbd>Enter</kbd>${st.active ? '여기로 이동' : '이동할 수 없음'}</button>`;
    }
    el.innerHTML = h;
    const go = el.querySelector('.go');
    if (go) go.addEventListener('click', () => this.mapGo());
  }

  // 누른 방향에 있는 귀환석 고르기
  mapMove(dx, dy) {
    const g = this.game;
    const cur = this.mapSel;
    if (!cur) return this._mapInitSel();
    let best = null;
    let bs = Infinity;
    for (const st of g.objects.stones) {
      if (st === cur) continue;
      const ddx = st.x - cur.x;
      const ddy = st.z - cur.z;
      const along = dx ? ddx * dx : ddy * dy;
      const across = dx ? Math.abs(ddy) : Math.abs(ddx);
      if (along < 20) continue;
      const score = along + across * 1.6;
      if (score < bs) {
        bs = score;
        best = st;
      }
    }
    if (best) {
      this.mapSel = best;
      this._mapReveal(best.x, best.z);
      g.audio.click();
      this._mapSelInfo();
      this.drawMap();
    }
  }

  mapGo() {
    const st = this.mapSel;
    if (!st) return;
    if (!st.active) {
      this.toast('아직 깨우지 않은 귀환석입니다. 직접 찾아가서 깨워야 해요.');
      return;
    }
    this.closeAll();
    this.game.fastTravel(st);
  }

  _mapClick(e) {
    const g = this.game;
    const cv = $('map');
    const r = cv.getBoundingClientRect();
    const v = this.mapView;
    const span = W.SIZE / v.z;
    const wx = v.x + ((e.clientX - r.left) / r.width - 0.5) * span;
    const wz = v.y + ((e.clientY - r.top) / r.height - 0.5) * span;
    let best = null;
    let bd = 35 * (span / 1200); // 넓게 볼수록 넉넉하게 잡아 준다
    for (const st of g.objects.stones) {
      const d = Math.hypot(st.x - wx, st.z - wz);
      if (d < bd) {
        bd = d;
        best = st;
      }
    }
    if (!best) return;
    this.mapSel = best;
    this._mapSelInfo();
    this.mapGo();
    if (this.mapOpen) this.drawMap();
  }
}

installItemsUI(UI);
